# IDMC OpenAPI 3.0 Generator - User Guide

This guide provides step-by-step instructions for using the IDMC OpenAPI 3.0 Generator to create comprehensive API specifications from your IDMC Business Entity schemas.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Basic Usage](#basic-usage)
3. [Advanced Features](#advanced-features)
4. [Examples](#examples)
5. [Best Practices](#best-practices)
6. [Troubleshooting](#troubleshooting)

## Getting Started

### Prerequisites

Before you begin, ensure you have:

- **Java 21 or later** installed on your system
- **IDMC Business Entity schema files** in JSON format
- **Basic familiarity** with OpenAPI 3.0 specifications

### Installation

1. **Download or build the application:**
   ```bash
   # Clone and build from source
   cd gen3-openapi3
   ./gradlew shadowJar
   
   # The executable JAR will be created at:
   # build/libs/gen3-openapi3.jar
   ```

2. **Verify installation:**
   ```bash
   java -jar build/libs/gen3-openapi3.jar
   ```
   You should see the usage instructions.

## Basic Usage

### Single Schema File Processing

The most common use case is generating an OpenAPI specification from a single IDMC schema file:

```bash
java -jar gen3-openapi3.jar \
  path/to/cg_organization-schema.json \
  output/cg_organization-openapi.json
```

**What happens:**
1. The application parses your IDMC schema file
2. Extracts Business Entity fields and Field Groups
3. Generates complete OpenAPI 3.0 specification with:
   - Authentication endpoints (login/logout)
   - CRUD operations for your Business Entity
   - Search functionality
   - Comprehensive error handling
4. Writes the result to your specified output file

### Batch Processing Multiple Files

For processing multiple schema files at once:

```bash
java -jar gen3-openapi3.jar \
  input-directory/ \
  output-directory/ \
  ".*-schema\\.json$"
```

**Parameters explained:**
- `input-directory/`: Directory containing your schema files
- `output-directory/`: Where generated OpenAPI specs will be saved
- `".*-schema\\.json$"`: Regular expression pattern to match files

## Advanced Features

### Parallel Processing

The application automatically processes multiple files in parallel for improved performance:

```bash
# This will process all matching files concurrently
java -jar gen3-openapi3.jar \
  ./schemas \
  ./generated \
  ".*\\.json$"
```

### Custom JVM Configuration

For large schema files or batch processing:

```bash
# Increase memory allocation
java -Xmx4g -jar gen3-openapi3.jar schema.json output.json

# Enable detailed logging
java -Dlogging.level.com.idmc.openapi=DEBUG \
  -jar gen3-openapi3.jar schema.json output.json
```

### Preview Features

The application uses Java 21 preview features for enhanced performance:

```bash
java --enable-preview -jar gen3-openapi3.jar schema.json output.json
```

## Examples

### Example 1: CG_Organization Entity

```bash
# Generate OpenAPI spec for CG_Organization
java -jar gen3-openapi3.jar \
  ../idmc-resources/cg_organization-schema.json \
  api-specs/cg_organization-openapi.json
```

**Generated endpoints include:**
- `POST /public/core/v3/login` - Authentication
- `POST /public/core/v3/logout` - Logout
- `POST /business-entity/public/api/v1/entity/cg_organization` - Create/Update
- `GET /business-entity/public/api/v1/entity/cg_organization/{businessId}` - Get by ID
- `GET /business-entity/public/api/v1/entity-xref/cg_organization/{sourceSystem}/{sourcePKey}` - Get by source
- `POST /search/public/api/v1/search` - Search entities

### Example 2: Batch Processing Multiple Entities

```bash
# Process all schema files in a directory
java -jar gen3-openapi3.jar \
  ../idmc-resources/ \
  ./generated-apis/ \
  ".*-schema\\.json$"
```

This will process files like:
- `cg_organization-schema.json` → `cg_organization-schema-openapi.json`
- `cg_person-schema.json` → `cg_person-schema-openapi.json`
- `cg_location-schema.json` → `cg_location-schema-openapi.json`

### Example 3: Custom Directory Structure

```bash
# Create organized output structure
mkdir -p api-specifications/v1/{organization,person,location}

# Generate individual specs
java -jar gen3-openapi3.jar \
  cg_organization-schema.json \
  api-specifications/v1/organization/openapi.json

java -jar gen3-openapi3.jar \
  cg_person-schema.json \
  api-specifications/v1/person/openapi.json
```

## Best Practices

### 1. File Organization

**Recommended directory structure:**
```
project/
├── schemas/               # Input IDMC schema files
│   ├── cg_organization-schema.json
│   ├── cg_person-schema.json
│   └── cg_location-schema.json
├── generated/             # Generated OpenAPI specs
│   ├── cg_organization-openapi.json
│   ├── cg_person-openapi.json
│   └── cg_location-openapi.json
└── scripts/               # Automation scripts
    └── generate-all.sh
```

### 2. Automation Script

Create a script for regular regeneration:

```bash
#!/bin/bash
# generate-all.sh

GENERATOR_JAR="path/to/gen3-openapi3.jar"
SCHEMA_DIR="./schemas"
OUTPUT_DIR="./generated"

echo "Generating OpenAPI specifications..."

java -jar "$GENERATOR_JAR" "$SCHEMA_DIR" "$OUTPUT_DIR" ".*-schema\\.json$"

echo "Generation complete. Files created in $OUTPUT_DIR"
```

### 3. Version Control

**Include in version control:**
- Input schema files
- Generated OpenAPI specifications
- Build scripts

**Exclude from version control:**
- JAR files (if using pre-built binary)
- Temporary files
- Log files

### 4. Validation

After generation, validate your OpenAPI specs:

```bash
# Using Swagger CLI (if installed)
swagger-codegen validate -i generated/cg_organization-openapi.json

# Using online validator
# Upload to https://editor.swagger.io/
```

## Troubleshooting

### Common Issues and Solutions

#### Issue: "Preview features are not enabled"
```
Error: Preview features are not enabled for javac 21.0.1
```

**Solution:**
```bash
java --enable-preview -jar gen3-openapi3.jar schema.json output.json
```

#### Issue: Out of Memory Error
```
Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
```

**Solution:**
```bash
java -Xmx4g -jar gen3-openapi3.jar large-schema.json output.json
```

#### Issue: Schema File Not Found
```
IllegalArgumentException: Schema file not found: /path/to/schema.json
```

**Solutions:**
1. Check file path is correct and absolute
2. Verify file exists and is readable
3. Ensure proper file permissions

#### Issue: Invalid JSON Schema
```
Failed to parse schema file: Unexpected character
```

**Solutions:**
1. Validate JSON format using online validator
2. Check for trailing commas or syntax errors
3. Ensure proper UTF-8 encoding

#### Issue: No Files Processed in Batch Mode
```
No schema files found matching pattern: .*\.json
```

**Solutions:**
1. Check the regular expression pattern
2. Verify files exist in the input directory
3. Use proper escaping: `".*\\.json$"`

### Debug Mode

Enable detailed logging for troubleshooting:

```bash
java -Dlogging.level.com.idmc.openapi=DEBUG \
  -jar gen3-openapi3.jar schema.json output.json
```

### Performance Tuning

For large-scale processing:

```bash
# Optimize JVM settings
java -Xms2g -Xmx8g \
  -XX:+UseG1GC \
  -XX:MaxGCPauseMillis=200 \
  -jar gen3-openapi3.jar
```

## Getting Help

### Command Line Help

```bash
# Display usage information
java -jar gen3-openapi3.jar

# Display version information
java -jar gen3-openapi3.jar --version
```

### Log Files

Check log output for detailed error information:

```bash
# Redirect output to file for analysis
java -jar gen3-openapi3.jar schema.json output.json 2>&1 | tee generation.log
```

### Support Resources

- **Documentation**: Check the README.md file
- **Examples**: See the `examples/` directory
- **Source Code**: Review the Java source for implementation details

---

This user guide covers the essential aspects of using the IDMC OpenAPI 3.0 Generator. For additional questions or advanced use cases, refer to the source code documentation or create an issue in the project repository.
package com.idmc.openapi.model;

public record Server(String url, String description) {}
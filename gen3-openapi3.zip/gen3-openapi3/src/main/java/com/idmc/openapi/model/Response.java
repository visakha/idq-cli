package com.idmc.openapi.model;

import java.util.Map;

public record Response(String description, Map<String, MediaType> content) {}
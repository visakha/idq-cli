package com.idmc.openapi.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record Schema(String type, String format, String description, String example, Integer maxLength,
             List<String> required, Map<String, Schema> properties, Schema items, 
             Boolean additionalProperties, List<String> enumValues) {
    
    public static Schema stringSchema(String description, String example, Integer maxLength) {
        return new Schema("string", null, description, example, maxLength, null, null, null, null, null);
    }
    
    public static Schema integerSchema(String description) {
        return new Schema("integer", null, description, null, null, null, null, null, null, null);
    }
    
    public static Schema booleanSchema(String description) {
        return new Schema("boolean", null, description, null, null, null, null, null, null, null);
    }
    
    public static Schema arraySchema(Schema items) {
        return new Schema("array", null, null, null, null, null, null, items, null, null);
    }
    
    public static Schema objectSchema(Map<String, Schema> properties, List<String> required) {
        return new Schema("object", null, null, null, null, required, properties, null, null, null);
    }
    
    public static Schema objectSchemaWithAdditionalProperties() {
        return new Schema("object", null, null, null, null, null, null, null, true, null);
    }
    
    @JsonProperty("enum")
    public List<String> enumValues() { return enumValues; }
}
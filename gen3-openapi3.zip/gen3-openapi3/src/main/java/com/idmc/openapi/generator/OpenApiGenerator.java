package com.idmc.openapi.generator;

import com.idmc.openapi.model.*;
import com.idmc.openapi.schema.IdmcSchemaParser.ParsedSchema;

import java.util.*;
import java.util.stream.Stream;

/**
 * Generator for OpenAPI 3.0 specifications from IDMC schemas
 */
public class OpenApiGenerator {
    
    private final EndpointGenerator endpointGenerator;
    
    public OpenApiGenerator() {
        this.endpointGenerator = new EndpointGenerator();
    }
    
    /**
     * Generate complete OpenAPI specification with inlined schemas
     */
    public OpenApiSpec generateSpec(ParsedSchema parsedSchema) {
        var baseSpec = OpenApiSpec.createDefault();
        var entityName = parsedSchema.entityName().toLowerCase();
        
        return new OpenApiSpec(
            baseSpec.openapi(),
            baseSpec.info(),
            baseSpec.servers(),
            baseSpec.security(),
            generatePaths(parsedSchema),
            baseSpec.components(),
            baseSpec.tags()
        );
    }
    
    /**
     * Generate all API paths with inlined schemas
     */
    private Map<String, PathItem> generatePaths(ParsedSchema parsedSchema) {
        var paths = new LinkedHashMap<String, PathItem>();
        paths.put("/public/core/v3/login", endpointGenerator.createLoginPath());
        paths.put("/public/core/v3/logout", endpointGenerator.createLogoutPath());
        paths.put("/business-entity/public/api/v1/entity/" + parsedSchema.entityName().toLowerCase(), 
            endpointGenerator.createEntityCreatePath(parsedSchema));
        paths.put("/business-entity/public/api/v1/entity/" + parsedSchema.entityName().toLowerCase() + "/{businessId}", 
            endpointGenerator.createEntityGetByIdPath(parsedSchema));
        paths.put("/business-entity/public/api/v1/entity-xref/" + parsedSchema.entityName().toLowerCase() + "/{sourceSystem}/{sourcePKey}",
            endpointGenerator.createEntityGetBySourcePath(parsedSchema));
        paths.put("/search/public/api/v1/search", endpointGenerator.createSearchPath(parsedSchema));
        return paths;
    }
    
    /**
     * Helper class for generating endpoint definitions
     */
    private static class EndpointGenerator {
        
        /**
         * Create login endpoint
         */
        PathItem createLoginPath() {
            return new PathItem(
                null,
                new Operation(
                    List.of("Authentication"),
                    "Login to IDMC Platform",
                    "Authenticate with IDMC and obtain session ID and base API URL",
                    "loginToIDMC",
                    null,
                    new RequestBody(true, Map.of("application/json", new MediaType(createLoginRequestSchema()))),
                    Map.of(
                        "200", new Response("Successful authentication", 
                            Map.of("application/json", new MediaType(createLoginResponseSchema()))),
                        "401", new Response("Authentication failed", 
                            Map.of("application/json", new MediaType(createErrorSchema())))
                    ),
                    List.of()
                ),
                null, null, null, null
            );
        }
        
        /**
         * Create logout endpoint
         */
        PathItem createLogoutPath() {
            return new PathItem(
                null,
                new Operation(
                    List.of("Authentication"),
                    "Logout from IDMC Platform",
                    "End the current IDMC session",
                    "logoutFromIDMC",
                    null,
                    null,
                    Map.of(
                        "200", new Response("Successfully logged out", null),
                        "401", new Response("Invalid session", 
                            Map.of("application/json", new MediaType(createErrorSchema())))
                    ),
                    null
                ),
                null, null, null, null
            );
        }
        
        /**
         * Create entity creation endpoint
         */
        PathItem createEntityCreatePath(ParsedSchema parsedSchema) {
            return new PathItem(
                null,
                new Operation(
                    List.of("CG_Organization"),
                    "Create or Update " + parsedSchema.entityName() + " by Source Name and Source Key",
                    "Create a new " + parsedSchema.entityName() + " business entity or update existing one",
                    "createOrUpdate" + parsedSchema.entityName(),
                    List.of(
                        new Parameter("sourceSystem", "query", true, "Source system identifier", 
                            Schema.stringSchema("Source system", "c360.default.system", null)),
                        new Parameter("sourcePKey", "query", true, "Source primary key", 
                            Schema.stringSchema("Source key", "944", null))
                    ),
                    new RequestBody(true, Map.of("application/json", new MediaType(parsedSchema.entitySchema()))),
                    Map.of(
                        "200", new Response("Entity created/updated successfully", 
                            Map.of("application/json", new MediaType(createCreateUpdateResponseSchema()))),
                        "400", new Response("Bad request", 
                            Map.of("application/json", new MediaType(createErrorSchema()))),
                        "401", new Response("Unauthorized", 
                            Map.of("application/json", new MediaType(createErrorSchema())))
                    ),
                    null
                ),
                null, null, null, null
            );
        }
        
        /**
         * Create entity get by ID endpoint
         */
        PathItem createEntityGetByIdPath(ParsedSchema parsedSchema) {
            var responseSchema = createEntityResponseSchema(parsedSchema);
            
            return new PathItem(
                new Operation(
                    List.of("CG_Organization"),
                    "Get " + parsedSchema.entityName() + " by Business ID",
                    "Retrieve a specific " + parsedSchema.entityName() + " business entity by its business ID",
                    "get" + parsedSchema.entityName() + "ById",
                    List.of(
                        new Parameter("businessId", "path", true, "The business ID", 
                            Schema.stringSchema("Business ID", "MDM0000000256T", null))
                    ),
                    null,
                    Map.of(
                        "200", new Response("Entity retrieved successfully", 
                            Map.of("application/json", new MediaType(responseSchema))),
                        "404", new Response("Entity not found", 
                            Map.of("application/json", new MediaType(createErrorSchema()))),
                        "401", new Response("Unauthorized", 
                            Map.of("application/json", new MediaType(createErrorSchema())))
                    ),
                    null
                ),
                null, null, null, null, null
            );
        }
        
        /**
         * Create entity get by source endpoint
         */
        PathItem createEntityGetBySourcePath(ParsedSchema parsedSchema) {
            var responseSchema = createEntityResponseSchema(parsedSchema);
            
            return new PathItem(
                new Operation(
                    List.of("CG_Organization"),
                    "Get " + parsedSchema.entityName() + " by Source Name and Source Key",
                    "Retrieve a " + parsedSchema.entityName() + " business entity by its source system and key",
                    "get" + parsedSchema.entityName() + "BySource",
                    List.of(
                        new Parameter("sourceSystem", "path", true, "Source system identifier", 
                            Schema.stringSchema("Source system", "c360.default.system", null)),
                        new Parameter("sourcePKey", "path", true, "Source primary key", 
                            Schema.stringSchema("Source key", "944", null))
                    ),
                    null,
                    Map.of(
                        "200", new Response("Entity retrieved successfully", 
                            Map.of("application/json", new MediaType(responseSchema))),
                        "404", new Response("Entity not found", 
                            Map.of("application/json", new MediaType(createErrorSchema()))),
                        "401", new Response("Unauthorized", 
                            Map.of("application/json", new MediaType(createErrorSchema())))
                    ),
                    null
                ),
                null, null, null, null, null
            );
        }
        
        /**
         * Create search endpoint
         */
        PathItem createSearchPath(ParsedSchema parsedSchema) {
            return new PathItem(
                null,
                new Operation(
                    List.of("Search"),
                    "Search " + parsedSchema.entityName() + " Business Entities",
                    "Search for " + parsedSchema.entityName() + " business entities with various criteria",
                    "search" + parsedSchema.entityName() + "s",
                    List.of(
                        new Parameter("_showContentMeta", "query", false, "Include metadata in response", 
                            Schema.booleanSchema("Show metadata"))
                    ),
                    new RequestBody(true, Map.of("application/json", new MediaType(createSearchRequestSchema()))),
                    Map.of(
                        "200", new Response("Search results returned successfully", 
                            Map.of("application/json", new MediaType(createSearchResponseSchema(parsedSchema)))),
                        "400", new Response("Bad request", 
                            Map.of("application/json", new MediaType(createErrorSchema()))),
                        "401", new Response("Unauthorized", 
                            Map.of("application/json", new MediaType(createErrorSchema())))
                    ),
                    null
                ),
                null, null, null, null
            );
        }
        
        /**
         * Create entity response schema with metadata
         */
        private Schema createEntityResponseSchema(ParsedSchema parsedSchema) {
            var properties = new LinkedHashMap<>(parsedSchema.entitySchema().properties());
            properties.put("_meta", createMetadataSchema());
            
            return Schema.objectSchema(properties, List.of());
        }
        
        /**
         * Create search response schema
         */
        private Schema createSearchResponseSchema(ParsedSchema parsedSchema) {
            var recordSchema = createEntityResponseSchema(parsedSchema);
            
            return Schema.objectSchema(Map.of(
                "totalRecords", Schema.integerSchema("Total number of records found"),
                "records", Schema.arraySchema(recordSchema),
                "facets", Schema.objectSchemaWithAdditionalProperties()
            ), List.of());
        }
        
        /**
         * Helper methods for common schemas
         */
        private Schema createLoginRequestSchema() {
            return Schema.objectSchema(Map.of(
                "username", Schema.stringSchema("IDMC username", "org01_vamsi.vegi", null),
                "password", Schema.stringSchema("IDMC password", "ch3kM8_90", null)
            ), List.of("username", "password"));
        }
        
        private Schema createLoginResponseSchema() {
            var userInfoSchema = Schema.objectSchema(Map.of(
                "sessionId", Schema.stringSchema("Session ID for subsequent API calls", "8He6mIRe3uQhssta52RJaa", null),
                "id", Schema.stringSchema("User ID", "8SCR3Du2yrGfvtL8cWB1EV", null),
                "name", Schema.stringSchema("Username", "org01_vamsi.vegi", null),
                "parentOrgId", Schema.stringSchema("Parent organization ID", "57FmrfVx1QBgMBc9Q1pjO6", null),
                "orgId", Schema.stringSchema("Organization ID", "0K89zwdwLDDcaGEzCs73a1", null),
                "orgName", Schema.stringSchema("Organization name", "GssOrg01_0K-a1", null),
                "groups", Schema.objectSchemaWithAdditionalProperties(),
                "status", Schema.stringSchema("User status", "Active", null)
            ), List.of());
            
            var productSchema = Schema.objectSchema(Map.of(
                "name", Schema.stringSchema("Product name", "Integration Cloud", null),
                "baseApiUrl", Schema.stringSchema("Base API URL", "https://usw1.dmp-us.informaticacloud.com/saas", null)
            ), List.of());
            
            return Schema.objectSchema(Map.of(
                "products", Schema.arraySchema(productSchema),
                "userInfo", userInfoSchema
            ), List.of());
        }
        
        private Schema createCreateUpdateResponseSchema() {
            return Schema.objectSchema(Map.of(
                "approvalRequired", Schema.booleanSchema("Indicates if approval is required"),
                "id", Schema.stringSchema("Document ID", "MDM000000037QO", null),
                "businessId", Schema.stringSchema("Business ID", "MDM000000037QO", null)
            ), List.of());
        }
        
        private Schema createSearchRequestSchema() {
            return Schema.objectSchema(Map.of(
                "entityType", Schema.stringSchema("The business entity type to search", "cg_organization", null),
                "search", Schema.stringSchema("Search criteria", "*", null),
                "maxRecords", Schema.stringSchema("Maximum number of records", "100", null),
                "filter", Schema.objectSchemaWithAdditionalProperties()
            ), List.of("entityType"));
        }
        
        private Schema createMetadataSchema() {
            var properties = new LinkedHashMap<String, Schema>();
            properties.put("id", Schema.stringSchema("Document ID", "MDM0000000256T", null));
            properties.put("businessEntity", Schema.stringSchema("Business Entity Type", "cg_organization", null));
            properties.put("businessId", Schema.stringSchema("Business ID", "MDM0000000256T", null));
            properties.put("state", Schema.stringSchema("Entity State", "ACTIVE", null));
            properties.put("validation", Schema.stringSchema("Validation Status", "PASSED", null));
            properties.put("consolidation", Schema.stringSchema("Consolidation Status", "MATCH_INDEXED", null));
            properties.put("searchIndex", Schema.stringSchema("Search Index Status", "SEARCH_INDEXED", null));
            properties.put("createdBy", Schema.stringSchema("Created By User", "org01_anup.shukla", null));
            properties.put("creationDate", new Schema("integer", "int64", "Creation Date (timestamp)", "1753817576827", null, null, null, null, null, null));
            properties.put("updatedBy", Schema.stringSchema("Updated By User", "org01_anup.shukla", null));
            properties.put("lastUpdateDate", new Schema("integer", "int64", "Last Update Date (timestamp)", "1753969243862", null, null, null, null, null, null));
            
            return Schema.objectSchema(properties, List.of());
        }
        
        private Schema createErrorSchema() {
            return Schema.objectSchema(Map.of(
                "error", Schema.stringSchema("Error message", null, null),
                "errorCode", Schema.stringSchema("Error code", null, null),
                "details", Schema.stringSchema("Error details", null, null)
            ), List.of());
        }
    }
}
package com.idmc.openapi.model;

import java.util.List;
import java.util.Map;

public record Operation(List<String> tags, String summary, String description, String operationId, 
                List<Parameter> parameters, RequestBody requestBody, Map<String, Response> responses, 
                List<Map<String, List<String>>> security) {}
package com.idmc.openapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

public record OpenApiSpec(
    String openapi,
    Info info,
    List<Server> servers,
    List<Map<String, List<String>>> security,
    Map<String, PathItem> paths,
    Components components,
    List<Tag> tags
) {
    
    public static OpenApiSpec createDefault() {
        return new OpenApiSpec(
            "3.0.3",
            new Info("IDMC CG_Organization Business Entity API", 
                    "OpenAPI specification for Informatica Data Management Cloud (IDMC) CG_Organization Business Entity operations including authentication, CRUD operations, and search functionality. All schemas are inlined without references.", 
                    "1.0.0", 
                    new Contact("IDMC API Support")),
            List.of(
                new Server("https://dmp-us.informaticacloud.com/saas", "IDMC Login Server"),
                new Server("https://usw1.dmp-us.informaticacloud.com/saas", "IDMC Base API Server (obtained after login)"),
                new Server("https://usw1-mdm.dmp-us.informaticacloud.com", "IDMC MDM Server for Business Entity operations")
            ),
            List.of(Map.of("SessionAuth", List.of())),
            new LinkedHashMap<>(),
            new Components(Map.of("SessionAuth", 
                new SecurityScheme("apiKey", "header", "IDS-SESSION-ID", "Session ID obtained from login endpoint. Session expires after 30 minutes of inactivity."))),
            List.of(
                new Tag("Authentication", "IDMC authentication operations"),
                new Tag("CG_Organization", "CG_Organization business entity operations"),
                new Tag("Search", "Search operations for business entities")
            )
        );
    }
}


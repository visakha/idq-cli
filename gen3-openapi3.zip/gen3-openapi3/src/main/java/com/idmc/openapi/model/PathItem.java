package com.idmc.openapi.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record PathItem(Operation get, Operation post, Operation put, Operation delete, Operation patch, List<Parameter> parameters) {}
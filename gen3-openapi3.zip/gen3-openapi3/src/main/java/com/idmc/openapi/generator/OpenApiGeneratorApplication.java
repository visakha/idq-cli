package com.idmc.openapi.generator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.idmc.openapi.schema.IdmcSchemaParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;

/**
 * Main application for generating OpenAPI 3.0 specifications from IDMC schemas
 */
public class OpenApiGeneratorApplication {
    
    private static final Logger logger = LoggerFactory.getLogger(OpenApiGeneratorApplication.class);
    
    private final IdmcSchemaParser schemaParser;
    private final OpenApiGenerator openApiGenerator;
    private final ObjectMapper objectMapper;
    
    public OpenApiGeneratorApplication() {
        this.schemaParser = new IdmcSchemaParser();
        this.openApiGenerator = new OpenApiGenerator();
        this.objectMapper = createObjectMapper();
    }
    
    /**
     * Main entry point
     */
    public static void main(String[] args) {
        var app = new OpenApiGeneratorApplication();
        
        try {
            switch (args.length) {
                case 0 -> app.showUsage();
                case 2 -> app.generateFromSchema(args[0], args[1]);
                case 3 -> app.generateBatch(args[0], args[1], args[2]);
                default -> {
                    logger.error("Invalid number of arguments: {}", args.length);
                    app.showUsage();
                    System.exit(1);
                }
            }
        } catch (Exception e) {
            logger.error("Error generating OpenAPI specification", e);
            System.exit(1);
        }
    }
    
    /**
     * Generate OpenAPI spec from single schema file
     */
    public void generateFromSchema(String schemaFilePath, String outputFilePath) throws Exception {
        logger.info("Generating OpenAPI specification from schema: {}", schemaFilePath);
        
        var schemaPath = Paths.get(schemaFilePath);
        var outputPath = Paths.get(outputFilePath);
        
        validateInputFile(schemaPath);
        ensureOutputDirectory(outputPath);
        
        var parsedSchema = schemaParser.parseSchema(schemaPath);
        var openApiSpec = openApiGenerator.generateSpec(parsedSchema);
        
        writeSpecToFile(openApiSpec, outputPath);
        
        logger.info("OpenAPI specification generated successfully: {}", outputPath);
        logger.info("Entity: {}, Fields: {}, Field Groups: {}", 
            parsedSchema.entityName(),
            parsedSchema.entitySchema().properties().size(),
            parsedSchema.fieldGroups().size()
        );
    }
    
    /**
     * Generate OpenAPI specs from multiple schema files in a directory
     */
    public void generateBatch(String inputDir, String outputDir, String pattern) throws Exception {
        logger.info("Batch generating OpenAPI specifications from: {}", inputDir);
        
        var inputPath = Paths.get(inputDir);
        var outputPath = Paths.get(outputDir);
        
        if (!Files.isDirectory(inputPath)) {
            throw new IllegalArgumentException("Input path is not a directory: " + inputPath);
        }
        
        Files.createDirectories(outputPath);
        
        var schemaFiles = Files.list(inputPath)
            .filter(path -> path.toString().matches(pattern))
            .toList();
        
        if (schemaFiles.isEmpty()) {
            logger.warn("No schema files found matching pattern: {}", pattern);
            return;
        }
        
        // Process files in parallel
        var futures = schemaFiles.stream()
            .map(schemaFile -> CompletableFuture.runAsync(() -> {
                try {
                    var fileName = schemaFile.getFileName().toString();
                    var outputFileName = fileName.replaceAll("\\.(json|JSON)$", "-openapi.json");
                    var outputFile = outputPath.resolve(outputFileName);
                    
                    generateFromSchema(schemaFile.toString(), outputFile.toString());
                } catch (Exception e) {
                    logger.error("Failed to process schema file: {}", schemaFile, e);
                }
            }))
            .toArray(CompletableFuture[]::new);
        
        CompletableFuture.allOf(futures).join();
        
        logger.info("Batch generation completed. Processed {} files", schemaFiles.size());
    }
    
    /**
     * Validate command line arguments and show usage
     */
    private void showUsage() {
        System.out.println("""
            
            IDMC OpenAPI 3.0 Generator
            ===========================
            
            Usage:
              java -jar openapi-generator.jar <schema-file> <output-file>
              java -jar openapi-generator.jar <input-dir> <output-dir> <pattern>
            
            Examples:
              # Generate from single schema file
              java -jar openapi-generator.jar cg_organization-schema.json cg_organization-openapi.json
              
              # Batch generate from directory
              java -jar openapi-generator.jar ./schemas ./output ".*\\.json"
              
            Features:
              ✓ Generates OpenAPI 3.0 compliant specifications
              ✓ Fully inlined schemas (no references)
              ✓ Complete CRUD operations for IDMC Business Entities
              ✓ Authentication endpoints (login/logout)
              ✓ Search functionality
              ✓ Parallel batch processing
              ✓ Comprehensive error handling
            
            """);
    }
    
    /**
     * Configure Jackson ObjectMapper for clean JSON output
     */
    private ObjectMapper createObjectMapper() {
        return new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT)
            .disable(SerializationFeature.WRITE_NULL_MAP_VALUES)
            .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
            .setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }
    
    /**
     * Write OpenAPI specification to file
     */
    private void writeSpecToFile(Object spec, Path outputPath) throws Exception {
        var parent = outputPath.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        objectMapper.writeValue(outputPath.toFile(), spec);
    }
    
    /**
     * Validate input file exists and is readable
     */
    private void validateInputFile(Path filePath) {
        if (!Files.exists(filePath)) {
            throw new IllegalArgumentException("Schema file not found: " + filePath);
        }
        
        if (!Files.isReadable(filePath)) {
            throw new IllegalArgumentException("Schema file is not readable: " + filePath);
        }
        
        if (!filePath.toString().toLowerCase().endsWith(".json")) {
            logger.warn("Input file does not have .json extension: {}", filePath);
        }
    }
    
    /**
     * Ensure output directory exists
     */
    private void ensureOutputDirectory(Path outputPath) throws Exception {
        var parentDir = outputPath.getParent();
        if (parentDir != null) {
            Files.createDirectories(parentDir);
        }
    }
}
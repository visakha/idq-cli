package com.idmc.openapi.model;

import java.util.Map;

public record Components(Map<String, SecurityScheme> securitySchemes) {}
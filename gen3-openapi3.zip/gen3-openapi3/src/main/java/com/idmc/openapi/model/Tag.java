package com.idmc.openapi.model;

public record Tag(String name, String description) {}
package com.idmc.openapi.schema;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.idmc.openapi.model.Schema;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.StreamSupport;

/**
 * Parser for IDMC Business Entity schema JSON files
 */
public class IdmcSchemaParser {
    
    private final ObjectMapper objectMapper;
    
    public IdmcSchemaParser() {
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Parse IDMC schema file and convert to OpenAPI schemas
     */
    public ParsedSchema parseSchema(Path schemaFile) throws IOException {
        var rootNode = objectMapper.readTree(schemaFile.toFile());
        var entityName = rootNode.path("name").asText();
        var fields = rootNode.path("field");
        
        return new ParsedSchema(
            entityName,
            createEntitySchema(fields),
            extractFieldGroups(fields)
        );
    }
    
    /**
     * Create the main entity schema with all fields and field groups inlined
     */
    private Schema createEntitySchema(JsonNode fields) {
        var properties = new LinkedHashMap<String, Schema>();
        
        StreamSupport.stream(fields.spliterator(), false)
            .forEach(field -> processField(field, properties));
        
        return Schema.objectSchema(properties, List.of());
    }
    
    /**
     * Process individual field or field group
     */
    private void processField(JsonNode field, Map<String, Schema> properties) {
        var fieldName = field.path("name").asText();
        var fieldType = field.path("eClass").asText();
        
        switch (extractFieldType(fieldType)) {
            case TEXT -> properties.put(fieldName, createTextFieldSchema(field));
            case INTEGER -> properties.put(fieldName, createIntegerFieldSchema(field));
            case DATE -> properties.put(fieldName, createDateFieldSchema(field));
            case FIELD_GROUP -> properties.put(fieldName, createFieldGroupSchema(field));
        }
    }
    
    /**
     * Extract field type from eClass
     */
    private FieldType extractFieldType(String eClass) {
        return switch (eClass) {
            case String s when s.contains("TextField") -> FieldType.TEXT;
            case String s when s.contains("IntegerField") -> FieldType.INTEGER;
            case String s when s.contains("DateField") -> FieldType.DATE;
            case String s when s.contains("FieldGroup") -> FieldType.FIELD_GROUP;
            default -> FieldType.TEXT;
        };
    }
    
    /**
     * Create schema for text field
     */
    private Schema createTextFieldSchema(JsonNode field) {
        var description = extractLabel(field);
        var maxLength = field.path("length").asInt(255);
        var example = generateExample(field.path("name").asText());
        
        return Schema.stringSchema(description, example, maxLength);
    }
    
    /**
     * Create schema for integer field
     */
    private Schema createIntegerFieldSchema(JsonNode field) {
        var description = extractLabel(field);
        return Schema.integerSchema(description);
    }
    
    /**
     * Create schema for date field
     */
    private Schema createDateFieldSchema(JsonNode field) {
        var description = extractLabel(field);
        return new Schema("string", "date", description, null, null, null, null, null, null, null);
    }
    
    /**
     * Create schema for field group (array of objects)
     */
    private Schema createFieldGroupSchema(JsonNode fieldGroup) {
        var allowMany = fieldGroup.path("allowMany").asBoolean(false);
        var itemSchema = createFieldGroupItemSchema(fieldGroup);
        
        return allowMany ? Schema.arraySchema(itemSchema) : itemSchema;
    }
    
    /**
     * Create schema for field group item
     */
    private Schema createFieldGroupItemSchema(JsonNode fieldGroup) {
        var properties = new LinkedHashMap<String, Schema>();
        
        // Add internal ID field
        properties.put("_id", Schema.stringSchema("Internal ID", null, null));
        
        // Process nested fields
        var nestedFields = fieldGroup.path("field");
        StreamSupport.stream(nestedFields.spliterator(), false)
            .forEach(field -> processField(field, properties));
        
        return Schema.objectSchema(properties, List.of());
    }
    
    /**
     * Extract field groups for separate processing
     */
    private Map<String, Schema> extractFieldGroups(JsonNode fields) {
        return StreamSupport.stream(fields.spliterator(), false)
            .filter(field -> extractFieldType(field.path("eClass").asText()) == FieldType.FIELD_GROUP)
            .collect(LinkedHashMap::new,
                (map, field) -> map.put(field.path("name").asText(), createFieldGroupItemSchema(field)),
                LinkedHashMap::putAll);
    }
    
    /**
     * Extract human-readable label from field
     */
    private String extractLabel(JsonNode field) {
        return Optional.ofNullable(field.path("label").path("en").asText(null))
            .orElse(field.path("name").asText());
    }
    
    /**
     * Generate example values based on field name
     */
    private String generateExample(String fieldName) {
        return switch (fieldName.toLowerCase()) {
            case String s when s.contains("name") -> "Example Name";
            case String s when s.contains("phone") -> "+1234567890";
            case String s when s.contains("email") -> "example@domain.com";
            case String s when s.contains("address") -> "123 Main St";
            case String s when s.contains("city") -> "Example City";
            case String s when s.contains("country") -> "US";
            case String s when s.contains("postal") || s.contains("zip") -> "12345";
            case String s when s.contains("tax") -> "TAX123456";
            default -> null;
        };
    }
    
    /**
     * Field type enumeration
     */
    private enum FieldType {
        TEXT, INTEGER, DATE, FIELD_GROUP
    }
    
    /**
     * Result of schema parsing
     */
    public record ParsedSchema(
        String entityName,
        Schema entitySchema,
        Map<String, Schema> fieldGroups
    ) {}
}
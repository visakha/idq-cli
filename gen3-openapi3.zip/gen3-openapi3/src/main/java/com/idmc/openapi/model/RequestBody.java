package com.idmc.openapi.model;

import java.util.Map;

public record RequestBody(boolean required, Map<String, MediaType> content) {}
package com.idmc.openapi.model;

public record Contact(String name) {}
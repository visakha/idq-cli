package com.idmc.openapi.model;

public record Info(String title, String description, String version, Contact contact) {}
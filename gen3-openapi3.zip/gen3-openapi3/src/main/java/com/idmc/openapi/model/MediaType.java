package com.idmc.openapi.model;

public record MediaType(Schema schema) {}
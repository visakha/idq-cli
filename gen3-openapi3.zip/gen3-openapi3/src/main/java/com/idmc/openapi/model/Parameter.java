package com.idmc.openapi.model;

public record Parameter(String name, String in, boolean required, String description, Schema schema) {}
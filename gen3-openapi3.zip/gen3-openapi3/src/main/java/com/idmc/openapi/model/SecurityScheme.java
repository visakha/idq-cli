package com.idmc.openapi.model;

public record SecurityScheme(String type, String in, String name, String description) {}
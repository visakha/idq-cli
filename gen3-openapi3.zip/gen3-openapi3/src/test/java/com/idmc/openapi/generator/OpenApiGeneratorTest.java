package com.idmc.openapi.generator;

import com.idmc.openapi.model.Schema;
import com.idmc.openapi.schema.IdmcSchemaParser.ParsedSchema;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test cases for OpenAPI generator
 */
class OpenApiGeneratorTest {
    
    private OpenApiGenerator generator;
    
    @BeforeEach
    void setUp() {
        generator = new OpenApiGenerator();
    }
    
    @Test
    void shouldGenerateCompleteOpenApiSpec() {
        // Given
        var entitySchema = Schema.objectSchema(Map.of(
            "name", Schema.stringSchema("Organization name", "Test Org", 255),
            "legal_name", Schema.stringSchema("Legal name", "Test Legal", 255)
        ), List.of());
        
        var fieldGroups = Map.of(
            "address", Schema.objectSchema(Map.of(
                "street", Schema.stringSchema("Street", "Main St", 255)
            ), List.of())
        );
        
        var parsedSchema = new ParsedSchema("CG_Organization", entitySchema, fieldGroups);
        
        // When
        var spec = generator.generateSpec(parsedSchema);
        
        // Then
        assertThat(spec.openapi()).isEqualTo("3.0.3");
        assertThat(spec.info().title()).contains("IDMC CG_Organization");
        assertThat(spec.servers()).hasSize(3);
        assertThat(spec.paths()).hasSize(6);
        assertThat(spec.tags()).hasSize(3);
        
        // Verify authentication endpoints
        assertThat(spec.paths()).containsKey("/public/core/v3/login");
        assertThat(spec.paths()).containsKey("/public/core/v3/logout");
        
        // Verify entity endpoints
        assertThat(spec.paths()).containsKey("/business-entity/public/api/v1/entity/cg_organization");
        assertThat(spec.paths()).containsKey("/business-entity/public/api/v1/entity/cg_organization/{businessId}");
        
        // Verify search endpoint
        assertThat(spec.paths()).containsKey("/search/public/api/v1/search");
    }
    
    @Test
    void shouldGenerateInlinedSchemasWithoutReferences() {
        // Given
        var entitySchema = Schema.objectSchema(Map.of(
            "contact_mechanism", Schema.arraySchema(Schema.objectSchema(Map.of(
                "type", Schema.stringSchema("Contact type", "PHONE", 50),
                "value", Schema.stringSchema("Contact value", "+1234567890", 255)
            ), List.of()))
        ), List.of());
        
        var parsedSchema = new ParsedSchema("TestEntity", entitySchema, Map.of());
        
        // When
        var spec = generator.generateSpec(parsedSchema);
        
        // Then
        var createPath = spec.paths().get("/business-entity/public/api/v1/entity/testentity");
        var requestSchema = createPath.post().requestBody().content().get("application/json").schema();
        
        assertThat(requestSchema.type()).isEqualTo("object");
        assertThat(requestSchema.properties()).containsKey("contact_mechanism");
        
        var contactMechanismSchema = requestSchema.properties().get("contact_mechanism");
        assertThat(contactMechanismSchema.type()).isEqualTo("array");
        assertThat(contactMechanismSchema.items().type()).isEqualTo("object");
        assertThat(contactMechanismSchema.items().properties()).containsKeys("type", "value");
    }
}
package com.idmc.openapi;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class SimpleTest {
    
    @Test
    void shouldWork() {
        assertThat(true).isTrue();
    }
}
IDMC is a cloud based SaaS platform by Informatica. It is used move data around (ETL), build web services, Data Governance and Master the client data like Organization, Person, Office, Group, Roles and Relationships between them. It can also be used to master other domains like Investments, 401K plans, Locations etc.

The data for any of the above domains is organized around 'Business Entity', the definition of which is below.

the below are synonyms
BE: Business Entity, Entity, Root level
FG: Field Group, Child, Child level
Field: an atomic attribute at the BE level,  a BE can have many Fields



Terminology:
 - entityType, in the IDMC parlance, is a logical representation of INSTANCE data - usually related to Organization, Person, Office, Role and Relationships
	- This entityType is of Type 'Business Entity' (also called BE or Entity).
	- The 'Business Entity' has the below logical stucture
		- set of Fields
		- set of Field Groups
		
		- More about the Fields: a Field is the most atomic representation of data, for example 'Date of Birth', or 'Legal Name' or 'Status Indicator' etc
		- More about the Field Groups: a Field Group is the logical grouping of Fields, for example: Address. In this case Address is a container around the address related fields like 'Street Number', 'Street Name', 'City', 'County', 'state','postal code' etc
		 - another example is 'Phone', where the logical grouping is 'Phone number', 'Phone extention', 'Phone country code', 'Phone usage type' etc
		 
		- Note: Field Group can be nested
		- Note: Field and Field Groups cannot contain data that points to another fields and or Field Groups
		 
		- in summary: 'Business Entity' (or BE) is a logical container of Fields and Field Groups. and Field Group are logical container of related Field and other Field Groups
					
 - Entity Schema: this is a JSON file that defines the share and structure of an INSTANCE Business Entity, for example there are sperate 'Entity Schema' JSONs files for each of Organization, Office, Person etc
		 - the 'Entity Schema' defined the meta data for an INSTANCE Business Entity
		 - How to use this 'Entity Schema'?
			- you can use this 'Entity Schema' to genrate the POJOs (Java classes) that can represent the INSTANCE Business Entity
			- these generated POJOs can be used for deserilization and serialization in the Jackson or GSON for HTTP
			- these generated POJOs can be used for deserilization and serialization in the Kafka
			- these generated POJOs can be used for deserilization and serialization in the JPA after marked with @Entity annotation
			- Note while generating the JAP Annotation, - DO NOT USE PARENT 'Join' Mappings, just keep it simple and put a field called 'parent_id' in the JPAs for the Field Group
		 - sample schema.json file is in the folder idmc-resources
	

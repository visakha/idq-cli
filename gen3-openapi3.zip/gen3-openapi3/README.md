# IDMC OpenAPI 3.0 Generator

A modern Java application that generates OpenAPI 3.0 specifications from IDMC (Informatica Data Management Cloud) Business Entity schema files. Built with Java 21+ features including records, switch expressions, streams, and pattern matching.

## Features

🚀 **Modern Java Architecture**
- Java 21+ with preview features
- Records for immutable data structures
- Pattern matching and switch expressions
- Streams and functional programming
- Type-safe schema generation

⚡ **OpenAPI 3.0 Generation**
- Fully inlined schemas (no `$ref` references)
- Complete CRUD operations for IDMC Business Entities
- Authentication endpoints (login/logout)
- Search functionality with filters
- Comprehensive error handling

🔧 **Developer Experience**
- Parallel batch processing
- Detailed logging and error reporting
- Comprehensive test coverage
- Gradle build with shadow JAR
- Clean CLI interface

## Quick Start

### Prerequisites

- Java 21 or later
- Gradle 8.0+ (or use included wrapper)

### Build

```bash
# Build the application
./gradlew build

# Create executable JAR
./gradlew shadowJar
```

### Usage

#### Single Schema File

```bash
# Generate OpenAPI spec from single schema
java -jar build/libs/gen3-openapi3.jar \
  ../idmc-resources/cg_organization-schema.json \
  output/cg_organization-openapi.json
```

#### Batch Processing

```bash
# Process multiple schema files
java -jar build/libs/gen3-openapi3.jar \
  ../idmc-resources \
  output \
  ".*-schema\\.json"
```

## Architecture

### Core Components

#### Records (Immutable Data Structures)
```java
public record OpenApiSpec(
    String openapi,
    Info info,
    List<Server> servers,
    Map<String, PathItem> paths,
    Components components
) {}

public record ParsedSchema(
    String entityName,
    Schema entitySchema,
    Map<String, Schema> fieldGroups
) {}
```

#### Pattern Matching and Switch Expressions
```java
private FieldType extractFieldType(String eClass) {
    return switch (eClass) {
        case String s when s.contains("TextField") -> FieldType.TEXT;
        case String s when s.contains("IntegerField") -> FieldType.INTEGER;
        case String s when s.contains("DateField") -> FieldType.DATE;
        case String s when s.contains("FieldGroup") -> FieldType.FIELD_GROUP;
        default -> FieldType.TEXT;
    };
}
```

#### Streams and Functional Programming
```java
private Map<String, Schema> extractFieldGroups(JsonNode fields) {
    return StreamSupport.stream(fields.spliterator(), false)
        .filter(field -> extractFieldType(field.path("eClass").asText()) == FieldType.FIELD_GROUP)
        .collect(LinkedHashMap::new,
            (map, field) -> map.put(field.path("name").asText(), createFieldGroupItemSchema(field)),
            LinkedHashMap::putAll);
}
```

#### Parallel Processing
```java
var futures = schemaFiles.stream()
    .map(schemaFile -> CompletableFuture.runAsync(() -> {
        try {
            generateFromSchema(schemaFile.toString(), outputFile.toString());
        } catch (Exception e) {
            logger.error("Failed to process schema file: {}", schemaFile, e);
        }
    }))
    .toArray(CompletableFuture[]::new);

CompletableFuture.allOf(futures).join();
```

### Project Structure

```
gen3-openapi3/
├── src/main/java/com/idmc/openapi/
│   ├── model/           # OpenAPI data models (records)
│   │   └── OpenApiSpec.java
│   ├── schema/          # IDMC schema parsing
│   │   └── IdmcSchemaParser.java
│   └── generator/       # OpenAPI generation logic
│       ├── OpenApiGenerator.java
│       └── OpenApiGeneratorApplication.java
├── src/test/java/       # Comprehensive tests
├── src/main/resources/  # Configuration files
├── build.gradle.kts     # Modern Gradle build
└── README.md           # This file
```

## Generated OpenAPI Features

### Complete API Coverage
- **Authentication**: Login/logout with session management
- **CRUD Operations**: Create, read, update for business entities
- **Search**: Advanced search with filters and pagination
- **Error Handling**: Comprehensive error responses

### Fully Inlined Schemas
All schemas are completely inlined without references:

```json
{
  "requestBody": {
    "required": true,
    "content": {
      "application/json": {
        "schema": {
          "type": "object",
          "properties": {
            "contact_mechanism": {
              "type": "array",
              "items": {
                "type": "object",
                "properties": {
                  "contact_mechanism_type": {
                    "type": "string",
                    "maxLength": 255,
                    "description": "Contact Mechanism Type"
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
```

### IDMC-Specific Features
- Business Entity field mapping
- Field Group array handling
- IDMC authentication patterns
- Metadata structure support

## Examples

### Basic Usage

```bash
# Generate from CG_Organization schema
java -jar gen3-openapi3.jar \
  cg_organization-schema.json \
  cg_organization-api.json
```

### Batch Processing

```bash
# Process all JSON schemas in a directory
java -jar gen3-openapi3.jar \
  ./schemas \
  ./generated \
  ".*\\.json$"
```

### Custom Output Directory

```bash
# Generate with custom directory structure
mkdir -p api-specs/v1
java -jar gen3-openapi3.jar \
  person-schema.json \
  api-specs/v1/person-openapi.json
```

## Advanced Configuration

### Java System Properties

```bash
# Enable preview features
java --enable-preview -jar gen3-openapi3.jar schema.json output.json

# Configure memory
java -Xmx4g -jar gen3-openapi3.jar large-schema.json output.json

# Enable debug logging
java -Dlogback.configurationFile=logback-debug.xml -jar gen3-openapi3.jar
```

### Gradle Build Options

```bash
# Run tests with coverage
./gradlew test jacocoTestReport

# Build with specific Java version
./gradlew build -Dorg.gradle.java.home=/path/to/java21

# Generate distribution
./gradlew distTar distZip
```

## Development

### Running Tests

```bash
# Run all tests
./gradlew test

# Run specific test class
./gradlew test --tests "OpenApiGeneratorTest"

# Run with verbose output
./gradlew test --info
```

### Code Quality

```bash
# Check code style
./gradlew checkstyleMain checkstyleTest

# Static analysis
./gradlew spotbugsMain

# Generate reports
./gradlew check
```

### IDE Setup

For IntelliJ IDEA:
1. Open the project root directory
2. Enable "Use Gradle from" → "gradle-wrapper.properties file"
3. Set Project SDK to Java 21+
4. Enable preview features in Settings → Build → Compiler → Java Compiler

## Troubleshooting

### Common Issues

**Java Version Error**
```
Error: Preview features are not enabled
```
Solution: Add `--enable-preview` to JVM arguments

**Memory Issues**
```
OutOfMemoryError: Java heap space
```
Solution: Increase heap size with `-Xmx4g`

**Schema Parsing Errors**
```
Failed to parse schema file
```
Solution: Validate JSON format and IDMC schema structure

### Debug Mode

Enable detailed logging:
```bash
java -Dlogging.level.com.idmc.openapi=DEBUG -jar gen3-openapi3.jar
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

---

Built with ❤️ using modern Java features and best practices.
"""Harness tests. SQLite only -- no Oracle, no Snowflake, no network.

A tester reads these tests as the specification for the failure
modes: whitelist gates, filename safety, all four compare statuses,
diff detail, diff caps, and the full API flow in demo mode with
the planted differences.
"""

from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine

from harness import demo, pipeline
from harness.catalog import get_source
from harness.compare import compare_tables, create_results_db
from harness.pipeline import Engines
from harness.store import Store
from harness.whitelist import load_whitelist, not_whitelisted

INPUTS = [
    "STG_TRS_D_DC_INDV",
    "STG_TRS_D_INDV_ADDR",
    "STG_TRS_H_DC_INDV",
    "STG_TRS_D_DC_RELATIONSHIPS",
    "LOOKUP_CODE_VALUE",
]
OUTPUTS = [
    "C_S_TRS_PTY",
    "C_S_TRS_PTY_RLE_PHN",
    "STG_TRS_VALID_MEMBERS",
    "EXC_STG_BAD_REC_MEMB",
    "ZZ_UTL_UNMERGE_TREE_SRC_KEY",
]
TABLES = INPUTS + OUTPUTS


def _store(path: str) -> Store:
    return Store(create_engine(f"sqlite:///{path}"))


def _load(store: Store, table_name: str, rows: list[dict]) -> None:
    spec = next(t for t in get_source("TRS").all_tables if t.name == table_name)
    store.ensure(spec, None)
    store.insert(spec, None, [{c: row.get(c) for c in spec.column_names} for row in rows])


def _pty(pkey: str, last: str, first: str = "X") -> dict:
    return {
        "PKEY_SRC_OBJECT": pkey,
        "FRST_NM": first,
        "LST_NM": last,
        "FULL_NM": f"{first} {last}",
        "VERSION_SEQ": 1,
    }


def test_whitelist_ignores_comments_blanks_and_case(tmp_path) -> None:
    path = tmp_path / "wl.txt"
    path.write_text("# comment\n\n  stg_trs_d_dc_indv \nC_S_TRS_PTY\n")
    loaded = load_whitelist(str(path))
    assert loaded == {"STG_TRS_D_DC_INDV", "C_S_TRS_PTY"}
    assert not_whitelisted(["C_S_TRS_PTY"], loaded) == []
    assert not_whitelisted(["C_S_TRS_PTY_RLE_PHN"], loaded) == ["C_S_TRS_PTY_RLE_PHN"]


def test_whitelist_missing_file_fails_closed(tmp_path) -> None:
    with pytest.raises(ValueError, match="Whitelist file not found"):
        load_whitelist(str(tmp_path / "nope.txt"))


def test_resolve_file_rejects_paths(tmp_path) -> None:
    for bad in ("../evil.db", "sub/dir.db", "", ".", "..", "/abs.db"):
        with pytest.raises(ValueError, match="bare filename"):
            pipeline.resolve_file(str(tmp_path), bad, must_exist=False)
    assert pipeline.resolve_file(str(tmp_path), "prod_TRS_1.db", False).endswith("prod_TRS_1.db")


def test_copy_round_trip_verifies_counts(tmp_path) -> None:
    src, dst = _store(str(tmp_path / "src.db")), _store(str(tmp_path / "dst.db"))
    _load(src, "C_S_TRS_PTY", [_pty("TRS-1", "Anderson", "Alice"), _pty("TRS-2", "Jones", "Bob")])
    spec = next(t for t in get_source("TRS").outputs if t.name == "C_S_TRS_PTY")
    results = pipeline._copy_tables(
        src, None, dst, None, [spec], clear_first=False, verb="COPIED", batch_size=5000
    )
    assert results[0].status == "COPIED"
    assert (results[0].source_rows, results[0].target_rows) == (2, 2)


def test_copy_missing_source_is_not_found(tmp_path) -> None:
    src, dst = _store(str(tmp_path / "src.db")), _store(str(tmp_path / "dst.db"))
    spec = next(t for t in get_source("TRS").outputs if t.name == "C_S_TRS_PTY")
    results = pipeline._copy_tables(
        src, None, dst, None, [spec], clear_first=False, verb="COPIED", batch_size=5000
    )
    assert results[0].status == "NOT_FOUND"


def _compare(tmp_path, prod_rows, dev_rows, table_name="C_S_TRS_PTY", diff_cap=10000):
    prod, dev = _store(str(tmp_path / "prod.db")), _store(str(tmp_path / "dev.db"))
    _load(prod, table_name, prod_rows)
    _load(dev, table_name, dev_rows)
    spec = next(t for t in get_source("TRS").outputs if t.name == table_name)
    results_path = str(tmp_path / "compare.db")
    create_results_db(results_path)
    summaries, verdict, _ = compare_tables(
        prod,
        dev,
        [spec],
        results_path,
        "TRS_TEST_1",
        "TRS",
        "prod.db",
        "dev.db",
        "2026-10-27T00:00:00+00:00",
        diff_cap,
        5000,
    )
    return summaries[0], verdict, results_path


def test_compare_all_four_statuses(tmp_path) -> None:
    summary, verdict, _ = _compare(
        tmp_path,
        [
            _pty("TRS-1", "Anderson", "Alice"),
            _pty("TRS-2", "Jones", "Bob"),
            _pty("TRS-3", "White", "Carol"),
        ],
        [
            _pty("TRS-1", "Anderson", "Alice"),
            _pty("TRS-2", "Changed", "Bob"),
            _pty("TRS-4", "Only", "Dev"),
        ],
    )
    assert summary.status == "MISMATCH" and verdict == "MISMATCH"
    assert (summary.matched, summary.different, summary.only_in_prod, summary.only_in_dev) == (
        1,
        1,
        1,
        1,
    )


def test_compare_diff_detail_names_columns_and_values(tmp_path) -> None:
    import sqlite3

    _, _, results_path = _compare(
        tmp_path, [_pty("TRS-2", "Jones", "Bob")], [_pty("TRS-2", "Changed", "Bob")]
    )
    conn = sqlite3.connect(results_path)
    row = conn.execute(
        "SELECT status, pk_json, differing_columns_json, "
        "prod_values_json, dev_values_json FROM row_diffs"
    ).fetchone()
    assert row[0] == "DIFFERENT" and "TRS-2" in row[1]
    assert "LST_NM" in row[2] and "FULL_NM" in row[2]
    assert "Jones" in row[3] and "Changed" in row[4]


def test_compare_missing_table_is_partial(tmp_path) -> None:
    prod, dev = _store(str(tmp_path / "prod.db")), _store(str(tmp_path / "dev.db"))
    _load(prod, "C_S_TRS_PTY", [_pty("TRS-1", "Anderson", "Alice")])
    spec = next(t for t in get_source("TRS").outputs if t.name == "C_S_TRS_PTY")
    results_path = str(tmp_path / "compare.db")
    create_results_db(results_path)
    summaries, verdict, _ = compare_tables(
        prod,
        dev,
        [spec],
        results_path,
        "TRS_TEST_2",
        "TRS",
        "prod.db",
        "dev.db",
        "2026-10-27T00:00:00+00:00",
        10000,
        5000,
    )
    assert summaries[0].status == "MISSING_IN_DEV" and verdict == "PARTIAL"


def test_compare_count_only_without_pk(tmp_path) -> None:
    from dataclasses import replace

    prod, dev = _store(str(tmp_path / "prod.db")), _store(str(tmp_path / "dev.db"))
    catalog_spec = next(t for t in get_source("TRS").inputs if t.name == "LOOKUP_CODE_VALUE")
    spec = replace(catalog_spec, pk=[])
    _load(prod, "LOOKUP_CODE_VALUE", [{"CODE_TYPE": "GENDER"}])
    _load(dev, "LOOKUP_CODE_VALUE", [{"CODE_TYPE": "GENDER"}])
    results_path = str(tmp_path / "compare.db")
    create_results_db(results_path)
    summaries, verdict, _ = compare_tables(
        prod,
        dev,
        [spec],
        results_path,
        "TRS_TEST_3",
        "TRS",
        "prod.db",
        "dev.db",
        "2026-10-27T00:00:00+00:00",
        10000,
        5000,
    )
    assert summaries[0].status == "COUNT_ONLY" and verdict == "PARTIAL"


def test_compare_diff_cap_keeps_counts_complete(tmp_path) -> None:
    summary, _, _ = _compare(
        tmp_path,
        [_pty(f"TRS-{i}", "A") for i in range(5)],
        [_pty(f"TRS-{i}", "B") for i in range(5)],
        diff_cap=2,
    )
    assert summary.different == 5 and summary.diff_rows_stored == 2


def test_step_c_refuses_non_whitelisted_and_truncates_nothing(tmp_path) -> None:
    prod_path, dev_path, snow_path = (str(tmp_path / n) for n in ("prod.db", "dev.db", "snow.db"))
    prod, dev = _store(prod_path), _store(dev_path)
    _load(prod, "C_S_TRS_PTY", [_pty("TRS-1", "Anderson", "Alice")])
    _load(dev, "C_S_TRS_PTY", [_pty("TRS-9", "Old", "Row")])
    wl = tmp_path / "wl.txt"
    wl.write_text("STG_TRS_D_DC_INDV\n")
    engines = Engines(
        create_engine(f"sqlite:///{prod_path}"),
        create_engine(f"sqlite:///{dev_path}"),
        create_engine(f"sqlite:///{snow_path}"),
        str(tmp_path),
        "",
        False,
        prod_path,
        dev_path,
    )
    with pytest.raises(ValueError, match="NOT in the whitelist"):
        pipeline.sqlite_to_dev(engines, "TRS", "prod.db", ["C_S_TRS_PTY"], str(wl), 5000)
    assert (
        dev.count(next(t for t in get_source("TRS").outputs if t.name == "C_S_TRS_PTY"), None) == 1
    )


def test_step_c_refuses_identical_prod_dev(tmp_path) -> None:
    path = str(tmp_path / "same.db")
    engines = Engines(
        create_engine(f"sqlite:///{path}"),
        create_engine(f"sqlite:///{path}"),
        create_engine(f"sqlite:///{tmp_path}/snow.db"),
        str(tmp_path),
        "",
        False,
        path,
        path,
    )
    with pytest.raises(ValueError, match="identical"):
        pipeline.sqlite_to_dev(engines, "TRS", "prod.db", ["C_S_TRS_PTY"], "wl.txt", 5000)


def _demo_client(tmp_path):
    from harness.api import app, get_engines, get_run_store
    from harness.runs import RunStore

    demo_dir = str(tmp_path / "demo")
    os.makedirs(demo_dir, exist_ok=True)
    prod = _store(os.path.join(demo_dir, "demo_prod.db"))
    _load(prod, "STG_TRS_D_DC_INDV", demo.MEMBERS)
    for table_name in (
        "STG_TRS_D_INDV_ADDR",
        "STG_TRS_H_DC_INDV",
        "STG_TRS_D_DC_RELATIONSHIPS",
        "LOOKUP_CODE_VALUE",
    ):
        prod.ensure(next(t for t in get_source("TRS").all_tables if t.name == table_name), None)
    for table_name, rows in demo.derive_outputs(demo.MEMBERS, plant_diffs=False).items():
        _load(prod, table_name, rows)
    prod.engine.dispose()
    dev = _store(os.path.join(demo_dir, "demo_dev_oracle.db"))
    for table_name in TABLES:
        dev.ensure(next(t for t in get_source("TRS").all_tables if t.name == table_name), None)
    dev.engine.dispose()
    snow = _store(os.path.join(demo_dir, "demo_snowflake.db"))
    for table_name in OUTPUTS:
        snow.ensure(next(t for t in get_source("TRS").all_tables if t.name == table_name), None)
    snow.engine.dispose()

    sqlite_dir = str(tmp_path / "pipeline_data")
    os.makedirs(sqlite_dir, exist_ok=True)
    engines = Engines(
        create_engine(f"sqlite:///{demo_dir}/demo_prod.db"),
        create_engine(f"sqlite:///{demo_dir}/demo_dev_oracle.db"),
        create_engine(f"sqlite:///{demo_dir}/demo_snowflake.db"),
        sqlite_dir,
        "",
        True,
        f"{demo_dir}/demo_prod.db",
        f"{demo_dir}/demo_dev_oracle.db",
    )

    def _yield_engines():
        yield engines

    run_engine = create_engine(f"sqlite:///{tmp_path}/control.db")
    app.dependency_overrides[get_run_store] = lambda: RunStore(run_engine)
    app.dependency_overrides[get_engines] = _yield_engines
    return TestClient(app), app


def test_api_end_to_end_demo(tmp_path) -> None:
    from harness.api import app, get_engines, get_run_store
    from harness.config import settings

    wl = tmp_path / "wl.txt"
    wl.write_text("\n".join(TABLES) + "\n")
    old_wl = settings.whitelist_path
    settings.whitelist_path = str(wl)
    try:
        client, _ = _demo_client(tmp_path)
        ready = client.get("/pipeline/readiness", params={"source": "TRS"})
        assert ready.status_code == 200
        by_name = {t["table"]: t for t in ready.json()["tables"]}
        assert all(by_name[t]["exists"] for t in TABLES)
        b = client.post("/pipeline/prod-to-sqlite", json={"source": "TRS", "tables": TABLES})
        assert b.status_code == 200 and b.json()["status"] == "COMPLETED"
        prod_file = b.json()["sqlite_path"]
        c = client.post(
            "/pipeline/sqlite-to-dev",
            json={"source": "TRS", "prod_sqlite": prod_file, "tables": TABLES},
        )
        assert c.status_code == 200 and c.json()["status"] == "COMPLETED"
        d = client.post("/pipeline/run-snowflake-etl", json={"source": "TRS"})
        assert d.status_code == 200 and d.json()["status"] == "COMPLETED"
        assert "demo-simulator" in d.json()["message"]
        e = client.post("/pipeline/snowflake-to-sqlite", json={"source": "TRS", "tables": OUTPUTS})
        assert e.status_code == 200 and e.json()["status"] == "COMPLETED"
        dev_file = e.json()["sqlite_path"]
        f = client.post(
            "/pipeline/compare",
            json={
                "source": "TRS",
                "prod_sqlite": prod_file,
                "dev_sqlite": dev_file,
                "tables": OUTPUTS,
            },
        )
        assert f.status_code == 200
        body = f.json()
        assert body["verdict"] == "MISMATCH"
        by_table = {t["table"]: t for t in body["tables"]}
        pty = by_table["C_S_TRS_PTY"]
        assert (pty["matched"], pty["different"], pty["only_in_prod"], pty["only_in_dev"]) == (
            4,
            1,
            1,
            1,
        )
        assert by_table["C_S_TRS_PTY_RLE_PHN"]["status"] == "MATCH"
        assert by_table["STG_TRS_VALID_MEMBERS"]["status"] == "MATCH"
        assert by_table["ZZ_UTL_UNMERGE_TREE_SRC_KEY"]["status"] == "MATCH"
        assert by_table["EXC_STG_BAD_REC_MEMB"]["only_in_dev"] == 1
        got = client.get(
            f"/pipeline/compare/{body['run_id']}",
            params={"table": "C_S_TRS_PTY", "status": "DIFFERENT"},
        )
        assert got.status_code == 200
        diffs = got.json()["diffs"]
        assert len(diffs) == 1
        assert "LST_NM" in diffs[0]["differing_columns"]
        assert diffs[0]["prod_values"]["LST_NM"] == "White"
        assert diffs[0]["dev_values"]["LST_NM"] == "Changed"
    finally:
        settings.whitelist_path = old_wl
        app.dependency_overrides.pop(get_run_store, None)
        app.dependency_overrides.pop(get_engines, None)


def test_api_unknown_table_is_400(tmp_path) -> None:
    from harness.api import app, get_engines, get_run_store

    client, _ = _demo_client(tmp_path)
    try:
        resp = client.post(
            "/pipeline/prod-to-sqlite", json={"source": "TRS", "tables": ["NO_SUCH_TABLE"]}
        )
        assert resp.status_code == 400
    finally:
        app.dependency_overrides.pop(get_run_store, None)
        app.dependency_overrides.pop(get_engines, None)

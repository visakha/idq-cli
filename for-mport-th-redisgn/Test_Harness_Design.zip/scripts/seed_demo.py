"""Seed the demo databases.

Builds three SQLite files (default directory ./demo):
  demo_prod.db       -- "Production Oracle": 5 inputs + 5 outputs
  demo_dev_oracle.db -- "Dev Oracle": the same 10 tables, empty
  demo_snowflake.db  -- "Snowflake Dev": the 5 outputs, empty

Run from the project root:  python scripts/seed_demo.py
Re-running rebuilds all three files from scratch.
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from sqlalchemy import create_engine

from harness import demo
from harness.catalog import get_source
from harness.store import Store


def _fresh_store(path: str) -> Store:
    if os.path.exists(path):
        os.remove(path)
    return Store(create_engine(f"sqlite:///{path}"))


def _load(store: Store, table_name: str, rows: list[dict]) -> int:
    spec = next(t for t in get_source("TRS").all_tables if t.name == table_name)
    store.ensure(spec, None)
    cleaned = [{c: row.get(c) for c in spec.column_names} for row in rows]
    store.insert(spec, None, cleaned)
    return len(cleaned)


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed the pipeline demo databases.")
    parser.add_argument("--dir", default="./demo", help="Directory for the demo .db files")
    args = parser.parse_args()
    os.makedirs(args.dir, exist_ok=True)
    spec = get_source("TRS")

    prod = _fresh_store(os.path.join(args.dir, "demo_prod.db"))
    for table_name, rows in [
        ("STG_TRS_D_DC_INDV", demo.MEMBERS),
        ("STG_TRS_D_INDV_ADDR", demo.ADDRESSES),
        ("STG_TRS_H_DC_INDV", demo.HISTORY),
        ("STG_TRS_D_DC_RELATIONSHIPS", demo.RELATIONSHIPS),
        ("LOOKUP_CODE_VALUE", demo.LOOKUPS),
    ]:
        print(f"demo_prod.db: {table_name}: {_load(prod, table_name, rows)} rows")
    for table_name, rows in demo.derive_outputs(demo.MEMBERS, plant_diffs=False).items():
        print(f"demo_prod.db: {table_name}: {_load(prod, table_name, rows)} rows (Prod outputs)")
    prod.engine.dispose()

    dev = _fresh_store(os.path.join(args.dir, "demo_dev_oracle.db"))
    for table in spec.all_tables:
        dev.ensure(table, None)
        print(f"demo_dev_oracle.db: {table.name}: 0 rows (empty, step C fills it)")
    dev.engine.dispose()

    snow = _fresh_store(os.path.join(args.dir, "demo_snowflake.db"))
    for table in spec.outputs:
        snow.ensure(table, None)
        print(f"demo_snowflake.db: {table.name}: 0 rows (empty, step D fills it)")
    snow.engine.dispose()
    print(f"Done. Demo databases in {args.dir}/")


if __name__ == "__main__":
    main()

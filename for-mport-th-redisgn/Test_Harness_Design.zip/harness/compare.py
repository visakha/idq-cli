"""Record-by-record compare (step F).

Both sides stream in PK order and merge in Python -- a merge join,
not a load-everything approach, so a large table costs memory
proportional to the batch size, not the table size. Every row lands
in exactly one class: MATCHED, DIFFERENT (same PK, a column
differs; differing columns and both values stored), ONLY_IN_PROD,
ONLY_IN_DEV.

A table with no PK cannot be compared record by record: it gets a
COUNT_ONLY row and pushes the verdict to PARTIAL, never a false
MATCH. A table missing on either side is reported, not failed: a
missing Dev table is exactly what the tester needs to see.

Value normalisation: the sides may come from different engines
(Oracle NUMBER arrives as Decimal, SQLite as int), so values are
normalised before comparing -- dates to ISO strings, numbers to
their shortest decimal string, bytes to hex, None stays None.
Stored diff values are the normalised forms. Caveat, stated
plainly: exotic floats compare on their shortest string form, so a
float differing beyond display precision reads as equal. For
money/measure columns that is the right trade; for bit-exact float
work, compare that table by another means.

Results file schema (three Core tables, no ORM):
  compare_runs  -- one row per compare run
  table_summary -- one row per table, counts always complete
  row_diffs     -- one row per DIFFERENT / ONLY_IN_* row, capped
                   per table by diff_cap; counts stay complete
                   when the cap bites
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Column, Index, Integer, MetaData, String, Table, Text, create_engine
from sqlalchemy.engine import Connection, Engine

from harness.catalog import TableDef
from harness.store import Store

_METADATA = MetaData()
COMPARE_RUNS = Table(
    "compare_runs",
    _METADATA,
    Column("run_id", String, primary_key=True),
    Column("source", String, nullable=False),
    Column("prod_sqlite", String, nullable=False),
    Column("dev_sqlite", String, nullable=False),
    Column("started_at", String, nullable=False),
    Column("finished_at", String, nullable=True),
    Column("status", String, nullable=False),
    Column("verdict", String, nullable=False),
    Column("message", Text, nullable=False, default=""),
)
TABLE_SUMMARY = Table(
    "table_summary",
    _METADATA,
    Column("run_id", String, nullable=False),
    Column("table_name", String, nullable=False),
    Column("status", String, nullable=False),
    Column("prod_count", Integer, nullable=True),
    Column("dev_count", Integer, nullable=True),
    Column("matched", Integer, nullable=False, default=0),
    Column("different", Integer, nullable=False, default=0),
    Column("only_in_prod", Integer, nullable=False, default=0),
    Column("only_in_dev", Integer, nullable=False, default=0),
    Column("diff_rows_stored", Integer, nullable=False, default=0),
    Column("message", Text, nullable=False, default=""),
)
ROW_DIFFS = Table(
    "row_diffs",
    _METADATA,
    Column("run_id", String, nullable=False),
    Column("table_name", String, nullable=False),
    Column("status", String, nullable=False),
    Column("pk_json", Text, nullable=False, default="{}"),
    Column("differing_columns_json", Text, nullable=False, default="[]"),
    Column("prod_values_json", Text, nullable=False, default="{}"),
    Column("dev_values_json", Text, nullable=False, default="{}"),
    Index("ix_row_diffs_run_table_status", "run_id", "table_name", "status"),
)


@dataclass
class TableSummary:
    table: str
    status: str  # MATCH | MISMATCH | MISSING_IN_PROD | MISSING_IN_DEV | COUNT_ONLY | FAILED
    prod_count: int | None = None
    dev_count: int | None = None
    matched: int = 0
    different: int = 0
    only_in_prod: int = 0
    only_in_dev: int = 0
    diff_rows_stored: int = 0
    message: str = ""


def normalize(value: object) -> object:
    """Normalise one value for cross-engine comparison and JSON storage."""
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value.normalize())
    if isinstance(value, float):
        try:
            return str(Decimal(str(value)).normalize())
        except Exception:
            return str(value)  # NaN / Infinity have no decimal form
    if isinstance(value, int):
        return str(value)
    if isinstance(value, bytes):
        return value.hex()
    return str(value)


def _pk(row: dict, pk: list[str]) -> tuple:
    return tuple(normalize(row.get(c)) for c in pk)


class _Peekable:
    """A batched row stream with one-row lookahead."""

    def __init__(self, batches: Iterator[list[dict]]) -> None:
        self._batches = iter(batches)
        self._buffer: list[dict] = []
        self._pos = 0
        self._exhausted = False

    def _fill(self) -> None:
        if self._pos >= len(self._buffer) and not self._exhausted:
            try:
                self._buffer = next(self._batches)
                self._pos = 0
            except StopIteration:
                self._exhausted = True

    def peek(self) -> dict | None:
        self._fill()
        return self._buffer[self._pos] if self._pos < len(self._buffer) else None

    def take(self) -> dict | None:
        row = self.peek()
        if row is not None:
            self._pos += 1
        return row


def create_results_db(path: str) -> None:
    engine = create_engine(f"sqlite:///{path}")
    try:
        _METADATA.create_all(engine)
    finally:
        engine.dispose()


def compare_tables(
    prod: Store,
    dev: Store,
    tables: list[TableDef],
    results_path: str,
    run_id: str,
    source: str,
    prod_file: str,
    dev_file: str,
    started_at: str,
    diff_cap: int,
    batch_size: int,
) -> tuple[list[TableSummary], str, str]:
    """Compare every table; write summaries + diffs; return verdict.

    MATCH only if every table is MATCH; MISMATCH if any table
    differs and nothing is incomplete; PARTIAL if anything is
    missing, PK-less, or failed -- incomplete evidence must not be
    reported as a clean match or a clean mismatch.
    """
    engine: Engine = create_engine(f"sqlite:///{results_path}")
    summaries: list[TableSummary] = []
    try:
        with engine.begin() as conn:
            for spec in tables:
                summaries.append(_compare_one(conn, prod, dev, spec, run_id, diff_cap, batch_size))
        statuses = {s.status for s in summaries}
        if summaries and statuses <= {"MATCH"}:
            verdict = "MATCH"
        elif statuses & {"MISSING_IN_PROD", "MISSING_IN_DEV", "COUNT_ONLY", "FAILED"}:
            verdict = "PARTIAL"
        elif "MISMATCH" in statuses:
            verdict = "MISMATCH"
        else:
            verdict = "PARTIAL"
        message = (
            f"Compare {verdict} over {len(summaries)} tables: "
            f"{sum(s.matched for s in summaries)} matched, "
            f"{sum(s.different for s in summaries)} different, "
            f"{sum(s.only_in_prod for s in summaries)} only in Prod, "
            f"{sum(s.only_in_dev for s in summaries)} only in Dev."
        )
        with engine.begin() as conn:
            conn.execute(
                COMPARE_RUNS.insert().values(
                    run_id=run_id,
                    source=source,
                    prod_sqlite=prod_file,
                    dev_sqlite=dev_file,
                    started_at=started_at,
                    finished_at=datetime.now().isoformat(timespec="seconds"),
                    status="COMPLETED",
                    verdict=verdict,
                    message=message,
                )
            )
        return summaries, verdict, message
    finally:
        engine.dispose()


def _compare_one(
    conn: Connection,
    prod: Store,
    dev: Store,
    spec: TableDef,
    run_id: str,
    diff_cap: int,
    batch_size: int,
) -> TableSummary:
    def store(summary: TableSummary) -> TableSummary:
        conn.execute(
            TABLE_SUMMARY.insert().values(
                run_id=run_id,
                table_name=summary.table,
                status=summary.status,
                prod_count=summary.prod_count,
                dev_count=summary.dev_count,
                matched=summary.matched,
                different=summary.different,
                only_in_prod=summary.only_in_prod,
                only_in_dev=summary.only_in_dev,
                diff_rows_stored=summary.diff_rows_stored,
                message=summary.message,
            )
        )
        return summary

    try:
        prod_exists = prod.exists(spec, None)
        dev_exists = dev.exists(spec, None)
        if not prod_exists or not dev_exists:
            missing = "MISSING_IN_PROD" if not prod_exists else "MISSING_IN_DEV"
            return store(
                TableSummary(
                    table=spec.name,
                    status=missing,
                    prod_count=prod.count(spec, None) if prod_exists else None,
                    dev_count=dev.count(spec, None) if dev_exists else None,
                    message=f"Table {spec.name} is missing on the "
                    f"{'Prod' if not prod_exists else 'Dev'} side.",
                )
            )
        prod_count = prod.count(spec, None)
        dev_count = dev.count(spec, None)
        if not spec.pk:
            return store(
                TableSummary(
                    table=spec.name,
                    status="COUNT_ONLY",
                    prod_count=prod_count,
                    dev_count=dev_count,
                    message=f"No PK registered for {spec.name}; counts only. "
                    "Register a PK to compare record by record.",
                )
            )
        summary = TableSummary(
            table=spec.name, status="MATCH", prod_count=prod_count, dev_count=dev_count
        )
        stored = 0

        def record(
            status: str, pk_row: dict, differing: list[str], prod_row: dict, dev_row: dict
        ) -> None:
            nonlocal stored
            if status == "DIFFERENT":
                summary.different += 1
            elif status == "ONLY_IN_PROD":
                summary.only_in_prod += 1
            else:
                summary.only_in_dev += 1
            if stored >= diff_cap:
                return
            if status == "DIFFERENT":
                prod_vals = {c: normalize(prod_row.get(c)) for c in differing}
                dev_vals = {c: normalize(dev_row.get(c)) for c in differing}
            elif status == "ONLY_IN_PROD":
                prod_vals = {c: normalize(prod_row.get(c)) for c in spec.column_names}
                dev_vals = {}
            else:
                prod_vals = {}
                dev_vals = {c: normalize(dev_row.get(c)) for c in spec.column_names}
            conn.execute(
                ROW_DIFFS.insert().values(
                    run_id=run_id,
                    table_name=spec.name,
                    status=status,
                    pk_json=json.dumps({c: normalize(pk_row.get(c)) for c in spec.pk}),
                    differing_columns_json=json.dumps(differing),
                    prod_values_json=json.dumps(prod_vals),
                    dev_values_json=json.dumps(dev_vals),
                )
            )
            stored += 1

        prod_stream = _Peekable(prod.stream(spec, None, batch_size))
        dev_stream = _Peekable(dev.stream(spec, None, batch_size))
        while True:
            p = prod_stream.peek()
            d = dev_stream.peek()
            if p is None and d is None:
                break
            if d is None or (p is not None and _pk(p, spec.pk) < _pk(d, spec.pk)):
                prod_stream.take()
                assert p is not None
                record("ONLY_IN_PROD", p, [], p, {})
            elif p is None or _pk(d, spec.pk) < _pk(p, spec.pk):
                dev_stream.take()
                assert d is not None
                record("ONLY_IN_DEV", d, [], {}, d)
            else:
                prod_stream.take()
                dev_stream.take()
                assert p is not None and d is not None
                differing = [
                    c for c in spec.column_names if normalize(p.get(c)) != normalize(d.get(c))
                ]
                if differing:
                    record("DIFFERENT", p, differing, p, d)
                else:
                    summary.matched += 1
        summary.diff_rows_stored = stored
        summary.status = (
            "MATCH"
            if (summary.different == 0 and summary.only_in_prod == 0 and summary.only_in_dev == 0)
            else "MISMATCH"
        )
        summary.message = (
            f"Prod={prod_count}, Dev={dev_count}, matched={summary.matched}, "
            f"different={summary.different}, only_in_prod={summary.only_in_prod}, "
            f"only_in_dev={summary.only_in_dev}."
        )
        return store(summary)
    except Exception as exc:
        return store(
            TableSummary(table=spec.name, status="FAILED", message=f"{type(exc).__name__}: {exc}")
        )

"""Demo data + DEMO ONLY simulator.

DEMO ONLY: this module never runs in real mode. It reads Dev-side
SQLite inputs and writes Dev-side SQLite outputs, mimicking a stage
load at sample scale, so steps E and F have something to copy and
compare when there is no Snowflake.

The derivation lives in derive_outputs() and is shared with the
seed script on purpose: the seed builds Prod outputs with
plant_diffs=False, the simulator builds Dev outputs with
plant_diffs=True, so every row matches exactly EXCEPT the planted
differences. That is what makes the compare produce every status
for the tester to see.

PLANTED DIFFERENCES (deliberate, documented, demo-only):
  * Member 1003 renamed in Dev (DIFFERENT on C_S_TRS_PTY).
  * Member 1005 dropped from Dev party output (ONLY_IN_PROD).
  * Member 1007 added in Dev (ONLY_IN_DEV).
  * One extra Dev-only exception row (ONLY_IN_DEV on EXC).
  * Everything else matches exactly.
"""

from __future__ import annotations

from harness.catalog import get_source
from harness.store import Store

INPUT_COLS = [
    "INDV_ID",
    "FIRST_NAME",
    "LAST_NAME",
    "GENDER_CD",
    "DOB_DT",
    "INACTIVE_IND",
    "DELETE_SW",
]

MEMBERS: list[dict] = [
    {
        "INDV_ID": 1001,
        "FIRST_NAME": "Alice",
        "LAST_NAME": "Anderson",
        "GENDER_CD": "F",
        "DOB_DT": "1985-03-14",
        "INACTIVE_IND": "N",
        "DELETE_SW": "N",
    },
    {
        "INDV_ID": 1002,
        "FIRST_NAME": "Bob",
        "LAST_NAME": "Jones",
        "GENDER_CD": "M",
        "DOB_DT": "1978-11-02",
        "INACTIVE_IND": "Y",
        "DELETE_SW": "N",
    },
    {
        "INDV_ID": 1003,
        "FIRST_NAME": "Carol",
        "LAST_NAME": "White",
        "GENDER_CD": "F",
        "DOB_DT": "1992-07-19",
        "INACTIVE_IND": "N",
        "DELETE_SW": "N",
    },
    {
        "INDV_ID": 1004,
        "FIRST_NAME": "Dan",
        "LAST_NAME": "",
        "GENDER_CD": "M",
        "DOB_DT": "2001-05-30",
        "INACTIVE_IND": "N",
        "DELETE_SW": "N",
    },
    {
        "INDV_ID": 1005,
        "FIRST_NAME": "Eve",
        "LAST_NAME": "Martin",
        "GENDER_CD": "F",
        "DOB_DT": "1988-09-09",
        "INACTIVE_IND": "Y",
        "DELETE_SW": "N",
    },
    {
        "INDV_ID": 1006,
        "FIRST_NAME": "Frank",
        "LAST_NAME": "Brown",
        "GENDER_CD": "M",
        "DOB_DT": "1975-01-25",
        "INACTIVE_IND": "N",
        "DELETE_SW": "N",
    },
]

ADDRESSES: list[dict] = [
    {
        "INDV_ID": 1001,
        "ADDR_LINE": "12 Oak St",
        "ADDR_CITY": "Austin",
        "ADDR_STATE_CD": "TX",
        "ADDR_ZIP5": "78701",
        "ADDR_TYPE_CD": "HOME",
        "EFF_BEGIN_DT": "2020-01-01",
    },
    {
        "INDV_ID": 1002,
        "ADDR_LINE": "34 Pine Ave",
        "ADDR_CITY": "Dallas",
        "ADDR_STATE_CD": "TX",
        "ADDR_ZIP5": "75201",
        "ADDR_TYPE_CD": "HOME",
        "EFF_BEGIN_DT": "2019-06-15",
    },
    {
        "INDV_ID": 1003,
        "ADDR_LINE": "56 Cedar Ln",
        "ADDR_CITY": "Houston",
        "ADDR_STATE_CD": "TX",
        "ADDR_ZIP5": "77001",
        "ADDR_TYPE_CD": "HOME",
        "EFF_BEGIN_DT": "2021-03-10",
    },
    {
        "INDV_ID": 1004,
        "ADDR_LINE": "78 Elm Rd",
        "ADDR_CITY": "El Paso",
        "ADDR_STATE_CD": "TX",
        "ADDR_ZIP5": "79901",
        "ADDR_TYPE_CD": "HOME",
        "EFF_BEGIN_DT": "2022-02-20",
    },
    {
        "INDV_ID": 1005,
        "ADDR_LINE": "90 Maple Dr",
        "ADDR_CITY": "San Antonio",
        "ADDR_STATE_CD": "TX",
        "ADDR_ZIP5": "78201",
        "ADDR_TYPE_CD": "HOME",
        "EFF_BEGIN_DT": "2018-11-05",
    },
    {
        "INDV_ID": 1006,
        "ADDR_LINE": "11 Birch Ct",
        "ADDR_CITY": "Fort Worth",
        "ADDR_STATE_CD": "TX",
        "ADDR_ZIP5": "76101",
        "ADDR_TYPE_CD": "HOME",
        "EFF_BEGIN_DT": "2017-08-08",
    },
]

HISTORY: list[dict] = [
    {
        "INDV_ID": 1001,
        "HISTORY_SEQ": 1,
        "FIRST_NAME": "Alice",
        "LAST_NAME": "Anderson",
        "GENDER_CD": "F",
        "DOB_DT": "1985-03-14",
        "INACTIVE_IND": "N",
        "DELETE_SW": "N",
    },
    {
        "INDV_ID": 1002,
        "HISTORY_SEQ": 1,
        "FIRST_NAME": "Bob",
        "LAST_NAME": "Jones",
        "GENDER_CD": "M",
        "DOB_DT": "1978-11-02",
        "INACTIVE_IND": "N",
        "DELETE_SW": "N",
    },
]

RELATIONSHIPS: list[dict] = [
    {
        "INDV_ID": 1001,
        "REF_INDV_ID": 1003,
        "HISTORY_SEQ": 1,
        "RELATIONSHIP_TYPE_CD": "PARENT",
        "EFF_BEGIN_DT": "2010-01-01",
    },
    {
        "INDV_ID": 1002,
        "REF_INDV_ID": 1005,
        "HISTORY_SEQ": 1,
        "RELATIONSHIP_TYPE_CD": "SPOUSE",
        "EFF_BEGIN_DT": "2005-06-01",
    },
]

LOOKUPS: list[dict] = [
    {
        "CODE_TYPE": "GENDER",
        "SRC_SYS": "TRS",
        "SRC_CODE_VALUE": "M",
        "MSTR_REF_CODE": "M",
        "MSTR_REF_LABEL": "Male",
    },
    {
        "CODE_TYPE": "GENDER",
        "SRC_SYS": "TRS",
        "SRC_CODE_VALUE": "F",
        "MSTR_REF_CODE": "F",
        "MSTR_REF_LABEL": "Female",
    },
    {
        "CODE_TYPE": "INACTIVE_IND",
        "SRC_SYS": "TRS",
        "SRC_CODE_VALUE": "Y",
        "MSTR_REF_CODE": "Y",
        "MSTR_REF_LABEL": "Inactive",
    },
    {
        "CODE_TYPE": "INACTIVE_IND",
        "SRC_SYS": "TRS",
        "SRC_CODE_VALUE": "N",
        "MSTR_REF_CODE": "N",
        "MSTR_REF_LABEL": "Active",
    },
]


def _pty_row(member: dict) -> dict:
    return {
        "PKEY_SRC_OBJECT": f"TRS-{member['INDV_ID']}",
        "ROWID_OBJECT": None,
        "DELETED_IND": 0,
        "DELETED_DATE": None,
        "DELETED_BY": None,
        "PERIOD_START_DATE": None,
        "PERIOD_END_DATE": None,
        "VERSION_SEQ": 1,
        "PERIOD_REFERENCE_TIME": None,
        "TIMELINE_ACTION": 1,
        "LAST_UPDATE_DATE": None,
        "UPDATED_BY": None,
        "CREATE_DATE": None,
        "CREATOR": None,
        "SRC_ROWID": None,
        "HUB_STATE_IND": 0,
        "PTY_BO_CLASS_CD": None,
        "PRFX_NM": None,
        "FRST_NM": member["FIRST_NAME"],
        "MDL_NM": None,
        "LST_NM": member["LAST_NAME"],
        "SFX_NM": None,
        "FULL_NM": f"{member['FIRST_NAME']} {member['LAST_NAME']}".strip(),
        "GNDR_CD": member["GENDER_CD"],
        "BIRTH_DT": member["DOB_DT"],
        "DEATH_DT": None,
        "FLAG_SRC": None,
        "SRC_FULL_NM": None,
        "SRC_LAST_UPD_DT": None,
        "ETHNCTY": None,
        "SRC_RACE_CD": None,
        "SRC_ETHNCTY": None,
        "RACE_CD": None,
    }


def _exc_row(member: dict) -> dict:
    return {
        "SRC_SYS": "TRS",
        "SRC_SYS_ID_1": str(member["INDV_ID"]),
        "SRC_SYS_ID_2": None,
        "SRC_SYS_ID_3": None,
        "EXCEPTION_TYPE": "BAD_REC",
        "EXCEPTION_CODE": "BLANK_LAST_NAME",
        "EXCEPTION_DESC": "Last name is blank",
        "RUN_DATE": None,
        "PREFIX": None,
        "FIRST_NAME": member["FIRST_NAME"],
        "MIDDLE_NAME": None,
        "LAST_NAME": member["LAST_NAME"],
        "SUFFIX": None,
        "ALIAS_PREFIX": None,
        "ALIAS_FIRST_NAME": None,
        "ALIAS_MIDDLE_NAME": None,
        "ALIAS_LAST_NAME": None,
        "ALIAS_SUFFIX": None,
        "BIRTH_DATE": member["DOB_DT"],
        "GENDER": member["GENDER_CD"],
        "ADDRESS_TYPE": None,
        "ADDRESS_LINE_1": None,
        "ADDRESS_LINE_2": None,
        "ADDRESS_CITY": None,
        "ADDRESS_COUNTY": None,
        "ADDRESS_STATE": None,
        "ADDRESS_ZIP": None,
        "ADDRESS_ZIP_EXT": None,
        "ADDRESS_COUNTRY": None,
        "ADDRESS_DR_ERROR_CODE": None,
        "ADDRESS_DR_ERROR_DESC": None,
        "ADDRESS_DR_MAILABILITY_SCORE": None,
        "PRIMARY_PHONE": None,
        "WORK_PHONE": None,
        "SECONDARY_PHONE": None,
        "EMAIL": None,
        "ATTRIBUTE_NAME": "LAST_NAME",
        "ATTRIBUTE_VALUE": "",
        "MAPPING_NAME": "PTY",
        "PERIOD_START_DATE": None,
        "PERIOD_END_DATE": None,
        "DEATH_DT": None,
    }


def derive_outputs(members: list[dict], plant_diffs: bool) -> dict[str, list[dict]]:
    """Derive the 5 sample outputs. plant_diffs=False is Prod (IDQ);
    True is Dev (Snowflake) with the planted differences."""
    pty = [_pty_row(m) for m in members]
    if plant_diffs:
        for row in pty:
            if row["PKEY_SRC_OBJECT"] == "TRS-1003":
                row["LST_NM"] = "Changed"
                row["FULL_NM"] = "Carol Changed"
        pty = [r for r in pty if r["PKEY_SRC_OBJECT"] != "TRS-1005"]
        pty.append(
            _pty_row(
                {
                    "INDV_ID": 1007,
                    "FIRST_NAME": "Dev",
                    "LAST_NAME": "Only",
                    "GENDER_CD": "F",
                    "DOB_DT": "1990-01-01",
                }
            )
        )
    phn = [
        {
            "PKEY_SRC_OBJECT": f"TRS-{i}-PHN",
            "ROWID_OBJECT": None,
            "DELETED_IND": 0,
            "DELETED_DATE": None,
            "DELETED_BY": None,
            "PERIOD_START_DATE": None,
            "PERIOD_END_DATE": None,
            "VERSION_SEQ": 1,
            "PERIOD_REFERENCE_TIME": None,
            "TIMELINE_ACTION": 1,
            "LAST_UPDATE_DATE": None,
            "UPDATED_BY": None,
            "CREATE_DATE": None,
            "CREATOR": None,
            "SRC_ROWID": None,
            "HUB_STATE_IND": 0,
            "PTY_RLE_FK": None,
            "PHN_TP": "HOME",
            "USG_TP": "PRIMARY",
            "PHN_NUM": f"555010{i % 10}",
            "PREF_LVL": 1,
            "SRC_LAST_UPD_DT": None,
        }
        for i in (1001, 1002, 1003, 1004, 1005)
    ]
    spine = [
        {
            "INDV_ID": m["INDV_ID"],
            "PTY_PK": f"TRS-{m['INDV_ID']}",
            "SRC_TBL": "STG_TRS_D_DC_INDV",
            "CREATE_DATE": None,
        }
        for m in members
    ]
    exc = [_exc_row(m) for m in members if not (m["LAST_NAME"] or "").strip()]
    if plant_diffs:
        planted = _exc_row(
            {
                "INDV_ID": 1002,
                "FIRST_NAME": "Bob",
                "LAST_NAME": "Jones",
                "GENDER_CD": "M",
                "DOB_DT": None,
            }
        )
        planted.update(
            {
                "EXCEPTION_CODE": "DEV_ONLY_CHECK",
                "EXCEPTION_DESC": "Planted Dev-only exception for the demo",
                "ATTRIBUTE_NAME": "DEMO",
                "ATTRIBUTE_VALUE": "X",
            }
        )
        exc.append(planted)
    zz = [
        {
            "INDV_ID": m["INDV_ID"],
            "SRC_KEY": f"TRS-{m['INDV_ID']}",
            "TREE_LEVEL": 1,
            "PROCESSED_YN": "N",
        }
        for m in members
        if (m["INACTIVE_IND"] or "N") == "Y"
    ]
    return {
        "C_S_TRS_PTY": pty,
        "C_S_TRS_PTY_RLE_PHN": phn,
        "STG_TRS_VALID_MEMBERS": spine,
        "EXC_STG_BAD_REC_MEMB": exc,
        "ZZ_UTL_UNMERGE_TREE_SRC_KEY": zz,
    }


def _members(dev: Store) -> list[dict]:
    spec = next(t for t in get_source("TRS").inputs if t.name == "STG_TRS_D_DC_INDV")
    rows: list[dict] = []
    for batch in dev.stream(spec, None, 1000):
        rows.extend(batch)
    return rows


def simulate(dev: Store, snow: Store) -> dict[str, object]:
    """Simulate the TRS stage load into the demo Snowflake file."""
    outputs = derive_outputs(_members(dev), plant_diffs=True)
    counts: dict[str, object] = {}
    for name, rows in outputs.items():
        spec = next(t for t in get_source("TRS").outputs if t.name == name)
        snow.ensure(spec, None)
        snow.clear(spec, None)
        snow.insert(spec, None, rows)
        counts[name] = len(rows)
    counts["_note"] = (
        "DEMO ONLY. Planted differences vs Prod: member 1003 renamed, "
        "member 1005 dropped from C_S_TRS_PTY, member 1007 added, one "
        "extra EXC row. Everything else matches Prod exactly."
    )
    return counts

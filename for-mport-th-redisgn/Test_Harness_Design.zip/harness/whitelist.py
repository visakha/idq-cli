"""Whitelist for step C. All rules fail closed.

* The file must exist. A missing file is an error, not an empty
  whitelist: silently truncating nothing would report success
  while loading nothing.
* One table name per line; blank lines and "#" lines ignored;
  names upper-cased on load.
* A requested table that is NOT listed is rejected BEFORE
  anything is written, and the error names every offender.
  There is no partial-truncate path.
"""

from __future__ import annotations


def load_whitelist(path: str) -> set[str]:
    try:
        with open(path, encoding="utf-8") as fh:
            lines = fh.read().splitlines()
    except FileNotFoundError as exc:
        raise ValueError(
            f"Whitelist file not found: {path}. Refusing to truncate "
            "anything without it. Create it with one Dev Oracle table "
            "name per line."
        ) from exc
    names: set[str] = set()
    for raw in lines:
        line = raw.strip()
        if line and not line.startswith("#"):
            names.add(line.upper())
    return names


def not_whitelisted(requested: list[str], allowed: set[str]) -> list[str]:
    return [name for name in requested if name.upper() not in allowed]

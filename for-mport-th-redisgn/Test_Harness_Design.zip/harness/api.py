"""FastAPI routes. Thin, in the Spring MVC sense: validate the
request, call the pipeline service, record the run, return the
response. No route touches a database directly, and no route
builds SQL.

Failure shape: a validation failure (unknown source/table/
workflow, whitelist refusal, prod==dev, bad filename) is a 400
raised BEFORE anything is written. A step that ran but hit
per-table problems returns 200 with status PARTIAL/FAILED and the
per-table results. A MISMATCH compare is a successful compare
with a negative answer (200, not an error).
"""

from __future__ import annotations

import json
import os
import sqlite3
from collections.abc import Iterator
from dataclasses import asdict
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Query, Security
from fastapi.security import APIKeyHeader
from sqlalchemy import create_engine

from harness import pipeline
from harness.catalog import SOURCES
from harness.config import settings
from harness.models import (
    CompareOut,
    CompareRequest,
    ProdToSqliteRequest,
    ReadinessOut,
    ReadinessRowOut,
    RowDiffOut,
    RunEtlRequest,
    RunOut,
    SnowflakeToSqliteRequest,
    SourceOut,
    SqliteToDevRequest,
    TableResultOut,
    TableSummaryOut,
)
from harness.pipeline import Engines
from harness.runs import RunStore

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def require_api_key(key: str | None = Security(api_key_header)) -> None:
    if settings.api_key and key != settings.api_key:
        raise HTTPException(status_code=401, detail="Missing or incorrect X-API-Key header.")


def get_engines() -> Iterator[Engines]:
    engines = pipeline.build_engines(settings)
    try:
        yield engines
    finally:
        engines.dispose()


def get_run_store() -> RunStore:
    return RunStore(create_engine(settings.control_db_url))


def _table_out(results: list) -> list[TableResultOut]:
    return [TableResultOut(**asdict(r)) for r in results]


def _record(
    store: RunStore,
    run_type: str,
    status: str,
    message: str,
    summary: object,
    run_id: str | None = None,
) -> str:
    import uuid

    record = store.new_run(run_id or str(uuid.uuid4()), run_type)
    finished = store.finish_run(record, status, message, summary)
    return finished.id


app = FastAPI(
    title="Test Harness",
    version="1.0.0",
    description="Daily tester pipeline: Oracle Production -> Prod_SQLite -> "
    "Dev Oracle -> Snowflake Dev -> Dev_SQLite -> Compare_Results_SQLite.",
)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "demo_mode": settings.demo_mode, "source": settings.snowflake_source}


@app.get("/pipeline/sources", response_model=list[SourceOut])
def list_sources() -> list[SourceOut]:
    return [
        SourceOut(
            source=spec.source,
            runners=dict(spec.runners),
            input_tables=[t.name for t in spec.inputs],
            output_tables=[t.name for t in spec.outputs],
        )
        for spec in SOURCES.values()
    ]


@app.get(
    "/pipeline/readiness", response_model=ReadinessOut, dependencies=[Depends(require_api_key)]
)
def get_readiness(
    engines: Annotated[Engines, Depends(get_engines)], source: str = "TRS"
) -> ReadinessOut:
    try:
        ready, message, rows = pipeline.readiness(engines, source)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"{type(exc).__name__}: {exc}") from exc
    return ReadinessOut(
        source=source.upper(),
        ready=ready,
        message=message,
        tables=[ReadinessRowOut(**asdict(r)) for r in rows],
    )


@app.post(
    "/pipeline/prod-to-sqlite", response_model=RunOut, dependencies=[Depends(require_api_key)]
)
def post_prod_to_sqlite(
    request: ProdToSqliteRequest,
    store: Annotated[RunStore, Depends(get_run_store)],
    engines: Annotated[Engines, Depends(get_engines)],
) -> RunOut:
    try:
        results, overall, filename = pipeline.prod_to_sqlite(
            engines, request.source, request.tables, settings.copy_batch_size
        )
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    run_id = _record(
        store,
        "prod-to-sqlite",
        overall,
        f"Prod -> Prod_SQLite {overall}: {filename}.",
        {"sqlite_file": filename, "tables": [asdict(r) for r in results]},
    )
    return RunOut(
        run_id=run_id,
        run_type="prod-to-sqlite",
        status=overall,
        message=f"Prod -> Prod_SQLite {overall}: {filename}.",
        results=_table_out(results),
        sqlite_path=filename,
    )


@app.post("/pipeline/sqlite-to-dev", response_model=RunOut, dependencies=[Depends(require_api_key)])
def post_sqlite_to_dev(
    request: SqliteToDevRequest,
    store: Annotated[RunStore, Depends(get_run_store)],
    engines: Annotated[Engines, Depends(get_engines)],
) -> RunOut:
    try:
        results, overall = pipeline.sqlite_to_dev(
            engines,
            request.source,
            request.prod_sqlite,
            request.tables,
            settings.whitelist_path,
            settings.copy_batch_size,
        )
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    run_id = _record(
        store,
        "sqlite-to-dev",
        overall,
        f"Prod_SQLite -> Dev Oracle {overall}.",
        {"prod_sqlite": request.prod_sqlite, "tables": [asdict(r) for r in results]},
    )
    return RunOut(
        run_id=run_id,
        run_type="sqlite-to-dev",
        status=overall,
        message=f"Prod_SQLite -> Dev Oracle {overall}.",
        results=_table_out(results),
    )


@app.post(
    "/pipeline/run-snowflake-etl", response_model=RunOut, dependencies=[Depends(require_api_key)]
)
def post_run_etl(
    request: RunEtlRequest,
    store: Annotated[RunStore, Depends(get_run_store)],
    engines: Annotated[Engines, Depends(get_engines)],
) -> RunOut:
    try:
        results, overall, summaries = pipeline.run_etl(
            engines, request.source, request.workflows, request.reset_outputs
        )
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = "; ".join(f"{r.get('workflow')}: {r.get('status')}" for r in results)
    run_id = _record(
        store, "run-snowflake-etl", overall, message, {"workflows": results, "summaries": summaries}
    )
    return RunOut(
        run_id=run_id,
        run_type="run-snowflake-etl",
        status=overall,
        message=message,
        results=results,
    )


@app.post(
    "/pipeline/snowflake-to-sqlite", response_model=RunOut, dependencies=[Depends(require_api_key)]
)
def post_snowflake_to_sqlite(
    request: SnowflakeToSqliteRequest,
    store: Annotated[RunStore, Depends(get_run_store)],
    engines: Annotated[Engines, Depends(get_engines)],
) -> RunOut:
    try:
        results, overall, filename = pipeline.snowflake_to_sqlite(
            engines,
            request.source,
            request.tables,
            request.include_inputs,
            settings.copy_batch_size,
        )
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    run_id = _record(
        store,
        "snowflake-to-sqlite",
        overall,
        f"Snowflake Dev -> Dev_SQLite {overall}: {filename}.",
        {"sqlite_file": filename, "tables": [asdict(r) for r in results]},
    )
    return RunOut(
        run_id=run_id,
        run_type="snowflake-to-sqlite",
        status=overall,
        message=f"Snowflake Dev -> Dev_SQLite {overall}: {filename}.",
        results=_table_out(results),
        sqlite_path=filename,
    )


@app.post("/pipeline/compare", response_model=CompareOut, dependencies=[Depends(require_api_key)])
def post_compare(
    request: CompareRequest,
    store: Annotated[RunStore, Depends(get_run_store)],
    engines: Annotated[Engines, Depends(get_engines)],
) -> CompareOut:
    try:
        summaries, verdict, status, filename, run_id = pipeline.compare_sqlites(
            engines,
            request.source,
            request.prod_sqlite,
            request.dev_sqlite,
            request.tables,
            settings.diff_cap,
            settings.copy_batch_size,
        )
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = f"Compare {verdict} over {len(summaries)} tables: {filename}."
    _record(
        store,
        "pipeline-compare",
        status,
        message,
        {
            "results_db": filename,
            "results_path": os.path.join(engines.sqlite_dir, filename),
            "tables": [asdict(s) for s in summaries],
            "verdict": verdict,
        },
        run_id=run_id,
    )
    return CompareOut(
        run_id=run_id,
        status=status,
        verdict=verdict,
        message=message,
        results_db=filename,
        tables=[TableSummaryOut(**asdict(s)) for s in summaries],
    )


@app.get("/pipeline/compare/{run_id}", dependencies=[Depends(require_api_key)])
def get_compare(
    run_id: str,
    store: Annotated[RunStore, Depends(get_run_store)],
    table: str | None = None,
    status: str | None = None,
    limit: int = Query(default=200, ge=1, le=5000),
) -> dict:
    """Read a compare run's results back. The file comes from the run
    record, never from the request, so a caller cannot point this at
    an arbitrary file."""
    record = store.get_run(run_id)
    if record is None or record.run_type != "pipeline-compare":
        raise HTTPException(status_code=404, detail=f"No pipeline compare run with id {run_id!r}.")
    summary = json.loads(record.summary_json) if record.summary_json else {}
    filename = summary.get("results_db")
    if not filename:
        raise HTTPException(
            status_code=404, detail="This compare run has no results file recorded."
        )
    path = summary.get("results_path") or os.path.join(settings.sqlite_dir, filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail=f"Results file not found: {filename}.")
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    try:
        tables = [
            dict(r)
            for r in conn.execute(
                "SELECT table_name, status, prod_count, dev_count, matched, different, "
                "only_in_prod, only_in_dev, diff_rows_stored, message FROM table_summary "
                "WHERE run_id = ? ORDER BY table_name",
                (run_id,),
            )
        ]
        query = (
            "SELECT table_name, status, pk_json, differing_columns_json, "
            "prod_values_json, dev_values_json FROM row_diffs WHERE run_id = ?"
        )
        params: list = [run_id]
        if table:
            query += " AND table_name = ?"
            params.append(table)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY table_name, status LIMIT ?"
        params.append(limit)
        diffs = []
        for r in conn.execute(query, params):
            diffs.append(
                RowDiffOut(
                    table=r["table_name"],
                    status=r["status"],
                    pk=json.loads(r["pk_json"]),
                    differing_columns=json.loads(r["differing_columns_json"]),
                    prod_values=json.loads(r["prod_values_json"]),
                    dev_values=json.loads(r["dev_values_json"]),
                ).model_dump()
            )
        return {
            "run_id": run_id,
            "verdict": summary.get("verdict"),
            "results_db": filename,
            "tables": tables,
            "diffs": diffs,
        }
    finally:
        conn.close()


@app.get("/pipeline/compare-runs", dependencies=[Depends(require_api_key)])
def list_compare_runs(
    store: Annotated[RunStore, Depends(get_run_store)], limit: int = Query(default=50, ge=1, le=200)
) -> list[dict]:
    out = []
    for record in store.list_runs(run_type="pipeline-compare", limit=limit):
        summary = json.loads(record.summary_json) if record.summary_json else {}
        out.append(
            {
                "run_id": record.id,
                "status": record.status,
                "message": record.message,
                "started_at": record.started_at,
                "finished_at": record.finished_at,
                "verdict": summary.get("verdict"),
                "results_db": summary.get("results_db"),
            }
        )
    return out

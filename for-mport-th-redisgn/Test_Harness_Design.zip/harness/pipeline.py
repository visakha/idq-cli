"""Pipeline steps A-F. Rules only; row movement lives in Store,
comparison lives in compare.py.

Overall status: COMPLETED (every table ok), PARTIAL (some ok),
FAILED (none ok). A validation failure (unknown source/table/
workflow, whitelist refusal, prod==dev) raises BEFORE anything is
written. A per-table failure is recorded and the run continues --
one bad table must not hide the other tables' results.

Step A is a precondition, not a job: the readiness() check reports
table existence and row counts on the Prod side. It proves the
tables are there, not that the 8 AM ETL actually ran -- confirm
that by hand, as before. There is deliberately no scheduler here:
a cron that silently copies stale data is worse than a human
checking readiness first.
"""

from __future__ import annotations

import contextlib
import os
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from harness import compare as compare_engine
from harness.catalog import TableDef, get_source, stage_workflows, tables_for
from harness.compare import TableSummary
from harness.config import Settings
from harness.store import Store
from harness.whitelist import load_whitelist, not_whitelisted


@dataclass
class Engines:
    """The three pipeline sides, plus where steps write files."""

    prod: Engine
    dev: Engine
    snowflake: Engine
    sqlite_dir: str
    snowflake_schema: str
    demo_mode: bool
    prod_label: str  # URL in real mode, file path in demo mode
    dev_label: str

    def dispose(self) -> None:
        for engine in (self.prod, self.dev, self.snowflake):
            with contextlib.suppress(Exception):
                engine.dispose()


@dataclass
class TableResult:
    table: str
    kind: str
    status: str  # COPIED | LOADED | FAILED | NOT_FOUND | SKIPPED_MISSING
    source_rows: int | None = None
    target_rows: int | None = None
    message: str = ""


@dataclass
class ReadinessRow:
    table: str
    kind: str
    exists: bool
    row_count: int | None
    message: str = ""


def timestamp() -> str:
    return datetime.now(UTC).strftime("%Y%m%d_%H%M%S")


def resolve_file(sqlite_dir: str, filename: str, must_exist: bool) -> str:
    """Resolve a bare filename inside sqlite_dir. Paths are rejected:
    a request must never escape the directory."""
    if not filename or filename != os.path.basename(filename) or filename in (".", ".."):
        raise ValueError(
            f"Invalid SQLite filename: {filename!r}. Give a bare filename "
            "inside the pipeline SQLite directory, not a path."
        )
    path = os.path.join(sqlite_dir, filename)
    if must_exist and not os.path.exists(path):
        raise ValueError(
            f"SQLite file not found in the pipeline directory: {filename!r}. "
            "Run the step that produces it first."
        )
    return path


def _overall(results: list[TableResult]) -> str:
    ok = {"COPIED", "LOADED"}
    statuses = {r.status for r in results}
    if statuses and statuses <= ok:
        return "COMPLETED"
    if statuses & ok:
        return "PARTIAL"
    return "FAILED"


def _copy_tables(
    source: Store,
    source_schema: str | None,
    target: Store,
    target_schema: str | None,
    tables: list[TableDef],
    clear_first: bool,
    verb: str,
    batch_size: int,
) -> list[TableResult]:
    results: list[TableResult] = []
    for spec in tables:
        src_schema = source.schema_for(spec, source_schema)
        tgt_schema = target.schema_for(spec, target_schema)
        if not source.exists(spec, src_schema):
            results.append(
                TableResult(
                    spec.name,
                    spec.kind,
                    "NOT_FOUND",
                    message=f"Table {spec.name} does not exist on the source side.",
                )
            )
            continue
        try:
            source_rows = source.count(spec, src_schema)
            target.ensure(spec, tgt_schema)
            if clear_first:
                target.clear(spec, tgt_schema)
            copied = 0
            for batch in source.stream(spec, src_schema, batch_size):
                target.insert(spec, tgt_schema, batch)
                copied += len(batch)
            target_rows = target.count(spec, tgt_schema)
            if target_rows == source_rows and copied == source_rows:
                results.append(
                    TableResult(
                        spec.name,
                        spec.kind,
                        verb,
                        source_rows,
                        target_rows,
                        f"{verb} {source_rows} rows.",
                    )
                )
            else:
                results.append(
                    TableResult(
                        spec.name,
                        spec.kind,
                        "FAILED",
                        source_rows,
                        target_rows,
                        f"Row-count mismatch: source={source_rows}, "
                        f"streamed={copied}, target={target_rows}.",
                    )
                )
        except Exception as exc:
            results.append(
                TableResult(spec.name, spec.kind, "FAILED", message=f"{type(exc).__name__}: {exc}")
            )
    return results


def readiness(engines: Engines, source: str) -> tuple[bool, str, list[ReadinessRow]]:
    """Step A check: do all input + output tables exist in Production?"""
    spec = get_source(source)
    store = Store(engines.prod)
    rows: list[ReadinessRow] = []
    missing: list[str] = []
    for table in spec.all_tables:
        schema = store.schema_for(table, None)
        exists = store.exists(table, schema)
        count = store.count(table, schema) if exists else None
        if not exists:
            missing.append(table.name)
        rows.append(
            ReadinessRow(
                table.name,
                table.kind,
                exists,
                count,
                "" if exists else "Table does not exist on the Prod side.",
            )
        )
    ready = not missing
    message = (
        f"Production is ready for {spec.source}: all {len(rows)} tables exist."
        if ready
        else f"Production is NOT ready for {spec.source}: {len(missing)} table(s) missing: "
        + ", ".join(missing)
    )
    return ready, message, rows


def prod_to_sqlite(
    engines: Engines, source: str, requested: list[str] | None, batch_size: int
) -> tuple[list[TableResult], str, str]:
    """Step B: Oracle Production -> fresh Prod_SQLite file."""
    spec = get_source(source)
    tables = tables_for(source, None, requested)
    if not tables:
        raise ValueError(f"No tables registered for {spec.source} yet. Register them first.")
    os.makedirs(engines.sqlite_dir, exist_ok=True)
    filename = f"prod_{spec.source}_{timestamp()}.db"
    path = os.path.join(engines.sqlite_dir, filename)
    if os.path.exists(path):
        os.remove(path)
    sqlite = Store(create_engine(f"sqlite:///{path}"))
    try:
        results = _copy_tables(
            Store(engines.prod),
            None,
            sqlite,
            None,
            tables,
            clear_first=False,
            verb="COPIED",
            batch_size=batch_size,
        )
    finally:
        sqlite.engine.dispose()
    return results, _overall(results), filename


def sqlite_to_dev(
    engines: Engines,
    source: str,
    prod_file: str,
    requested: list[str] | None,
    whitelist_path: str,
    batch_size: int,
) -> tuple[list[TableResult], str]:
    """Step C: Prod_SQLite -> Dev Oracle, truncating ONLY whitelisted tables."""
    if engines.prod_label == engines.dev_label:
        raise ValueError(
            "Refusing to run: Prod and Dev connections are identical. "
            "Step C truncates Dev tables; it must never run against Production."
        )
    allowed = load_whitelist(whitelist_path)
    tables = tables_for(source, None, requested)
    offenders = not_whitelisted([t.name for t in tables], allowed)
    if offenders:
        raise ValueError(
            f"Refusing to truncate: these tables are NOT in the whitelist file "
            f"({whitelist_path}): {', '.join(offenders)}. Add them to the file "
            "first, or remove them from the request. Nothing was truncated."
        )
    prod_path = resolve_file(engines.sqlite_dir, prod_file, must_exist=True)
    sqlite = Store(create_engine(f"sqlite:///{prod_path}"))
    dev = Store(engines.dev)
    try:
        results: list[TableResult] = []
        for table in tables:
            dev_schema = dev.schema_for(table, None)
            if not dev.exists(table, dev_schema):
                results.append(
                    TableResult(
                        table.name,
                        table.kind,
                        "NOT_FOUND",
                        message=f"Table {table.name} does not exist in Dev. "
                        "Create it there first; step C never creates Dev tables.",
                    )
                )
                continue
            results.extend(
                _copy_tables(
                    sqlite,
                    None,
                    dev,
                    None,
                    [table],
                    clear_first=True,
                    verb="LOADED",
                    batch_size=batch_size,
                )
            )
        return results, _overall(results)
    finally:
        sqlite.engine.dispose()


def run_etl(
    engines: Engines, source: str, workflows: list[str] | None, reset_outputs: bool
) -> tuple[list[dict], str, dict]:
    """Step D: run the Snowflake ETL for a source in Dev.

    A failure stops later workflows (later ones report NOT_RUN).
    In demo mode the simulator runs instead, and the response says
    so, so a demo run can never be mistaken for a real one.
    """
    spec = get_source(source)
    keys = workflows if workflows is not None else stage_workflows(source)
    if not keys:
        raise ValueError(f"No workflows registered for {spec.source}.")
    unknown = [k for k in keys if k not in spec.runners]
    if unknown:
        raise ValueError(
            f"Unknown workflow(s) for {spec.source}: {unknown}. Allowed: {sorted(spec.runners)}"
        )
    if engines.demo_mode:
        from harness import demo

        counts = demo.simulate(Store(engines.dev), Store(engines.snowflake))
        note = str(counts.pop("_note", ""))
        detail = "; ".join(f"{t}: {n} rows" for t, n in counts.items())
        return (
            [
                {
                    "workflow": "(demo-simulator)",
                    "status": "COMPLETED",
                    "message": note + " " + detail,
                }
            ],
            "COMPLETED",
            counts,
        )
    snow = Store(engines.snowflake)
    results: list[dict] = []
    if reset_outputs:
        for table in spec.outputs:
            try:
                snow.clear(table, engines.snowflake_schema)
            except Exception as exc:
                return (
                    [
                        {
                            "workflow": "(reset-outputs)",
                            "status": "FAILED",
                            "message": f"Could not truncate Dev output table {table.name}: {exc}",
                        }
                    ],
                    "FAILED",
                    {},
                )
        results.append(
            {
                "workflow": "(reset-outputs)",
                "status": "CLEARED",
                "message": f"Truncated {len(spec.outputs)} Dev output tables in "
                f"{engines.snowflake_schema} before running.",
            }
        )
    summaries: dict = {}
    for key in keys:
        proc = spec.runners[key]
        try:
            text_out = snow.call_procedure(engines.snowflake_schema, proc)
            summaries[key] = text_out
            results.append(
                {"workflow": key, "procedure": proc, "status": "COMPLETED", "message": text_out}
            )
        except Exception as exc:
            results.append(
                {
                    "workflow": key,
                    "procedure": proc,
                    "status": "FAILED",
                    "message": f"{type(exc).__name__}: {exc}",
                }
            )
            for rest in keys[keys.index(key) + 1 :]:
                results.append(
                    {
                        "workflow": rest,
                        "procedure": spec.runners[rest],
                        "status": "NOT_RUN",
                        "message": "Not started because an earlier workflow failed.",
                    }
                )
            return results, "FAILED", summaries
    return results, "COMPLETED", summaries


def snowflake_to_sqlite(
    engines: Engines,
    source: str,
    requested: list[str] | None,
    include_inputs: bool,
    batch_size: int,
) -> tuple[list[TableResult], str, str]:
    """Step E: Snowflake Dev -> fresh Dev_SQLite file (outputs by default)."""
    kinds = ["output"] + (["input"] if include_inputs else [])
    tables = tables_for(source, kinds, requested)
    if not tables:
        raise ValueError(f"No tables registered for {get_source(source).source} yet.")
    os.makedirs(engines.sqlite_dir, exist_ok=True)
    filename = f"dev_{get_source(source).source}_{timestamp()}.db"
    path = os.path.join(engines.sqlite_dir, filename)
    if os.path.exists(path):
        os.remove(path)
    sqlite = Store(create_engine(f"sqlite:///{path}"))
    try:
        results = _copy_tables(
            Store(engines.snowflake),
            engines.snowflake_schema,
            sqlite,
            None,
            tables,
            clear_first=False,
            verb="COPIED",
            batch_size=batch_size,
        )
    finally:
        sqlite.engine.dispose()
    return results, _overall(results), filename


def compare_sqlites(
    engines: Engines,
    source: str,
    prod_file: str,
    dev_file: str,
    requested: list[str] | None,
    diff_cap: int,
    batch_size: int,
) -> tuple[list[TableSummary], str, str, str, str]:
    """Step F: Prod_SQLite vs Dev_SQLite -> Compare_Results_SQLite.

    One run id everywhere: the control-store run id, the results
    DB's run id, and part of the results filename, so the read-back
    endpoint always finds the diff rows it recorded.
    """
    spec = get_source(source)
    tables = tables_for(source, ["output"], requested)
    if not tables:
        raise ValueError(f"No output tables registered for {spec.source} yet.")
    prod_path = resolve_file(engines.sqlite_dir, prod_file, must_exist=True)
    dev_path = resolve_file(engines.sqlite_dir, dev_file, must_exist=True)
    os.makedirs(engines.sqlite_dir, exist_ok=True)
    run_id = f"{spec.source}_{timestamp()}_{uuid.uuid4().hex[:6]}"
    filename = f"compare_{run_id}.db"
    results_path = os.path.join(engines.sqlite_dir, filename)
    if os.path.exists(results_path):
        os.remove(results_path)
    compare_engine.create_results_db(results_path)
    prod = Store(create_engine(f"sqlite:///{prod_path}"))
    dev = Store(create_engine(f"sqlite:///{dev_path}"))
    try:
        summaries, verdict, message = compare_engine.compare_tables(
            prod,
            dev,
            tables,
            results_path,
            run_id,
            spec.source,
            prod_file,
            dev_file,
            started_at=datetime.now(UTC).isoformat(timespec="seconds"),
            diff_cap=diff_cap,
            batch_size=batch_size,
        )
    finally:
        prod.engine.dispose()
        dev.engine.dispose()
    status = "COMPLETED" if verdict in ("MATCH", "MISMATCH") else "PARTIAL"
    return summaries, verdict, status, filename, run_id


def build_engines(cfg: Settings) -> Engines:
    """Build the three engines from settings (no caching: tests flip
    settings between requests, and a cached engine would silently
    keep the old database). Creating an engine opens no connection
    until first use, so per-request construction costs nothing."""
    if cfg.demo_mode:
        paths = {
            "prod": os.path.join(cfg.demo_dir, "demo_prod.db"),
            "dev": os.path.join(cfg.demo_dir, "demo_dev_oracle.db"),
            "snowflake": os.path.join(cfg.demo_dir, "demo_snowflake.db"),
        }
        missing = [p for p in paths.values() if not os.path.exists(p)]
        if missing:
            raise RuntimeError(
                "Demo mode is on but demo database file(s) are missing: "
                + ", ".join(missing)
                + ". Build them first with: python scripts/seed_demo.py"
            )
        return Engines(
            create_engine(f"sqlite:///{paths['prod']}"),
            create_engine(f"sqlite:///{paths['dev']}"),
            create_engine(f"sqlite:///{paths['snowflake']}"),
            cfg.sqlite_dir,
            "",
            True,
            paths["prod"],
            paths["dev"],
        )
    if not cfg.oracle_prod_url or not cfg.oracle_dev_url:
        raise RuntimeError(
            "Oracle URLs are not configured: set ORACLE_PROD_URL and "
            "ORACLE_DEV_URL (or run with DEMO_MODE=true for the SQLite demo)."
        )
    if not cfg.snowflake_account or not cfg.snowflake_user:
        raise RuntimeError(
            "Snowflake Dev is not configured: set SNOWFLAKE_ACCOUNT and "
            "SNOWFLAKE_USER (plus authenticator/token or password)."
        )
    url = (
        f"snowflake://{cfg.snowflake_user}@{cfg.snowflake_account}/"
        f"{cfg.snowflake_database}/{cfg.snowflake_schema}"
    )
    connect_args: dict[str, str] = {}
    if cfg.snowflake_authenticator:
        connect_args["authenticator"] = cfg.snowflake_authenticator
    if cfg.snowflake_oauth_token:
        connect_args["token"] = cfg.snowflake_oauth_token
    if cfg.snowflake_password:
        connect_args["password"] = cfg.snowflake_password
    if cfg.snowflake_warehouse:
        connect_args["warehouse"] = cfg.snowflake_warehouse
    if cfg.snowflake_role:
        connect_args["role"] = cfg.snowflake_role
    return Engines(
        create_engine(cfg.oracle_prod_url),
        create_engine(cfg.oracle_dev_url),
        create_engine(url, connect_args=connect_args),
        cfg.sqlite_dir,
        cfg.snowflake_schema or "",
        False,
        cfg.oracle_prod_url,
        cfg.oracle_dev_url,
    )

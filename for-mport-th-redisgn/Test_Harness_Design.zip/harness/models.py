"""API models. Pydantic only, no ORM. Every endpoint's contract is
typed and visible in /docs; file arguments are bare filenames
(the service resolves them inside the SQLite directory).
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class ProdToSqliteRequest(BaseModel):
    source: str = "TRS"
    tables: list[str] | None = Field(default=None, description="None = all input + output tables")


class SqliteToDevRequest(BaseModel):
    source: str = "TRS"
    prod_sqlite: str = Field(description="Prod_SQLite filename from step B")
    tables: list[str] | None = Field(
        default=None, description="None = all registry tables (all must be whitelisted)"
    )


class RunEtlRequest(BaseModel):
    source: str = "TRS"
    workflows: list[str] | None = Field(
        default=None, description="None = stage-load runners in order"
    )
    reset_outputs: bool = Field(
        default=False, description="Truncate Dev output tables before running"
    )


class SnowflakeToSqliteRequest(BaseModel):
    source: str = "TRS"
    tables: list[str] | None = Field(default=None, description="None = all output tables")
    include_inputs: bool = False


class CompareRequest(BaseModel):
    source: str = "TRS"
    prod_sqlite: str = Field(description="Prod_SQLite filename from step B")
    dev_sqlite: str = Field(description="Dev_SQLite filename from step E")
    tables: list[str] | None = Field(default=None, description="None = all output tables")


class TableResultOut(BaseModel):
    table: str
    kind: str = ""
    status: str
    source_rows: int | None = None
    target_rows: int | None = None
    message: str = ""


class RunOut(BaseModel):
    run_id: str
    run_type: str
    status: str
    message: str = ""
    results: object = []
    sqlite_path: str | None = None
    results_db: str | None = None


class TableSummaryOut(BaseModel):
    table: str
    status: str
    prod_count: int | None = None
    dev_count: int | None = None
    matched: int = 0
    different: int = 0
    only_in_prod: int = 0
    only_in_dev: int = 0
    diff_rows_stored: int = 0
    message: str = ""


class CompareOut(BaseModel):
    run_id: str
    status: str
    verdict: str
    message: str = ""
    results_db: str | None = None
    tables: list[TableSummaryOut] = []


class ReadinessRowOut(BaseModel):
    table: str
    kind: str
    exists: bool
    row_count: int | None = None
    message: str = ""


class ReadinessOut(BaseModel):
    source: str
    ready: bool
    message: str = ""
    tables: list[ReadinessRowOut] = []


class SourceOut(BaseModel):
    source: str
    runners: dict[str, str] = {}
    input_tables: list[str] = []
    output_tables: list[str] = []


class RowDiffOut(BaseModel):
    table: str
    status: str
    pk: dict = {}
    differing_columns: list[str] = []
    prod_values: dict = {}
    dev_values: dict = {}

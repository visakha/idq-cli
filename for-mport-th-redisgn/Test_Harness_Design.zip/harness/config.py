"""Settings. One place, one source: the environment.

Nothing here connects to anything. A missing URL in real mode is a
configuration error at request time, never a silent fallback to a
demo database: demo mode is an explicit switch (DEMO_MODE=true).
"""

from __future__ import annotations

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """All settings. Defaults are for local/demo use only."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    api_key: str | None = None
    control_db_url: str = "sqlite:///./harness_runs.db"

    # Demo mode: all three sides are SQLite files under demo_dir.
    demo_mode: bool = False
    demo_dir: str = "./demo"
    # Directory for prod_*.db, dev_*.db, compare_*.db files.
    sqlite_dir: str = "./pipeline_data"

    # Real mode: full SQLAlchemy URLs. Prod is read-only to this
    # API (it is never written); Dev is truncated and loaded.
    oracle_prod_url: str | None = None
    oracle_dev_url: str | None = None

    # Whitelist for step C: only these Dev tables may be truncated.
    whitelist_path: str = "./config/White_list_tables_safe_to_truncate.txt"

    # Snowflake Dev (also used for SSO-style auth in real mode).
    snowflake_account: str = ""
    snowflake_user: str = ""
    snowflake_password: str | None = None
    snowflake_authenticator: str = "snowflake"
    snowflake_oauth_token: str | None = None
    snowflake_warehouse: str = ""
    snowflake_role: str = ""
    snowflake_source: str = "TRS"
    snowflake_database: str | None = None
    snowflake_schema: str | None = None

    copy_batch_size: int = 5000
    diff_cap: int = 10000

    @model_validator(mode="after")
    def _derive_snowflake_names(self) -> Settings:
        source = (self.snowflake_source or "TRS").upper()
        if self.snowflake_database is None:
            self.snowflake_database = f"MDM_ETL_{source}"
        if self.snowflake_schema is None:
            self.snowflake_schema = f"{source}_ETL_WRK"
        return self


settings = Settings()

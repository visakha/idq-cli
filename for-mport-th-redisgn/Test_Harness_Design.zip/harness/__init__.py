"""Test harness package: typed, SQLAlchemy Core only, no ORM.

Modules, in dependency order (nothing imports sideways):
  config   -- settings from the environment, nothing else
  catalog  -- the registry: tables, columns, PKs, runner allowlist
  store    -- one Store class that moves rows between engines
  whitelist-- the step-C safety file
  runs     -- audit trail (control store), Core table only
  compare  -- record-by-record merge + results-file schema
  pipeline -- steps A-F: rules only, no SQL of its own
  engines  -- build the three engines from settings
  demo     -- DEMO ONLY data + simulator (never used in real mode)
  api      -- FastAPI routes: thin, validate -> service -> record
"""

from __future__ import annotations

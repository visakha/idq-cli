"""Registry: the single source of truth for tables and runners.

A tester reads this file to know what the harness will touch. That
is why it is data, not logic:

  * TableDef: name, kind ("input" | "output"), Oracle schema,
    columns as (name, SQLAlchemy type) pairs, and the compare PK.
    Columns are explicit code, never reflected from a database, and
    every copy SELECTs them by name (no SELECT *): Prod Oracle
    tables do not carry the v5 DATA_SOURCE discriminator, so a
    SELECT * copy would break the moment a side gains a column.
  * SourceDef: a source's runners (workflow key -> procedure) and
    its tables. Runners are an allowlist: step D accepts keys, never
    a raw procedure name from a request.

Scope, stated honestly: TRS is registered as a vertical slice --
5 inputs and 5 outputs with real names and real column lists, enough
to run the whole flow and to show every compare status. The other
sources carry their real stage-load runner procedures and empty
table lists. That is deliberate: their Oracle column lists were not
part of this delivery, and inventing them would be worse than
leaving them blank. A request for an unregistered source's tables
returns a 400 naming the gap, never an empty run pretending to
have compared something. Adding tables is a data change (§9 of the
user guide): one TableDef, one whitelist line, one test row.

The ZZ table's columns are SAMPLE columns (the deactivation
workflows' ZZ tables were not in the supplied exports). Replace
them with the real Oracle DDL columns before production use.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sqlalchemy import Date, Integer, Numeric, String
from sqlalchemy.types import TypeEngine

Col = tuple[str, TypeEngine]


def s(n: int = 255) -> String:
    return String(n)


def i() -> Integer:
    return Integer()


def num() -> Numeric:
    return Numeric(38, 0)


def d() -> Date:
    return Date()


@dataclass(frozen=True)
class TableDef:
    name: str
    kind: str  # "input" | "output"
    oracle_schema: str | None
    columns: list[Col]
    pk: list[str] = field(default_factory=list)  # empty = copy only, never compare

    @property
    def column_names(self) -> list[str]:
        return [name for name, _ in self.columns]


@dataclass
class SourceDef:
    source: str
    runners: dict[str, str] = field(default_factory=dict)
    inputs: list[TableDef] = field(default_factory=list)
    outputs: list[TableDef] = field(default_factory=list)

    @property
    def all_tables(self) -> list[TableDef]:
        return self.inputs + self.outputs


# --- TRS inputs (vertical slice; derivation needs these columns) ---
_TRS_INPUTS: list[TableDef] = [
    TableDef(
        "STG_TRS_D_DC_INDV",
        "input",
        "STAGING",
        [
            ("INDV_ID", i()),
            ("FIRST_NAME", s(50)),
            ("LAST_NAME", s(50)),
            ("GENDER_CD", s(10)),
            ("DOB_DT", d()),
            ("INACTIVE_IND", s(1)),
            ("DELETE_SW", s(1)),
        ],
    ),
    TableDef(
        "STG_TRS_D_INDV_ADDR",
        "input",
        "STAGING",
        [
            ("INDV_ID", i()),
            ("ADDR_LINE", s(100)),
            ("ADDR_CITY", s(50)),
            ("ADDR_STATE_CD", s(10)),
            ("ADDR_ZIP5", s(10)),
            ("ADDR_TYPE_CD", s(20)),
            ("EFF_BEGIN_DT", d()),
        ],
    ),
    TableDef(
        "STG_TRS_H_DC_INDV",
        "input",
        "STAGING",
        [
            ("INDV_ID", i()),
            ("HISTORY_SEQ", i()),
            ("FIRST_NAME", s(50)),
            ("LAST_NAME", s(50)),
            ("GENDER_CD", s(10)),
            ("DOB_DT", d()),
            ("INACTIVE_IND", s(1)),
            ("DELETE_SW", s(1)),
        ],
    ),
    TableDef(
        "STG_TRS_D_DC_RELATIONSHIPS",
        "input",
        "STAGING",
        [
            ("INDV_ID", i()),
            ("REF_INDV_ID", i()),
            ("HISTORY_SEQ", i()),
            ("RELATIONSHIP_TYPE_CD", s(20)),
            ("EFF_BEGIN_DT", d()),
        ],
    ),
    TableDef(
        "LOOKUP_CODE_VALUE",
        "input",
        "STAGING",
        [
            ("CODE_TYPE", s(50)),
            ("SRC_SYS", s(20)),
            ("SRC_CODE_VALUE", s(50)),
            ("MSTR_REF_CODE", s(50)),
            ("MSTR_REF_LABEL", s(100)),
        ],
    ),
]

# --- TRS outputs (real column lists, DATA_SOURCE excluded: it does
# not exist in Oracle Production) ---
_TRS_OUTPUTS: list[TableDef] = [
    TableDef(
        "C_S_TRS_PTY",
        "output",
        "HHS_MDM",
        [
            ("PKEY_SRC_OBJECT", s()),
            ("ROWID_OBJECT", s(14)),
            ("DELETED_IND", num()),
            ("DELETED_DATE", d()),
            ("DELETED_BY", s(50)),
            ("PERIOD_START_DATE", d()),
            ("PERIOD_END_DATE", d()),
            ("VERSION_SEQ", i()),
            ("PERIOD_REFERENCE_TIME", d()),
            ("TIMELINE_ACTION", i()),
            ("LAST_UPDATE_DATE", d()),
            ("UPDATED_BY", s(50)),
            ("CREATE_DATE", d()),
            ("CREATOR", s(50)),
            ("SRC_ROWID", s(14)),
            ("HUB_STATE_IND", num()),
            ("PTY_BO_CLASS_CD", s(20)),
            ("PRFX_NM", s(20)),
            ("FRST_NM", s(50)),
            ("MDL_NM", s(50)),
            ("LST_NM", s(50)),
            ("SFX_NM", s(20)),
            ("FULL_NM", s(200)),
            ("GNDR_CD", s(10)),
            ("BIRTH_DT", d()),
            ("DEATH_DT", d()),
            ("FLAG_SRC", s(20)),
            ("SRC_FULL_NM", s(200)),
            ("SRC_LAST_UPD_DT", d()),
            ("ETHNCTY", s(20)),
            ("SRC_RACE_CD", s(20)),
            ("SRC_ETHNCTY", s(20)),
            ("RACE_CD", s(20)),
        ],
        pk=["PKEY_SRC_OBJECT"],
    ),
    TableDef(
        "C_S_TRS_PTY_RLE_PHN",
        "output",
        "HHS_MDM",
        [
            ("PKEY_SRC_OBJECT", s()),
            ("ROWID_OBJECT", s(14)),
            ("DELETED_IND", num()),
            ("DELETED_DATE", d()),
            ("DELETED_BY", s(50)),
            ("PERIOD_START_DATE", d()),
            ("PERIOD_END_DATE", d()),
            ("VERSION_SEQ", i()),
            ("PERIOD_REFERENCE_TIME", d()),
            ("TIMELINE_ACTION", i()),
            ("LAST_UPDATE_DATE", d()),
            ("UPDATED_BY", s(50)),
            ("CREATE_DATE", d()),
            ("CREATOR", s(50)),
            ("SRC_ROWID", s(14)),
            ("HUB_STATE_IND", num()),
            ("PTY_RLE_FK", s(14)),
            ("PHN_TP", s(20)),
            ("USG_TP", s(20)),
            ("PHN_NUM", s(50)),
            ("PREF_LVL", i()),
            ("SRC_LAST_UPD_DT", d()),
        ],
        pk=["PKEY_SRC_OBJECT"],
    ),
    TableDef(
        "STG_TRS_VALID_MEMBERS",
        "output",
        "STAGING",
        [
            ("INDV_ID", i()),
            ("PTY_PK", s()),
            ("SRC_TBL", s(100)),
            ("CREATE_DATE", d()),
        ],
        pk=["INDV_ID", "SRC_TBL"],
    ),
    TableDef(
        "EXC_STG_BAD_REC_MEMB",
        "output",
        "STAGING",
        [
            ("SRC_SYS", s(20)),
            ("SRC_SYS_ID_1", s(100)),
            ("SRC_SYS_ID_2", s(100)),
            ("SRC_SYS_ID_3", s(100)),
            ("EXCEPTION_TYPE", s(20)),
            ("EXCEPTION_CODE", s(50)),
            ("EXCEPTION_DESC", s(200)),
            ("RUN_DATE", d()),
            ("PREFIX", s(20)),
            ("FIRST_NAME", s(50)),
            ("MIDDLE_NAME", s(50)),
            ("LAST_NAME", s(50)),
            ("SUFFIX", s(20)),
            ("ALIAS_PREFIX", s(20)),
            ("ALIAS_FIRST_NAME", s(50)),
            ("ALIAS_MIDDLE_NAME", s(50)),
            ("ALIAS_LAST_NAME", s(50)),
            ("ALIAS_SUFFIX", s(20)),
            ("BIRTH_DATE", d()),
            ("GENDER", s(10)),
            ("ADDRESS_TYPE", s(20)),
            ("ADDRESS_LINE_1", s(100)),
            ("ADDRESS_LINE_2", s(100)),
            ("ADDRESS_CITY", s(50)),
            ("ADDRESS_COUNTY", s(50)),
            ("ADDRESS_STATE", s(10)),
            ("ADDRESS_ZIP", s(10)),
            ("ADDRESS_ZIP_EXT", s(10)),
            ("ADDRESS_COUNTRY", s(20)),
            ("ADDRESS_DR_ERROR_CODE", s(20)),
            ("ADDRESS_DR_ERROR_DESC", s(200)),
            ("ADDRESS_DR_MAILABILITY_SCORE", s(20)),
            ("PRIMARY_PHONE", s(50)),
            ("WORK_PHONE", s(50)),
            ("SECONDARY_PHONE", s(50)),
            ("EMAIL", s(100)),
            ("ATTRIBUTE_NAME", s(50)),
            ("ATTRIBUTE_VALUE", s(200)),
            ("MAPPING_NAME", s(50)),
            ("PERIOD_START_DATE", d()),
            ("PERIOD_END_DATE", d()),
            ("DEATH_DT", d()),
        ],
        pk=["SRC_SYS_ID_1", "EXCEPTION_CODE", "ATTRIBUTE_NAME", "ATTRIBUTE_VALUE", "MAPPING_NAME"],
    ),
    TableDef(
        "ZZ_UTL_UNMERGE_TREE_SRC_KEY",
        "output",
        "STAGING",
        [
            ("INDV_ID", i()),
            ("SRC_KEY", s()),
            ("TREE_LEVEL", i()),
            ("PROCESSED_YN", s(1)),
        ],
        pk=["INDV_ID"],
    ),
]

SOURCES: dict[str, SourceDef] = {
    "TRS": SourceDef(
        "TRS",
        runners={
            "toa": "sp_etl_run_wf_TRS_Stage_Load_TOA",
            "ongoing": "sp_etl_run_wf_TRS_Stage_Load_1_Ongoing",
            "deactivation-initial": "sp_etl_run_wf_TRS_Deactivation_Initial",
            "deactivation-relationship": "sp_etl_run_wf_TRS_Relationship_Deactivation",
            "deactivation-history": "sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History",
            "deactivation-complete": "sp_etl_run_wf_TRS_Deactivation_Complete",
        },
        inputs=_TRS_INPUTS,
        outputs=_TRS_OUTPUTS,
    ),
    "ECI": SourceDef("ECI", runners={"stage-load": "sp_etl_run_wf_ECI_Stage_Load"}),
    "WIC": SourceDef("WIC", runners={"stage-load": "sp_etl_run_wf_WIC_Stage_Load"}),
    "TTF": SourceDef("TTF", runners={"stage-load": "sp_etl_run_wf_TTF_Stage_Load"}),
    "FSS": SourceDef("FSS", runners={"stage-load": "sp_etl_run_wf_FSS_Stage_Load"}),
    "CRE": SourceDef("CRE", runners={"stage-load": "sp_etl_run_wf_CRE_Stage_Load_Ongoing"}),
}


def get_source(source: str) -> SourceDef:
    """SourceDef for a name (case-insensitive), else KeyError."""
    key = (source or "").upper()
    if key not in SOURCES:
        raise KeyError(f"Unknown source: {source!r}. Known sources: {sorted(SOURCES)}")
    return SOURCES[key]


def tables_for(source: str, kinds: list[str] | None, requested: list[str] | None) -> list[TableDef]:
    """Tables for a step, in registry order. Unknown names are a 400,
    never a name reaching SQL unchecked."""
    spec = get_source(source)
    pool = [t for t in spec.all_tables if kinds is None or t.kind in kinds]
    if requested is None:
        return pool
    by_name = {t.name: t for t in pool}
    unknown = [n for n in requested if n not in by_name]
    if unknown:
        raise KeyError(f"Unknown table(s) for {spec.source} (kind={kinds}): {unknown}")
    return [by_name[n] for n in requested]


def stage_workflows(source: str) -> list[str]:
    """Stage-load runner keys in order (deactivation excluded)."""
    spec = get_source(source)
    return [k for k in spec.runners if not k.startswith("deactivation-")]

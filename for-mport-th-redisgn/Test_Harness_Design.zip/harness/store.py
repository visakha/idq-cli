"""Store: the only place rows move. One class, three dialects.

Rules that make cross-engine copies safe:
  * Tables are built fresh from the catalog on every call. A
    SQLAlchemy Column may belong to only one Table, so Column
    objects are never shared between calls.
  * Every SELECT names its columns explicitly. No SELECT *.
  * Schema is decided here, once: SQLite tables are unqualified
    (a file has no schemas); Oracle uses the catalog's
    oracle_schema; Snowflake uses the caller-supplied schema.
  * TRUNCATE vs DELETE is dialect here too: SQLite has no
    TRUNCATE, so clear() is DELETE there, TRUNCATE elsewhere.
    Both keep DDL and grants intact.
  * Date boundary rule: an ISO date string is coerced to a date
    object on insert (see insert()), so demo data written as
    strings and Oracle DATE values behave identically downstream.
  * exists() probes with COUNT. A permission failure reads as
    missing here, but it cannot hide: the copy that follows fails
    loudly with the real error.
"""

from __future__ import annotations

from collections.abc import Iterator

from sqlalchemy import Column, Date, MetaData, Table, func, select, text
from sqlalchemy.engine import Engine
from sqlalchemy.schema import CreateTable

from harness.catalog import TableDef


def build_table(table: TableDef, schema: str | None) -> Table:
    """A fresh Table for one side of one operation."""
    return Table(
        table.name,
        MetaData(),
        *[Column(name, ctype) for name, ctype in table.columns],
        schema=schema,
    )


class Store:
    """Row operations for one engine. No business rules live here."""

    def __init__(self, engine: Engine) -> None:
        self.engine = engine

    @property
    def dialect(self) -> str:
        return self.engine.dialect.name

    def schema_for(self, table: TableDef, target_schema: str | None) -> str | None:
        if self.dialect == "sqlite":
            return None
        if self.dialect == "oracle":
            return table.oracle_schema
        return target_schema

    def exists(self, table: TableDef, schema: str | None) -> bool:
        tbl = build_table(table, schema)
        try:
            with self.engine.connect() as conn:
                conn.execute(select(func.count()).select_from(tbl))
            return True
        except Exception:
            return False

    def ensure(self, table: TableDef, schema: str | None) -> None:
        """Create the table if the probe says it is missing."""
        if self.exists(table, schema):
            return
        tbl = build_table(table, schema)
        ddl = str(CreateTable(tbl).compile(self.engine))
        with self.engine.begin() as conn:
            conn.execute(text(ddl))

    def count(self, table: TableDef, schema: str | None) -> int:
        tbl = build_table(table, schema)
        with self.engine.connect() as conn:
            value = conn.execute(select(func.count()).select_from(tbl)).scalar()
            return int(value or 0)

    def stream(self, table: TableDef, schema: str | None, batch_size: int) -> Iterator[list[dict]]:
        """Yield row batches in PK order (the compare's merge order)."""
        tbl = build_table(table, schema)
        cols = [tbl.c[name] for name in table.column_names]
        stmt = select(*cols)
        if table.pk:
            stmt = stmt.order_by(*[tbl.c[name] for name in table.pk])
        with self.engine.connect() as conn:
            result = conn.execute(stmt)
            keys = result.keys()
            while True:
                batch = result.fetchmany(batch_size)
                if not batch:
                    break
                yield [dict(zip(keys, row, strict=False)) for row in batch]

    def insert(self, table: TableDef, schema: str | None, rows: list[dict]) -> None:
        if not rows:
            return
        tbl = build_table(table, schema)
        cleaned: list[dict] = []
        for row in rows:
            out: dict = {}
            for col in tbl.columns:
                value = row.get(col.name)
                # Boundary rule: an ISO date string ("1985-03-14") is
                # coerced to a date object here, once, so demo data
                # written as strings and Oracle DATE values behave
                # identically downstream. The compare then normalises
                # dates back to ISO strings on both sides.
                if isinstance(col.type, Date) and isinstance(value, str):
                    from datetime import date as _date

                    value = _date.fromisoformat(value)
                out[col.name] = value
            cleaned.append(out)
        with self.engine.begin() as conn:
            conn.execute(tbl.insert(), cleaned)

    def clear(self, table: TableDef, schema: str | None) -> None:
        tbl = build_table(table, schema)
        sql = (
            f"DELETE FROM {tbl.fullname}"
            if self.dialect == "sqlite"
            else f"TRUNCATE TABLE {tbl.fullname}"
        )
        with self.engine.begin() as conn:
            conn.execute(text(sql))

    def call_procedure(self, schema: str, procedure: str) -> str:
        """CALL a runner in a schema; return its summary text.

        The procedure name comes only from the catalog allowlist,
        never from a request.
        """
        with self.engine.connect() as conn:
            if self.dialect == "snowflake":
                conn.execute(text(f"USE SCHEMA {schema}"))
            row = conn.execute(text(f"CALL {procedure}()")).fetchone()
            if row is None or row[0] is None:
                return ""
            return str(row[0])

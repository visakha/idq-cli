"""Audit trail: the runs table. Core Table only, no ORM.

One row per API run, with the full per-table summary as JSON, so
yesterday's compare is still readable after today's copy. This
table holds job history only -- never ETL data.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, MetaData, String, Table, Text, desc, insert, select, update
from sqlalchemy.engine import Engine


@dataclass
class RunRecord:
    id: str
    run_type: str
    status: str  # COMPLETED | FAILED | PARTIAL | RUNNING
    started_at: datetime
    finished_at: datetime | None
    summary_json: str
    message: str


_METADATA = MetaData()
RUNS = Table(
    "runs",
    _METADATA,
    Column("id", String, primary_key=True),
    Column("run_type", String, nullable=False),
    Column("status", String, nullable=False),
    Column("started_at", DateTime, nullable=False),
    Column("finished_at", DateTime, nullable=True),
    Column("summary_json", Text, nullable=False, default="{}"),
    Column("message", Text, nullable=False, default=""),
)


def _to_record(row: object) -> RunRecord:
    mapping = dict(row._mapping)  # type: ignore[attr-defined]
    return RunRecord(
        id=str(mapping["id"]),
        run_type=str(mapping["run_type"]),
        status=str(mapping["status"]),
        started_at=mapping["started_at"],
        finished_at=mapping["finished_at"],
        summary_json=str(mapping["summary_json"] or "{}"),
        message=str(mapping["message"] or ""),
    )


class RunStore:
    """Job history store."""

    def __init__(self, engine: Engine) -> None:
        self.engine = engine
        _METADATA.create_all(engine)

    def new_run(self, run_id: str, run_type: str) -> RunRecord:
        record = RunRecord(run_id, run_type, "RUNNING", datetime.now(UTC), None, "{}", "")
        with self.engine.begin() as conn:
            conn.execute(
                insert(RUNS).values(
                    id=record.id,
                    run_type=record.run_type,
                    status=record.status,
                    started_at=record.started_at,
                    finished_at=None,
                    summary_json="{}",
                    message="",
                )
            )
        return record

    def finish_run(
        self, record: RunRecord, status: str, message: str, summary: object
    ) -> RunRecord:
        finished = RunRecord(
            record.id,
            record.run_type,
            status,
            record.started_at,
            datetime.now(UTC),
            json.dumps(summary, default=str),
            message,
        )
        with self.engine.begin() as conn:
            conn.execute(
                update(RUNS)
                .where(RUNS.c.id == record.id)
                .values(
                    status=status,
                    finished_at=finished.finished_at,
                    summary_json=finished.summary_json,
                    message=message,
                )
            )
        return finished

    def get_run(self, run_id: str) -> RunRecord | None:
        with self.engine.connect() as conn:
            row = conn.execute(select(RUNS).where(RUNS.c.id == run_id)).fetchone()
            return _to_record(row) if row is not None else None

    def list_runs(self, run_type: str | None = None, limit: int = 50) -> list[RunRecord]:
        stmt = select(RUNS).order_by(desc(RUNS.c.started_at)).limit(limit)
        if run_type is not None:
            stmt = stmt.where(RUNS.c.run_type == run_type)
        with self.engine.connect() as conn:
            return [_to_record(row) for row in conn.execute(stmt)]

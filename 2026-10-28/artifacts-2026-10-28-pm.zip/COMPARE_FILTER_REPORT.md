# COMPARE-FILTER — VIEW-CUTOVER §4b built (Compare v5.4.1)

Keyword: **COMPARE-FILTER**. User-approved build (2026-10-28),
implementing VIEW-CUTOVER_NOTES.md §4b exactly as specified.
The headline verdict stands and is not reopened here: Compare
is **NOT** moved to `V_CMP_*` views. Compare stays on tables
split by the `DATA_SOURCE` discriminator (`'IDQ'` vs
`'SNOWFLAKE'`).

## What changed (4 files, all in the patched copy)

Patched tree: `workspace/trs_compare_filter/` (complete,
runnable copy of v5.4.0). The original tree
`workspace/trs_compare/` was **not modified** — verified by
`diff -rq`: the only differences between the trees are the
four files below (plus the new test file). No existing zip
was touched.

### 1. `app/domain/tables.py` — 4 flag columns, additive

All 13 `C_S_*` entries in `COLUMN_TYPES` gained the same 4
columns, appended **last** (after `DATA_SOURCE`, which was
previously last in every one of the 13 blocks), so no existing
column moved and none was removed (diff: 52 added lines,
0 removed lines):

```python
('SPINE_FILTERED_YN', String(1)),
('SPINE_FILTER_REASON', String()),
('NONSPINE_FILTERED_YN', String(1)),
('NONSPINE_FILTER_REASON', String()),
```

Tables: `C_S_LU_TOA`, `C_S_TRS_PTY`, `C_S_TRS_PTY_MNG_ATTR`,
`C_S_TRS_PTY_NM`, `C_S_TRS_PTY_RLE`, `C_S_TRS_PTY_RLE_ADDR`,
`C_S_TRS_PTY_RLE_ALT_ID`, `C_S_TRS_PTY_RLE_EADDR`,
`C_S_TRS_PTY_RLE_PHN`, `C_S_TRS_PTY_RLE_PLN`,
`C_S_TRS_PTY_RLE_REL`, `C_S_TRS_PTY_RLE_REL_PROV`,
`C_S_TRS_PTY_RLE_TOA`.

Type note: `String(1)` for the `*_YN` columns (values are
`'Y'`/`'N'`/NULL); unbounded `String()` for the reasons,
matching the v3 01c ALTERs (`VARCHAR` unbounded). No non-`C_S_*`
table gained flag columns (asserted by test).

Why all 13, including `C_S_LU_TOA`: the v3 01c ALTER file
adds the 4 flag columns to `C_S_LU_TOA` too, so it is
flag-bearing in a 01c-applied schema and the gate is safe
for it. If a deployment has NOT applied 01c to some table,
reads against that table will fail on the missing column —
that is the prerequisite below, not something this code
papers over.

### 2. `app/repositories/snowflake_repository.py` — the gate

Two helpers, then one two-line insertion in each of the four
read methods (`count_rows`, `distinct_count`,
`key_difference`, `coverage_count`):

```python
def _spine_gate_applies(table, discriminator):
    return (
        discriminator is not None
        and discriminator == settings.discriminator_snowflake_value  # 'SNOWFLAKE'
        and table.name.startswith("C_S_")
    )

def _apply_spine_gate(stmt, table):
    return stmt.where(
        or_(table.c.SPINE_FILTERED_YN.is_(None),
            table.c.SPINE_FILTERED_YN == "N")
    )
```

Before (each method, e.g. `count_rows`):

```python
stmt = select(func.count()).select_from(table)
if discriminator is not None:
    stmt = stmt.where(table.c.DATA_SOURCE == discriminator)
```

After:

```python
stmt = select(func.count()).select_from(table)
if discriminator is not None:
    stmt = stmt.where(table.c.DATA_SOURCE == discriminator)
if _spine_gate_applies(table, discriminator):
    stmt = _apply_spine_gate(stmt, table)
```

In `key_difference` the gate is applied **per side**:
`left_stmt` gated only if the left discriminator is
SNOWFLAKE, `right_stmt` only if the right discriminator is
SNOWFLAKE — so in the usual same-table IDQ-vs-SNOWFLAKE
call, exactly the SNOWFLAKE side is gated and the IDQ side
never is. The discriminator value is read from
`settings.discriminator_snowflake_value` (default
`'SNOWFLAKE'`), not hard-coded, so a deployment that renames
the discriminator value still gates the right side.

Deliberately NOT gated: `truncate`, `insert_rows`, and
`delete_discriminator_rows`. The ETL clear step must delete
the whole SNOWFLAKE side, flagged rows included; gating a
delete would leak flagged rows across re-runs. No verdict,
key-set, version-set, spine-definition, or `DATA_SOURCE`
logic changed anywhere (compare_service.py untouched).

### 3. `pyproject.toml` — version `5.4.0` → `5.4.1`

So the zip name is true. No dependency changes.

### 4. `tests/test_compare_filter.py` — new, 7 tests

Uses the REAL `SnowflakeRepository` pointed at SQLite (the
same mechanism as `tests/sqlite_harness.py`), not fakes:

- Flag columns appended last on all 13 `C_S_*` tables; no
  flag columns on any non-`C_S_*` table.
- `count_rows` / `distinct_count` / `coverage_count`:
  SNOWFLAKE side counts 3 of 5 rows (NULL + `N` + non-spine-`Y`
  pass; spine-`Y` excluded); IDQ side counts 4 of 4
  (including an IDQ row with spine flag `Y` — never gated);
  no-discriminator count is the whole table (9, ungated).
- `key_difference`: SNOWFLAKE-only = `{1006}` only;
  IDQ-only = `{1003, 1004}` — 1003 is IDQ-only *because*
  its SNOWFLAKE row is spine-flagged and gated out, which is
  the intended §4b effect (a flagged row surfaces as a
  difference to disposition, not a silent match).
- Non-`C_S_*` table (`EXC_STG_BAD_REC_MEMB`, which has no
  spine column): SNOWFLAKE rows count in full, no error.
- Party-role spine (`C_S_TRS_PTY_RLE`) gated like the party
  table.

## Prerequisite (NOT executed by this build)

The v3 flag ALTERs (`01_unified_tables/01c_alter_v3_only.sql`
in the v3 tree) must be applied to the **Compare schema**
before this build is used against Snowflake, so the 4 flag
columns exist on the `C_S_*` tables there. This build applies
**no** ALTER to any Snowflake account or shared schema, and
no production schema was touched. Without 01c, a gated read
fails on the missing column — that failure is the
prerequisite check working, and the cutover verification
script's section 0b catches it the same way.

## Verification

### Test suite — clean copy: 55 passed

- Baseline on the untouched original tree: **48 passed**
  (matches the v5.4.0 claim).
- Patched tree in place: **55 passed** (48 pre-existing,
  unchanged, + 7 new).
- Patched tree from a **clean copy** (`/tmp/clean-copy`,
  copied fresh from the patched tree, caches removed):
  **55 passed**. The pre-existing tests passing unchanged
  proves the "no flagged rows ⇒ no behaviour change"
  property: with legacy-NULL / `N` flags, every old
  expectation holds.

### Before/after dimension run (§4b's own test)

Same 9-row PTY dataset, original repository vs patched
repository, via the SQLite harness:

| Metric | Before (unfiltered) | After (filtered) | Movement explained by |
|---|---|---|---|
| SNOWFLAKE count / distinct / coverage | 5 / 5 / 5 | 3 / 3 / 3 | Exactly the 2 spine-flagged SNOWFLAKE rows (1003, 1005) |
| IDQ count / distinct / coverage | 4 / 4 / 4 | 4 / 4 / 4 | Nothing — IDQ side byte-identical |
| SNOWFLAKE-only keys | 2 (1005, 1006) | 1 (1006) | Flagged 1005 drops out |
| IDQ-only keys | 1 (1004) | 2 (1003, 1004) | Flagged 1003 surfaces as a difference (intended) |

Non-spine flag alone never excludes: row 1006
(`SPINE='N'`, `NONSPINE='Y'`) counts on the SNOWFLAKE side
before and after.

### PARITY-RUN UC1 rehearsal — what was and was not verified

Read this carefully; it is the one place where a careless
claim would be wrong:

- The pipeline UC1 numbers (PTY 4 matched / 1 DIFFERENT /
  1 ONLY_IN_PROD / 1 ONLY_IN_DEV, PHN MATCH, VALID MATCH,
  EXC 1 ONLY_IN_DEV, ZZ MATCH) are produced by the **pipeline**
  PK-merge engine (`trs_compare_pipe`), which compares
  SQLite files. This change touches only the Compare tool's
  Snowflake repository; no pipeline file changed, and
  VIEW-CUTOVER §4b states explicitly that pipeline UC1 is
  **not** a test of this change. The pipeline UC1 expectation
  therefore stands **unchanged** — but it is unchanged
  because its engine and data are untouched, not because
  this build re-proved it. The pipeline demo was not re-run
  as evidence for this filter, since it cannot test it.
- What WAS verified at the layer this change actually
  touches: with no flagged rows, every Compare expectation
  holds exactly (48 pre-existing tests); with flagged rows,
  the SNOWFLAKE side moves by exactly the flagged count and
  the IDQ side does not move at all (before/after table
  above). A future UC1-shaped dataset run through the
  Compare tool would therefore show the UC1 expectation
  intact except where a row is spine-flagged — and a flagged
  row surfacing as a difference is the §4b intended effect,
  dispositioned per the runbook as "expected flag vs
  investigation", not a code defect.
- Related known delta from §4b (not a failure): EXC rows
  written with the EXC-CATALOG placeholder description
  (`LOOKUP_MISSING: …`) will appear on the Snowflake side
  of the Exceptions dimension with no IDQ counterpart until
  the catalogue row is added and the reconciliation update
  heals them. Disposition those as catalogue gaps.

### Grep checks (all pass)

- No `V_MDM_*` / `V_CMP_*` / `V_AUDIT_*` reference anywhere
  in the patched tree's `app/` or the new test.
- No `NONSPINE_FILTERED_YN` reference in
  `snowflake_repository.py` at all: there is no NONSPINE
  gate, in code or in comments that could be mistaken for
  one. (The column exists only in `tables.py` definitions
  and in the test that proves it does not gate.)
- No IDQ-side query gained the gate: every gate call is
  guarded by `_spine_gate_applies`, which requires the
  SNOWFLAKE discriminator.
- `tables.py` diff: 52 added lines, 0 removed lines.
  `snowflake_repository.py` diff: helpers + docstring +
  2 lines per read method, nothing else.

### Two test-authoring findings (test bugs, not product bugs)

1. SQLAlchemy executemany compiles the INSERT from the
   parameter keys: a flag key missing from the *first* row
   of a batch silently drops that column for the whole
   batch (first run: all flags arrived NULL, 5 tests
   failed). The test now gives every row the same key set
   (NULL = legacy-NULL). Production copy inserts are
   uniform-column, so this does not affect the product —
   but any future harness scenario with mixed key sets
   will hit the same silent drop.
2. One expectation was mine, not the code's: IDQ-only keys
   are 2, not 1, because a flagged SNOWFLAKE row makes its
   key IDQ-only. The test now asserts that, with the
   explanation in the comment.

## Caveats — what was NOT verified

- **No live Snowflake or Oracle run.** All verification is
  SQLite-harness + unit tests. The gate SQL is plain
  SQLAlchemy Core (identical shape on Snowflake), but a
  gated read against a real 01c-applied Compare schema has
  not been executed. That first live run is a deployment
  step, not something claimed here.
- **No MDM batch change.** The batch is the user's team's
  code and is untouched, as required.
- **Pipeline copy step (§4c) NOT built.** Until the pipeline
  Dev-copy step is cut over (copy from `V_MDM_*` views or
  apply the §4b predicate at copy time), pipeline Dev
  compares still see table contents, flagged rows included.
  Do not present a pipeline verdict as a publish-surface
  verdict until that step is built.
- **No NONSPINE gate flipped.** Non-spine flags remain
  audit-only everywhere, per the gating rule.
- **Copy-path note:** copying IDQ rows into a
  01c-applied Compare schema inserts NULL flags (IDQ rows
  carry no flags), which the legacy-NULL rule counts as
  passing — and the IDQ side is never gated anyway, so this
  is safe in both directions.

## Deliverables

- Patched tree: `workspace/trs_compare_filter/` (run
  `python -m pytest` there; 55 passed on the clean copy).
- Zip: `workspace/your_files/TRS_Compare_FastAPI_v5.4.1_COMPARE_FILTER.zip`
  (136,526 bytes, SHA-256
  `1473802f23d8ce0995123bf0d395493039a7fd0a360f2bccd9ddccbe4b5bdbee`,
  `unzip -t` clean).
- This report: `workspace/your_files/COMPARE_FILTER_REPORT.md`.

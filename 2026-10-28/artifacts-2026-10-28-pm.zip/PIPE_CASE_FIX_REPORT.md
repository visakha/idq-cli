# PIPE-CASE-FIX — the two live-Snowflake casing defects, fixed (Pipeline v5.5.2)

Keyword: **PIPE-CASE-FIX**. User-approved build (2026-10-28),
the follow-on to LIVE-VERIFY, which found step E failing on
real Snowflake for two reasons SQLite testing could never
see. Both defects are fixed here, and the full step-E +
step-F result LIVE-VERIFY could not obtain is now obtained
on live scratch.

## What changed (patched copy only)

Patched tree: `workspace/trs_compare_pipe_casefix/` (complete,
runnable copy of v5.5.1). The original trees
`workspace/trs_compare_pipe/` (v5.5.0) and
`workspace/trs_compare_pipe_filter/` (v5.5.1) were **not
modified** — verified by `diff -rq`: the only differences
are the files below. No existing zip was touched. Version
5.5.1 → 5.5.2.

### Fix 1 — probe case bug (LIVE-VERIFY §4a)

File: `app/repositories/pipeline_repository.py`,
`TableStore.assert_spine_flag_column` (lines ~190–200).

snowflake-sqlalchemy's inspector returns column names in
lowercase (`spine_filtered_yn`), while the probe tested the
uppercase constant `SPINE_FILTERED_YN` with a case-sensitive
set membership test — so step E failed closed on **every**
flag-bearing Snowflake table, claiming the flag column was
missing. The fix normalises both sides before comparing
(`str(c["name"]).upper()` against the uppercased constant).
This is idempotent on SQLite (its inspector preserves the
defined case, so nothing changes there) and correct on
Snowflake.

The fail-closed intent survives intact, and is re-proven
below on live scratch: a genuinely flag-less table still
raises `SpineGateMissingColumnError` naming the table and
the 01c prerequisite.

### Fix 2 — copy values all NULL (LIVE-VERIFY §4b)

File: `app/repositories/pipeline_repository.py`, two places.

- `TableStore.stream_rows` (lines ~248–258): on the
  Snowflake path, `result.keys()` comes back lowercase,
  while the registry column names are uppercase — so the
  yielded dicts' keys missed `insert_rows`' lookups and
  copied NULLs. The fix maps each returned key back to its
  registry name case-insensitively
  (`key_map = {c.lower(): c for c in select_cols}`).
  On SQLite the keys already match, so this is a no-op
  there. Keys with no registry match pass through
  unchanged (none are expected).
- `TableStore.insert_rows` (lines ~273–282), second line of
  defence: row lookups are now case-insensitive
  (`lowered.get(c.lower())`), so a batch whose keys arrive
  in any casing still inserts values, not NULLs. Also a
  no-op when keys already match.

## Deliberately NOT changed

- The gate predicate itself
  (`SPINE_FILTERED_YN IS NULL OR = 'N'`): it was correct
  in both places in LIVE-VERIFY and is untouched here.
- Step F compare verdict logic (`pipeline_compare.py`):
  untouched; the verdict below falls out of the gated copy.
- The demo-mode ungated exception: untouched; demo step E
  still copies ungated by design.
- The fail-closed philosophy: untouched; a missing flag
  column still fails the table, never copies ungated.
- Prod/Oracle paths: untouched and not exercised.
- No NONSPINE gate anywhere; no view references added.

## Verification

### Test suite

- Baseline on the untouched v5.5.1 tree: **70 passed**.
- Patched tree: **75 passed** (70 pre-existing unchanged +
  5 new in `tests/test_pipe_case_fix.py`).
- Patched tree from a fresh clean copy (`/tmp/casefix_clean`):
  **75 passed**.

New tests reproduce both defects at the unit level, so a
regression fails here instead of on a live run: a
lowercase-named inspector satisfies the probe; a
flag-less inspector (any casing) still fails closed
naming 01c; a lowercase-keyed stream normalises to
registry casing and copies values, not NULLs, through
the real insert path; `insert_rows` given lowercase
keys directly still inserts values; and the gated
SQLite copy still moves 5 → 3 (gate predicate
regression guard).

### SQLite before/after — unchanged

The pre-existing gated-copy tests still pass with the
same numbers as PIPE_FILTER_REPORT: gated copy 5 → 3
(legacy-NULL row copied, non-spine-Y-only row copied),
ungated copy 5 → 5, Prod copy unmoved. The casing fixes
are no-ops on the SQLite path, as designed.

### Live re-run on scratch — the result LIVE-VERIFY could not obtain

Scratch reused: `SPINEFIRST_COMPILE_DB.LIVEVERIFY` (the
schema LIVE-VERIFY left in place). Key-pair auth only
(`private_key_file`, `SNOWFLAKE_JWT`); no production
database or schema touched; no procedure CALLed; all
rows are invented stubs. Two scratch-only fixture notes:
the LIVE-VERIFY stubs carry NULL names, so one existing
stub row (key 1001) was given name values
(`FRST_NM='Ada'`, `LST_NM='Lovelace'`) — counts and keys
unchanged — so the copy could be checked for VALUES,
not just counts; and the flag-less fixture table
`C_S_TRS_PTY_NOFLAG` was (re)created in scratch for the
fail-closed check.

| Check | Result |
|---|---|
| Scratch source rows | 7 (keys 1001–1005 SNOWFLAKE, 2001–2002 IDQ) |
| Probe on `C_S_TRS_PTY` | PASS — flag column recognised (was the §4a failure) |
| Probe on `C_S_TRS_PTY_NOFLAG` | FAIL CLOSED as designed, naming 01c |
| Step E (real `snowflake_to_sqlite`, demo off, gated) | **COPIED 5 rows (2 spine-flagged rows excluded; source 7 rows)**, overall COMPLETED |
| Dev copy values | Key 1001 copied as `('1001', 'Ada', 'Lovelace', 1)` — values, not NULLs (§4b fixed). The other copied rows show NULL names because the source stubs themselves carry NULL names — a faithful copy, not a defect |
| Dev copy keys | 1001, 1002, 1003, 1005, 2001 — exactly the passing rows |
| Prod file (ungated copy of the same scratch table) | COPIED 7 rows |
| Step F on the live-copied data | **MISMATCH**: Prod 7, Dev 5, matched 5, different 0, only_in_prod 2, only_in_dev 0; diff keys exactly `1004` and `2002` — the two flagged rows, and nothing else |

That step-F shape is the live analogue of the
COMPARE-FILTER / PIPE-FILTER before/after runs: flagged
rows surface as Prod-only differences, with zero
spurious differences and zero Dev-only keys.

## Caveats (plainly stated)

- **Scratch only, TRS PTY only.** Only `C_S_TRS_PTY` was
  live-copied; other tables and sources were not
  live-verified (the gate logic is source-agnostic, as
  before). Prod/Oracle paths were not exercised by
  design.
- **Scratch fixture changed in one documented way:** stub
  row 1001 now carries name values (see above). Counts,
  keys, and flag values are exactly as LIVE-VERIFY left
  them; the `C_S_TRS_PTY_NOFLAG` fixture table is also
  present in the scratch schema.
- **TYPE-CHECK's live-Oracle-DESCRIBE translation caveat**
  still stands; this run verifies Snowflake-side
  behaviour only.
- **Stale Dev_SQLite files** from pre-5.5.2 runs (and
  from ungated step E runs) must still be regenerated
  before any pipeline verdict is read as a
  publish-surface verdict.
- The live evidence files for this run are ephemeral
  (`/tmp/casefix_live/dev_TRS_*.db`,
  `prod_TRS_live.db`, `compare_TRS_*.db`); the durable
  record is this report.

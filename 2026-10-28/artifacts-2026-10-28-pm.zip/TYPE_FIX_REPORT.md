# TYPE-FIX — generator rule + generated DDL, both fixed (no regeneration)

Keyword: **TYPE-FIX**. User-approved 2026-10-28 ("apply the fix that
covers both"). This task changes files, but only in a copy, and
never by regenerating the tree.

**Source of truth:** `TYPE_CHECK_REPORT.md` §2/§6 (29 load-changing
mismatches, priority order) and §7 (EXC appendix). The 29 are the
scope; the EXC appendix cell was fixed as well and is counted
separately below.

**Original tree untouched.** The v3 tree
`workspace/snowflake_common_cs_v3_trs_dqm/` was copied to
`workspace/snowflake_common_cs_v3_typefix/` and only the copy was
changed. A full-tree `diff -rq` between original and copy shows
exactly: 15 CREATE files + `01b_alter_existing.sql` changed, one
new file (`01d_typefix_migration.sql`), and
`tools/generate_common.py` changed. No loader, pass, enrich,
driver, runner, view, or run-script file differs. `01c` is
byte-identical (it contains none of these columns).

**Why not regenerate.** The generated files carry "Do not
hand-edit: change the generator and regenerate" — but regenerating
the whole tree would wipe the FLAG / DIAG / CRE / EXC-CATALOG /
NONSPINE / TRS-DQM patches, because the generator spec was never
updated for them. So the fix is two-sided by design: the generator
rule is fixed so a future DDL regeneration produces the right
types, and the generated DDL is patched in place to the same
types now. Each changed DDL file carries a trailing TYPE-FIX
comment noting this, so a future reader is not misled by the
"Do not hand-edit" header.

## 1. Generator fix (copy's `tools/generate_common.py`)

Old rule (lines 65–76): `NUM_COLS` → `NUMBER`; date-like →
`TIMESTAMP_NTZ`; else unbounded `VARCHAR`. `NUM_COLS` contained
`LATTD`, `LNGTD`, `MLBLTY_SCR`, `ADDRDR_RSLT_PCT` — which is
exactly how scale-0 coordinates, a scale-0 result percent, and a
NUMBER mailability score were produced.

New rule, in the same function (`col_type`, also used for the
`01b` ADD statements at old line 637, so a future regeneration
of both CREATE and 01b picks the fix up):

- New `EXPLICIT_TYPES` dict, checked **first** in `col_type`:
  `LATTD` → `NUMBER(20,6)`, `LNGTD` → `NUMBER(20,6)`,
  `ADDRDR_RSLT_PCT` → `NUMBER(5,2)`, `MLBLTY_SCR` →
  `VARCHAR(2)`, `ADDRESS_DR_MAILABILITY_SCORE` → `NUMBER(1,0)`.
- `NUM_COLS` now: `VERSION_SEQ`, `HUB_STATE_IND`,
  `DELETED_IND`, `TIMELINE_ACTION`, `BIRTH_WGHT_GRMS`.
  (`DELETED_IND` / `TIMELINE_ACTION` added, so they become plain
  `NUMBER`, which is `NUMBER(38,0)` under Snowflake defaults —
  the same normalisation TYPE-CHECK already counted as MATCH for
  `VERSION_SEQ` / `HUB_STATE_IND`.)

Verified by importing the patched generator and calling
`col_type` directly (the generator's `main()` was **not** run,
so no tree was regenerated): all seven target columns return
the new types above, and untouched columns are unchanged
(`VERSION_SEQ` → `NUMBER`, `HUB_STATE_IND` → `NUMBER`,
`BIRTH_WGHT_GRMS` → `NUMBER`, `FRST_NM` → `VARCHAR`,
`LAST_UPDATE_DATE` → `TIMESTAMP_NTZ`).

**Deliberately untouched:** `BIRTH_WGHT_GRMS` stays scale-0
`NUMBER`. Its suspected scale issue (ECI fractional grams) is
UNVERIFIED — no ECI/WIC Oracle DDL in this estate — and it is
not one of the 29. Changing it on suspicion would be inventing
a type.

## 2. Generated DDL fixes (copy's `01_unified_tables/`)

CREATE-file replacements (block-level counts; one dimension file
holds one CREATE per source, so counts exceed the TRS-table
counts — the TRS cells are the verified subset):

| Column | Old → New | CREATE replacements | 01b replacements |
|---|---|---|---|
| `LATTD` | `NUMBER` → `NUMBER(20,6)` | 6 (ADDR 5 source blocks + DQM 1) | 0 (not in 01b) |
| `LNGTD` | `NUMBER` → `NUMBER(20,6)` | 6 (ADDR 5 + DQM 1) | 0 |
| `MLBLTY_SCR` | `NUMBER` → `VARCHAR(2)` | 6 (ADDR 5 + DQM 1) | 0 |
| `ADDRDR_RSLT_PCT` | `NUMBER` → `NUMBER(5,2)` | 1 (DQM) | 0 |
| `DELETED_IND` | `VARCHAR` → `NUMBER` | 42 blocks (13 TRS tables + all other sources' blocks) | 26 ADD lines |
| `TIMELINE_ACTION` | `VARCHAR` → `NUMBER` | 38 blocks (9 TRS tables + all other sources' blocks) | 25 ADD lines |
| `ADDRESS_DR_MAILABILITY_SCORE` (EXC, appendix) | `VARCHAR` → `NUMBER(1,0)` | 1 | 0 |

No old-type line for any target column remains in any CREATE
file (verified by re-grep after patching). `01c` needed no
change (zero occurrences of these columns).

### New file: `01d_typefix_migration.sql` (100 ALTER statements)

This file exists because `01b`'s `ADD COLUMN IF NOT EXISTS` is
a no-op for a column that already exists with the wrong type.
A v2/v3 install that already has `VARCHAR` `DELETED_IND` or
scale-0 `LATTD` is **not** fixed by the CREATE files or by
`01b` alone. `01d` therefore emits, for every table in the
patched CREATE files carrying a target column,
`ALTER TABLE … ALTER COLUMN … SET DATA TYPE …;` (100
statements, generated from the patched CREATE files, pattern-
checked: 0 malformed).

**Deployment order and limits (read before running):**
fresh install → patched CREATE files (01d unnecessary);
existing install → CREATE files (no-op for existing tables) +
`01b` (adds genuinely missing columns at the new types) +
`01d` (retypes columns that already exist). Run `01d` on a
scratch schema first: widening changes cannot lose data, but
the `VARCHAR` → `NUMBER` retypes require stored values to be
convertible — §3 shows why they are in this tree, but that
argument covers this tree's loaders, not arbitrary legacy data
already sitting in a shared schema.

## 3. Judgment calls (each checked, none silently picked)

**LATTD / LNGTD — wider `NUMBER(20,6)` for both tables.**
Oracle ADDR says `(20,6)`, Oracle DQM says `(9,6)`; one unified
rule cannot match both exactly. `(20,6)` was chosen because it
holds every `(9,6)` value without loss. Consequence, stated
plainly in the re-diff: ADDR cells become exact MATCH, DQM
cells become COSMETIC (SF wider) rather than MATCH. No value
is lost either way. Insert-site check: TRS ADDR2 inserts staging
`lat`/`lngtd` decimals, ECI/FSS/WIC ADR loaders insert staging
decimals — all fit `(20,6)` (14 integer digits; latitudes and
longitudes are < 180).

**MLBLTY_SCR — `VARCHAR(2)`, the wider Oracle length.**
Oracle ADDR `(1)` vs DQM `(2)`; `(2)` covers both. Insert-site
check: TRS ADDR1 inserts `av:mailability_score::VARCHAR` and
the score gate (`helper05`) compares mailability as a
single-digit string, so stored scores are single digits and fit
`(2)`; the DQM pass copies the ADDR column into DQM
`VARCHAR(2)` consistently. A hypothetical 3-character score
would fail under `(2)` — but it would also fail under both
Oracle lengths, so `(2)` is no worse than Oracle. The
`adr_exc` pass inserts the same value into EXC
`ADDRESS_DR_MAILABILITY_SCORE`, now `NUMBER(1,0)`: Snowflake
implicitly casts a digit string such as `'3'` to `3`; a
non-numeric score would fail there, but Oracle's EXC column
is `NUMBER(1,0)`, so IDQ-side values must already be numeric.

**DELETED_IND / TIMELINE_ACTION — `NUMBER`, safe at every
insert site in this tree.** No loader in the tree computes a
`DELETED_IND` value: every occurrence outside an INSERT column
list is absent, so every insert supplies `NULL` (verified by
grep over all loaders). `TIMELINE_ACTION` values in this tree
are `NULL` or the integer `2` (CRE: `IFF(end_dated, 2, NULL)`;
TRS loaders: `NULL` / `2` positions). Both convert cleanly to
`NUMBER`. If a foreign loader outside this tree writes a
non-numeric string into either column, that loader — not this
type change — is the defect, and `01d` will fail loudly on
that table rather than silently mistyping it.

**Non-TRS blocks changed identically — UNVERIFIED scope.**
The dimension files are shared: one ADDR file holds CRE, ECI,
FSS, TRS, and WIC blocks, and the same holds for the
`DELETED_IND` / `TIMELINE_ACTION` blocks. All blocks received
the same new types, because a unified schema cannot carry two
types for one column. For TRS the new types are verified
against Oracle DDL; for the other sources they are the
TRS-verified types adopted as the unified standard, and their
own Oracle DDL is still unverified (TYPE-CHECK §5). If a
non-TRS Oracle uses a different type for one of these columns,
that divergence will surface when that source's Oracle DDL is
obtained — it is not hidden by this change, since the change
is uniform and documented here.

## 4. Re-diff against Oracle (patched copy vs `01_etl_wrk.sql`)

Same parser and normalisation as TYPE-CHECK, run against the
patched CREATE files, for exactly the 29 cells plus the EXC
appendix cell:

| Result | Count | Which cells |
|---|---|---|
| MATCH | 26 | All 13 `DELETED_IND`, all 9 `TIMELINE_ACTION`, ADDR `LATTD`/`LNGTD`, DQM `MLBLTY_SCR`, DQM `ADDRDR_RSLT_PCT` |
| COSMETIC (SF wider, no value loss) | 3 | ADDR `MLBLTY_SCR` (`VARCHAR(2)` vs Oracle `VARCHAR(1)`), DQM `LATTD`/`LNGTD` (`NUMBER(20,6)` vs Oracle `NUMBER(9,6)`) |
| LOAD-CHANGING | **0** | — |
| EXC appendix (outside the 29) | MATCH | `ADDRESS_DR_MAILABILITY_SCORE` `NUMBER(1,0)` vs Oracle `NUMBER(1,0)` |

**29 of 29 load-changing mismatches resolved; 0 remain as
exceptions.** No cell was left unfixed on safety grounds, so
there is no remaining-exception list for the 29. (Separate,
out-of-scope items from TYPE-CHECK are unchanged by this fix
and are not claimed here: Oracle-only columns with no writer
— `ADDR_LN_3/4/5`, DQM `PLAN_CD`, `TIMELINE_ACTION` on
LU_TOA/NM/PLN/TOA, `PERIOD_REFERENCE_TIME` on PLN — adding
those needs columns *plus* writers, not a type change; and
`BIRTH_WGHT_GRMS`, deliberately untouched per §1.)

## 5. Parse checks (no live run)

- Installer `--dry-run` on the patched `01_unified_tables/`
  (no connection, CREATE-only scope): 18 files, 44 CREATE
  statements, **0 errors, 0 failed**. The 1,008 statements it
  reports as skipped are exactly the ALTER statements it never
  executes by design: 734 (`01b`) + 174 (`01c`) + 100 (`01d`)
  = 1,008.
- Statement-pattern check on the skipped files: `01b` 734
  statements, `01d` 100 statements, **0 malformed** in either.
- CREATE-block paren balance: all dimension / DQM / EXC files
  balanced.
- **Not verified:** no live Snowflake compile or load was run
  (per the brief, no ALTER was applied to any account or
  shared schema), and no live Oracle DESCRIBE was used — the
  Oracle side remains the translated `01_etl_wrk.sql`, the
  same translation caveat TYPE-CHECK carried. The first live
  run of the patched CREATE files (fresh scratch schema) and
  of `01d` (scratch copy of an existing install) are
  deployment steps, not done here.

## 6. What this copy is — and is not

- It **is** the v3 TRS-DQM tree with the generator rule fixed
  and the generated DDL fixed to match, plus an
  existing-install migration, verified by re-diff and
  parse-checks.
- It **is not** the adopted tree. The original v3 tree is
  untouched; this copy is a separate line until the user
  adopts it (replace the v3 tree, or cherry-pick the DDL +
  generator changes into it). Do not run a generator
  regeneration over the original tree from the *old* generator
  afterwards — that would revert these types. A future DDL
  regeneration must use the *fixed* generator in this copy,
  and even then only the DDL files should be taken from it,
  never a full-tree regeneration (loader/pass patches would
  still be lost).
- It does **not** change any loader, pass, enrich, driver, or
  view logic, any row set, or any flag/DIAG behaviour. Types
  only.

## Deliverables

- Patched copy: `workspace/snowflake_common_cs_v3_typefix/`
- Zip: `workspace/your_files/Snowflake_Spine_First_Common_CS_v3_TRS_DQM_TYPE_FIX.zip`
  (457,760 bytes, SHA-256
  `36dc5af314fe5a2606fbf6e54d6a6b076653df2854be9fcd61d8859184d881f5`,
  `unzip -t` clean)
- This report: `workspace/your_files/TYPE_FIX_REPORT.md`

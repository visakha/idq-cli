# TYPE-CHECK — unified Snowflake C_S_* types vs Oracle DDL

**Scope:** read-only file-to-file diff. No code was changed, no type fix was applied,
and nothing was run against a live Snowflake or Oracle account.

**Snowflake side:** `workspace/snowflake_common_cs_v3_trs_dqm/01_unified_tables/`
(unified CREATE files, plus `01b_alter_existing.sql` and `01c_alter_v3_only.sql`).
**Oracle side:** `workspace/trs_compare_pipe/sql/01_etl_wrk.sql` (Oracle DDL translated
into Snowflake dialect — lengths, numeric precision/scale, and DATE-vs-TIMESTAMP are
preserved by that translation), cross-checked against
`workspace/trs_compare/app/domain/tables.py` `COLUMN_TYPES` (generated from the Oracle
DDL exports). The two Oracle renderings agree exactly after normalisation: **0
disagreements** — so the Oracle side of this diff is internally consistent.

**Root cause, up front:** the unified types are not per-column Oracle types. They come
from one three-line rule in `tools/generate_common.py` (lines 65–76):
`NUM_COLS` → `NUMBER`; `DATE_COLS` or `*_DT`/`*_DATE` → `TIMESTAMP_NTZ`; everything
else → unbounded `VARCHAR`. Every load-changing mismatch below traces to that rule.
The generator header says “Do not hand-edit: change the family spec / generator and
regenerate” — so the fix list in §6 names the generator, not the generated files.

## 1. Headline counts

| Measure | Count |
|---|---|
| Tables compared (present on both sides) | 14 |
| Columns present on both sides | 372 |
| MATCH (identical after normalisation) | 103 |
| COSMETIC (no value effect on a Snowflake load) | 240 |
| LOAD-CHANGING (see §2) | 29 |
| SF-only columns (no Oracle counterpart) | 122 |
| Oracle-only columns (no SF counterpart) | 23 |
| SF tables with NO Oracle DDL in this estate (UNVERIFIED, see §5) | 31 |

The 14 compared tables are the TRS `C_S_*` tables plus `DQM_ADDRESS`. The Compare
tool and `01_etl_wrk.sql` are TRS-only, so every CRE / ECI / FSS / TTF / WIC unified
table is UNVERIFIED by this diff — not “matching”, just not checkable from files here.

## 2. Load-changing mismatches, in priority order

### Tier 1 — value loss at load (fix before any real-data run)

**2.1 `LATTD` / `LNGTD` — latitude/longitude rounded to whole degrees.**
Oracle `C_S_TRS_PTY_RLE_ADDR`: `NUMBER(20,6)`; Oracle `DQM_ADDRESS`: `NUMBER(9,6)`.
Snowflake unified (both tables): `NUMBER` with no precision/scale, i.e. scale 0.
Snowflake rounds to the declared scale on insert, so `30.123456` lands as `30`.
Geocoding precision is destroyed, not approximated: a parity compare on these columns
will mismatch on essentially every geocoded address, and the SF values are unusable
for any distance or mapping purpose. Note the Oracle precisions themselves differ
between the two tables (20,6 vs 9,6), so a single unified type rule cannot match
both exactly — the fix must either use the wider `NUMBER(20,6)` for both or give the
generator a per-table override.

**2.2 `ADDRDR_RSLT_PCT` (DQM_ADDRESS) — result percent rounded to an integer.**
Oracle: `NUMBER(5,2)`. Snowflake: scale-0 `NUMBER`. `95.50` lands as `96`.
This is the known TRS-ADR-DQM smoke symptom, explained: the stub smoke value was
`'95'`, which converts to `95` exactly under scale 0, so the smoke could not see
the loss. Any real doctor result percent with a fraction will round, and DQM parity
on this column will mismatch.

**2.3 `MLBLTY_SCR` — family flip: number in Snowflake, string in Oracle.**
Oracle `C_S_TRS_PTY_RLE_ADDR`: `VARCHAR(1)`; Oracle `DQM_ADDRESS`: `VARCHAR(2)`.
Snowflake (both tables): `NUMBER`, because `MLBLTY_SCR` sits in the generator’s
`NUM_COLS` set. Two consequences: (a) any non-numeric mailability score fails the
INSERT outright; (b) even for digit scores, the stored type no longer matches
Oracle, and the IDQ/Snowflake score gate (`helper05`) compares mailability as a
STRING — the gate itself reads staging doctor outputs, not this column, so the gate
is unaffected, but any consumer comparing stored scores across the two systems is
comparing across types. Side note: Oracle itself is inconsistent here (`VARCHAR(1)`
in ADDR vs `VARCHAR(2)` in DQM_ADDRESS) — worth confirming which length IDQ actually
writes before choosing the SF replacement type; `VARCHAR(2)` covers both.

### Tier 2 — family flip, value survives in Snowflake but typed consumers break

**2.4 `DELETED_IND` (13 tables) and `TIMELINE_ACTION` (9 tables) — VARCHAR in
Snowflake, `NUMBER(38,0)` in Oracle.** The SF INSERT itself does not fail and does
not change the digit (`2` lands as the string `'2'`, `NULL` stays `NULL`), so this is
not a load failure in Snowflake. The risk concentrates downstream: the MDM batch and
any consumer that reads these columns as numbers, does arithmetic on them, or
compares them under strict typing will either convert implicitly or fail, depending
on the consumer — and a parity tool that compares typed values strictly will flag
every non-NULL row. Affected tables for `DELETED_IND`: `C_S_LU_TOA`, `C_S_TRS_PTY`,
`C_S_TRS_PTY_MNG_ATTR`, `C_S_TRS_PTY_NM`, `C_S_TRS_PTY_RLE`, `C_S_TRS_PTY_RLE_ADDR`,
`C_S_TRS_PTY_RLE_ALT_ID`, `C_S_TRS_PTY_RLE_EADDR`, `C_S_TRS_PTY_RLE_PHN`,
`C_S_TRS_PTY_RLE_PLN`, `C_S_TRS_PTY_RLE_REL`, `C_S_TRS_PTY_RLE_REL_PROV`,
`C_S_TRS_PTY_RLE_TOA`. Affected tables for `TIMELINE_ACTION`: the same list minus
`C_S_LU_TOA`, `C_S_TRS_PTY_NM`, `C_S_TRS_PTY_RLE_PLN`, `C_S_TRS_PTY_RLE_TOA` — those
four lack the column entirely (see §3).

### Appendix-tier family flip (EXC table, not a C_S_* table)

`EXC_STG_BAD_REC_MEMB.ADDRESS_DR_MAILABILITY_SCORE`: Snowflake `VARCHAR`, Oracle
`NUMBER(1,0)`. Same shape as §2.3 but lower priority: exception detail, not a spine
or DQM value. Values `'3'` vs `3` compare equal under Snowflake implicit
conversion, but a strict typed compare will flag them.

## 3. Oracle-only columns — values with nowhere to land in Snowflake

These are not type mismatches; the SF table has no such column at all, and the
corresponding loader/pass does not write the value. They are listed separately
because the fix is a column + writer change, not a type change.

| Column | Tables | Consequence |
|---|---|---|
| `DATA_SOURCE` | all 14 compared tables | EXPECTED, not a gap. This is the Compare discriminator, added by the Compare copy job — it is not an ETL table column and must not be added to the unified schema. |
| `ADDR_LN_3`, `ADDR_LN_4`, `ADDR_LN_5` | `C_S_TRS_PTY_RLE_ADDR` | Published address lines 3–5 exist in Oracle (50 chars each) but no SF ADDR column and no loader writes them (verified: no `ADDR_LN_3` in the TRS ADDR loaders). Multi-line addresses lose lines 3–5 in SF. Note Oracle has no `SRC_ADDR_LN_3/4/5` — only the published lines. |
| `PLAN_CD` | `DQM_ADDRESS` | Oracle `VARCHAR(10)`; no SF DQM column and no DQM pass writes it (verified: no `PLAN_CD` in `02_common`). If IDQ populates it, SF DQM parity fails on this column. If IDQ leaves it NULL, the gap is invisible — confirm from IDQ data, not from DDL. |
| `TIMELINE_ACTION` | `C_S_LU_TOA`, `C_S_TRS_PTY_NM`, `C_S_TRS_PTY_RLE_PLN`, `C_S_TRS_PTY_RLE_TOA` | The TOA/NM/PLN loaders do not insert it either (verified in their INSERT lists), so this is a silent drop, not a CALL-time failure. If IDQ sets `TIMELINE_ACTION = 2` on end-dated rows in these tables, SF has no equivalent signal for parity. `C_S_LU_TOA` has no loader in this tree, so whether IDQ populates it there is unverified. |
| `PERIOD_REFERENCE_TIME` | `C_S_TRS_PTY_RLE_PLN` | Same shape: the PLN loader does not insert it. End-dated plan rows lose their reference time in SF. |

## 4. Cosmetic mismatches (240) — no value effect on a Snowflake load

| Family | Count | Why it is cosmetic |
|---|---|---|
| SF `VARCHAR` (unbounded) vs Oracle `VARCHAR2(n)` | 205 | SF is wider: every Oracle value loads without truncation. Direction matters — the reverse (SF → Oracle) would truncate, but that is not the SF load direction. |
| SF `TIMESTAMP_NTZ` vs Oracle `DATE` | 22 | SF is wider: Oracle `DATE` carries time to the second; `TIMESTAMP_NTZ` holds it fully. |
| SF `VARCHAR` vs Oracle `CHAR(n)` | 13 | Fixed-width IDs (`ROWID_OBJECT`, `ROWID_SYSTEM`, `CHAR(14)` keys). Values are 14 characters in practice, so no padding difference arises. Watch item only: Oracle `CHAR` comparison ignores trailing blanks while Snowflake `VARCHAR` comparison does not — if a future value is shorter than its `CHAR` width, a join across the two systems could disagree. No such value was found in the files. |

Two further cosmetic notes. First, unbounded `VARCHAR` means a load that would FAIL
in Oracle (over-length value) SUCCEEDS in Snowflake — so SF parity counts can differ
from Oracle on over-length data in the other direction. That is a parity-completeness
note, not a truncation risk. Second, SF `TIMESTAMP_NTZ` default precision is 9 vs
Oracle `TIMESTAMP(6)` — wider, no loss.

## 5. SF-only columns (122) and UNVERIFIED scope

SF-only columns are expected additions, not mismatches: 115 are v3 `DIAG_*` columns
and the four flag columns (`SPINE_FILTERED_YN/REASON`, `NONSPINE_FILTERED_YN/REASON`)
plus `DIAG_SRC_ID`. The remaining 7 are union columns that other sources contribute
to the shared dimension list and that TRS Oracle DDL does not have: `BIRTH_WGHT_GRMS`,
`PRFRD_LANG_CD`, `SRC_PRFRD_LANG_CD` (PTY); `ORG_DEPT` (ADDR); `PHN_NUM_EXT`,
`RAW_PHN_TP` (PHN); `TOA_CD` (TOA). Extra nullable columns in the TRS tables change
nothing for TRS rows.

**UNVERIFIED — do not read as “matching”.** The following SF tables have no Oracle
DDL anywhere in this estate (Compare and `01_etl_wrk.sql` are TRS-only), so no
statement about their types is possible from files here:

- CRE (5): `C_S_CRE_PTY`, `C_S_CRE_PTY_RLE`, `C_S_CRE_PTY_RLE_ADDR`,
  `C_S_CRE_PTY_RLE_ALT_ID`, `C_S_CRE_PTY_RLE_PHN`.
- ECI (7): `C_S_ECI_PTY`, `C_S_ECI_PTY_RLE`, `C_S_ECI_PTY_RLE_ADDR`,
  `C_S_ECI_PTY_RLE_ALT_ID`, `C_S_ECI_PTY_RLE_EADDR`, `C_S_ECI_PTY_RLE_PHN`,
  `C_S_ECI_PTY_RLE_REL`.
- FSS (7): `C_S_FSS_PTY`, `C_S_FSS_PTY_RLE`, `C_S_FSS_PTY_RLE_ADDR`,
  `C_S_FSS_PTY_RLE_ALT_ID`, `C_S_FSS_PTY_RLE_EADDR`, `C_S_FSS_PTY_RLE_PHN`,
  `C_S_FSS_PTY_RLE_REL`.
- TTF (4): `C_S_TTF_PTY`, `C_S_TTF_PTY_RLE`, `C_S_TTF_PTY_RLE_ALT_ID`,
  `C_S_TTF_PTY_RLE_PHN`.
- WIC (7): `C_S_WIC_PTY`, `C_S_WIC_PTY_RLE`, `C_S_WIC_PTY_RLE_ADDR`,
  `C_S_WIC_PTY_RLE_ALT_ID`, `C_S_WIC_PTY_RLE_EADDR`, `C_S_WIC_PTY_RLE_PHN`.
- `EXC_STG_BAD_REC_MEMB` was diffed as an appendix (§7); its Oracle DDL exists.

**Suspected, not proven, scale issue in UNVERIFIED scope:** `BIRTH_WGHT_GRMS` is
scale-0 `NUMBER` in the unified schema, but the ECI loader computes it as
`BIRTH_WT_LB * 453.6 + BIRTH_WT_OZ * 28.35` — a fractional gram value. If the ECI/WIC
Oracle DDL carries a scale for this column, the SF value is rounded on load. That
needs the ECI/WIC Oracle DDL, which is not in this estate — do not assume it either way.

**Translation caveat:** the Oracle side here is the translated `01_etl_wrk.sql`, not
a live Oracle `DESCRIBE`. Lengths, scales, and DATE-vs-TIMESTAMP survived translation
and the two renderings agree, but if the translation itself introduced an error, this
diff inherits it. A live Oracle DESCRIBE of the 14 tables is the one confirmation
that would close that caveat.

## 6. Fix list (report only — NOT applied)

All generated files carry “Do not hand-edit”. The change point is the generator:
`workspace/snowflake_common_cs_v3_trs_dqm/tools/generate_common.py`, lines 65–76
(`NUM_COLS` / `DATE_COLS` / `col_type`). After changing the generator, regenerate,
then re-run the dry-run, the live compile, and the 01b/01c consistency check below.
Priority order:

1. **Scale for coordinates and result percent.** Remove the scale-0 default for
   `LATTD`, `LNGTD`, `ADDRDR_RSLT_PCT` and give them explicit types: `LATTD`/`LNGTD`
   → `NUMBER(20,6)` (the wider of Oracle ADDR 20,6 and DQM 9,6; or a per-table
   override if exactness per table is required), `ADDRDR_RSLT_PCT` → `NUMBER(5,2)`.
   Regenerates: `01_unified_tables/C_S_PTY_RLE_ADDR.sql` (all 5 source blocks) and
   `01_unified_tables/DQM_ADDRESS.sql`.
2. **`MLBLTY_SCR` out of `NUM_COLS`.** Delete it from the set (line 65–66) so it
   falls through to `VARCHAR`; `VARCHAR(2)` covers both Oracle lengths (ADDR 1, DQM 2)
   if a length is later pinned. Regenerates the same two files as (1).
3. **`DELETED_IND` and `TIMELINE_ACTION` into `NUM_COLS`.** They become
   `NUMBER(38,0)`, matching Oracle. Regenerates all 13 dimension files that carry
   them. Note: this changes the loader INSERT expressions only if a loader casts
   to VARCHAR today — verify at regeneration time; the v3 loaders write these as
   NULL or small integers, which need no cast change.
4. **Missing columns (separate from types).** Add `ADDR_LN_3/4/5` to the ADDR
   dimension, `PLAN_CD` to `DQM_ADDRESS`, `TIMELINE_ACTION` to LU_TOA/NM/PLN/TOA,
   and `PERIOD_REFERENCE_TIME` to PLN — in the generator’s dimension specs, and, in
   the same change, in the loader/pass INSERT lists that must populate them
   (TRS ADDR loaders, the common DQM pass, TOA/NM/PLN loaders). Adding the columns
   without the writers leaves them NULL and parity still fails on those columns.
5. **Confirm from Oracle data, not DDL:** whether IDQ populates `PLAN_CD`,
   `TIMELINE_ACTION` on LU_TOA/NM/PLN/TOA, and `PERIOD_REFERENCE_TIME` on PLN. If
   any of them is always NULL in IDQ, item (4) for that column is cosmetic and can
   be deferred.

**Internal consistency checks already run (all clean):** `01b_alter_existing.sql`
(734 statements) and `01c_alter_v3_only.sql` (174 statements) have zero type
mismatches against the CREATE files and zero ALTER columns absent from CREATE —
so a fresh install and an ALTER-based install end up with the same types today.
That agreement will need re-checking after any fix in (1)–(3), since the ALTER
files are generated from the same spec.

## 7. Appendix — EXC_STG_BAD_REC_MEMB diff (not a C_S_* table)

38 SF columns vs 43 Oracle columns. All shared columns are COSMETIC (VARCHAR
widening; `TIMESTAMP_NTZ` vs Oracle `DATE` widening; `RUN_DATE` TIMESTAMP vs
TIMESTAMP(6)) except `ADDRESS_DR_MAILABILITY_SCORE` (SF `VARCHAR` vs Oracle
`NUMBER(1,0)` — see §2 appendix-tier note). Oracle-only: `DATA_SOURCE` (expected,
Compare discriminator) and the four alias-name columns `ALIAS_PREFIX`,
`ALIAS_FIRST_NAME`, `ALIAS_MIDDLE_NAME`, `ALIAS_LAST_NAME` (`ALIAS_SUFFIX` is
present in SF) — alias exception detail has no SF landing column.

## 8. Appendix — full per-column diff (compared tables only)

Severity key: MATCH = identical after normalisation; COSMETIC = wider SF type, no
value loss on a Snowflake load; LOAD-CHANGING = §2; SF-ONLY / ORACLE-ONLY = column
present on one side only (see §3 and §5). Full column lists, including MATCH rows,
are given so the diff is auditable rather than sampled.

### C_S_LU_TOA

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| EFF_END_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| EFF_STRT_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| MBR_PRG_CD | VARCHAR | VARCHAR(100) | COSMETIC |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | — (absent in unified SF DDL) | NUMBER(38,0) | ORACLE-ONLY |
| TOA_CD | VARCHAR | VARCHAR(100) | COSMETIC |
| TOA_DESC | VARCHAR | VARCHAR(250) | COSMETIC |
| TOA_LBL | VARCHAR | VARCHAR(100) | COSMETIC |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| BIRTH_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| BIRTH_WGHT_GRMS | NUMBER | — (absent in Oracle DDL) | SF-ONLY |
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DEATH_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_BIRTH_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DEATH_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_ETHN_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_GNDR_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_LANG_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RACE_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RACE_IND_LIST | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_BIRTH_DT | TIMESTAMP_NTZ | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_DEATH_DT | TIMESTAMP_NTZ | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_FRST_NM | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_GNDR_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_LST_NM | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_MDL_NM | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_SFX_NM | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SFX_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| ETHNCTY | VARCHAR | VARCHAR(20) | COSMETIC |
| FLAG_SRC | VARCHAR | VARCHAR(10) | COSMETIC |
| FRST_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| FULL_NM | VARCHAR | VARCHAR(100) | COSMETIC |
| GNDR_CD | VARCHAR | VARCHAR(1) | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| LST_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| MDL_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PRFRD_LANG_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PRFX_NM | VARCHAR | VARCHAR(10) | COSMETIC |
| PTY_BO_CLASS_CD | VARCHAR | VARCHAR(255) | COSMETIC |
| RACE_CD | VARCHAR | VARCHAR(20) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SFX_NM | VARCHAR | VARCHAR(10) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_ETHNCTY | VARCHAR | VARCHAR(20) | COSMETIC |
| SRC_FULL_NM | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_PRFRD_LANG_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_RACE_CD | VARCHAR | VARCHAR(20) | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_MNG_ATTR

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| MNG_ATTR_TP | VARCHAR | VARCHAR(50) | COSMETIC |
| MNG_ATTR_VAL | VARCHAR | VARCHAR(20) | COSMETIC |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_NM

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| FRST_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| FULL_NM | VARCHAR | VARCHAR(100) | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| LST_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| MDL_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| NM_TP | VARCHAR | VARCHAR(20) | COSMETIC |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PFX_NM | VARCHAR | VARCHAR(10) | COSMETIC |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SFX_NM | VARCHAR | VARCHAR(10) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_FULL_NM | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | — (absent in unified SF DDL) | NUMBER(38,0) | ORACLE-ONLY |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| RLE_BO_CLASS_CD | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_ADDR

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| ADDR_LN_1 | VARCHAR | VARCHAR(200) | COSMETIC |
| ADDR_LN_2 | VARCHAR | VARCHAR(100) | COSMETIC |
| ADDR_LN_3 | — (absent in unified SF DDL) | VARCHAR(50) | ORACLE-ONLY |
| ADDR_LN_4 | — (absent in unified SF DDL) | VARCHAR(50) | ORACLE-ONLY |
| ADDR_LN_5 | — (absent in unified SF DDL) | VARCHAR(50) | ORACLE-ONLY |
| ADDR_TP | VARCHAR | VARCHAR(50) | COSMETIC |
| ADDR_TP_CD | VARCHAR | VARCHAR(5) | COSMETIC |
| BLDG_NMBR | VARCHAR | VARCHAR(20) | COSMETIC |
| BLDNG_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| CITY | VARCHAR | VARCHAR(50) | COSMETIC |
| CNTRY_CD | VARCHAR | VARCHAR(2) | COSMETIC |
| COUNTY | VARCHAR | VARCHAR(10) | COSMETIC |
| CRDNT_SYS | VARCHAR | VARCHAR(50) | COSMETIC |
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_ADDR_DQM_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_ADDR_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_ADDR_TP_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_CASS_ERR_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_COUNTY_FIPS | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_DLVRY_PNT_VLDN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_ERLY_WRNG_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_MTCH_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_ADDR_1 | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_ADDR_2 | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_CITY | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_CNTRY | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_COUNTY | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_PCT | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_PSTL_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_RSLT_STATE | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_DQM_STATE_FIPS | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| EFF_END_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| EFF_STRT_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| FLR_NUM | VARCHAR | VARCHAR(10) | COSMETIC |
| GEOCD_STS_CD | VARCHAR | VARCHAR(10) | COSMETIC |
| HIERARCHY_CODE | VARCHAR | VARCHAR(255) | COSMETIC |
| HM_REL_TP_CD | VARCHAR | VARCHAR(255) | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| LATTD | NUMBER | NUMBER(20,6) | LOAD-CHANGING |
| LCTN_CRDNT_DESC | VARCHAR | VARCHAR(50) | COSMETIC |
| LNGTD | NUMBER | NUMBER(20,6) | LOAD-CHANGING |
| LOC_IDN | VARCHAR | VARCHAR(25) | COSMETIC |
| MLBLTY_SCR | NUMBER | VARCHAR(1) | LOAD-CHANGING |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| ORG_DEPT | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| ORG_DESC | VARCHAR | VARCHAR(50) | COSMETIC |
| ORG_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PREF_LVL | VARCHAR | VARCHAR(20) | COSMETIC |
| PSTL_BRCD | VARCHAR | VARCHAR(20) | COSMETIC |
| PSTL_CD | VARCHAR | VARCHAR(10) | COSMETIC |
| PSTL_CD_EXT | VARCHAR | VARCHAR(10) | COSMETIC |
| PTY_RLE_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| RGN_CD | VARCHAR | VARCHAR(20) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| RSDNTL_DLVRY_IND | VARCHAR | VARCHAR(1) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_ADDR_LN_1 | VARCHAR | VARCHAR(200) | COSMETIC |
| SRC_ADDR_LN_2 | VARCHAR | VARCHAR(100) | COSMETIC |
| SRC_CITY | VARCHAR | VARCHAR(50) | COSMETIC |
| SRC_CNTRY | VARCHAR | VARCHAR(50) | COSMETIC |
| SRC_COUNTY | VARCHAR | VARCHAR(100) | COSMETIC |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_PSTL_CD | VARCHAR | VARCHAR(10) | COSMETIC |
| SRC_PSTL_CD_EXT | VARCHAR | VARCHAR(10) | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| SRC_STATE | VARCHAR | VARCHAR(50) | COSMETIC |
| STATE | VARCHAR | VARCHAR(50) | COSMETIC |
| SUB_BLDG_DESC | VARCHAR | VARCHAR(20) | COSMETIC |
| SUB_BLDG_NM | VARCHAR | VARCHAR(128) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| USG_TP | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |
| VLDTN_MSG | VARCHAR | VARCHAR(50) | COSMETIC |

### C_S_TRS_PTY_RLE_ALT_ID

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| ALT_ID_TP | VARCHAR | VARCHAR(20) | COSMETIC |
| ALT_ID_TP_FLTR | VARCHAR | VARCHAR(20) | COSMETIC |
| ALT_ID_VAL | VARCHAR | VARCHAR(50) | COSMETIC |
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| CV_IND | VARCHAR | VARCHAR(1) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_ALT_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_MEDICAID_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SSN_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| STS_CD | VARCHAR | VARCHAR(20) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_EADDR

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| ADDR_TP | VARCHAR | VARCHAR(20) | COSMETIC |
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_EMAIL_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_EMAIL_TXT | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| ELEC_ADDR | VARCHAR | VARCHAR(200) | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| IS_VLD | VARCHAR | VARCHAR(1) | COSMETIC |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| STS_CD | VARCHAR | VARCHAR(20) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| USG_TP | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_PHN

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_EXT_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_PHN_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_RAW_PHN_TXT | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PHN_NUM | VARCHAR | VARCHAR(20) | COSMETIC |
| PHN_NUM_EXT | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PHN_TP | VARCHAR | VARCHAR(20) | COSMETIC |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PREF_LVL | VARCHAR | VARCHAR(20) | COSMETIC |
| PTY_RLE_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| RAW_PHN_TP | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| USG_TP | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_PLN

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_PLN_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | — (absent in unified SF DDL) | TIMESTAMP_NTZ(6) | ORACLE-ONLY |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PLN_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | — (absent in unified SF DDL) | NUMBER(38,0) | ORACLE-ONLY |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_REL

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_REL_DATE_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_REL_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_REL_LOOKUP_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_REL_MAIN_ALT_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_REL_REF_ALT_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HIERARCHY_CODE | VARCHAR | VARCHAR(255) | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK_1 | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK_2 | VARCHAR | VARCHAR(255) | COSMETIC |
| REL_TP | VARCHAR | VARCHAR(255) | COSMETIC |
| REL_TYPE_CODE | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_REL_PROV

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_REL_DATE_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_REL_DEFAULT_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| HIERARCHY_CODE | VARCHAR | VARCHAR(255) | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK_1 | VARCHAR | VARCHAR(255) | COSMETIC |
| PTY_RLE_FK_2 | VARCHAR | VARCHAR(255) | COSMETIC |
| REL_TP | VARCHAR | VARCHAR(255) | COSMETIC |
| REL_TYPE_CODE | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### C_S_TRS_PTY_RLE_TOA

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| CASE_NUM | VARCHAR | VARCHAR(50) | COSMETIC |
| CNVRT_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| CNVRT_SYS_CD | VARCHAR | VARCHAR(3) | COSMETIC |
| CREATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| CREATOR | VARCHAR | VARCHAR(50) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DELETED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| DELETED_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| DELETED_IND | VARCHAR | NUMBER(38,0) | LOAD-CHANGING |
| DIAG_SRC_ID | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_TOA_BAD_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| DIAG_TOA_DATE_EXC_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| EDG_NUM | VARCHAR | VARCHAR(50) | COSMETIC |
| EFF_END_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| EFF_STRT_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| HUB_STATE_IND | NUMBER | NUMBER(38,0) | MATCH |
| INDV_ID | VARCHAR | VARCHAR(50) | COSMETIC |
| LAST_UPDATE_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| NONSPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| NONSPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| PERIOD_END_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_REFERENCE_TIME | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PERIOD_START_DATE | TIMESTAMP_NTZ | TIMESTAMP_NTZ(6) | MATCH |
| PKEY_SRC_OBJECT | VARCHAR | VARCHAR(255) | COSMETIC |
| PRTCPNT_STS_CD | VARCHAR | VARCHAR(2) | COSMETIC |
| PTY_RLE_FK | VARCHAR | VARCHAR(255) | COSMETIC |
| ROWID_OBJECT | VARCHAR | CHAR(14) | COSMETIC |
| SGMNT_KEY | VARCHAR | VARCHAR(80) | COSMETIC |
| SPINE_FILTERED_YN | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SPINE_FILTER_REASON | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| SRC_LAST_UPD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| SRC_ROWID | VARCHAR | VARCHAR(30) | COSMETIC |
| TIMELINE_ACTION | — (absent in unified SF DDL) | NUMBER(38,0) | ORACLE-ONLY |
| TOA_CD | VARCHAR | — (absent in Oracle DDL) | SF-ONLY |
| TOA_FK | VARCHAR | VARCHAR(100) | COSMETIC |
| TOA_SOURCE | VARCHAR | VARCHAR(100) | COSMETIC |
| UPDATED_BY | VARCHAR | VARCHAR(50) | COSMETIC |
| VERSION_SEQ | NUMBER | NUMBER(38,0) | MATCH |

### DQM_ADDRESS

| Column | Snowflake | Oracle | Severity |
|---|---|---|---|
| ADDRDR_ADDR_TP_CD | VARCHAR | VARCHAR(5) | COSMETIC |
| ADDRDR_MTCH_CD | VARCHAR | VARCHAR(4) | COSMETIC |
| ADDRDR_RSLT_PCT | NUMBER | NUMBER(5,2) | LOAD-CHANGING |
| ADDR_SRC_KEY | VARCHAR | VARCHAR(255) | COSMETIC |
| BLDG | VARCHAR | VARCHAR(128) | COSMETIC |
| CASS_ERR_CD | VARCHAR | VARCHAR(2) | COSMETIC |
| COUNTY_FIPS | VARCHAR | VARCHAR(3) | COSMETIC |
| DATA_SOURCE | — (absent in unified SF DDL) | VARCHAR(20) | ORACLE-ONLY |
| DLVRY_PNT_VLDN | VARCHAR | VARCHAR(1) | COSMETIC |
| ERLY_WRNG_CD | VARCHAR | VARCHAR(1) | COSMETIC |
| GEOCD_STS_CD | VARCHAR | VARCHAR(10) | COSMETIC |
| LATTD | NUMBER | NUMBER(9,6) | LOAD-CHANGING |
| LNGTD | NUMBER | NUMBER(9,6) | LOAD-CHANGING |
| LOAD_DT | TIMESTAMP_NTZ | DATE | COSMETIC |
| MDM_ADDR_TP | VARCHAR | VARCHAR(30) | COSMETIC |
| MLBLTY_SCR | NUMBER | VARCHAR(2) | LOAD-CHANGING |
| ORG_DEPT | VARCHAR | VARCHAR(50) | COSMETIC |
| ORG_DESC | VARCHAR | VARCHAR(50) | COSMETIC |
| ORG_NM | VARCHAR | VARCHAR(50) | COSMETIC |
| PLAN_CD | — (absent in unified SF DDL) | VARCHAR(10) | ORACLE-ONLY |
| PTY_SRC_KEY | VARCHAR | VARCHAR(255) | COSMETIC |
| RSDNTL_DLVRY_IND | VARCHAR | VARCHAR(1) | COSMETIC |
| RSLT_ADDR_1 | VARCHAR | VARCHAR(128) | COSMETIC |
| RSLT_ADDR_2 | VARCHAR | VARCHAR(128) | COSMETIC |
| RSLT_CITY | VARCHAR | VARCHAR(50) | COSMETIC |
| RSLT_CNTRY | VARCHAR | VARCHAR(255) | COSMETIC |
| RSLT_COUNTY | VARCHAR | VARCHAR(255) | COSMETIC |
| RSLT_PSTL_CD | VARCHAR | VARCHAR(15) | COSMETIC |
| RSLT_STATE | VARCHAR | VARCHAR(50) | COSMETIC |
| SRC_ADDR_1 | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_ADDR_2 | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_CITY | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_CNTRY | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_COUNTY | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_PSTL_CD | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_STATE | VARCHAR | VARCHAR(255) | COSMETIC |
| SRC_SYSTEM | VARCHAR | VARCHAR(3) | COSMETIC |
| STATE_FIPS | VARCHAR | VARCHAR(2) | COSMETIC |
| SUB_BLDG | VARCHAR | VARCHAR(128) | COSMETIC |

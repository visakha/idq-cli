# PIPE-FILTER — VIEW-CUTOVER §4c built (Pipeline v5.5.1)

Keyword: **PIPE-FILTER**. User-approved build (2026-10-28),
the follow-on to COMPARE-FILTER (Compare v5.4.1, §4b). The
headline verdicts stand and are not reopened here: Compare
stays on tables (not `V_CMP_*` views), and the pipeline
compare engine (step F) needs no change. What changes is
only the step E copy that builds Dev_SQLite, so a pipeline
verdict finally reflects the publish surface — what MDM
would receive — instead of every landed Snowflake row.

## What changed (patched copy only)

Patched tree: `workspace/trs_compare_pipe_filter/` (complete,
runnable copy of v5.5.0). The original tree
`workspace/trs_compare_pipe/` was **not modified** — verified
by `diff -rq`: the only differences are the files below.
No existing zip was touched. Version 5.5.0 → 5.5.1.

### 1. `app/repositories/pipeline_repository.py` — the gate

- `SPINE_FLAG_COLUMN = "SPINE_FILTERED_YN"`, plus a
  `SpineGateMissingColumnError`.
- `TableStore.assert_spine_flag_column(table, schema)` — the
  fail-closed probe (see §2).
- `TableStore.stream_rows(..., spine_gate=False)` — when
  `spine_gate` is True **and** the table name starts with
  `C_S_`, the SELECT adds `SPINE_FILTERED_YN` as a
  filter-only column and a predicate
  `(SPINE_FILTERED_YN IS NULL OR SPINE_FILTERED_YN = 'N')`.
  `'N'` copies, `NULL` copies (legacy-NULL rule: rows written
  before flags existed carry NULL and must still copy),
  `'Y'` is excluded. The flag column is NOT inserted: the
  Dev_SQLite schema still comes from the registry columns
  only (`insert_rows` writes registry columns), so the target
  schema is unchanged and step F needs no change.
  Non-`C_S_*` tables stream ungated even with
  `spine_gate=True`. The NONSPINE flag is deliberately NOT
  used anywhere here: non-spine flags stay audit-only.

### 2. `app/services/pipeline_service.py` — wiring + count check

- `_copy_tables(..., apply_spine_gate=False)` — a new keyword
  argument, default off. Per table, `gated` is true only when
  the flag is on **and** the table is `C_S_*`. A gated table
  is probed **before** streaming (fail closed, §3), then
  streamed gated.
- Count verification changed for gated tables only: a gated
  copy is correct exactly when `target == copied` and
  `copied <= source` (previously `target == source` was
  required, which a correct gated copy can never satisfy).
  The per-table message reports all three numbers, so the
  exclusion is visible, never silent, e.g.:
  `COPIED 3 rows (2 spine-flagged rows excluded; source 5 rows).`
- `snowflake_to_sqlite` (step E) passes
  `apply_spine_gate=not engines.demo_mode` (see §4).
  `prod_to_sqlite` and `sqlite_to_dev` do not pass the flag
  and are never gated — the Prod/Oracle copy path and the
  IDQ side are untouched.
- `pyproject.toml` version 5.5.0 → 5.5.1.

### 3. The missing-flag-columns edge case — FAIL CLOSED (decided)

**Decision: if a `C_S_*` table in the Snowflake Dev schema
lacks `SPINE_FILTERED_YN`, that table's copy FAILS with a
clear message naming the table and the v3 01c flag ALTERs
prerequisite. It is never copied ungated, and no warning-only
fallback exists.**

Justification, against the pipeline's existing fail-closed
philosophy (whitelist fail-closed, prod==dev refusal,
row-count mismatch = FAILED): copying ungated would produce
a Dev_SQLite that is NOT the publish surface while looking
exactly like a valid copy — a verdict that appears sound
and is wrong. That silent success is the precise failure §4c
exists to prevent. A loud FAILED table (and a PARTIAL/FAILED
step E overall) forces the operator to apply the 01c ALTERs
and re-run, which is the correct recovery. The one
consequence to know: a partially-01c-applied Dev schema
fails step E table by table until every `C_S_*` table carries
the flags; that is intended, not a bug.

Implementation note worth keeping: the probe does NOT use a
SQL SELECT. Two SQL probes were tried and both pass silently
on a table that lacks the column, because of SQLite's
double-quoted-string misfeature (on by default): a
double-quoted identifier with no matching column degrades
to a string literal instead of raising. A `WHERE 1 = 0`
probe is optimised away entirely, and a `COUNT` probe
returns 0 — and, worse, a gated stream built on such a
probe would silently copy ZERO rows while reporting
success. The probe therefore uses SQLAlchemy's inspector
to read the table's real columns. The inspector is used
for this one existence check only: table shapes still come
from the registry, never from reflection.

### 4. Demo mode — ungated by design (documented exception)

`engines.demo_mode` bypasses the gate in step E. Demo Dev
tables are fixtures built from registry columns and carry
no flag columns by construction, so gating demo mode would
fail every demo run — including the UC1 rehearsal, whose
planted-diff expectations assume ungated demo data. Demo
verdicts are engine rehearsals, not publish-surface
evidence, so demo step E copies ungated by design. This is
the only exception to the fail-closed rule, and it applies
only when `demo_mode` is on. Real (non-demo) step E always
fails closed on a missing flag column.

## Verification

### Test suite

- Baseline on the untouched original tree: **63 passed**.
- Patched tree: **70 passed** (63 pre-existing unchanged +
  7 new in `tests/test_pipe_filter.py`).
- Patched tree from a fresh clean copy: **70 passed**.
- The one pre-existing test that initially failed after the
  first implementation (the demo end-to-end test) is what
  forced the §4 demo-mode decision above; it passes with
  the demo exception in place, with UC1 expectations
  unchanged.

New tests cover: gated copy excludes exactly the flagged
rows (5 → 3, message names the 2 excluded); ungated copy
copies everything including flagged rows; a non-`C_S_*`
output table is never gated even with the flag on; a
missing flag column fails closed (FAILED, message names
01c, no target rows); the target schema gains no flag
column; demo-mode step E copies ungated; real step E
end-to-end writes a gated Dev_SQLite file.

### Before/after dimension check (same Dev dataset, 5 rows)

| Run | Source | Target | Keys in Dev_SQLite |
|---|---|---|---|
| BEFORE (ungated, old step E) | 5 | 5 | 1001, 1002, 1003, 1004, 1005 |
| AFTER (gated, new step E) | 5 | 3 | 1001, 1002, 1004 |
| PROD copy (ungated, no flag column) | 5 | 5 | 1001, 1002, 1003, 1004, 1005 |

The gated copy moved the Dev side by exactly the flagged
count (2: keys 1003 `LOW_SCORE:40` and 1005
`NOT_VALID_MEMBER`); the legacy-NULL row (1002) copied, and
the row with spine `'N'` but NONSPINE `'Y'` (1004) copied —
proving there is no NONSPINE gate. The Prod side is
unmoved (5 → 5).

### Flagged keys surfacing through the real step F engine

Running the unchanged `compare_tables` engine on Prod vs
the two Dev files:

| Comparison | Verdict | Prod | Dev | Matched | Different | Only in Prod | Only in Dev |
|---|---|---|---|---|---|---|---|
| Prod vs UNGATED Dev | MATCH | 5 | 5 | 5 | 0 | 0 | 0 |
| Prod vs GATED Dev | MISMATCH | 5 | 3 | 3 | 0 | 2 | 0 |

This is the exact analogue of the COMPARE-FILTER
before/after run: flagged rows surface as Prod-only
differences (the 2 flagged keys), with zero spurious
differences and zero Dev-only keys. Step F itself was not
modified to produce this; it falls out of the gated copy.

### Grep verification

- Zero `V_MDM_*` / `V_CMP_*` / `V_AUDIT_*` references
  introduced in app code or the new tests.
- `NONSPINE` appears in the changed files only in the
  comment stating it is deliberately not used — no
  NONSPINE gate exists in the copy path.
- `apply_spine_gate` is passed only from
  `snowflake_to_sqlite` (step E); the Prod copy path never
  sets it.
- No change to `pipeline_compare.py` (step F), no change
  to `copy_service.py` (the v5 Oracle → Snowflake path),
  no change to the MDM batch.

## Prerequisites

- The v3 01c flag ALTERs must be applied to the Snowflake
  Dev schema before a real (non-demo) step E run; a table
  without them fails that table's copy (fail closed, §3).
  No ALTER was applied to any account or shared schema by
  this build.
- Dev_SQLite files produced by older (ungated) step E runs
  are stale for publish-surface purposes: re-run step E
  after upgrading to 5.5.1 before reading a pipeline
  verdict as a publish-surface verdict.

## Caveats (plainly stated)

- **No live Snowflake/Oracle run.** All verification is
  SQLite-harness + unit tests + the scripted before/after
  run above. A gated step E against a real 01c-applied
  Snowflake Dev schema has not been executed; that first
  live run is a deployment step (it is the subject of the
  separately nominated LIVE-VERIFY item, which needs its
  own go-ahead and runs in scratch only).
- **SQLite DQS trap (for future readers):** double-quoted
  column references on SQLite silently degrade to string
  literals when the column is absent. Any future probe or
  predicate that must fail on a missing column must not
  rely on a SQL SELECT against SQLite; use the inspector
  as `assert_spine_flag_column` does.
- **Demo verdicts are not publish-surface verdicts** (§4):
  demo step E copies ungated by design.
- **Scope:** TRS tables only in practice — other sources
  are registered with empty table lists in this pipeline,
  so their step E copies are unaffected (nothing to gate).
  The gate logic itself is source-agnostic (any `C_S_*`
  table) and will apply automatically when those sources
  gain table lists.

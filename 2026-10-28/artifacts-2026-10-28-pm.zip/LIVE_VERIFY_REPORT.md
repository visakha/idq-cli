# LIVE-VERIFY — first live gated read against real Snowflake

Keyword: **LIVE-VERIFY**. User-approved 2026-10-28, queued until
PIPE-FILTER and TYPE-FIX were both delivered, then run.
This is the first verification of the COMPARE-FILTER gate and the
PIPE-FILTER copy gate against a real Snowflake account. Everything
below ran in scratch only. Nothing production was touched.

## Scratch location (left in place for re-inspection)

- Database: `SPINEFIRST_COMPILE_DB` (existing scratch database)
- Schema: `LIVEVERIFY` (freshly created for this run)
- Snowflake account version reported by the connection: `10.39.101`
- Authentication: key-pair only (`private_key_file`, connector
  parameter `private_key_file`, `SNOWFLAKE_JWT` authenticator,
  user `VIZY`, role `ACCOUNTADMIN`, warehouse
  `SNOWFLAKE_LEARNING_WH`). No password login was used. The key
  itself appears nowhere in this report or in any file written
  for this run.
- Deliberately NOT touched: `MDM_ETL_TRS`, `MDM_ETL_COMMON`, and
  every other database/schema. No procedure was CALLed against
  real data; all rows in the scratch schema are invented stubs.
- Scratch evidence files (ephemeral, `/tmp`): the Dev SQLite
  copies at `/tmp/liveverify/dev_manual.db` (manual copy body)
  and the empty step-E output files `dev_TRS_*.db` (see §4).

## 1. DDL installed, and DESCRIBE spot-checks — PASS

Sources (all from the TYPE-FIX patched copy
`workspace/snowflake_common_cs_v3_typefix/`):

- `01_unified_tables/C_S_PTY.sql` → `C_S_TRS_PTY` CREATE
- `01_unified_tables/C_S_PTY_RLE_ADDR.sql` →
  `C_S_TRS_PTY_RLE_ADDR` CREATE
- `01_unified_tables/DQM_ADDRESS.sql` → `DQM_ADDRESS` CREATE
- `01_unified_tables/01c_alter_v3_only.sql` → the 8 flag ALTER
  statements for the two TRS tables above

Deviations from the approved installer route, documented:

- The DDL installer (`your_files/write_ddls_to_snowflake.py`)
  executes CREATE statements only and skips ALTERs, so the 01c
  ALTERs were run directly through the connector instead.
- The 01c statements are unqualified (`ALTER TABLE C_S_TRS_PTY
  ...`) and the connector session has no current schema, so the
  first attempt failed with 090106 ("no current schema"). The
  statements were qualified to
  `SPINEFIRST_COMPILE_DB.LIVEVERIFY.<table>` and then applied
  cleanly. (This is the same CREATE-SCHEMA-switches-schema
  gotcha as the earlier compile runs, in reverse.)
- The 01c ALTERs were no-ops in effect: the TYPE-FIX patched
  CREATE files already carry the four flag columns, and the
  ALTERs are `ADD COLUMN IF NOT EXISTS`. They ran without
  error, which is the claim being verified here — not that
  they added columns.
- One Compare-side adaptation, not ETL DDL: a `DATA_SOURCE`
  VARCHAR column was added to the two scratch C_S tables,
  because the Compare repository filters on the discriminator
  and the unified ETL DDL does not carry that column. The ETL
  DDL itself was installed verbatim.

DESCRIBE results (all TYPE-FIX expectations met):

| Table | Columns | Spot-check |
|---|---|---|
| `C_S_TRS_PTY` | 56 (+`DATA_SOURCE`) | `SPINE_FILTERED_YN` VARCHAR, `NONSPINE_FILTERED_YN` VARCHAR, `TIMELINE_ACTION` NUMBER(38,0), `DELETED_IND` NUMBER(38,0) |
| `C_S_TRS_PTY_RLE_ADDR` | 83 (+`DATA_SOURCE`) | `LATTD` NUMBER(20,6), `LNGTD` NUMBER(20,6), `MLBLTY_SCR` VARCHAR(2), `TIMELINE_ACTION` NUMBER(38,0), `DELETED_IND` NUMBER(38,0), flag columns VARCHAR |
| `DQM_ADDRESS` | 37 | `ADDRDR_RSLT_PCT` NUMBER(5,2) |

## 2. Stub set (invented, fully controlled)

`C_S_TRS_PTY`, SNOWFLAKE side (5 rows):

| Key | `SPINE_FILTERED_YN` | Expected under the gate |
|---|---|---|
| 1001, 1002, 1003 | `'N'` | counted |
| 1004 | `'Y'` (reason `LOW_SCORE:40`) | excluded |
| 1005 | NULL (legacy) | counted |

`C_S_TRS_PTY`, IDQ side (2 rows, to prove the IDQ side is
never gated): 2001 flag `'N'`, 2002 flag `'Y'` on purpose —
if the gate were wrongly applied to IDQ, 2002 would drop out.

Dimensions: ADDR rows for 1001 (passing) and 1004 (flagged);
DQM row for 1001 (see §5).

## 3. COMPARE-FILTER gated read, real repository, live Snowflake — PASS

Run with the actual Compare v5.4.1 repository code
(`workspace/trs_compare_filter/app/repositories/snowflake_repository.py`)
over a snowflake-sqlalchemy engine with key-pair auth, pointed
at `SPINEFIRST_COMPILE_DB.LIVEVERIFY`. Not a reimplementation:
the repository's own `count_rows`, `distinct_count`,
`key_difference`, and `coverage_count` methods, including its
`_spine_gate_applies` / `_apply_spine_gate` helpers.

| Read | Result | Expected |
|---|---|---|
| `count_rows`, SNOWFLAKE (gated) | **4** | 4 (1001, 1002, 1003, 1005) |
| `count_rows`, IDQ (ungated) | **2** | 2 (2001, 2002 — flagged IDQ row still counts) |
| `count_rows`, no discriminator (ungated) | **7** | 7 |
| `distinct_count` PKEY, SNOWFLAKE | **4** | 4 |
| `distinct_count` PKEY, IDQ | **2** | 2 |
| `key_difference` SNOWFLAKE − IDQ | **4**, sample 1001, 1002, 1003, 1005 | 4, flagged 1004 absent |
| `key_difference` IDQ − SNOWFLAKE | **2**, sample 2001, 2002 | 2 |
| `coverage_count`, SNOWFLAKE | **4** | 4 |

Raw-SQL cross-check (same numbers): SNOWFLAKE ungated 5,
gated 4, excluded keys exactly `[1004]`, gated keys exactly
`[1001, 1002, 1003, 1005]`. Note for the record: applying the
gate formula to the IDQ side would give 1, not 2 — which is
exactly why the repository gates only the SNOWFLAKE
discriminator, and why the IDQ result above (2) is the proof
it does so.

**Verdict for step 2: PASS.** The COMPARE-FILTER gate behaves
on live Snowflake exactly as it behaved on SQLite.

## 4. Pipeline 5.5.1 step E gated copy, live Snowflake — FAILED (two live-path defects found)

This is the important result of the run: the pipeline copy
path does **not** work against live Snowflake as shipped, for
two distinct reasons. Both were invisible to the SQLite-only
verification, which is precisely what LIVE-VERIFY exists to
catch. Neither defect is in the gate predicate itself.

### 4a. Step E entry point: FAILED — fail-closed probe is case-sensitive against Snowflake's inspector

Running the real `snowflake_to_sqlite` (step E, demo mode off,
`apply_spine_gate=True`) against the scratch schema returned,
for `C_S_TRS_PTY`:

> `FAILED — SpineGateMissingColumnError: Table 'C_S_TRS_PTY'
> has no SPINE_FILTERED_YN column: apply the v3 01c flag
> ALTERs to the Snowflake Dev schema before running step E`

That is wrong: the column exists (DESCRIBE in §1, and the
Compare gate in §3 reads it). Root cause, verified directly:
snowflake-sqlalchemy's inspector returns column names in
**lowercase** (`spine_filtered_yn`, `spine_filter_reason`, …
— confirmed by listing the inspector output), while
`assert_spine_flag_column` in
`app/repositories/pipeline_repository.py` checks
`SPINE_FLAG_COLUMN` (`'SPINE_FILTERED_YN'`, uppercase) with a
case-sensitive set membership test. On SQLite the inspector
preserves the case as defined, so the shipped tests never saw
this. On Snowflake the probe fails closed on **every**
flag-bearing table, so step E copies nothing.

The fail-closed behaviour itself works when the column is
truly absent: the same probe on the scratch fixture table
`C_S_TRS_PTY_NOFLAG` (built without any flag column) raised
`SpineGateMissingColumnError` as designed. So the probe's
intent is sound; its case handling is the defect. Fix
direction (not applied here — see §6): compare inspector
column names case-insensitively.

### 4b. Copy body underneath the probe: gate correct, VALUES ALL NULL

With the probe bypassed by exercising the real stream +
write methods directly (the `_copy_tables` body minus the
probe — no delivered code was modified), the results were:

| Check | Result |
|---|---|
| Gated stream keys | `[1001, 1002, 1003, 1005, 2001]` — 5 rows |
| Ungated stream keys | all 7 rows |
| SQLite copy row count | 5 (matches the gated stream) |
| SQLite copy values | **ALL NULL** — `PKEY_SRC_OBJECT`, `VERSION_SEQ`, `FRST_NM`, `LST_NM` all NULL in all 5 rows |

Why: `stream_rows` builds row dicts from `result.keys()`,
which come back **lowercase** on the Snowflake path, while
`insert_rows` cleans each row with the uppercase registry
names (`row.get('PKEY_SRC_OBJECT')` → `None`). The row
*count* is right and the gate is right, but the copied
*values* are all NULL. In production this is masked today by
defect 4a (the probe fails before any copy happens); fixing
the probe alone would promote this defect from latent to
live. Fix direction (not applied here): normalise stream
dict keys (or make `insert_rows` look up case-insensitively).

Reading the gated stream result correctly: the 5 gated rows
are the 4 SNOWFLAKE passing rows plus the 1 IDQ passing row
(2001). That mixing is a scratch artifact — this scratch
table holds both discriminators, while a production Snowflake
Dev schema holds only the SNOWFLAKE side. The SNOWFLAKE-only
subset of the gated stream is exactly the expected 4 rows
(1001, 1002, 1003, 1005); the flagged rows on both sides
(1004, 2002) are excluded by the stream gate, which is the
stream function's specified behaviour for a C_S_* table.

**Verdict for step 3: FAILED as shipped.** Step E's entry
point fails (4a), and the copy body underneath it copies
NULL values (4b). The gate predicate itself is correct in
both places. A full step-E `COPIED` status and a step-F
verdict on live-copied data were therefore NOT obtained —
running step F on NULL-valued copies would have been
meaningless, so it was not run.

## 5. TYPE-FIX value round-trips, live Snowflake — PASS

| Value in | Value out | Exact? |
|---|---|---|
| ADDR `LATTD` 30.123456 | `Decimal('30.123456')` | yes (`LATTD = 30.123456` true) |
| ADDR `LNGTD` −97.654321 | `Decimal('-97.654321')` | yes |
| ADDR `MLBLTY_SCR` `'3'` | `'3'` | yes |
| DQM `ADDRDR_RSLT_PCT` 95.50 | `Decimal('95.50')` | yes (`= 95.50` true) |
| DQM `LATTD` 30.123456 | `Decimal('30.123456')` | yes |
| DQM `MLBLTY_SCR` `'10'` (2 chars) | `'10'` | yes |
| ADDR `MLBLTY_SCR` `'X'` (non-numeric) | `'X'` | yes — accepted, where the old NUMBER type would have rejected the insert outright |

Under the pre-TYPE-FIX scale-0 types, 30.123456 would have
landed as 30 and 95.50 as 96. On the patched types, scale is
preserved and the VARCHAR score column accepts non-numeric
values. **Verdict for step 4: PASS.**

## 6. What was NOT verified (and why)

- **Full step-E `COPIED` status and step F on live data:**
  blocked by §4a/§4b. Re-running step 3 after those two
  defects are fixed is the remaining LIVE-VERIFY work — it
  needs a PIPE-FILTER patch task, not a re-run of this one.
  No delivered tree was modified in this run to work around
  the defects; the stream/write exercise in §4b used the real
  methods, minus only the probe call.
- **Prod/Oracle paths:** not exercised by design. The
  pipeline Prod copy needs Oracle URLs; no Oracle connection
  was attempted. The IDQ side in §3 is scratch stub data, not
  real IDQ rows.
- **Live Oracle DESCRIBE:** out of scope (TYPE-CHECK's
  translation caveat stands; this run verifies Snowflake-side
  behaviour only).
- **Other sources/tables:** only TRS PTY, TRS ADDR, and
  DQM_ADDRESS were installed. The gate logic is
  source-agnostic, but CRE/ECI/FSS/TTF/WIC tables were not
  live-verified here.

## 7. Bottom line

- COMPARE-FILTER gate on live Snowflake: **PASS**, exactly
  as specified, IDQ side unmoved.
- TYPE-FIX types on live Snowflake: **PASS**, scale preserved,
  VARCHAR score accepts non-numeric values.
- PIPE-FILTER step E on live Snowflake: **FAILED as shipped**
  — probe case bug (§4a) blocks every flagged table, and the
  copy body underneath copies NULL values (§4b). Both are
  live-path-only defects, invisible to SQLite verification,
  and both need fixing before any pipeline verdict is read
  off a Snowflake Dev schema. The gate predicate itself is
  correct; do not "fix" the gate — fix the probe's case
  handling and the stream/insert key casing.

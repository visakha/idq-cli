# Walk-back: an ECI or WIC member with HUB_STATE_IND = -1 in the C_S tables

## What -1 means (read this first)

`HUB_STATE_IND` on a C_S row is an instruction to the MDM batch,
not a description of the source row: `1` = active, `-1` =
soft-delete (the hub row is flagged, never physically deleted),
`NULL` = not yet set (forced to `1` for an open `VERSION_SEQ = 1`
row, the IDQ fix for the error raised when all cross-references
are soft-deleted before a row is end-dated).

ECI and WIC share one walk-back shape, which is why they share
one document, but they differ in one important mechanical
detail (Step 3): ECI lands inactive members flagged, WIC
excludes them from the party load. Both use an
**inactive-status table** as the spine exclusion, not a
deactivation capture table like TRS. A -1 in an ECI/WIC C_S
row therefore means: the member was marked inactive in the
source's inactive-status feed, and a deactivation/end-dating
row was written for it. The ongoing party loaders themselves
write `HUB_STATE_IND = 1` — so, as with TRS, a -1 row comes
from the deactivation path, not from the ordinary load.

## Step 0 — Fix the member you are tracing

Business keys differ by source:

- **ECI:** the party key is `LPAD(ID, 10, '0')`, with an `'F'`
  suffix for family rows: a child with `ID_CHILD = 123` is key
  `0000000123`; a family with `ID_FAMILY = 123` is key
  `0000000123F`. Children and families are separate party keys
  even when they describe the same household — trace the exact
  key form, and check both forms if you are unsure which one
  the -1 row carries.
- **WIC:** the party key is `PTY_SRC_KEY` as carried by the
  source view `V_WIC_ETL_SRC` (with `SOURCE_TABLE` telling you
  which underlying source table the row came from).

Resolve a name or hub rowid first:

```sql
SELECT PKEY_SRC_OBJECT, ROWID_OBJECT, ORIG_ROWID_OBJECT,
       ROWID_SYSTEM, HUB_STATE_IND
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM IN ('ECI', 'WIC')
  AND PKEY_SRC_OBJECT = '<party key>';
```

## Step 1 — The C_S party row: capture the keys

```sql
-- ECI
SELECT PKEY_SRC_OBJECT, VERSION_SEQ, PERIOD_START_DATE,
       PERIOD_END_DATE, TIMELINE_ACTION, LAST_UPDATE_DATE,
       SRC_LAST_UPD_DT, PTY_BO_CLASS_CD, HUB_STATE_IND,
       FRST_NM, LST_NM, BIRTH_DT
FROM C_S_ECI_PTY
WHERE HUB_STATE_IND = -1 AND PKEY_SRC_OBJECT = '<party key>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;

-- WIC (same shape; note PERIOD_START_DATE / CREATE_DATE here
-- carry the source DATEKEY in the WIC loader)
SELECT PKEY_SRC_OBJECT, VERSION_SEQ, PERIOD_START_DATE,
       PERIOD_END_DATE, LAST_UPDATE_DATE, SRC_LAST_UPD_DT,
       PTY_BO_CLASS_CD, HUB_STATE_IND, FRST_NM, LST_NM, BIRTH_DT
FROM C_S_WIC_PTY
WHERE HUB_STATE_IND = -1 AND PKEY_SRC_OBJECT = '<party key>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;
```

Write down: `PKEY_SRC_OBJECT`, `VERSION_SEQ`,
`PERIOD_END_DATE` / `TIMELINE_ACTION` (a -1 row should be
end-dated; an open -1 row is the suspect pattern), and
`LAST_UPDATE_DATE` (the run timestamp — your date anchor).

## Step 2 — The role and dimension rows: how wide is the -1?

```sql
SELECT PKEY_SRC_OBJECT, PTY_FK, RLE_BO_CLASS_CD, VERSION_SEQ,
       PERIOD_START_DATE, PERIOD_END_DATE, HUB_STATE_IND, LAST_UPDATE_DATE
FROM C_S_ECI_PTY_RLE   -- or C_S_WIC_PTY_RLE
WHERE PTY_FK = '<party key>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;

-- Dimensions by the role key.
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_ECI_PTY_RLE_ADDR WHERE PTY_RLE_FK = '<role key>';  -- WIC likewise
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_ECI_PTY_RLE_PHN  WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_ECI_PTY_RLE_ALT_ID WHERE PTY_RLE_FK = '<role key>';
```

PTY -1 + RLE -1 = party deactivation. RLE -1 with PTY live =
role/relationship deactivation. PTY -1 with an open PTY row
still present = version history (the -1 row closed an old
version), not a delete.

## Step 3 — The inactive-status table: the actual cause

This is the step that answers "why". Both sources maintain a
status table whose presence (with a non-null deactivation
status) marks a member inactive:

```sql
-- ECI
SELECT SRC_KEY, ROWID_SYSTEM, DEACTIVATION_STS
FROM STG_ECI_PTY_INACTIVE_STS
WHERE SRC_KEY = '<party key>' AND ROWID_SYSTEM = 'ECI';

-- WIC
SELECT SRC_KEY, ROWID_SYSTEM, DEACTIVATION_STS
FROM STG_WIC_PTY_INACTIVE_STS
WHERE SRC_KEY = '<party key>' AND ROWID_SYSTEM = 'WIC';
```

Mechanics differ, and the difference changes what you should
expect to find in C_S:

- **ECI:** the party loader tests `EXISTS` on this table and
  sets an `is_inactive` flag; inactive members still land in
  C_S (flagged `INACTIVE_STATUS` in the spine flag columns),
  and the deactivation path end-dates them to -1. So for ECI
  you should find both the inactive-status row **and** the
  -1 C_S row, and the dates should line up with the run in
  Step 1.
- **WIC:** the party loader tests `NOT EXISTS` on this table
  and **excludes** inactive members from the party load
  outright. So for WIC, a -1 C_S row for a member that is
  currently in the inactive-status table is expected to be an
  older, end-dated row (from before the exclusion, or from the
  deactivation path), and a member that is inactive today
  may have **no current C_S row at all**. Absence from C_S
  for a currently-inactive WIC member is normal, not an error
  — do not report it as a missing load.

If the inactive-status table has **no** row for your member,
the -1 did not come from inactive status: check the source
flags in Step 4 and the relationship tables.

## Step 4 — The _D delta tables: today's source rows (today only)

`_D` tables are truncate-and-load every day: today's snapshot
only. Query them the same day the -1 row was written.

```sql
-- ECI: two party sources, child and family.
SELECT ID_CHILD, FIRST_NAME, LAST_NAME, DOB, DATE_CREATED,
       DATE_MODIFIED, LOAD_DATE
FROM STG_ECI_D_CHILD WHERE ID_CHILD = <id>;
SELECT ID_FAMILY, FIRST_NAME, LAST_NAME, DOB, DATE_CREATED,
       DATE_MODIFIED, LOAD_DATE
FROM STG_ECI_D_FAMILY WHERE ID_FAMILY = <id>;

-- WIC: go through the source view, and note SOURCE_TABLE.
SELECT SOURCE_TABLE, DATEKEY, LOAD_DATE, ID, PTY_SRC_KEY,
       FIRST_NAME, LAST_NAME, DOB
FROM V_WIC_ETL_SRC WHERE PTY_SRC_KEY = '<party key>';
```

For WIC, the view hides the underlying tables: read the view
definition in production (the view's base tables are the
`_D`/`_H` tables behind it) before claiming a source row is
missing — a row absent from the view may be filtered by the
view, not absent from staging.

## Step 5 — The _H history tables: when did it go inactive?

`_H` tables are append-only Type 2 history: every change adds
a row with a timestamp; nothing is overwritten. ECI's `_H`
tables in this estate are dimension histories, and they are
the right tool when the -1 is dimension-scoped (Step 2):

```sql
-- ECI dimension histories: address, phone, Medicaid alt id.
SELECT * FROM STG_ECI_H_FAMILY_ADDRESS
WHERE <family/member key> ORDER BY <load/effective timestamp>;
SELECT * FROM STG_ECI_H_FAMILY_PHONE
WHERE <family/member key> ORDER BY <load/effective timestamp>;
SELECT * FROM STG_ECI_H_MEDICAID
WHERE <family/member key> ORDER BY <load/effective timestamp>;
```

For the **party** itself, ECI carries its history on the `_D`
rows (`DATE_CREATED`, `DATE_MODIFIED`, `LOAD_DATE`) and on
the inactive-status table: the flip is the point where a
`DEACTIVATION_STS` value appears for the key, and the `_D`
row's `DATE_MODIFIED`/`LOAD_DATE` sequence shows the last
active state before it. For WIC, the party history is likewise
the view's `DATEKEY`/`LOAD_DATE` sequence plus the
inactive-status table; there is no separate `_H` party table
in this estate for WIC — if production holds one behind the
view, the view definition (Step 4) will name it.

General rule, repeated because it is the most common walk-back
mistake: **_D tells you today, _H tells you when.** A _D read
on a later day cannot clear or confirm a past inactive flag.

## Step 6 — The hub: did the batch apply it?

```sql
SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM, MAX(HUB_STATE_IND)
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM IN ('ECI', 'WIC')
  AND PKEY_SRC_OBJECT = '<party key>'
GROUP BY PKEY_SRC_OBJECT, ROWID_SYSTEM;
```

Hub -1 = applied. Hub still 1 with an inactive-status row and
a -1 C_S row = the batch has not applied this deactivation
yet. Hub -1 with no inactive-status row = the -1 came from
outside the inactive-status chain (hub-side script or an
earlier event) — say so.

## Traps

1. **ECI key forms.** `0000000123` (child) and `0000000123F`
   (family) are different keys. Tracing the wrong form shows
   a live member while the other form is -1.
2. **ECI lands inactive rows; WIC excludes them.** The same
   inactive-status evidence leads to different expected C_S
   contents. Do not apply one source's expectation to the
   other.
3. **_D is today only.** See Step 5.
4. **WIC view opacity.** `V_WIC_ETL_SRC` is a view: always
   read its definition before concluding a source row does
   not exist.
5. **Snowflake rewrite caveat.** The Snowflake loaders for
   ECI/WIC reproduce the inactive-status logic, but the wider
   estate's deactivation behaviour carries documented parity
   gaps (IDQ deletes vs insert-only). Trace a production -1
   through the IDQ chain above.

# Walk-back: a TRS member with HUB_STATE_IND = -1 in the C_S tables

## What -1 means (read this first)

`HUB_STATE_IND` on a C_S row is an instruction to the MDM batch,
not a description of the source row:

- `1` = active. The batch keeps (or creates) the hub cross-reference.
- `-1` = soft-delete. The batch must soft-delete that party / party-role
  cross-reference in the hub. The hub row is **never physically deleted**;
  it is flagged -1.
- `NULL` = not yet set. For an open (unterminated) `VERSION_SEQ = 1` row
  the mapping forces this to `1` — an IDQ fix for the bug where the
  batch raised an error if all cross-references were soft-deleted
  before the row was end-dated.

A -1 row in production C_S therefore almost never comes from the
ongoing load (the ongoing TRS party loader writes `HUB_STATE_IND`
NULL, forced to 1 for open rows). It comes from the **deactivation
path**: a deactivation workflow writes an end-dated C_S row with
`HUB_STATE_IND = -1`, `PERIOD_END_DATE` set, and
`TIMELINE_ACTION = 2`, and the batch then applies it. After the
batch, the hub cross-reference tables (`C_B_PTY_XREF`,
`C_B_PTY_RLE_REL_XREF`) show `MAX(HUB_STATE_IND) = -1` for that
member, and the deactivation "Mark Processed" step verifies exactly
that before marking the capture row processed.

So the question "why is this member -1?" is really "what deactivated
this member, when did the source flag it, and did the batch apply
it?" Walk it back in this order. Do not start at the source tables:
start at the C_S row and let each step hand you the key for the next.

## Step 0 — Fix the member you are tracing

You need the business key first: the TRS individual id, `INDV_ID`.
If you only have a name or a hub rowid, resolve it first:

```sql
-- Hub cross-reference: business key -> hub rowid (TRS, party)
SELECT PKEY_SRC_OBJECT, ROWID_OBJECT, ORIG_ROWID_OBJECT,
       ROWID_SYSTEM, HUB_STATE_IND
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'TRS'
  AND PKEY_SRC_OBJECT = '<INDV_ID>';   -- or '<INDV_ID>|DC_INDV', see Step 1
```

If this returns `MAX(HUB_STATE_IND) = -1` over the member's rows,
the hub has already applied the soft-delete. If it returns 1, the
batch has not applied it yet (or applied it to a different rowid)
— that distinction matters at Step 6.

## Step 1 — The C_S party row: capture the keys

```sql
SELECT PKEY_SRC_OBJECT, VERSION_SEQ, PERIOD_START_DATE,
       PERIOD_END_DATE, TIMELINE_ACTION, LAST_UPDATE_DATE,
       SRC_ROWID, SRC_LAST_UPD_DT, PTY_BO_CLASS_CD,
       HUB_STATE_IND, DELETED_IND, FRST_NM, LST_NM, BIRTH_DT
FROM C_S_TRS_PTY
WHERE HUB_STATE_IND = -1
  AND PKEY_SRC_OBJECT LIKE '<INDV_ID>%'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;
```

Write down, from the -1 row:

- **`PKEY_SRC_OBJECT`** — the key for every later step. For TRS it
  is `INDV_ID` for MCI-sourced rows, and `INDV_ID || '|DC_INDV'`
  for DC_INDV-sourced rows. The two forms are different keys in
  C_S even though they are the same person. Trace **both** forms
  if both exist.
- **`VERSION_SEQ`** and **`PERIOD_END_DATE` / `TIMELINE_ACTION`** —
  a -1 row with `PERIOD_END_DATE` set and `TIMELINE_ACTION = 2`
  is an end-dated version: the member had an earlier open version
  and this row closes it. A -1 row with no period end and
  `VERSION_SEQ = 1` is the suspect pattern (see "Traps" below).
- **`LAST_UPDATE_DATE`** — the run timestamp that wrote this row.
  This is your date anchor: the deactivation capture and the
  source flags must be read as of this run, not as of today.
- **`SRC_ROWID`, `SRC_LAST_UPD_DT`** — the source rowid and the
  source last-update timestamp carried into C_S. `SRC_LAST_UPD_DT`
  is the timestamp to match in the staging tables, not
  `LAST_UPDATE_DATE`.

## Step 2 — The role and dimension rows: how wide is the -1?

The same `PKEY_SRC_OBJECT` (party) and the role key
(`PKEY_SRC_OBJECT || '|Member'`) appear in the role table, and the
role key fans out to the dimensions. Check each in turn:

```sql
-- Role: is the member-role also -1, or only the party?
SELECT PKEY_SRC_OBJECT, PTY_FK, RLE_BO_CLASS_CD, VERSION_SEQ,
       PERIOD_START_DATE, PERIOD_END_DATE, HUB_STATE_IND, LAST_UPDATE_DATE
FROM C_S_TRS_PTY_RLE
WHERE PTY_FK = '<PKEY_SRC_OBJECT>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;

-- Dimensions, by the role key (PTY_RLE_FK): address, phone, alt id.
-- A -1 on PTY_RLE_ADDR / _PHN / _ALT_ID with a live PTY row means
-- a dimension-level end-date, not a party deactivation.
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_TRS_PTY_RLE_ADDR WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_TRS_PTY_RLE_PHN  WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_TRS_PTY_RLE_ALT_ID WHERE PTY_RLE_FK = '<role key>';
```

Decision rule:

- PTY -1 **and** RLE -1 (and dimensions -1 or absent) = party
  deactivation. Continue to Step 3.
- RLE -1 but PTY still 1/NULL = relationship/role deactivation,
  not a party deactivation. Switch to the relationship capture
  table in Step 3 (`STG_TRS_DEACTIVATED_RELATIONSHIPS`) and the
  relationship source table `STG_TRS_D_DC_RELATIONSHIPS`.
- PTY -1 but an open PTY row for the same key still exists
  (`PERIOD_END_DATE IS NULL`, `HUB_STATE_IND` 1 or NULL) =
  version history, not a delete: the -1 row closed an old
  version. Read the open row's `LAST_UPDATE_DATE` — that is the
  current state; the -1 row explains the past.

## Step 3 — The valid-member spine and the deactivation capture

Two tables decide whether the member is currently a valid member,
and whether a deactivation was captured for it:

```sql
-- Still in the spine? (Absent = not a current valid member.)
SELECT INDV_ID, PTY_PK FROM STG_TRS_VALID_MEMBERS
WHERE INDV_ID = <INDV_ID>;

-- Captured for deactivation? (Note the spelling: DEACTIVED, not DEACTIVATED.)
SELECT INDV_ID, PTY_PK, SRC_TBL, CREATE_DATE,
       SRC_DEACTIVATION_DATE, LOAD_DATE, INACTIVE_IND, DELETE_SW,
       PROCESSED_YN
FROM STG_TRS_DEACTIVED_MEMBERS
WHERE INDV_ID = <INDV_ID>
ORDER BY LOAD_DATE;
```

Read `PROCESSED_YN` carefully: in the party deactivation flow the
"Mark Processed" step trusts the copied key table, while the
relationship flow verifies `MAX(HUB_STATE_IND) = -1` first
(documented asymmetry). A captured row with `PROCESSED_YN`
unprocessed and a hub xref still at 1 means "captured, not yet
applied". A captured row processed and a hub xref at -1 means
"applied, closed". A -1 C_S row with **no** capture row at all
means the -1 did not come through the deactivation capture —
check the source flags directly (Step 4) and the relationship
capture table.

## Step 4 — The _D delta tables: today's source flags (today only)

`_D` tables are **truncate-and-load every day**: they hold only
today's snapshot. Query them the same day the -1 row was written,
or they will already have moved on. For TRS party deactivation
the flags are:

```sql
-- DC_INDV: the operative flags for party deactivation.
SELECT INDV_ID, INACTIVE_IND, DELETE_SW, FILE_CLEARANCE_SW
FROM STG_TRS_D_DC_INDV
WHERE INDV_ID = <INDV_ID>;

-- MCI: a second, independent inactive flag.
SELECT INDV_ID, INACTIVE_IND
FROM STG_TRS_D_CV_DC_MCI_INDV
WHERE INDV_ID = <INDV_ID>;

-- TOA conversion rows also feed the valid-member set.
SELECT INDV_ID, CONVERSION_IND
FROM STG_TRS_D_CV_MCI_EDG_INDV_TOA
WHERE INDV_ID = <INDV_ID>;
```

The ongoing valid-member set is, in logic: TOA rows with
`CONVERSION_IND = 'C'`, plus DC_INDV rows with
`FILE_CLEARANCE_SW = 'Y'` and `INACTIVE_IND = 'N'` and
`DELETE_SW = 'N'`, plus MCI rows with `INACTIVE_IND = 'N'`,
plus `STG_TRS_VALID_MEMBERS`, **minus** DC_INDV rows with
`INACTIVE_IND = 'Y'` or `DELETE_SW = 'Y'`, **minus** MCI rows
with `INACTIVE_IND = 'Y'`, **minus**
`STG_TRS_DEACTIVED_MEMBERS`. So a member is -1 when it falls
out of that set through one of: `INACTIVE_IND = 'Y'`,
`DELETE_SW = 'Y'`, or presence in the deactivated-members
capture. Pin down **which one** — they are different business
events (inactive vs deleted vs captured-deactivated) even
though all three land as -1 in C_S.

If the _D flags today show the member active again, you have
already missed the flag day: go to Step 5. Do not conclude
"the source never flagged it" from a _D table read on a later
day.

## Step 5 — The _H history tables: when did the flag flip?

`_H` tables are **append-only Type 2 history**: every change
adds a row with a timestamp; nothing is overwritten or deleted.
That is what makes the walk-back possible after the _D snapshot
has moved on. For TRS:

```sql
-- All history for this member, oldest first. The flip row is the
-- first row where the deactivation flag turns to 'Y' (or the row
-- appears in the history with a deactivation marker), and the row
-- immediately before it is the last good state.
SELECT INDV_ID, INACTIVE_IND, DELETE_SW, FILE_CLEARANCE_SW,
       <effective/load timestamp columns as defined on this table>
FROM STG_TRS_H_DC_INDV
WHERE INDV_ID = <INDV_ID>
ORDER BY <effective/load timestamp columns>;
```

Check, in order: (a) does a flip row exist at all — if not, the
-1 did not come from a source flag flip, and you are looking at
a capture-only or relationship deactivation; (b) the timestamp
of the flip row — it must be on or before the C_S row's
`LAST_UPDATE_DATE` from Step 1, and after the previous C_S
run's timestamp (otherwise the -1 belongs to an earlier run);
(c) the row before the flip — that is the member's last active
state, and its values should match the open C_S version that
the -1 row end-dated.

General _H rule for every source in this set: **_D tells you
today, _H tells you when**. If you only ever query _D, every
deactivation older than one day looks unexplained.

## Step 6 — The hub: did the batch apply it?

Close the loop in the hub cross-references, the same way the
deactivation "Mark Processed" step does:

```sql
SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM,
       MAX(HUB_STATE_IND) AS MAX_HUB_STATE_IND,
       COUNT(DISTINCT PKEY_SRC_OBJECT) AS SRC_PKEY_CT
FROM C_B_PTY_RLE_REL_XREF
WHERE ROWID_SYSTEM = 'TRS'
  AND PKEY_SRC_OBJECT = '<PKEY_SRC_OBJECT>'
GROUP BY PKEY_SRC_OBJECT, ROWID_SYSTEM
HAVING MAX(HUB_STATE_IND) = -1;
```

- Hub already -1 + capture processed = deactivation complete.
  The walk-back ends here; the answer is the flag flip in
  Step 5 and the capture row in Step 3.
- Hub still 1 + capture unprocessed = deactivation captured but
  not applied (batch pending, or the batch run failed, or the
  gateway skipped the stage because the target-row count was
  zero — the deactivation flow skips Stage 3 when `TgtRows = 0`).
- Hub -1 but no capture row and no _H flip = the -1 came from
  outside this chain (a hub-side merge/unmerge script, e.g. the
  external `unmerge_soft_delete_party.sh` / relationship
  scripts, which are a black box in the IDQ exports). Say so
  plainly rather than forcing the story into the capture tables.

## Traps

1. **Two PKEY forms for one person.** `INDV_ID` and
   `INDV_ID|DC_INDV` are separate C_S keys. Tracing only one
   form can show a live member while the other form is -1.
2. **_D is today only.** A _D read on a later day cannot clear
   or confirm a past flag. Always pair it with _H.
3. **-1 on an open VERSION_SEQ = 1 row is suspect.** Open rows
   are supposed to be forced to 1. If you find -1 there, treat
   it as the known PRT-error bug pattern, not as a normal
   deactivation.
4. **Party vs relationship.** `STG_TRS_DEACTIVED_MEMBERS` is the
   party capture; `STG_TRS_DEACTIVATED_RELATIONSHIPS` is the
   relationship capture (note: different spelling, and its
   Mark Processed step verifies hub state first, unlike the
   party step). Mixing them up misattributes the -1.
5. **Snowflake rewrite ≠ production.** The Snowflake loaders
   in this estate do **not** perform the IDQ deactivation
   deletes (documented parity gaps D1/D2: IDQ deletes
   deactivated members from the valid-member spine and
   deletes-first for Auth_Rep; the rewrite does not). If you
   are tracing a -1 in the Snowflake C_S tables, the
   deactivation capture may be absent by design — trace the
   production (IDQ) chain above for the true story, and treat
   the Snowflake gap as a known difference, not as evidence
   the member was never deactivated.

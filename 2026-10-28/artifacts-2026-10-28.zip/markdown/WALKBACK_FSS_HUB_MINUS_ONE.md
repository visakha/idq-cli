# Walk-back: an FSS member with HUB_STATE_IND = -1 in the C_S tables

## What -1 means (read this first)

`HUB_STATE_IND` on a C_S row is an instruction to the MDM batch,
not a description of the source row: `1` = active, `-1` =
soft-delete (the hub row is flagged, never physically deleted),
`NULL` = not yet set (forced to `1` for an open `VERSION_SEQ = 1`
row, the IDQ fix for the error raised when all cross-references
are soft-deleted before a row is end-dated).

FSS follows the ECI/WIC shape: an inactive-status table is the
spine exclusion, and the ongoing party loader writes
`HUB_STATE_IND = 1` for the rows it loads — so a -1 row in an
FSS C_S table comes from the deactivation/end-dating path, not
from the ordinary load. FSS's source-specific features are:
the party key is composite in spirit (`PTY_SRC_KEY` plus
`SOURCE_TYPE` and `ID_CLIENT` on the source view), and there
is a second source view for relationships
(`V_FSS_ETL_SRC_RELATIONS`) — so a party -1 and a relationship
-1 are traced through different views, and confusing them is
the FSS-specific trap.

## Step 0 — Fix the member you are tracing

Business keys on the FSS source view: `PTY_SRC_KEY` (the party
key used in C_S), `ID_CLIENT` (the client id), and
`SOURCE_TYPE` (which FSS source flavour the row came from).
A member can appear under more than one `SOURCE_TYPE`; trace
the exact (`PTY_SRC_KEY`, `SOURCE_TYPE`) combination carried
by the -1 C_S row, and check the other `SOURCE_TYPE` rows for
the same `ID_CLIENT` before concluding the person (as opposed
to one source flavour of the person) is deactivated.

```sql
SELECT PKEY_SRC_OBJECT, ROWID_OBJECT, ORIG_ROWID_OBJECT,
       ROWID_SYSTEM, HUB_STATE_IND
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'FSS'
  AND PKEY_SRC_OBJECT = '<PTY_SRC_KEY>';
```

## Step 1 — The C_S party row: capture the keys

```sql
SELECT PKEY_SRC_OBJECT, VERSION_SEQ, PERIOD_START_DATE,
       PERIOD_END_DATE, TIMELINE_ACTION, LAST_UPDATE_DATE,
       SRC_LAST_UPD_DT, PTY_BO_CLASS_CD, HUB_STATE_IND,
       FRST_NM, LST_NM, BIRTH_DT
FROM C_S_FSS_PTY
WHERE HUB_STATE_IND = -1 AND PKEY_SRC_OBJECT = '<PTY_SRC_KEY>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;
```

Write down: `PKEY_SRC_OBJECT`, `VERSION_SEQ`,
`PERIOD_END_DATE` / `TIMELINE_ACTION` (a -1 row should be
end-dated; an open -1 row is the suspect pattern), and
`LAST_UPDATE_DATE` (the run timestamp — your date anchor).
In the FSS loader, `SRC_LAST_UPD_DT` carries the view's
`DT_LAST_UPDATE`; match on that in the source view.

## Step 2 — The role and dimension rows: how wide is the -1?

```sql
SELECT PKEY_SRC_OBJECT, PTY_FK, RLE_BO_CLASS_CD, VERSION_SEQ,
       PERIOD_START_DATE, PERIOD_END_DATE, HUB_STATE_IND, LAST_UPDATE_DATE
FROM C_S_FSS_PTY_RLE
WHERE PTY_FK = '<PTY_SRC_KEY>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;

-- Dimensions by the role key.
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_FSS_PTY_RLE_ADDR WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_FSS_PTY_RLE_PHN  WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_FSS_PTY_RLE_ALT_ID WHERE PTY_RLE_FK = '<role key>';
```

PTY -1 + RLE -1 = party deactivation. RLE -1 with PTY live =
role deactivation. PTY -1 with an open PTY row still present =
version history. If the -1 is on a **relationship** row
(`C_S_FSS_PTY_RLE_REL` / the relationship loader's output),
trace it through `V_FSS_ETL_SRC_RELATIONS` (Step 4), not
through the party view — that is the FSS trap.

## Step 3 — The inactive-status table: the actual cause

```sql
SELECT SRC_KEY, ROWID_SYSTEM, DEACTIVATION_STS
FROM STG_FSS_PTY_INACTIVE_STS
WHERE SRC_KEY = '<PTY_SRC_KEY>' AND ROWID_SYSTEM = 'FSS';
```

A row here with a non-null `DEACTIVATION_STS` is the
inactive evidence. As with ECI, the FSS loader tests `EXISTS`
on this table and flags inactive members (spine flag
`INACTIVE_STATUS`); inactive members still land flagged, and
the deactivation path end-dates them to -1. You should find
both the status row and the -1 C_S row, with dates lining up
with the run in Step 1. No status row means the -1 did not
come from inactive status: go to Step 4.

## Step 4 — The source views: party view and relationship view (today only, via the views)

```sql
-- Party view: today's rows for this member, all source types.
SELECT SOURCE_TYPE, DT_LAST_UPDATE, PTY_SRC_KEY, ID_CLIENT,
       NM_FIRST, NM_LAST, NM_MIDDLE
FROM V_FSS_ETL_SRC
WHERE PTY_SRC_KEY = '<PTY_SRC_KEY>' OR ID_CLIENT = <id_client>
ORDER BY DT_LAST_UPDATE;

-- Relationship view: only if the -1 is relationship-scoped (Step 2).
SELECT * FROM V_FSS_ETL_SRC_RELATIONS
WHERE <party/relationship keys for this member>
ORDER BY <load/effective timestamp columns>;
```

Both views hide their base tables: in production, read each
view's definition to name the `_D` (daily truncate-load)
and `_H` (append-only history) tables behind it. The
`_D` vs `_H` rule applies through the views exactly as
elsewhere: current view rows show today; the history behind
them shows when a flag flipped. A view read on a later day
cannot clear or confirm a past flag — pair it with the `_H`
base table whenever the view definition gives you one. And
keep the two views apart: a row missing from the party view
but present in the relationship view (or vice versa) is a
view-scope fact, not a deactivation.

## Step 5 — The _H history: when did it flip?

There is no separate `_H` party table for FSS named in this
estate. In practice the flip evidence is, in order: (1) the
appearance of a `DEACTIVATION_STS` row in
`STG_FSS_PTY_INACTIVE_STS` (Step 3 — that table is itself
the dated inactive history for the party); (2) the
`DT_LAST_UPDATE` sequence on the party view (Step 4) — the
last row before the member stops appearing, or the row where
its source values change, is the last active state; (3) the
`_H` base table behind the view, if the view definition
names one — query it by `PTY_SRC_KEY` (and `SOURCE_TYPE`)
ordered by its load/effective timestamp, the same way as any
`_H` table: the flip row is the first row carrying the
deactivation marker, and the row before it is the last good
state.

## Step 6 — The hub: did the batch apply it?

```sql
SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM, MAX(HUB_STATE_IND)
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'FSS' AND PKEY_SRC_OBJECT = '<PTY_SRC_KEY>'
GROUP BY PKEY_SRC_OBJECT, ROWID_SYSTEM;
```

Hub -1 = applied. Hub still 1 with a status row and a -1
C_S row = captured/written but not yet applied. Hub -1 with
no status row and no view change = the -1 came from outside
this chain — say so.

## Traps

1. **Party view vs relationship view.** `V_FSS_ETL_SRC` and
   `V_FSS_ETL_SRC_RELATIONS` are different surfaces. A
   party -1 is traced through the first; a relationship -1
   through the second. Mixing them misattributes the -1.
2. **SOURCE_TYPE multiplicity.** One `ID_CLIENT` can appear
   under several `SOURCE_TYPE` values. A -1 for one
   combination is not a -1 for the person.
3. **View opacity.** Both views hide their base tables;
   read their definitions before concluding a source row
   does not exist, and before assuming which table is `_D`
   and which is `_H`.
4. **_D is today only.** See Steps 4–5.
5. **Snowflake rewrite caveat.** The Snowflake FSS loader
   reproduces the inactive-status logic, but the wider
   estate's deactivation behaviour carries documented parity
   gaps (IDQ deletes vs insert-only). Trace a production -1
   through the IDQ chain above.

# ECI manifest diagrams — addendum to Snowflake_All_Sources_Modular_Step_Driver_v2.1

Supplement to the all-sources step-driver package (409 files). The 31
rebuilt manifests each carry a Mermaid phase-flow; the 9 ECI manifests
below had none, because they were kept verbatim from the approved
v2.1. These 9 diagrams close that gap without touching the v2.1 zip,
any ECI manifest, any code, step order, or branch order.

Style matches the TRS manifests: `flowchart LR`, phase subgraphs with
direction TB, Publish as one subgraph and one transaction, spine /
status / non-spine branches labelled. Transform nodes use the
manifests' checkpoint STEP_NAMEs; Publish nodes use the manifests'
step numbers, targets, and kinds, in order.

Validation status, stated plainly: these were checked structurally
only — 9 diagrams, 6 subgraphs and 6 matching `end` statements each,
unique node ids within each diagram, Transform/Publish order matching
the source manifest. They have NOT been parsed by a Mermaid parser.
Parse them in a Mermaid viewer before splicing into a rebuilt zip.

Preserved quirks, deliberately not smoothed over:

- ADR publish order: DQM_ADDRESS (60) before the spine branch (70)
  before the exception branch (80).
- VAL publish order: 40 NON-SPINE blank-name, 50 STATUS log
  deactivation, 60 STATUS status table, 70 STATUS log reactivation.
- RFA/RFP/RFM each have a single STATUS publish branch.

Use as-is (this file), or say the word and each diagram will be
spliced into its ECI manifest as a `## Phase-flow diagram` section
with the all-sources zip rebuilt, leaving the original v2.1 zip
untouched.

---

## 1. PTY — ECI/PTY/PTY_MANIFEST.md — m_Tgt_C_S_ECI_Pty

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 SRC_DELTA_PARTIES"] --> G["Step 20 ACTIVE_PARTIES"] --> H["Step 30 DQ_RULES"] --> I["Step 40 DQ_EXCEPTIONS_RESOLVED"] --> J["Step 50 ROUTED_READY"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        K["Branch 60 SPINE C_S_ECI_PTY"] --> L["Branch 70 SPINE C_S_ECI_PTY_RLE"] --> M["Branch 80 NON-SPINE EXC GENDER"] --> N["Branch 90 NON-SPINE EXC BIRTH"] --> O["Branch 100 NON-SPINE EXC ETHNICITY"] --> P["Branch 110 NON-SPINE EXC RACE"] --> Q["Branch 120 NON-SPINE EXC LANGUAGE"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        R["Job end"] --> S["Work tables left standing"] --> T["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 2. ADR — ECI/ADR/ADR_MANIFEST.md — m_Tgt_C_S_ECI_Pty_Addr

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 SRC_ADDRESSES"] --> G["Step 20 KEYED_ACTIVE"] --> H["Step 30 ADDR_VALIDATION"] --> I["Step 40 FLAT_VALIDATION"] --> J["Step 50 SCORED_READY"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        K["Branch 60 NON-SPINE DQM_ADDRESS"] --> L["Branch 70 SPINE C_S_ECI_PTY_RLE_ADDR"] --> M["Branch 80 NON-SPINE EXC"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        N["Job end"] --> O["Work tables left standing"] --> P["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 3. ALT — ECI/ALT/ALT_MANIFEST.md — m_Tgt_C_S_ECI_Pty_Rle_Alt_Id

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 SRC_ALT_IDS"] --> G["Step 20 ACTIVE_ALT_IDS"] --> H["Step 30 VALIDATED_ROUTED"] --> I["Step 40 READY_TO_PUBLISH"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        J["Branch 50 SPINE C_S_ECI_PTY_RLE_ALT_ID"] --> K["Branch 60 NON-SPINE EXC SSN"] --> L["Branch 70 NON-SPINE EXC MEDICAID"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        M["Job end"] --> N["Work tables left standing"] --> O["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 4. PHN — ECI/PHN/PHN_MANIFEST.md — m_Tgt_C_S_ECI_Pty_Rle_Phn_And_EAddr

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 SRC_PHN_EADDR"] --> G["Step 20 ACTIVE_PHN_EADDR"] --> H["Step 30 DQ_CLEAN_VALIDATE"] --> I["Step 40 ROUTED_GROUPS"] --> J["Step 50 READY_TO_PUBLISH"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        K["Branch 60 SPINE C_S_ECI_PTY_RLE_PHN"] --> L["Branch 70 NON-SPINE EXC PHONE"] --> M["Branch 80 SPINE C_S_ECI_PTY_RLE_EADDR"] --> N["Branch 90 NON-SPINE EXC EMAIL"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        O["Job end"] --> P["Work tables left standing"] --> Q["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 5. REL — ECI/REL/REL_MANIFEST.md — m_Tgt_C_S_ECI_Pty_Rle_Rel

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 SRC_BOTH_DIRECTIONS"] --> G["Step 20 KEYED_BOTH_ACTIVE"] --> H["Step 30 CODED_TRANSLATED"] --> I["Step 40 READY_TO_PUBLISH"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        J["Branch 50 SPINE C_S_ECI_PTY_RLE_REL"] --> K["Branch 60 NON-SPINE EXC"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        L["Job end"] --> M["Work tables left standing"] --> N["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 6. VAL — ECI/VAL/VAL_MANIFEST.md — m_Tgt_C_S_ECI_Pty_Validation

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 SRC_DELTA_PARTIES"] --> G["Step 20 ENRICHED_STD_NAMES"] --> H["Step 30 ROUTED_GROUPS"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        I["Branch 40 NON-SPINE EXC blank-name"] --> J["Branch 50 STATUS LOG DEACTIVATION"] --> K["Branch 60 STATUS STS"] --> L["Branch 70 STATUS LOG REACTIVATION"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        M["Job end"] --> N["Work tables left standing"] --> O["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 7. RFA — ECI/RFA/RFA_MANIFEST.md — m_Tgt_Stg_ECI_Pty_Reactivation_D_Family_Addr

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 LATEST_HISTORY_ROWS"] --> G["Step 20 KEEP_NEW_ONLY"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        H["Branch 30 STATUS STG_ECI_D_FAMILY_ADDRESS"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        I["Job end"] --> J["Work tables left standing"] --> K["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 8. RFP — ECI/RFP/RFP_MANIFEST.md — m_Tgt_Stg_ECI_Pty_Reactivation_D_Family_Phn

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 LATEST_HISTORY_ROWS"] --> G["Step 20 KEEP_NEW_ONLY"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        H["Branch 30 STATUS STG_ECI_D_FAMILY_PHONE"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        I["Job end"] --> J["Work tables left standing"] --> K["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

## 9. RFM — ECI/RFM/RFM_MANIFEST.md — m_Tgt_Stg_ECI_Pty_Reactivation_D_Medicaid

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Generate run id"] --> B["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        C["Config gather"] --> D["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        E["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        F["Step 10 LATEST_HISTORY_ROWS"] --> G["Step 20 KEEP_NEW_ONLY"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        H["Branch 30 STATUS STG_ECI_D_MEDICAID"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        I["Job end"] --> J["Work tables left standing"] --> K["RETURN summary"]
    end
    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5
    P5 --> P6
```

# The Seven Reference Objects — background, usage, maintenance, and the Oracle extraction ask

## Why these seven, in one paragraph

The Snowflake ETL does not hard-code its reference data. Every code
translation, junk-name check, phone-area check, address-doctor text,
daylight-saving instant, and exception description comes from a lookup
table (or view) that the IDQ mappings also read on Oracle. In Snowflake
those lookups are implemented as eight SQL table functions in
`00_common/02_snow_common_lookups.sql` (`fn_snow_helper40_common` …
`fn_snow_helper47_common`). A calling procedure joins the function the
way IDQ joins a lookup: set-based, one hash join, at most one row per
lookup key (the function keeps one row per key with
`QUALIFY ROW_NUMBER()`, mirroring IDQ's "Multiple matches: Return any
row"). The functions are evaluated inside the calling statement, so
they read the same snapshot as the rest of that statement — the
Snowflake equivalent of IDQ's static lookup cache.

That is why these seven objects are special. Procedure bodies are
**not** validated at `CREATE` time in Snowflake, but these eight
functions **are** (they are SQL table functions, not procedures). On a
fresh target without the seven objects, the whole lookups file fails —
8 statements, error `002003` — while the other ~330 statements install
fine. The ETL then looks installed and is not runnable: loaders that
need a translation return nothing, enrichment flags rows as
lookup-not-found, and exception passes silently drop rows (see
§4 below). The placeholder file
`reference_objects_for_barebones_install.sql` lets `CREATE` succeed,
but its tables are **empty** (and four of its shapes are minimal, not
the Oracle definitions), so lookups still return nothing until the
real definitions **and rows** are loaded. Empty is not the same as
present.

## The seven, one by one

### 1. `EXC_LOOKUP_CODE_VALUE` — the exception catalogue
- **Read by:** `fn_snow_helper40_common`.
- **Key → value:** `EXCEPTION_CODE → EXCEPTION_DESC, EXCEPTION_TYPE`.
- **Used by:** every EXC pass (all dimensions: name, gender, birth,
  death, ethnicity, race, language, suffix, phone, email, extension,
  address exception, alt-id, relationship, TOA, validation).
- **Columns that matter:** `EXCEPTION_CODE`, `EXCEPTION_DESC`,
  `EXCEPTION_TYPE` (the placeholder file also carries the Oracle
  audit columns `EXC_LOOKUP_CODE_VALUE_ID, CREATED_BY, CREATE_DATE,
  UPDATED_BY, LAST_UPDATE_DATE` — confirm against today's Oracle).
- **If missing/empty:** the lookups file fails at install; if present
  but empty, **every EXC pass becomes a silent no-op** — see §4. This
  is the object behind keyword **EXC-CATALOG**.
- **If stale:** any exception code the loaders can emit that is not
  in this table is silently dropped by the inner join today, and
  lands as a placeholder row after the queued EXC-CATALOG fix (§4).
- **Extract from Oracle:** table DDL as-is, all rows, row count, and
  the count of distinct `EXCEPTION_CODE` values. This is the one
  table where a missing row is a silent data loss, not an error, so
  the distinct-code count is the check that matters.

### 2. `V_LOOKUP_CODE_VALUE` — the code-translation view
- **Read by:** `fn_snow_helper41_common` (with a `CODE_TYPE` filter)
  and `fn_snow_helper42_common` (without one, for suffix
  standardisation).
- **Key → value:** `CODE_TYPE, SRC_SYS, SRC_CODE_VALUE →
  MSTR_CODE_VALUE`.
- **Used by:** ethnicity, language, gender (via helper41 in the
  enrich passes and in loaders), state/country, prefix/suffix, and —
  since Common-CS v3 — **phone-type standardisation**:
  `sp_common_enrich_phn_type` requires rows with
  `CODE_TYPE = 'PHONE_TYPE'` for each source, **including identity
  rows** where an already-standard code maps to itself
  (`SRC_CODE_VALUE = MSTR_CODE_VALUE`). Without the identity rows,
  a good phone type is flagged `LOOKUP_NOT_FOUND:PHN_TP` and its
  standard column is nulled.
- **If missing/empty:** lookups file fails at install; if empty,
  enrich passes map everything to NULL and flag it.
- **Trap:** on Oracle this is a **view**. The placeholder file
  creates it as a **table**, so replacing it with the real view
  later needs `DROP TABLE` first, then `CREATE VIEW`. Do not try to
  `CREATE OR REPLACE VIEW` over the placeholder table.
- **Extract from Oracle:** the **view definition** as-is, plus the
  rows the view returns (or a materialisation of them), row count,
  distinct `CODE_TYPE` values, and confirmation that `PHONE_TYPE`
  rows (including identity rows) are present for TRS, ECI, FSS,
  TTF, and WIC.

### 3. `LOOKUP_CODE_VALUE` — the master-code translation table
- **Read by:** `fn_snow_helper45_common`.
- **Key → value:** `CODE_TYPE, SRC_SYS, MSTR_REF_CODE →
  MSTR_REF_LABEL`.
- **Used by:** phone usage type (`PHN_USG_TP`) and alt-id type
  (`ALT_ID_TP`) normalisation in loaders. Do not confuse it with
  `V_LOOKUP_CODE_VALUE`: that table translates a *source* code to a
  master code; this one translates a *master reference code* to its
  label.
- **If missing/empty:** lookups file fails at install; if empty,
  usage-type and alt-type labels come back NULL.
- **Extract from Oracle:** table DDL as-is, all rows, row count,
  distinct `CODE_TYPE` values (expect at least `PHN_USG_TP` and
  `ALT_ID_TP`).

### 4. `REF_JUNK_NAME_LIST` — the junk-name list
- **Read by:** `fn_snow_helper43_common`.
- **Key → value:** `NAME → IS_FIRST_JUNK, IS_LAST_JUNK`.
- **Used by:** the name mapplet in loaders: a name is a junk *first*
  name when a row with `EDIT_LIMITATION` NULL or `'FIRST'` has it, a
  junk *last* name when a row has NULL or `'LAST'`. Junk names are
  blanked before standardisation.
- **If missing/empty:** lookups file fails at install; if empty, no
  name is ever treated as junk, so junk names flow through as real
  names instead of being blanked (and then possibly flagged as
  missing names downstream).
- **Extract from Oracle:** table DDL as-is, all rows, row count,
  distinct `EDIT_LIMITATION` values. Note from the lookup code: this
  is the live list, not a dated backup — there is no date stamp on
  the table name.

### 5. `RDM.REF_PHN_AREA_CD` — the phone area-code table
- **Read by:** `fn_snow_helper44_common`.
- **Key → value:** `NPA_ID (first 3 digits of the cleaned phone) →
  SERVICE`.
- **Used by:** phone standardisation in every source's loader
  (`rule_Phone_Std`): the lookup already ran against Snowflake in
  IDQ through the Snowflake connection, and the Snowflake function
  reproduces its filter verbatim — in service (or in-service date
  reached), geographic or toll-free, US or non-geographic. Canada
  and Caribbean countries are excluded.
- **Two traps, both in the placeholder file's header:**
  1. The function references this table **qualified as `RDM.`**,
     so it must live in a schema literally named `RDM` in the **same
     database** as the install. Any other schema name breaks it.
  2. `CREATE SCHEMA` switches the session's current schema, so the
     placeholder file creates the `RDM` schema and its table
     **last**; nothing unqualified may follow it.
- **If missing/empty:** lookups file fails at install; if empty,
  every phone's area check finds nothing, so phones that should
  validate get an `Invalid_Phone_Number`-class exception.
- **Extract from Oracle:** table DDL as-is, all rows, row count,
  distinct `SERVICE` and `COUNTRY` values, and the range of
  `IN_SERVICE_DT` values. This table changes when numbering-plan
  area codes change — it is not a one-time load.

### 6. `REF_MATCHCODE_DESC` — the AddressDoctor match-code text
- **Read by:** `fn_snow_helper46_common`.
- **Key → value:** `MATCH_CODE → DESCRIPTION`.
- **Used by:** address validation (`mplt_Global_Addr_Validation`):
  the text of an AddressDoctor match code, carried into the
  `DQM_ADDRESS` output. Note from the lookup code: with the
  pass-through validator the match code is NULL, so nothing matches
  — a NULL match code is normal, not a missing-reference symptom.
- **If missing/empty:** lookups file fails at install; if empty,
  DQM address rows carry a NULL match-code description.
- **Extract from Oracle:** table DDL as-is, all rows, row count.

### 7. `REF_DYLGHT_SVNGS_TM` — the daylight-saving instants
- **Read by:** `fn_snow_helper47_common`.
- **Key → value:** `DST` (a timestamp; the function returns the
  distinct instants).
- **Used by:** timeline / DST correction (`mplt_DST_Correction`):
  the join is on `DST = DATEADD(hour, 2, <end date>)`, i.e. the
  instant a period ends is shifted where daylight saving applies.
- **If missing/empty:** lookups file fails at install; if empty,
  DST corrections silently do not apply and timeline dates can be
  off by the DST shift.
- **Extract from Oracle:** table DDL as-is, all rows, row count,
  and the **latest `DST` value** — this table must cover future
  years before they occur, so the latest instant is the maintenance
  signal: if it does not extend past the next load year, it needs
  extending before that year is loaded.

## How the seven relate to DIAG-GAP and EXC-CATALOG

The chain from a bad record to a visible exception row has four
links, and a break at any link is silent:

```
staging row
  → loader verdict, written into a DIAG_*_EXC_CD column     (DIAG-GAP fixed this link:
  → EXC pass predicate: DIAG code IS NOT NULL                loaders now write the verdicts)
  → catalogue join (helper40 → EXC_LOOKUP_CODE_VALUE)       (EXC-CATALOG is this link:
  → EXC_STG_BAD_REC_MEMB row                                  the join is INNER today)
```

- **DIAG-GAP** (delivered, on top of the flag patch-out) was the
  first half: before it, flagged rows without DIAG codes left the
  exception table silent while the audit view looked complete.
  Loaders now wire their already-computed verdicts into DIAG
  columns (21 loaders gained DIAG writes; WIC PTY was already
  complete).
- **EXC-CATALOG** (nominated, fix queued after CRE-RUNTIME) is the
  second half: the EXC pass still inner-joins the catalogue for
  `EXCEPTION_TYPE` and `EXCEPTION_DESC`. A DIAG code the catalogue
  does not know drops the row with no error. The chain is only
  closed when both halves hold: verdict written **and** catalogue
  covering the code.
- The other six objects are the same pattern in other dimensions:
  a missing or stale lookup does not raise an error in a loader or
  enrich pass, it returns no row, and the code proceeds with NULL
  (or a flag). That is why the extraction ask below is about rows
  and distinct-key counts, not just definitions: a table that
  exists but is empty passes install and fails silently at run time.

## The queued EXC-CATALOG fix (design, not yet built)

Agreed direction, to be built after the CRE-RUNTIME generation
completes (sequencing rule: one code generation at a time):

1. In every EXC pass, change the helper40 join from `INNER JOIN`
   to `LEFT JOIN`. The exception row is then always written when
   the DIAG predicate fires — no more silent no-op.
2. When the catalogue has no row for the code, write a short,
   monitorable placeholder instead of inventing a description:
   - `EXCEPTION_TYPE`: left NULL (unknown — not invented).
   - `EXCEPTION_DESC`: `LOOKUP_MISSING: add code to
     EXC_LOOKUP_CODE_VALUE` (49 characters; the code itself is
     already in the row's `EXCEPTION_CODE` column, so the message
     does not need to repeat it).
   - Operations monitor: `WHERE EXCEPTION_DESC LIKE
     'LOOKUP_MISSING%'`, grouped by `EXCEPTION_CODE`. That list
     **is** the list of rows to add to the catalogue.
3. One trap in the placeholder design, and the reason the fix also
   carries a reconciliation step: the EXC pass's `NOT EXISTS`
   guard is on `(SRC_SYS_ID_1, EXCEPTION_CODE, ATTRIBUTE_NAME,
   ATTRIBUTE_VALUE)` — it does not look at the description. So a
   placeholder row, once written, would block the corrected row on
   every later run even after the catalogue is fixed. The fix
   therefore also includes, in each EXC pass before the INSERT, an
   UPDATE that heals placeholder rows whose code now exists in the
   catalogue (set `EXCEPTION_TYPE` / `EXCEPTION_DESC` from the
   catalogue, for rows whose description starts with the marker
   only). After the catalogue row is added, the next run heals the
   old rows by itself; nobody has to delete rows by hand, and a
   re-run of the driver is not needed to fix them.
4. What the fix deliberately does **not** do: it never invents a
   description or type, never backfills the catalogue, and never
   changes the exception code. The catalogue remains the single
   source of truth for what a code means; the placeholder only
   makes its absence visible.

Verification planned for that generation (same bar as the prior
ones): arity check, dry-run parse, live CREATE-only compile into a
new scratch schema, and a stub-data smoke — catalogue row present
→ real type/description; catalogue row absent → placeholder row
written, exactly one, zero on re-run; catalogue row added later →
next pass run heals the placeholder row's type/description.

## Maintenance — who owns what, and what to watch

- **Owner:** the reference-data owner for each source system, not
  the ETL run itself. The ETL never writes to these seven tables;
  it only reads them. Any change to a code list is a reference-data
  change, deployed before the load that needs it.
- **Refresh triggers (not a calendar):** a new exception code
  (EXC catalogue), a new source code or a new phone type
  (V_LOOKUP_CODE_VALUE, including identity rows), a new usage or
  alt-id type label (LOOKUP_CODE_VALUE), a newly observed junk name
  (REF_JUNK_NAME_LIST), a numbering-plan change (REF_PHN_AREA_CD),
  a new AddressDoctor match code (REF_MATCHCODE_DESC), and the
  turn of a year the DST table does not yet cover
  (REF_DYLGHT_SVNGS_TM).
- **Monitoring queries to run after any load:**
  - Placeholder exceptions: count of EXC rows with
    `EXCEPTION_DESC LIKE 'LOOKUP_MISSING%'` by `EXCEPTION_CODE`
    (zero is the healthy state; after the fix lands, any row here
    is an action item, not noise).
  - Catalogue coverage: distinct DIAG codes the loaders can emit
    minus distinct `EXCEPTION_CODE` values in the catalogue —
    the EXC-CATALOG check. Any code in the first set and not the
    second is a silent drop today, a placeholder row after the fix.
  - Phone-type identity rows: `V_LOOKUP_CODE_VALUE` rows with
    `CODE_TYPE = 'PHONE_TYPE'` and `SRC_CODE_VALUE =
    MSTR_CODE_VALUE`, per source.
  - Area-code coverage: staging phones whose 3-digit NPA has no
    row in `RDM.REF_PHN_AREA_CD` under the helper44 filter.
- **If a load ever shows zero exceptions everywhere:** suspect an
  empty catalogue before celebrating clean data. Zero EXC rows
  with non-empty DIAG codes is the signature of this failure mode.

## The Oracle extraction ask — what to send back

For each of the seven objects above, please extract from today's
Oracle and hand over:

1. The object as it exists on Oracle: table DDL, or the view
   definition for `V_LOOKUP_CODE_VALUE`, with its owning schema
   name as found on Oracle (the Snowflake install needs the
   `RDM` schema literally for `REF_PHN_AREA_CD`; the other six
   install unqualified into the target schema, so their Oracle
   schema is for provenance, not for the install).
2. The rows: a full export (CSV or `INSERT` statements — either
   is fine, but keep one file per object and keep the file's
   column order matching the DDL).
3. Two counts with each file: total rows, and distinct values of
   the key column(s) listed for that object above. The distinct
   count is what the coverage checks in §5 run against.
4. For `REF_DYLGHT_SVNGS_TM`, the latest `DST` value as well, so
   the maintenance signal in §1.7 is answerable at a glance.
5. Anything that is **not** one of the seven but a loader or pass
   reads from Oracle: flag it rather than folding it in silently
   — the rule for this estate is that missing objects are flagged,
   never invented.

What you send back will replace the placeholder shapes (four
minimal, three Oracle-translated in the placeholder file) with the
real definitions and rows. Until then, treat any install on a fresh
target as "lookups file expected to fail" and any empty-catalogue
run as "exceptions expected to be silent" — both are known states,
neither is a surprise.

# Walk-back: a TTF member with HUB_STATE_IND = -1 in the C_S tables

## What -1 means (read this first)

`HUB_STATE_IND` on a C_S row is an instruction to the MDM batch,
not a description of the source row: `1` = active, `-1` =
soft-delete (the hub row is flagged, never physically deleted),
`NULL` = not yet set (forced to `1` for an open `VERSION_SEQ = 1`
row, the IDQ fix for the error raised when all cross-references
are soft-deleted before a row is end-dated).

TTF follows the ECI/WIC shape, not the TRS shape: there is no
TRS-style deactivation capture table. TTF marks members inactive
through an inactive-status table, and the ongoing party loader
writes `HUB_STATE_IND = 1` for the rows it loads — so a -1 row
in a TTF C_S table comes from the deactivation/end-dating path,
not from the ordinary load. TTF's extra, source-specific signal
is the `ACTIVE` flag (and `CLIENT_EXISTS_FLAG`) carried by its
source view, `V_TTF_ETL_SRC`. Both signals must be checked;
they do not always agree, and the disagreement is itself
diagnostic (see Step 4).

TTF has **no ADR dimension** in this estate (no TTF address
loader). A TTF walk-back therefore covers party, role, phone,
and alt id only — do not go looking for a TTF address row.

## Step 0 — Fix the member you are tracing

Business key: `PTY_SRC_KEY` as carried by `V_TTF_ETL_SRC`
(related keys on the same view: `DEMOGRAPHICS_ID`,
`FYCLIENTS_ID`, `CLIENTS_ID`, `CLIENTCODE`, `SUBMISSIONID`).
Resolve a name or hub rowid first:

```sql
SELECT PKEY_SRC_OBJECT, ROWID_OBJECT, ORIG_ROWID_OBJECT,
       ROWID_SYSTEM, HUB_STATE_IND
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'TTF'
  AND PKEY_SRC_OBJECT = '<PTY_SRC_KEY>';
```

## Step 1 — The C_S party row: capture the keys

```sql
SELECT PKEY_SRC_OBJECT, VERSION_SEQ, PERIOD_START_DATE,
       PERIOD_END_DATE, TIMELINE_ACTION, LAST_UPDATE_DATE,
       SRC_LAST_UPD_DT, PTY_BO_CLASS_CD, HUB_STATE_IND,
       FRST_NM, LST_NM, BIRTH_DT
FROM C_S_TTF_PTY
WHERE HUB_STATE_IND = -1 AND PKEY_SRC_OBJECT = '<PTY_SRC_KEY>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;
```

Write down: `PKEY_SRC_OBJECT`, `VERSION_SEQ`,
`PERIOD_END_DATE` / `TIMELINE_ACTION` (a -1 row should be
end-dated; an open -1 row is the suspect pattern), and
`LAST_UPDATE_DATE` (the run timestamp — your date anchor).
In the TTF loader, `SRC_LAST_UPD_DT` carries the source
`SUBMITDATE`; match on that in the source view, not on
`LAST_UPDATE_DATE`.

## Step 2 — The role and dimension rows: how wide is the -1?

```sql
SELECT PKEY_SRC_OBJECT, PTY_FK, RLE_BO_CLASS_CD, VERSION_SEQ,
       PERIOD_START_DATE, PERIOD_END_DATE, HUB_STATE_IND, LAST_UPDATE_DATE
FROM C_S_TTF_PTY_RLE
WHERE PTY_FK = '<PTY_SRC_KEY>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;

-- Dimensions by the role key: phone and alt id (no ADR for TTF).
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_TTF_PTY_RLE_PHN  WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_TTF_PTY_RLE_ALT_ID WHERE PTY_RLE_FK = '<role key>';
```

PTY -1 + RLE -1 = party deactivation. RLE -1 with PTY live =
role deactivation. PTY -1 with an open PTY row still present =
version history (the -1 row closed an old version).

## Step 3 — The inactive-status table: the actual cause

```sql
SELECT SRC_KEY, ROWID_SYSTEM, DEACTIVATION_STS
FROM STG_TTF_PTY_INACTIVE_STS
WHERE SRC_KEY = '<PTY_SRC_KEY>' AND ROWID_SYSTEM = 'TTF';
```

A row here with a non-null `DEACTIVATION_STS` is the
inactive evidence. As with ECI, the TTF loader tests `EXISTS`
on this table and flags inactive members (spine flag
`INACTIVE_STATUS`); inactive members still land flagged, and
the deactivation path end-dates them to -1. So you should
find both the status row and the -1 C_S row, with dates
lining up with the run in Step 1. If there is no status row,
the -1 did not come from inactive status: go to Step 4.

## Step 4 — The source view: ACTIVE and CLIENT_EXISTS_FLAG (today only, via the view)

The source view is the TTF `_D`/`_H` surface in this estate,
and it carries two flags that must be read together:

```sql
SELECT DEMOGRAPHICS_ID, PTY_SRC_KEY, YEAR, MONTH, ZIP,
       FIRSTNAME, LASTNAME, MIDDLENAME, DOB, ACTIVE,
       CLIENT_EXISTS_FLAG, SUBMITDATE, SUBMISSION_UPDATEDDATE,
       REPORTFORDATE, LOAD_DATE, CREATEDDATE, UPDATEDDATE
FROM V_TTF_ETL_SRC
WHERE PTY_SRC_KEY = '<PTY_SRC_KEY>'
ORDER BY SUBMITDATE, LOAD_DATE;
```

Read them as: `ACTIVE` is the submission's own active flag
for that demographics/submission row (note it is per
submission, not per member — a member with several
submissions can have mixed `ACTIVE` values, and the latest
submission by `SUBMITDATE`/`SUBMISSION_UPDATEDDATE` is the
one that matters); `CLIENT_EXISTS_FLAG` says whether the
client still exists in the source. Disagreements to note:
`ACTIVE = 0` with `CLIENT_EXISTS_FLAG = 'Y'` = inactive but
still present (an inactive-status deactivation, consistent
with Step 3); `CLIENT_EXISTS_FLAG = 'N'` = the client itself
is gone from the source (a stronger event than inactivity —
check whether the inactive-status row exists, and whether
the member's later submissions simply stopped arriving).

The view hides its base tables: in production, read the view
definition to name the `_D` (daily truncate-load) and `_H`
(append-only history) tables behind it. The `_D` vs `_H`
rule applies through the view exactly as elsewhere: the
view's current rows show today; the history behind it (or
the view's `LOAD_DATE`/`SUBMITDATE` sequence, if that is
all that is retained) shows when a flag flipped. A view read
on a later day cannot clear or confirm a past flag — pair it
with the `_H` base table whenever the view definition gives
you one.

## Step 5 — The _H history: when did it flip?

There is no separate `_H` party table for TTF named in this
estate. In practice the flip evidence is, in order: (1) the
appearance of a `DEACTIVATION_STS` row in
`STG_TTF_PTY_INACTIVE_STS` (Step 3 — that table is itself
the dated inactive history for the party); (2) the
`ACTIVE`/`CLIENT_EXISTS_FLAG` sequence over submissions in
the view (Step 4), ordered by `SUBMITDATE` /
`SUBMISSION_UPDATEDDATE` / `LOAD_DATE` — the submission
where `ACTIVE` turns 0, or `CLIENT_EXISTS_FLAG` turns to
`'N'`, is the flip, and the submission before it is the
last active state; (3) the `_H` base table behind the view,
if the view definition names one — query it by
`PTY_SRC_KEY` ordered by its load/effective timestamp, the
same way as any `_H` table.

## Step 6 — The hub: did the batch apply it?

```sql
SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM, MAX(HUB_STATE_IND)
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'TTF' AND PKEY_SRC_OBJECT = '<PTY_SRC_KEY>'
GROUP BY PKEY_SRC_OBJECT, ROWID_SYSTEM;
```

Hub -1 = applied. Hub still 1 with a status row and a -1
C_S row = captured/written but not yet applied. Hub -1 with
no status row and no view flag flip = the -1 came from
outside this chain — say so.

## Traps

1. **ACTIVE is per submission, not per member.** Mixed
   values across submissions are normal; use the latest
   submission, not any single row.
2. **No TTF address dimension.** Do not chase a missing
   TTF address row as evidence of anything.
3. **View opacity.** `V_TTF_ETL_SRC` hides its base tables;
   read its definition before concluding a source row does
   not exist, and before assuming which table is `_D` and
   which is `_H`.
4. **_D is today only.** See Step 4–5.
5. **Snowflake rewrite caveat.** The Snowflake TTF loader
   reproduces the inactive-status logic, but the wider
   estate's deactivation behaviour carries documented parity
   gaps (IDQ deletes vs insert-only). Trace a production -1
   through the IDQ chain above.

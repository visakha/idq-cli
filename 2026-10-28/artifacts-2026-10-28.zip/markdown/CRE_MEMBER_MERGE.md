# CRE-MEMBER-MERGE — how CRE case merges are detected, verified against MDM history, and handed to the MDM batch

Keyword: **CRE-MEMBER-MERGE**. This write-up traces one mechanism only:
the CRE source's own duplicate-case handling (case moves and case
deletes), how the IDQ mapping — and the Snowflake loader that
reproduces it — checks a claimed merge against the MDM hub's own
merge history before trusting it, and what happens downstream
depending on the answer. Sources are the IDQ mapping documentation
for `m_Tgt_C_S_CRE_CARE_Clients` (workflow
`wf_CRE_Stage_Load_Ongoing`), the bare-bones publish branch
`sp_snow_pub_CRE_CARE_CRE_SRC_MRG`, and the spine-first loader
`sp_sf_load_CRE_CARE` (all 8 CTE blocks repeat the same merge
chain; the first block writes `CRE_SRC_MRG` itself).

## TL;DR

CRE does its own deduplication. When two CARE cases turn out to be
the same member, the CRE system moves one case into the other
(`CASEMOV`) or deletes a case (`CASEDEL`), and that decision arrives
as a maintenance feed. The IDQ mapping does **not** re-match members
itself. Instead, for every claimed move it asks the MDM hub a
question: *have either of these two members ever been merged
before?* It answers that question from two hub tables,
`C_B_PTY_XREF` (cross-references) and `C_B_PTY_HMRG` (history of
merges), and derives a single flag, `ORIG_ROWID_OBJECT_DESC`:

| Flag | Meaning | What happens |
|---|---|---|
| `'N'` | Neither member has **any** merge history in the hub | The move is **new**: it is written to `CRE_SRC_MRG` (source MDM rowid, target MDM rowid, run date) for the MDM batch to act on, and downstream data for the move is re-keyed to the **target** member |
| `'Y'` | At least one of the two members **has** merge history | The move is **not** re-sent: no `CRE_SRC_MRG` row, and downstream data keeps the member's **own** id |
| `NULL` | The row is not a merge candidate at all (regular client, or a case delete) | No merge decision; the row follows the regular / end-dating path |

That is the yes/no flag, and it affects loading in two places at
once: the `CRE_SRC_MRG` handoff table, and the alternate-id keys
computed downstream in the same run.

## The actors

### The MDM hub tables (the ground truth being checked against)

- **`C_B_PTY`** — the hub's base-object party table: the member
  itself. Everything else hangs off it. (It is read by reference in
  this logic through its rowids; the merge chain itself joins the
  two tables below, not `C_B_PTY` directly.)
- **`C_B_PTY_XREF`** — the cross-reference table. One row links a
  source-system key to a hub party. Columns that matter here:
  - `PKEY_SRC_OBJECT` — the source key, here a CARE id.
  - `ROWID_OBJECT` — the hub party's current rowid for that key.
  - `ORIG_ROWID_OBJECT` — the party's **original** rowid, i.e. its
    identity before any merge. This is the column the history
    check is done on, not the current rowid — so the check follows
    a member through multiple merges instead of losing it after
    the first one.
  - `ROWID_SYSTEM` — filtered to `'CRE'` in this chain.
  - `ROWID_XREF` — the xref row's own id, used only to pick one
    row when a key has several (`ORDER BY ROWID_XREF`, first row
    wins — see the open questions).
- **`C_B_PTY_HMRG`** — the history-of-merges table. Each row is one
  merge the hub has already recorded, as a pair of hub rowids:
  `SRC_ROWID_OBJECT` (the party merged away) and
  `TGT_ROWID_OBJECT` (the party merged into). If a merge is in
  this table, the hub has already done it; if it is not, the hub
  has not — that is the whole test.
- **`CRE_SRC_MRG`** — the handoff table this mapping writes. Three
  columns only: `SRC_ROWID_OBJECT`, `TGT_ROWID_OBJECT`,
  `RUN_DATE` (the run timestamp). It is **not** a hub table and it
  is **not** read back by any loader, driver, or pass in this
  estate. Its consumer is the MDM batch, outside this codebase
  (see §6).

### The CRE source feed (where a "merge" comes from)

CRE's dedupe decision arrives as case maintenance, in two staging
tables:

- `STG_CRE_D_CARE_CLIENTS` — the daily delta of CARE clients,
  with `MAINT_FLAG` (`NULL` = regular client, `'D'` = a
  maintenance row).
- `STG_CRE_D_CARE_CASE_MAINT` — the case-maintenance feed, with
  `SOURCE_ID`, `TARGET_ID`, and `REC` (`'CASEMOV'` = this case
  moved into another case, `'CASEDEL'` = this case was deleted).
- `STG_CRE_SN_CARE_CLIENTS` — the snapshot of CARE clients, used
  to resolve the maintenance rows back to full client records.

The loader composes three input branches (the IDQ custom SQL, kept
verbatim in structure):

1. **Regular clients** — daily clients with `MAINT_FLAG IS NULL`,
   `SOURCE_ID`/`TARGET_ID`/`REC` all NULL, record type `'I'`.
2. **Move/delete sources** — delta clients (`MAINT_FLAG = 'D'`)
   joined to snapshot clients and to a maintenance row where the
   client is the `SOURCE_ID` and `REC` is `'CASEMOV'` or
   `'CASEDEL'`; record type is decoded as `'B'` for a move
   (moved away) and `'D'` for a delete.
3. **Move targets** — snapshot clients joined to a maintenance row
   where the client is the `TARGET_ID` and `REC` is `'CASEMOV'`;
   record type `'A'` (added as the surviving side of a move).

Record types, for reference: `'I'` = insert/new, `'A'` = move
target, `'B'` = moved away (end-dated), `'D'` = deleted
(end-dated). `'B'` and `'D'` rows are end-dated in the timeline:
period start = `CARE_LASTUP_DT` − 1 day, period end =
`CARE_LASTUP_DT`, timeline action = 2, and — this is the same
rule that explains the CRE loader's run-timestamp-minus-one-hour
stamp — `LAST_UPDATE_DATE` = run start − 1 hour (the role keeps
the run start). `'I'` and `'A'` rows take
`PERIOD_START_DATE = CARE_LASTUP_DT` and the rest NULL.

## The router: which rows are even merge candidates

The IDQ router `RTR_MERGES` sends each row to a group, and the
Snowflake loader mirrors it with one boolean, `grp_deletes`:

```
grp_deletes = MAINT_FLAG IS NULL
           OR (MAINT_FLAG = 'D' AND REC = 'CASEDEL')
```

**Naming trap — read this before the code.** Despite the name,
`grp_deletes` does **not** mean "this row is deleted". It means
"this row is **not** a merge candidate". It is true for regular
clients (branch 1) and for case deletes, and false for move rows
(branch 2 `CASEMOV`, and branch 3 move targets whose snapshot
maintenance flag qualifies). Actual deletion/end-dating is handled
separately, by record type `'D'` in the timeline (above), not by
this boolean. Rows with `grp_deletes` true get
`ORIG_ROWID_OBJECT_DESC = NULL` and never reach the merge filter,
whatever else is true about them.

## The flag derivation, step by step

For every non-`grp_deletes` row, the chain performs four hub
lookups. In IDQ they are `LKP_XREF_SRC`, `LKP_XREF_TGT`,
`LKP_HMRG_SRC1`, `LKP_HMRG_SRC2`, `LKP_HMRG_TGT1`,
`LKP_HMRG_TGT2` (two xref lookups, four merge-history lookups);
in Snowflake they are the `cte_s10_xref` and
`cte_s10_hmrg_src` / `cte_s10_hmrg_tgt` CTEs. The steps:

1. **Resolve both sides through XREF.** Look up the source
   member (`SOURCE_ID`) and the target member (`TARGET_ID`) in
   `C_B_PTY_XREF` for system `'CRE'`, taking the first xref row
   per key. This yields, for each side, the current hub rowid
   (`ROWID_OBJECT`) and the original rowid
   (`ORIG_ROWID_OBJECT`).
2. **Check both originals against HMRG, both ways round.** For
   each side's original rowid, check whether it appears in
   `C_B_PTY_HMRG` as a source **or** as a target. That is four
   checks in total:
   - source original as `SRC_ROWID_OBJECT` (SRC1),
   - source original as `TGT_ROWID_OBJECT` (SRC2),
   - target original as `SRC_ROWID_OBJECT` (TGT1),
   - target original as `TGT_ROWID_OBJECT` (TGT2).
3. **Derive the flag.** In IDQ's expression form:
   `IIF(all four lookups are NULL, 'N', 'Y')`. In Snowflake's
   form: `no_merge_history` is true exactly when all four
   left-joins miss, and `ORIG_ROWID_OBJECT_DESC` is `'N'` when
   `no_merge_history` is true, `'Y'` otherwise (and `NULL` for
   `grp_deletes` rows, per §3).

Note what the flag does **not** say. `'Y'` does **not** mean
"this exact (source, target) move was already processed". It
means "at least one of these two original members has been
involved in **some** merge before, with **anyone**". The check
is on the members, not on the pair. That distinction drives the
second-move question in §7.

4. **Filter for the handoff.** `FLTR_CRE_MRG` keeps only
   `'N'` rows, and the loader's first block inserts exactly
   those into `CRE_SRC_MRG`:
   `(src_rowid_object, tgt_rowid_object, run_ts)` — the hub
   rowids from step 1, stamped with the run timestamp. In
   Snowflake terms the gate is `grp_mrg`, defined as
   `NOT grp_deletes AND orig_rowid_object_desc = 'N'`.

## The second, quieter effect: MRG_CARE_ID

The flag does not only gate the handoff table. In the same run,
the loader derives a merged care id used downstream:

```
MRG_CARE_ID = TARGET_ID   when ORIG_ROWID_OBJECT_DESC = 'N'
            = CARE_ID     otherwise ('Y', or NULL for deletes)
```

For an **unmerged** move (`'N'`), the CARE-id alternate id is
computed from the **target** id, under the key of the source
member — i.e. the surviving member's id travels with the
moved-away member's key — and that id (via helper37's
`rule_CARE_ID_Std` object) feeds the Medicaid/SSN exception
grouping and the alt-id keys. Exception rows for the source and
the target of an unmerged move therefore carry the merged
(target) id as `SRC_SYS_ID_1`, which is also the documented
source of a known duplicate-exception-row risk (two equal
exception rows: IDQ rejects the second and carries on; a
single-statement Snowflake load fails as a whole — see the
mapping's open-risk note).

For a **previously merged** member (`'Y'`), downstream data
keeps its own `CARE_ID`. The reasoning, as the code expresses
it: the hub already knows about this member's merge, so this
run must not re-apply the move by re-keying its data to a
target.

## What the Snowflake loader preserves — and what it does not change

- The router, the four-lookup flag derivation, the `'N'`-only
  filter, and the `MRG_CARE_ID` rule are reproduced verbatim
  from IDQ in every one of the loader's 8 CTE blocks (the
  `CRE_SRC_MRG` block plus the 7 C_S_* blocks); the CRE
  patch-out changed only flag/DIAG columns around them, and the
  CRE report records the merge chain as untouched by that
  generation.
- `CRE_SRC_MRG` is written in the loader's first block, in the
  same transaction as the C_S_* loads, and committed with them
  by the driver. It is insert-only in this mapping (like every
  target here: never truncated by the loader). No loader, pass,
  or driver in this estate reads it back.
- The loader does **not** merge anything in the hub itself, does
  not dedupe members by matching, and does not schedule the MDM
  batch. Its job ends at writing dated handoff rows.

## The handoff: what happens "the next day" (and what is not verified here)

`CRE_SRC_MRG` rows, stamped with `RUN_DATE`, are the batch's
work list: each row says "hub party `SRC_ROWID_OBJECT` was
moved into hub party `TGT_ROWID_OBJECT` by CRE, and the hub
had no record of it when we checked". The MDM batch — the
user's team's code, outside this estate — is expected to pick
those rows up in a subsequent daily run, perform the merge in
the hub (which in hub terms means recording the merge in
`C_B_PTY_HMRG` and updating the cross-references, so that the
next day's check for the same members returns `'Y'`), and
end-date the source party accordingly.

**What is not verified from this estate:** the batch's job
name, schedule, or exact actions are not in any file examined
for this write-up, and no reader of `CRE_SRC_MRG` exists in
the Snowflake code here. "Next day" is therefore stated as the
operational cadence (a dated handoff consumed by a later daily
batch), not as a behaviour this loader enforces. Confirm the
consumer and its timing with the MDM batch owner before
treating any `CRE_SRC_MRG` row as "sent" in a stronger sense
than "written by this loader".

## Quirks and traps in the mechanism (all from the IDQ documentation, kept in Snowflake)

1. **A move is written even when neither member exists in XREF.**
   If the CARE ids have no cross-reference at all, both
   `ROWID_OBJECT`s are NULL — and the four HMRG lookups are
   then also NULL, so the flag is `'N'` and a
   `(NULL, NULL, run_date)` row lands in `CRE_SRC_MRG`. The
   batch can merge nothing from a NULL/NULL row; whether it
   ignores, errors, or queues such rows is a batch-side
   question, and the row count of NULL/NULL handoff rows is
   worth monitoring (see §8).
2. **A move can be written twice.** The move-target row
   (`'A'`) is written to `CRE_SRC_MRG` once more when the
   snapshot gives it a `MAINT_FLAG` that qualifies it out of
   the `grp_deletes` group. `CRE_SRC_MRG` has no dedup in this
   mapping, so duplicate (source, target) pairs for one move
   are possible; the batch must tolerate or dedupe them.
3. **The flag is member-level, not pair-level (the second-move
   question).** Because `'Y'` fires when *either* original has
   *any* merge history, a member that merges a second time —
   a genuinely new `CASEMOV` for a member already in `HMRG`
   from an earlier merge — will also get `'Y'` and will
   **not** reach `CRE_SRC_MRG`. Whether that is intended
   (the batch picks second moves up through another route,
   e.g. the end-dated `'B'` party rows) or a gap (second
   moves are silently never sent) is **not** answered by any
   file examined here, and it is the single most important
   question to put to the MDM batch owner. Do not assume
   either answer.
4. **XREF pick-first.** When a CARE id has several xref rows,
   only the first by `ROWID_XREF` is used for both the
   handoff rowids and the history check. If the first row is
   not the currently active cross-reference, both the flag
   and the handoff pair follow the wrong rowid.
5. **The `grp_deletes` naming trap** (§3): a regular new
   client is a "DELETES-group" row in router terms. Anyone
   reading the loader's `grp_deletes` boolean as "this row is
   being deleted" will misread every regular client row.
6. **History check follows originals, not currents.** That is
   deliberate and correct for repeated merges — but it also
   means a stale or wrong `ORIG_ROWID_OBJECT` in XREF poisons
   the flag for every later move involving that member.

## Relation to the other CRE items (do not conflate them)

- **PTY-ISMEMBER** (separate, parked for the user's decision):
  in IDQ, invalid-name members are *logged and dropped* — the
  name route writes `Missing_First_Name` / `Missing_Last_Name`
  exception rows from staging even though the member never
  loads to `C_S_CRE_PTY`. The spine-first rewrite lost that
  log (its name pass reads only landed rows). That is a
  *name-validity* gap, unrelated to merges except that both
  live in the same loader's router chain.
- **CRE-RUNTIME correction**: the loader's run-timestamp-minus-
  one-hour stamp on end-dated `'B'`/`'D'` rows is the timeline
  rule from this same mapping, not a staging timestamp — the
  merge chain's end-dating and the timestamp rule are the same
  mechanism seen from two sides.
- **No other source does this.** A grep over the whole v3 tree
  finds `HMRG` only in the CRE loader. TRS's merge-adjacent
  machinery is the opposite direction (unmerge / soft-delete
  on deactivation), not hub-merge reconciliation. CRE is the
  only source whose dedupe is source-system-driven and
  hub-verified in this way.

## Checks worth running (before trusting the handoff)

These are read-only counts against a loaded run; they need a
schema with `CRE_SRC_MRG`, `C_B_PTY_XREF`, and `C_B_PTY_HMRG`
populated, and they answer the questions above without changing
anything:

1. `CRE_SRC_MRG` rows per `RUN_DATE` — the daily volume of
   claimed new merges.
2. Rows with both rowids NULL — the §7.1 quirk, by day. Any
   non-zero count goes to the batch owner with the question
   "what do you do with these?".
3. Duplicate (source, target) pairs within one `RUN_DATE` —
   the §7.2 quirk.
4. Distribution of the flag in a run: count of `'N'` vs `'Y'`
   vs `NULL` `ORIG_ROWID_OBJECT_DESC` over the loader's input
   population (recomputable from the CTE chain on staging +
   hub tables) — `'N'` should equal the `CRE_SRC_MRG` row
   count for that run, modulo duplicates.
5. Second-move probe: CARE ids with a `CASEMOV` in the current
   feed whose original rowid already appears in `HMRG` —
   these are the §7.3 cases. List them and ask the batch owner
   whether they are handled elsewhere; do not flip the flag
   logic to force them through without that answer.
6. XREF multiplicity: CARE ids with more than one xref row —
   the §7.4 pick-first exposure.

## Open questions (for the user / MDM batch owner)

1. Who consumes `CRE_SRC_MRG`, on what schedule, and what
   exactly does it do per row (write `HMRG`, update `XREF`,
   end-date the source party, something else)? What does it
   do with NULL/NULL rows and with duplicates?
2. Second moves (§7.3): is a member merging twice handled by
   another route, or is it genuinely never sent? If the
   latter, is that accepted, or should the flag become
   pair-level (this exact pair in `HMRG`) instead of
   member-level?
3. Is `ROWID_XREF` order the right pick-first rule for
   multi-xref CARE ids, or should the currently active xref
   row be selected another way?
4. Does the batch feed anything back (e.g. a processed flag
   on `CRE_SRC_MRG`, or a confirmation) that this loader
   should read on the next run? As written, the loader never
   reads `CRE_SRC_MRG` back, so a failed batch run would leave
   the next day's `'Y'`/ `'N'` answers unchanged — the check
   is against hub history only, not against handoff
   consumption.

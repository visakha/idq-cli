# Walk-back: a CRE member with HUB_STATE_IND = -1 in the C_S tables

## What -1 means (read this first)

`HUB_STATE_IND` on a C_S row is an instruction to the MDM batch,
not a description of the source row: `1` = active, `-1` =
soft-delete (the hub row is flagged, never physically deleted),
`NULL` = not yet set (forced to `1` for an open `VERSION_SEQ = 1`
row, the IDQ fix for the error raised when all cross-references
are soft-deleted before a row is end-dated).

CRE is the one source in this set whose deactivation story is
**not** a separate deactivation workflow with a capture table.
CRE deactivation travels inside the ordinary ongoing mapping
(`m_Tgt_C_S_CRE_CARE_Clients`) as record types: a case that moved
away is record type `'B'`, a case that was deleted is record type
`'D'`, and both are end-dated in the timeline
(`PERIOD_START_DATE = CARE_LASTUP_DT - 1 day`,
`PERIOD_END_DATE = CARE_LASTUP_DT`, `TIMELINE_ACTION = 2`,
`LAST_UPDATE_DATE` = run start - 1 hour). A -1 C_S row for CRE
therefore means: this CARE case was moved away or deleted in the
CRE maintenance feed, and the mapping end-dated it. The walk-back
is: C_S row → record type → maintenance row → snapshot/delta
rows → merge-history check (CRE's extra step, below).

CRE has **no `_H` history table** in this estate and **no**
`PTY_INACTIVE_STS` table. Its history mechanism is different:
a daily snapshot (`STG_CRE_SN_CARE_CLIENTS`) plus a daily delta
(`STG_CRE_D_CARE_CLIENTS`) plus the maintenance feed
(`STG_CRE_D_CARE_CASE_MAINT`). If you need the state of a case
on a past day, it is the snapshot/delta of that day, or the
C_S rows themselves (which are insert-only, never truncated) —
there is no append-only `_H` table to fall back on for CRE
party data. Say that plainly when it bites; do not invent an
`_H` table for CRE.

## Step 0 — Fix the member you are tracing

Business key: `CARE_ID`. Resolve a name or hub rowid first:

```sql
SELECT PKEY_SRC_OBJECT, ROWID_OBJECT, ORIG_ROWID_OBJECT,
       ROWID_SYSTEM, HUB_STATE_IND
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'CRE'
  AND PKEY_SRC_OBJECT = '<CARE_ID>';
```

`ORIG_ROWID_OBJECT` matters for CRE more than for other sources:
it is the identity the merge-history check follows (Step 4).

## Step 1 — The C_S party row: capture the keys

```sql
SELECT PKEY_SRC_OBJECT, VERSION_SEQ, PERIOD_START_DATE,
       PERIOD_END_DATE, TIMELINE_ACTION, LAST_UPDATE_DATE,
       SRC_LAST_UPD_DT, PTY_BO_CLASS_CD, HUB_STATE_IND,
       FRST_NM, LST_NM, BIRTH_DT
FROM C_S_CRE_PTY
WHERE HUB_STATE_IND = -1
  AND PKEY_SRC_OBJECT = '<CARE_ID>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;
```

Write down: `PKEY_SRC_OBJECT` (= `CARE_ID` for CRE — one form,
unlike TRS's two), `VERSION_SEQ`, `PERIOD_END_DATE` /
`TIMELINE_ACTION` (a -1 row should carry an end date and action
2; an open -1 row is the suspect pattern), and
`LAST_UPDATE_DATE` (the run timestamp — your date anchor).
`SRC_LAST_UPD_DT` here is `CARE_LASTUP_DT`, the timestamp to
match in the staging tables.

## Step 2 — The role and dimension rows: how wide is the -1?

```sql
SELECT PKEY_SRC_OBJECT, PTY_FK, RLE_BO_CLASS_CD, VERSION_SEQ,
       PERIOD_START_DATE, PERIOD_END_DATE, HUB_STATE_IND, LAST_UPDATE_DATE
FROM C_S_CRE_PTY_RLE
WHERE PTY_FK = '<CARE_ID>'
ORDER BY VERSION_SEQ, PERIOD_START_DATE;

-- Dimensions by the role key: address, phone, alt id.
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_CRE_PTY_RLE_ADDR WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_CRE_PTY_RLE_PHN  WHERE PTY_RLE_FK = '<role key>';
SELECT PKEY_SRC_OBJECT, HUB_STATE_IND, PERIOD_END_DATE, LAST_UPDATE_DATE
FROM C_S_CRE_PTY_RLE_ALT_ID WHERE PTY_RLE_FK = '<role key>';
```

PTY -1 + RLE -1 = the case itself went away (move or delete).
PTY live + a dimension -1 = a dimension-level end-date, not a
case deactivation. Also check the valid-member rule before
concluding anything about names: a CRE client whose
standardised first **or** last name is blank never lands in
C_S_CRE_PTY at all (the `valid_member` rule — see the
PTY-ISMEMBER note). A member missing from C_S entirely is not
a -1; it is a name-validity drop, a different story.

## Step 3 — The maintenance row: CASEMOV or CASEDEL?

This is CRE's deactivation evidence, and it replaces the
capture tables other sources use:

```sql
SELECT SOURCE_ID, TARGET_ID, REC
FROM STG_CRE_D_CARE_CASE_MAINT
WHERE SOURCE_ID = '<CARE_ID>' OR TARGET_ID = '<CARE_ID>';
```

- `REC = 'CASEDEL'` with this case as `SOURCE_ID` = the case
  was deleted. Expect record type `'D'` in the mapping and an
  end-dated -1 row.
- `REC = 'CASEMOV'` with this case as `SOURCE_ID` = the case
  moved into `TARGET_ID`. Expect record type `'B'` (moved
  away, end-dated) for this case, and record type `'A'` (added)
  for the target case.
- `REC = 'CASEMOV'` with this case as `TARGET_ID` = this case
  is the **survivor** of someone else's move. It should not
  itself be -1 for that reason; if it is, the cause is
  elsewhere (its own CASEDEL, its own later CASEMOV, or a name
  drop — not this move).
- No maintenance row at all = the -1 did not come from a case
  move/delete. Check the delta/snapshot flags in Step 5 and
  the merge handoff in Step 4.

## Step 4 — The CRE-only step: the merge-history check

For a `CASEMOV`, the mapping does not trust the claim blindly.
It resolves both sides through `C_B_PTY_XREF` (system `'CRE'`,
first row by `ROWID_XREF` wins) and checks both original rowids
against `C_B_PTY_HMRG` four ways (each original as merge source
and as merge target). The flag `ORIG_ROWID_OBJECT_DESC` is
`'N'` if all four checks miss (new move) and `'Y'` if any hits
(already merged before). Only `'N'` moves are written to
`CRE_SRC_MRG` (`SRC_ROWID_OBJECT`, `TGT_ROWID_OBJECT`,
`RUN_DATE`) for the MDM batch, and only `'N'` moves re-key
downstream data to the target id (`MRG_CARE_ID = TARGET_ID`).

For your walk-back, this step answers a different question
than "why -1": it answers "was this move new, or already
known?" Check:

```sql
-- Was this move sent to the batch as new?
SELECT SRC_ROWID_OBJECT, TGT_ROWID_OBJECT, RUN_DATE
FROM CRE_SRC_MRG
WHERE RUN_DATE >= <run date from Step 1>
ORDER BY RUN_DATE;
-- Match the pair against the XREF rowids from Step 0.
```

Two quirks to watch for: a move is written to `CRE_SRC_MRG`
even when neither member has an XREF row (both rowids NULL —
the batch can merge nothing from it), and a move can be
written twice (source row plus target row). And the flag is
member-level, not pair-level: a member merging a second time
gets `'Y'` (it already has merge history) and is never
re-sent — if your member's second move never reached the
batch, this is the first place to look, and it is an open
question for the batch owner, not something to "fix" by
flipping the flag.

## Step 5 — The delta and snapshot: what the source actually said

`_D` tables are truncate-and-load daily (today's snapshot
only); the snapshot table is the full client list the delta
is resolved against. Read them as of the run date from Step 1:

```sql
-- Delta row for this case (today's delta only).
SELECT CARE_ID, CARE_LASTUP_DT, FIRSTNM, LASTNM, MAINT_FLAG
FROM STG_CRE_D_CARE_CLIENTS
WHERE CARE_ID = '<CARE_ID>';

-- Snapshot row for this case.
SELECT CARE_ID, CARE_LASTUP_DT, FIRSTNM, LASTNM, MAINT_FLAG
FROM STG_CRE_SN_CARE_CLIENTS
WHERE CARE_ID = '<CARE_ID>';
```

The mapping's three input branches are: (1) daily clients with
`MAINT_FLAG IS NULL` → record type `'I'`; (2) delta clients
with `MAINT_FLAG = 'D'` joined to the snapshot and to a
maintenance row where the client is `SOURCE_ID` and `REC` is
`CASEMOV`/`CASEDEL` → `'B'`/`'D'`; (3) snapshot clients joined
to a maintenance row where the client is `TARGET_ID` and `REC`
is `'CASEMOV'` → `'A'`. Find which branch your member took:
that branch, plus the maintenance row from Step 3, is the
complete source-side story. If the delta/snapshot of the run
day are no longer available (they were truncated since), the
C_S rows from Step 1 — insert-only, never truncated — plus
`CRE_SRC_MRG` are your surviving evidence; state that gap
rather than reconstructing the day from today's tables.

## Step 6 — The hub: did the batch apply it?

```sql
SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM, MAX(HUB_STATE_IND)
FROM C_B_PTY_XREF
WHERE ROWID_SYSTEM = 'CRE' AND PKEY_SRC_OBJECT = '<CARE_ID>'
GROUP BY PKEY_SRC_OBJECT, ROWID_SYSTEM;
```

Hub -1 = applied. Hub still 1 with a `CRE_SRC_MRG` row for
that run = sent but not yet applied (batch pending or failed).
Hub -1 with no maintenance row and no `CRE_SRC_MRG` row = the
-1 came from outside this chain (hub-side script or an
earlier merge) — say so.

## Traps

1. **CRE has no `_H` party history and no inactive-status
   table.** Do not go looking for `STG_CRE_H_*` or
   `STG_CRE_PTY_INACTIVE_STS`; they do not exist in this
   estate. Past-day evidence is the run day's delta/snapshot
   (if retained), the insert-only C_S rows, and `CRE_SRC_MRG`.
2. **Missing from C_S ≠ -1.** A blank first or last name
   drops a CRE client from C_S entirely (PTY-ISMEMBER). Do
   not report a missing member as deactivated.
3. **Source vs target of a move.** A -1 on the `SOURCE_ID`
   side is expected for a `CASEMOV`; a -1 on the `TARGET_ID`
   side needs a different explanation.
4. **The `grp_deletes` naming trap** (if you read the
   Snowflake loader): that boolean means "not a merge
   candidate" (regular clients and case deletes), not "this
   row is deleted". Real end-dating is by record type.
5. **Snowflake rewrite caveat.** The Snowflake CRE loader
   reproduces this chain, but the deactivation/delete
   behaviour of the wider estate carries the documented
   parity gaps (IDQ deletes vs insert-only). Trace -1 in
   production through the IDQ chain above.

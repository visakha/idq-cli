# PARITY-RUN Runbook

Human-driven, tool-executed. The endpoints, install scripts, and results
viewer are automated machinery; this document records the manual
decisions an operator makes around them: when IDQ is done, which
database and data slice, what order to trigger, and how to dispose of
each verdict. It does not re-derive the tools. The tools are:

- The Snowflake ETL, spine-first Common-CS v3 line: drivers, loaders,
  common passes, and `V_MDM_*` / `V_CMP_*` / `V_AUDIT_*` views, as
  shipped in `Snowflake_Spine_First_Common_CS_v3_Flags_Raw_Views_DIAG.zip`
  (the DIAG-patched tree; see its `README_V3.md`, `DESIGN_V3.md`,
  `INSTALL_AND_RUN.md`).
- The Compare tool: the FastAPI service, v5.4.0 lineage
  (`TRS_Compare_FastAPI_v5.4.0.zip`, `USER_GUIDE.md`), and the v5.5.0
  tester pipeline A–G (`Test_Harness_Pipeline_v5.5.0.zip`,
  `PIPELINE_USER_GUIDE.md`) with its Streamlit results viewer
  (`streamlit_app.py`). The sample pack is `Test_Harness_Sample_Data.zip`
  (`sample_data/` inside the pipeline tree).

Scope note: the pipeline registry is fully registered for TRS only
(30 inputs, 20 outputs). Other sources have runners registered but
empty table lists — a copy/compare request for them returns 400, not
an empty run. A parity run for a non-TRS source needs its tables
registered first (pipeline guide §9). The v5 compare covers Member
domain only; Provider is out of scope.

## Purpose and acceptance rule

A parity run proves, on a defined slice of real data, that the
Snowflake ETL produces the same targets IDQ produces. The run passes
only if the compare verdict is **MATCH**, or every differing dimension
or spine is explained by a **known parity gap** listed in §5 below and
recorded as such. Anything else is an open finding, not a pass.

Two warnings frame the whole run. **Compile-green is not
parity-proven.** Snowflake validates procedure bodies only at CALL
time, so an undeclared variable passes CREATE and fails on first
CALL — the `:c_mapping` defect passed a 360/360 compile and would
have failed on first CALL. **Stub smokes prove mechanics, not
parity.** The v3 stub-row smokes (good phone type standardizes, bad
type flags, spine-flagged rows leave the MDM view) prove the flag and
view machinery works; they say nothing about row-count parity
against IDQ on real data. That is what this run is for.

## 1. Prerequisites checklist

Do not start UC2 until every item below is checked. Owner is the
operator unless noted.

- [ ] **Morning check: IDQ finished.** Manual. The pipeline readiness
      endpoint (`GET /pipeline/readiness?source=TRS`) checks that
      registered tables *exist* and reports row counts; it cannot
      tell you whether the 8 AM ETL actually ran. Evidence that
      counts is the IDQ job's own completion record for that morning
      (job log / completion timestamp in your environment).
      **Confirm before running:** the exact IDQ completion signal in
      your environment is not stated in any of the files this
      runbook is grounded in — agree it with the IDQ owner before
      the first real run and write it here.
- [ ] **Non-prod Snowflake database and schema chosen and recorded.**
      Install rule for the v3 line: everything for one source into
      ONE schema (common procedures install into each source schema
      from the same files; there is no COMMON schema in this line).
      The pipeline defaults are `MDM_ETL_<SOURCE>` /
      `<SOURCE>_ETL_WRK` (`PIPELINE_SNOWFLAKE_DATABASE` /
      `PIPELINE_SNOWFLAKE_SCHEMA`). Record the actual database and
      schema used; steps (D) and (E) must point at the same pair.
- [ ] **The 7 reference objects exist with REAL definitions and REAL
      data.** `V_LOOKUP_CODE_VALUE`, `REF_JUNK_NAME_LIST`,
      `REF_MATCHCODE_DESC`, `RDM.REF_PHN_AREA_CD`,
      `EXC_LOOKUP_CODE_VALUE`, `LOOKUP_CODE_VALUE`,
      `REF_DYLGHT_SVNGS_TM`. These are required before any ETL run:
      the lookup functions' bodies (`fn_snow_helper40_common` …
      `fn_snow_helper47_common` in `00_common/02_snow_common_lookups.sql`)
      are validated at CREATE time, so on a fresh target that file
      fails with 002003 if the objects are missing.
      - The existing file `reference_objects_for_barebones_install.sql`
        is a **placeholder, not a substitute**: its tables are EMPTY,
        so CREATE succeeds but lookups return nothing until real
        definitions and data are loaded. Three objects in it carry
        full Oracle-translated definitions from the Compare package
        (`sql/01_etl_wrk.sql`); the other four are minimal shapes
        from `sql/04_missing_tables.sql`. Do not treat a run done
        on placeholders as sign-off.
      - `fn_snow_helper44_common` references `RDM.REF_PHN_AREA_CD`
        qualified: it must live in a schema **literally named `RDM`
        in the SAME database** as the install. An RDM database
        elsewhere does not satisfy it.
      - Ordering trap: `CREATE SCHEMA` switches the session's
        `CURRENT_SCHEMA`, so create the RDM schema LAST, after the
        six unqualified objects, or they land in RDM by mistake.
      - `V_LOOKUP_CODE_VALUE` is a VIEW in Oracle; the placeholder
        creates it as a TABLE. Replacing it later with the real view
        means DROP TABLE first, then CREATE VIEW.
- [ ] **Dictionary rows loaded, including PHONE_TYPE identity rows.**
      The phone-type enrichment (`sp_common_enrich_phn_type`) maps
      `RAW_PHN_TP` → `PHN_TP` through `fn_snow_helper41_common()` with
      `CODE_TYPE='PHONE_TYPE'` and `SRC_SYS=<source>`. The dictionary
      must carry a row per source representation, **including identity
      rows for codes that are already enterprise-standard**. A source
      value with no dictionary row is a lookup miss by definition:
      `PHN_TP` stays NULL and the row flags
      `LOOKUP_NOT_FOUND:PHN_TP`. If a source already emits standard
      codes and nobody added identity rows, those rows will flag —
      that is the contract working, not a bug, but it must be checked
      before the first run. The same reset-then-fill dictionary
      pattern applies to ethnicity and language enrichments.
      **Confirm before running:** actual dictionary contents are
      owned outside the ETL package and are not verified by any file
      in this runbook's sources — confirm the rows exist before
      running, or expect lookup-miss flags.
- [ ] **Data slice defined, in writing.** A parity run is meaningless
      without a stated slice: which source(s), which date or load
      window, which inclusion rule (e.g. all rows for that window,
      or a named subset), and which tables. Both sides must run on
      the same slice. **Confirm before running:** no slice definition
      exists in the shipped files — the operator and the IDQ owner
      define it for each run and record it with the run id.
- [ ] **IDQ baseline snapshot frozen, and how it was frozen recorded.**
      Pipeline route: the baseline is the `Prod_SQLite` file produced
      by step (B) — record its filename. It is frozen the moment
      step (B) completes; do not re-run (B) mid-investigation without
      recording a new baseline. v5 route: the baseline is the IDQ
      side of the target tables (`DATA_SOURCE='IDQ'`) after the copy
      step — record the copy run id.
- [ ] **ETL package installed in the non-prod schema, in order**
      (see UC2 §3). Do not run any ETL runner until the 7 reference
      objects exist.
- [ ] **CRE scope decided.** **Confirm before running:** at the time
      this runbook was written, the CRE loader still stamped a
      staging timestamp rather than the run timestamp (the
      CRE-RUNTIME change was approved but is a separate, sequenced
      piece of work), so no enrich/flags/run-scoped passes reach CRE
      and the views' legacy-NULL rule publishes every CRE row
      unfiltered. Confirm whether CRE-RUNTIME has landed before
      including CRE in a parity run; if it has not, either exclude
      CRE or record its results as unfiltered by design.
- [ ] **Compare surface decided and recorded.** The v5 compare as
      documented reads the target tables (IDQ vs SNOWFLAKE sides by
      `DATA_SOURCE` discriminator), not the `V_CMP_*` views.
      **Confirm before running:** whether the VIEW-CUTOVER work has
      landed for your install, and therefore whether the compare
      reads tables or `V_CMP_*` views. Record the choice with the
      run; do not mix surfaces within one run. Whichever surface is
      used, remember the legacy-NULL rule: a row whose spine flag is
      NULL was loaded by an unpatched loader and was never evaluated
      — views treat NULL as passed. A NULL flag is "not evaluated",
      not "passed".

## 2. UC1 — Rehearsal (sample pack)

Purpose: prove the tool end to end on data you can hold in your head
before touching real data. This rehearsal uses the pipeline in demo
mode (`PIPELINE_DEMO_MODE=true`); the demo simulator is not the ETL
and must never be pointed at a real database.

### 2.1 What to insert where

The sample pack ships prebuilt demo databases (`demo/demo_prod.db`,
`demo/demo_dev_oracle.db`, `demo/demo_snowflake.db`); rebuild any
time with `python sample_data/seed_demo.py` from the project root.
It holds 5 input and 5 output tables for TRS with real Oracle column
lists (one honesty note from the pack itself: the
`ZZ_UTL_UNMERGE_TREE_SRC_KEY` columns are sample columns, not Oracle
DDL — replace them with the real column list before using that entry
against real Dev Oracle tables).

Six fictional members: 1001 Alice Anderson, 1002 Bob Jones
(inactive), 1003 Carol White, 1004 Dan (blank last name), 1005 Eve
Martin (inactive), 1006 Frank Brown.

Inputs (Prod side): `STG_TRS_D_DC_INDV` (6 members),
`STG_TRS_D_INDV_ADDR` (6 addresses), `STG_TRS_H_DC_INDV` (2 history
rows), `STG_TRS_D_DC_RELATIONSHIPS` (2 relationships),
`LOOKUP_CODE_VALUE` (4 code rows).

Outputs (Prod side): `C_S_TRS_PTY` (6 rows),
`C_S_TRS_PTY_RLE_PHN` (5 rows), `STG_TRS_VALID_MEMBERS` (6 spine
rows), `EXC_STG_BAD_REC_MEMB` (1 bad-record row: member 1004, blank
last name), `ZZ_UTL_UNMERGE_TREE_SRC_KEY` (2 rows: inactive members
1002, 1005).

Nothing needs inserting by hand. The four planted differences are
switched on for the Dev side only, by the demo simulator's
`derive_outputs` (pipeline guide §8).

### 2.2 Trigger sequence (in this order, no shortcuts)

Demo-mode environment (pipeline guide §7):

```bash
export PIPELINE_DEMO_MODE=true PIPELINE_DEMO_DIR=./demo
export PIPELINE_SQLITE_DIR=./pipeline_data
export PIPELINE_WHITELIST_PATH=./sample_data/White_list_tables_safe_to_truncate.txt
uvicorn app.main:app --port 8000
```

Then, in order:

1. **(A) Readiness** — `GET /pipeline/readiness?source=TRS`.
   Expectation: the 10 sample tables exist on the Prod side.
   `ready` is false overall in demo mode because the demo only seeds
   10 of the 50 registry tables. That is expected, not a failure.
   Do not "fix" it by seeding the other 40.
2. **(B) Prod → Prod_SQLite** — `POST /pipeline/prod-to-sqlite` with
   the 10 sample tables. Record the returned `sqlite_path`
   (bare filename, e.g. `prod_TRS_....db`).
3. **(C) Prod_SQLite → Dev** — `POST /pipeline/sqlite-to-dev` with
   that filename. Expect status `COMPLETED`. The whitelist gate
   applies even in demo mode: tables not in the whitelist file are
   refused and nothing is truncated.
4. **(D) Run the ETL** — `POST /pipeline/run-snowflake-etl` with
   `{"source":"TRS"}`. In demo mode the response names the demo
   simulator, so a demo run can never be mistaken for a real one.
5. **(E) Snowflake Dev → Dev_SQLite** —
   `POST /pipeline/snowflake-to-sqlite` with the 5 output tables.
   Record the returned `sqlite_path`.
6. **(F) Compare** — `POST /pipeline/compare` with both filenames
   and the 5 output tables. Record the `run_id` and results
   filename (`compare_TRS_....db`).
7. **(G) Read the results** — `streamlit run streamlit_app.py`
   (after `pip install -r requirements-streamlit.txt` on that
   machine). The app offers the newest `compare_*.db` in
   `./pipeline_data`.

**NEVER run ETL after a PARTIAL copy.** If (B) or (C) reports
PARTIAL, stop. Fix the cause, then re-run the copy first, then ETL.
An ETL run on a partial copy compares Snowflake output against an
incomplete baseline and produces diffs that mean nothing. The same
rule holds on the v5 route: copy first, then ETL, then compare; a
failed copy is fixed by re-running copy, then ETL — an ETL re-run
without a fresh copy does not refresh the IDQ side or the inputs.

### 2.3 What a correct rehearsal looks like

Overall verdict: **MISMATCH — by design**. A rehearsal that returns
MATCH has not run the planted diffs; stop and find out why before
proceeding to real data.

| Table | Status | Prod | Dev | Matched | Different | Only Prod | Only Dev |
|---|---|---|---|---|---|---|---|
| `C_S_TRS_PTY` | MISMATCH | 6 | 6 | 4 | 1 | 1 | 1 |
| `C_S_TRS_PTY_RLE_PHN` | MATCH | 5 | 5 | 5 | 0 | 0 | 0 |
| `STG_TRS_VALID_MEMBERS` | MATCH | 6 | 6 | 6 | 0 | 0 | 0 |
| `EXC_STG_BAD_REC_MEMB` | MISMATCH | 1 | 2 | 1 | 0 | 0 | 1 |
| `ZZ_UTL_UNMERGE_TREE_SRC_KEY` | MATCH | 2 | 2 | 2 | 0 | 0 | 0 |

The four planted diffs, and what each one teaches:

1. **Member 1003 renamed in Dev** — one DIFFERENT row on
   `C_S_TRS_PTY` (`LST_NM`/`FULL_NM` White → Changed). Teaches the
   drill-down: same PK, columns differ; the results file stores the
   differing columns and both values.
2. **Member 1005 dropped from Dev party output** — one ONLY_IN_PROD
   row on `C_S_TRS_PTY`. Teaches the "IDQ produced it, Snowflake did
   not" direction.
3. **Member 1007 added in Dev** — one ONLY_IN_DEV row on
   `C_S_TRS_PTY`. Teaches the opposite direction.
4. **One extra Dev-only exception row** — one ONLY_IN_DEV row on
   `EXC_STG_BAD_REC_MEMB`. Teaches that exception tables are
   compared like any other output here.

### 2.4 Drill-down exercise (do this before UC2)

In the Streamlit app, pick the rehearsal run, then the `C_S_TRS_PTY`
table. Confirm you can see all three row statuses (one DIFFERENT,
one ONLY_IN_PROD, one ONLY_IN_DEV) and open the record detail view
for the DIFFERENT row to see Prod vs Dev values side by side. The
same path — `GET /pipeline/compare/{run_id}?table=...&status=...`
(limit default 200, max 5000) — reads results back without the UI.
If you cannot drill from a verdict to its rows here, do not start
UC2: on real data you will have hundreds of diffs and no way to
dispose of them. Note the diff cap: stored diff rows are capped per
table (`PIPELINE_COMPARE_DIFF_CAP`, default 10000); counts are always
complete, only stored detail is capped.

Rehearsal exit criteria: (A)–(G) all ran in order; verdict MISMATCH
with exactly the table above; all three row statuses drilled to;
operator can state, for each planted diff, which direction it points
and what it would mean on real data.

## 3. UC2 — Real-data run

Same sequence as UC1, on the real Oracle slice against the real IDQ
baseline, in real mode (demo mode off). The pipeline route is
described here; the v5 route's differences are noted at the end of
this section.

### 3.1 Decide and record, before triggering anything

- Source(s) and slice definition (§1), IDQ baseline freeze method,
  non-prod database/schema, compare surface (tables or `V_CMP_*`
  views), CRE in or out (§1), and the whitelist file contents.
- Whitelist discipline: `config/White_list_tables_safe_to_truncate.txt`
  must list exactly the Dev tables a reload may safely empty, one
  per line. The shipped file lists the 46 TRS tables that exist in
  the exports (the 4 missing objects are not listed, because they
  cannot be truncated in Dev until they exist there). Never list a
  Production table. Step (C) fails closed without the file, and
  refuses — naming every offender, truncating nothing — if any
  requested table is not whitelisted.
- Dev Oracle must mirror Production's schemas first: step (C) never
  creates Dev tables. A Dev table that does not exist is reported
  NOT_FOUND and the run goes PARTIAL.

### 3.2 Install order (Snowflake side)

Install into the recorded non-prod schema, in this order:

1. Database and schema, then the **7 reference objects with real
   definitions and data** (§1). The lookup file must install clean
   before anything runs.
2. `00_common/` — helpers plus lookup functions.
3. `01_unified_tables/` — dimension CREATE files (fresh install) or
   `01c_alter_v3_only.sql` (174 statements, v2 → v3 delta) or the
   regenerated `01b_alter_existing.sql` (734 statements, older
   installs). Views are validated at CREATE, so tables must exist
   before the view files.
4. `02_common/` — 33 common procedures (32 v2 + phone-type enrich).
5. `03_views/` — 42 files, 126 views.
6. `drivers/` (40, no purge in v3), `loaders/` (40, DIAG-patched
   tree), `runners/` (7), `run_scripts/` (7). CREATE order among
   loaders, common procedures, drivers, and runners does not matter
   (procedure bodies are not validated at creation) — but nothing
   is CALLed until steps 1–5 are in place.
7. Dictionary rows (§1), including PHONE_TYPE identity rows.

For a CREATE-only install check, the DDL writer
(`write_ddls_to_snowflake.py`, see its user guide) executes CREATE
statements only and skips run scripts. A clean dry run is parsing
evidence only — it is not proof a live install or a CALL succeeds.

### 3.3 Trigger sequence (pipeline route, real mode)

1. **(A) Morning check.** Confirm IDQ finished by hand (§1), then
   `GET /pipeline/readiness?source=TRS`. Readiness proves existence,
   not freshness. If any registered table is missing, stop: the
   baseline is not ready.
2. **(B) Copy Prod → Prod_SQLite.**
   `POST /pipeline/prod-to-sqlite` (omit `tables` for all input +
   output tables for the source, or name the slice's tables).
   Production is read-only to this API; it is never written.
   Record the returned filename — this file IS the frozen IDQ
   baseline. Verify the per-table row counts in the response before
   proceeding.
3. **(C) Load Prod_SQLite → Dev Oracle.**
   `POST /pipeline/sqlite-to-dev` with the filename from (B).
   The API refuses (400) if Prod and Dev connections are identical,
   and refuses if any requested table is not whitelisted. Verify
   per-table row counts. **If (B) or (C) is PARTIAL, stop.** Fix the
   cause, re-run the copy first, then ETL. Never run ETL after a
   PARTIAL copy.
4. **(D) Run the Snowflake ETL in Dev.**
   `POST /pipeline/run-snowflake-etl` with the source and workflows
   (omitted = the source's stage-load runners in order; TRS: TOA,
   then Ongoing). Two re-run rules, both from the pipeline guide:
   - Runners are insert-only with existing-key guards, so re-running
     (D) without clearing Dev outputs suppresses rows. Either run
     (D) with `"reset_outputs": true` (truncates the Dev output
     tables first) or re-install into a fresh schema. A second (D)
     run that changes nothing is this guard working, not a hang.
   - A workflow failure stops later workflows (later ones report
     NOT_RUN). Do not compare a run whose workflows did not all run.
   - On the bare-bones runner shape, the runner RETURNs a combined
     summary string. Log that string — in that design it is the
     only record of the run. Also record the run timestamp: v3
     enrich and flag passes operate on `LAST_UPDATE_DATE = P_RUN_TS`
     rows, so the run timestamp is how you scope any follow-up query
     to this run's rows.
5. **(E) Copy Snowflake Dev → Dev_SQLite.**
   `POST /pipeline/snowflake-to-sqlite` (omit `tables` for all output
   tables). Record the returned filename. Step (E) copies ALL rows
   from the Dev output tables (no `DATA_SOURCE` filter): in a fresh
   Dev schema the only rows are the ones (D) just wrote. If the Dev
   schema also holds older rows, clear it first (see step 4).
6. **(F) Compare.** `POST /pipeline/compare` with both filenames.
   Record the `run_id`, status, verdict, and results filename.
   Per-table failures do not hide the rest: a failed table is
   recorded FAILED/NOT_FOUND and the run continues; overall status
   is COMPLETED (all ok), PARTIAL (some ok), or FAILED (none ok).
   A validation failure (unknown source/table/workflow, whitelist
   refusal, prod==dev) is a 400 raised before anything is written.
7. **(G) Read the results** in the Streamlit app (UC3), or via
   `GET /pipeline/compare/{run_id}` and `GET /pipeline/compare-runs`.

### 3.4 What to capture for every run

Run id; (B)/(E)/(F) filenames; copy per-table row counts; ETL runner
summary string(s) and run timestamp; compare verdict and per-table
summary; slice definition; database/schema; compare surface; CRE
in/out; and the disposition of every differing dimension (UC3).
Without the run id and filenames, a later investigation cannot
reproduce what was compared.

### 3.5 v5 route differences (same order, different machinery)

If the run uses the v5 flow instead of the pipeline: `POST
/runs/copy`, then `POST /runs/etl`, then `POST /runs/compare`, with
`GET /runs` / `GET /runs/{run_id}` for status. Targets live in one
schema (`MDM_ETL_TRS.TRS_ETL_WRK` for TRS) with the `DATA_SOURCE`
discriminator: copy truncates the target then loads IDQ rows, and
ETL deletes only the SNOWFLAKE side before calling the procedures.
The v5 compare is the surface that gives dimension verdicts plus
the two spines (UC3 §1). A filter that matches zero dimensions is
rejected — reporting MATCH over zero dimensions would be a false
pass. The order rule is identical: copy, then ETL, then compare;
never ETL after a PARTIAL copy.

## 4. UC3 — Reading results

### 4.1 Verdicts, precisely

**Pipeline compare (per-table, record-by-record).** MATCH = every
compared table matched exactly. MISMATCH = at least one table differs
(a successful compare with a negative answer — HTTP 200, not an
error). PARTIAL = the evidence is incomplete: a table missing on a
side, a table with no PK compared by counts only, or a table that
failed. Per-row statuses: DIFFERENT (same PK, columns differ —
differing columns and both values stored), ONLY_IN_PROD,
ONLY_IN_DEV. For a one-sided row the full row from the side that has
it is stored.

**v5 compare (per-dimension plus spines).** MATCH = every compared
dimension's row count, key set, and (where applicable) version set
match, and both spines match. MISMATCH = at least one dimension or
spine does not match (still HTTP 200). PARTIAL = at least one
dimension could not be compared at all (table missing in one schema,
or an error on that table); its row counts are −1 and its message
names the cause — fix the cause and re-run compare.

The four comparisons that make up a dimension verdict:

- **Counts.** `oracle_row_count`, `snowflake_row_count`,
  `count_diff` (snowflake − oracle). A non-zero diff is the first
  thing to look at — but a zero diff is not a pass on its own (see
  coverage).
- **PKEY sets.** `matched_keys`, `oracle_only_keys`,
  `snowflake_only_keys`, plus samples (default 20 per dimension) of
  the differing keys. Oracle-only = rows IDQ produced that Snowflake
  did not. Snowflake-only = rows Snowflake produced that IDQ did not.
- **(PKEY, VERSION_SEQ) sets** (`C_S_*` tables only). If the PKEY set
  matches but the version set does not, a timeline version is missing
  or extra — typically a closed (end-dated) row one side emitted and
  the other did not. Non-`C_S_*` tables have null version fields:
  that means "not applicable", not "zero".
- **Spines.** Two, and they come first (see triage order):
  - **Valid-member spine** (`STG_TRS_VALID_MEMBERS.INDV_ID`): the set
    of individuals the load considers valid. If this differs, every
    downstream dimension will differ too.
  - **Party-role spine** (`C_S_TRS_PTY_RLE.PKEY_SRC_OBJECT`):
    `INDV_ID|Member` for Member parties. Same logic.
  - **Coverage per dimension:** for each Member `C_S_*` dimension
    (excluding the party-role spine table itself), the distinct
    spine INDV_IDs present in it (first segment of the PKEY), IDQ vs
    Snowflake, and the diff. A dimension can have a matching total
    row count and still be wrong — right number of rows, wrong
    members. Coverage catches that. Reference (TOA catalogue) and
    Exceptions are excluded from coverage: their keys are not member
    spine keys. The Exceptions dimension's compare key is a
    best-effort tuple (`SRC_SYS_ID_1, EXCEPTION_CODE, ATTRIBUTE_NAME,
    ATTRIBUTE_VALUE, MAPPING_NAME`) because the table has no unique
    key — treat its diffs as "look at the rows", and use the per-code
    breakdown where available.
- **Duplicates note:** key sets collapse duplicates by construction,
  so the response also checks the arithmetic — if a table's row count
  exceeds matched + only-keys on either side, duplicates exist and
  the message says so. Exception rows are the known case: the same
  exception can legitimately repeat, so treat that message as "look
  at the rows", not as a failure by itself.

### 4.2 Triage order for a MISMATCH (use this order, not dimension order)

1. **Spines first.** If either spine differs, the problem is upstream
   — do not debug dimensions until the spine is explained. A spine
   difference explains dimension differences; a dimension difference
   never explains a spine difference.
2. **Coverage.** A dimension with matching counts but differing
   coverage has the wrong members — that points at a filter or
   spine-join problem, not a row-count problem. Do not sign off a
   dimension with count diff 0 and a coverage diff; the coverage
   diff is the finding.
3. **Counts, then key samples.** Oracle-only samples point at the
   Snowflake mapping for that dimension (a missing source row, a
   filter difference, a lookup that did not translate). Snowflake-only
   samples point at SNOWFLAKE-side emptiness (stale rows from a
   previous run — re-run copy, then ETL) or an over-inclusive
   Snowflake filter.
4. **Version sets.** A PKEY match with a version mismatch points at
   timeline/close logic.
5. **Only then** open the mapping's step story (v5: the control store
   / job story for the run; step-driver line: `JOB_CONTROL_ETL`;
   bare-bones line: the runner's summary string and the work tables
   the mapping leaves standing) and the mapping's own step outputs
   for the sample keys. Do not hand-edit work or output tables to
   "fix" a run — fix the cause and re-run copy, then ETL.

### 4.3 Verdict disposition workflow

For each differing dimension or spine, write down exactly one
disposition before moving on:

- **Expected known gap.** The delta matches one of the gaps in §5,
  in the direction that gap predicts, for the keys involved. Record
  the gap id and the keys. A known gap explains a delta; it does not
  delete it from the report.
- **Code defect.** The delta is not predicted by any known gap and
  the Snowflake side is wrong against the IDQ mapping. Record the
  mapping, the sample keys, and the step where the rows diverge.
  The fix goes into the code (or a new checkpointed step), and the
  run is repeated with a fresh copy — not patched in place.
- **Data-slice difference.** The two sides did not run on the same
  slice, or the baseline moved mid-run (a re-run of (B) without a
  new baseline record, a Dev schema holding older rows, a stale
  SNOWFLAKE side). Evidence: the copy row counts, the (B)/(E)
  filenames, and whether (D) used `reset_outputs`. Fix the run
  discipline and re-run; this is not a code finding.
- **Investigate (unexplained).** None of the above fits. The delta
  stays open, the run is not signed off, and the next step is named
  (which keys, which mapping, which step to inspect) — not "look
  into it later".

Questions that decide between the three: Did the spine move? (If yes,
upstream, not this dimension.) Is the delta in the direction a known
gap predicts, for these keys? (If yes, known gap.) Were both sides
provably the same slice? (If not provable, slice difference — prove
it from the recorded filenames and counts, not from memory.) Does the
Snowflake mapping, read literally, produce the IDQ row for the sample
key? (If no, code defect.)

### 4.4 What "done" looks like

Copy COMPLETED, ETL COMPLETED (with a run id / runner summary you can
quote), compare COMPLETED (not PARTIAL), and every differing
dimension and spine carrying a disposition from §4.3. A PARTIAL
compare is never "done": fix the cause and re-run compare. An
unexplained delta is never waved through because the other
dimensions match, because the counts are "close", or because the
compile was clean. If a delta cannot be explained, the parity run is
open, and the open item names its keys, its mapping, and its next
inspection step.

## 5. Known parity gaps (the only pre-approved explanations)

A delta may be dispositioned "expected known gap" only if it matches
one of these, in the predicted direction. Everything else is a code
defect or an investigation until proven otherwise. (Wording follows
the production decisions draft; D1/D2 are business-owner decisions,
not settled code behaviour.)

1. **Insert-only vs IDQ truncate.** The Snowflake ETL is insert-only
   with existing-key guards; IDQ truncates/replaces its targets.
   Predicted direction: Snowflake-only rows that IDQ replaced away,
   especially on re-runs without a cleared SNOWFLAKE side.
2. **Deactivation deletes not performed in Snowflake.** IDQ deletes
   deactivated members from `STG_TRS_VALID_MEMBERS` (DD_DELETE);
   the Snowflake rewrite records `DELETE_VALID_STAGE_NOT_PERFORMED`
   and does not delete. Predicted direction: deactivated members
   present on the Snowflake valid-member spine and in downstream
   mappings that join it, absent on the IDQ side. (D1 — business
   owner to decide whether downstream loads may still see
   deactivated members.)
3. **Auth_Rep attribute-type delete not performed.** IDQ deletes
   `WHERE MNG_ATTR_TP='$ATTR_TP_AUTH_REP'` before loading; Snowflake
   is insert-only with `uq_*` guards. Predicted direction: a stale
   `Auth_Rep_Flag` row in `C_S_TRS_PTY_MNG_ATTR` on the Snowflake
   side that IDQ replaced. (D2 — business owner to decide.)
4. **`PROCESSED_YN` column default.** In relationship deactivation
   capture, `PROCESSED_YN` is left to the column default in the
   Snowflake rewrite. Predicted direction: rows whose `PROCESSED_YN`
   differs by the default value. (D3 — checkable in a minute:
   `SELECT COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE
   TABLE_NAME='STG_TRS_DEACTIVATED_RELATIONSHIPS' AND
   COLUMN_NAME='PROCESSED_YN';` — `'N'` matches IDQ; NULL means exact
   `='N'` tests miss rows.)
5. **v3 flag semantics vs v1 publish behaviour (audit-only
   non-spine flag).** In v3, only the spine flag gates the
   `V_MDM_*`/`V_CMP_*` views; the non-spine flag is audit-only, so
   lookup-miss rows still publish — matching v1 publish behaviour
   by design. Predicted direction: rows in `V_AUDIT_*` (non-spine
   flagged) that also appear in `V_MDM_*`/`V_CMP_*`. That is the
   design, not a defect. The one-line change to also gate on the
   non-spine flag is a separate decision, not something to assume
   mid-run. Conversely, rows flagged at the spine stage are excluded
   from `V_MDM_*`/`V_CMP_*` and appear only in `V_AUDIT_*` — if a
   run compares tables rather than views, those rows appear on both
   sides of the table compare and must not be misread as a publish
   leak; check which surface the run used (§1).

## 6. Troubleshooting (known failure modes only)

| Symptom | Cause and fix |
|---|---|
| `00_common/02_snow_common_lookups.sql` fails on a fresh target, error 002003, 7–8 statements failing | Missing reference objects. The lookup functions' bodies are validated at CREATE time. Create the 7 objects with real definitions and data (§1) — including a schema literally named `RDM` in the same database for `REF_PHN_AREA_CD` — then re-install that file. A placeholder install lets CREATE succeed but leaves lookups empty; it does not fix a parity run. On a target where a scratch RDM stub already exists, the count may show 7 failures instead of 8 — same cause. |
| A driver fails on first CALL despite a clean compile | Undeclared-variable class of defect. Snowflake validates procedure bodies only at CALL time. Precedent: `:c_mapping` used in 5 step procedures without a DECLARE, passing 360/360 compile. Fix: find the undeclared identifier in the failing procedure (the error names it), declare it or replace it with the literal the mapping uses (the shape used for the `:c_mapping` fix), re-install that procedure, and re-run from copy — do not hand-patch output tables. A clean compile after the fix proves nothing about the next CALL; only the CALL does. |
| Copy or compare reports PARTIAL | Evidence is incomplete: a table missing on a side, a table with no PK compared by counts only, or a table that failed. PARTIAL is not a pass and not a mismatch — fix the named cause (create the missing Dev table, register the PK, fix the failed table) and re-run. Never run ETL after a PARTIAL copy; re-run copy first, then ETL. |
| Step (C) refuses: "the Prod and Dev connections are identical" (400) | `PIPELINE_ORACLE_PROD_URL` equals `PIPELINE_ORACLE_DEV_URL`. Fix the URLs — step (C) must never run against Production. Nothing was written; this is the safety gate working. The same gate refuses, naming every offender and truncating nothing, if any requested table is not in the whitelist file, and fails closed if the whitelist file itself is missing. |
| Copy/compare request for a non-TRS source returns 400, or reports empty tables | That source's table list is not registered yet (ECI, WIC, TTF, FSS, CRE in the pipeline registry: runners only, empty table lists). Register its tables (pipeline guide §9: column lists from Oracle DDL in `tables.py`, one `PipelineTable` per table with its PK, whitelist entries where Dev may truncate) — do not run an "empty" compare and report it. |

## Appendix — Operator checklist (print this page)

Run id: __________  Date: __________  Operator: __________
Source(s): __________  Slice: __________
Non-prod DB / schema: __________ / __________
Compare surface (tables / `V_CMP_*` views): __________
CRE in / out: __________  Baseline file / copy run id: __________

- [ ] IDQ finished — completion evidence seen (not just readiness).
- [ ] Readiness checked; every registered table exists.
- [ ] 7 reference objects present with REAL definitions and data;
      `RDM` schema in the same database; lookups file installs clean.
- [ ] Dictionary rows present, including PHONE_TYPE identity rows.
- [ ] Slice defined in writing; same slice on both sides.
- [ ] Baseline frozen; filename / copy run id recorded above.
- [ ] ETL installed in order (§3.2); no runner CALLed before
      reference objects existed.
- [ ] (B) Copy Prod → Prod_SQLite COMPLETED; per-table counts verified.
- [ ] (C) Prod_SQLite → Dev Oracle COMPLETED; whitelist passed;
      Prod ≠ Dev confirmed by the API. If PARTIAL: stopped, fixed,
      re-ran copy first.
- [ ] (D) ETL run COMPLETED for all workflows (no NOT_RUN);
      `reset_outputs` used or fresh schema; runner summary string
      and run timestamp logged.
- [ ] (E) Snowflake Dev → Dev_SQLite COMPLETED; Dev schema held no
      older rows (or was cleared first).
- [ ] (F) Compare COMPLETED (not PARTIAL); run id and results
      filename recorded.
- [ ] (G) Results read in Streamlit (or via
      `GET /pipeline/compare/{run_id}`).
- [ ] Spines checked first; coverage checked second; counts, key
      samples, version sets checked in order (§4.2).
- [ ] Every differing dimension/spine has a disposition (§4.3):
      known gap (§5, with gap id) / code defect / slice difference /
      investigate — no blank rows.
- [ ] No unexplained delta waved through. If any delta is
      unexplained, the run is OPEN and the next inspection step is
      written here: _______________________________________________
- [ ] Verdict recorded: MATCH / MISMATCH-explained / OPEN.

---

Sources this runbook was grounded in (all read before writing):
`Snowflake_Spine_First_Common_CS_v3_Flags_Raw_Views_DIAG.zip` tree
(`README_V3.md`, `DESIGN_V3.md`, `VIEWS_AND_FLAGS.md`,
`INSTALL_AND_RUN.md`), `Test_Harness_Pipeline_v5.5.0.zip` tree
(`README.md`, `PIPELINE_USER_GUIDE.md`, `SAMPLE_DATA_README.md`,
`USER_GUIDE.md` §8), `reference_objects_for_barebones_install.sql`,
`TRS_Snowflake_Production_Decisions_DRAFT.md`. Anything not found in
those files is marked "Confirm before running" in the text above
rather than asserted.

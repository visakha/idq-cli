# VIEW-CUTOVER — operator checklist (one page, in run order)

Tick each box only when its evidence exists. Any unchecked STOP box
stops the cutover at that step. Do not skip ahead to "rely on flagged
loads" — that step is last for a reason.

## Phase 0 — Before anything moves

- [ ] Target database and schema names confirmed by the operator
      (not guessed, not copied from scratch layout). Written here:
      Database: ________________  Schema: ________________
- [ ] `verify_view_cutover.sql` placeholders `__DATABASE__` /
      `__SCHEMA__` replaced with the names above (find/replace all).
- [ ] Confirm: NO NONSPINE gate has been flipped. Gates stay commented
      unless separately approved per dimension. If one was flipped,
      STOP and re-baseline the verification script first.
- [ ] Confirm: the MDM batch change (§4a) is owned by the user's team
      and is NOT being made by this package. No batch code is touched here.

## Phase 1 — Install views, verify (views only; no consumer changes yet)

- [ ] v3 views (`03_views/`, 126 views) installed into each source schema
      (install order: `00_common` → `01_unified_tables` →
      `02_common` → `03_views` → drivers → loaders → runners).
- [ ] Section 0a passes: VIEW_CNT = 126.
- [ ] Section 0b passes: 42 rows, FLAG_COLS = 4 on every table.
      STOP if any table is short: apply the v3 flag ALTERs (01c) first.
- [ ] Section 1 run; every table's four checks read PASS.
- [ ] Section 2 verdict reads ALL CHECKS PASS.
- [ ] STOP if any check FAILs: do not switch consumers, do not enable
      flagged loads. Failing table(s): ________________

## Phase 2 — MDM batch cutover (user's team)

- [ ] Batch column name AND order diffed against `V_MDM_*` output.
      STOP if the batch reads positionally and the order differs:
      resolve the order before switching (see notes §2c).
- [ ] Batch object names changed per table per source schema
      (`C_S_<SRC>_*` → `V_MDM_C_S_<SRC>_*`). No other batch logic changed.
- [ ] Verification sections 1–2 re-run after the switch: still ALL PASS.
- [ ] MDM intake counts equal the `V_MDM_*` counts for the switched source.

## Phase 3 — Compare (specified, not built in this package)

- [ ] STOP — read this before acting: do NOT point Compare at `V_CMP_*`
      views. They carry no DATA_SOURCE and would mix the IDQ and
      SNOWFLAKE sides (false MATCH risk). See notes §3.
- [ ] Prerequisite confirmed: v3 flag ALTERs (01c) applied to the
      Compare schema, so flag columns exist on its `C_S_*` tables.
- [ ] Compare change built per notes §4b (SNOWFLAKE-side spine-flag
      filter only; IDQ side never filtered; non-C_S_* tables never
      filtered; `tables.py` flag columns added, additive only).
- [ ] Compare test suite re-run from a clean copy: all pass.
- [ ] Section 3 of the verification SQL run in the Compare schema:
      every TRS table PASS.
- [ ] Before/after Compare run on one dimension: the only count
      movement is the flagged-row count.
- [ ] Pipeline note acknowledged: pipeline Dev compares still see table
      contents until its copy step is cut over (notes §4c). Do not
      present a pipeline verdict as a publish-surface verdict until then.

## Phase 4 — Only now: rely on flagged loads in production

- [ ] Phases 1–3 complete for a source. (Cutover is per source: a source
      that has not completed Phases 1–2 must NOT have its flagged loads
      relied on, even if another source has.)
- [ ] Flag-retaining loads for the completed source may now be relied on
      in production. Flagged rows are excluded by the views (MDM) and by
      the SNOWFLAKE-side filter (Compare), and visible in V_AUDIT_*.
- [ ] Ongoing watch: EXC placeholder rows (`EXCEPTION_DESC LIKE
      'LOOKUP_MISSING%'`) reviewed by code; catalogue gaps dispositioned,
      not waved through.

## STOP conditions (any one stops the cutover)

- Any section 1/2 check FAILs.
- Section 0b short on any table (flag ALTERs missing).
- Batch column-order mismatch (positional reads).
- Any proposal to point Compare at `V_CMP_*` views directly.
- Any proposal to flip a NONSPINE gate as part of cutover.
- Any proposal to install a flag-retaining package into production for
  a source whose consumers have not completed Phases 1–2.

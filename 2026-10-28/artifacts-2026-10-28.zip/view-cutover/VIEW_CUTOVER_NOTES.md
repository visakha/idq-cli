# VIEW-CUTOVER — read-surface map, verdict, and cutover order

## 0. Bottom line first

The original framing — "Compare moves to `V_CMP_*` views" — is **not
the right surface for the Compare tool as it is actually built**.
Do not implement it. The evidence is in §2, and it is not close:
the shipped `V_CMP_*` views cannot separate the Compare tool's two
sides, and the Compare tool's table definitions do not even contain
the flag columns the views gate on.

What **is** correct, and what this package delivers:

1. **MDM batch → `V_MDM_*` views.** This is the real cutover, and
   it is the user's team's code to change (not ours). This package
   gives them the verification SQL and the run order, not a modified
   batch.
2. **Compare stays on tables, and gains a spine-flag filter on the
   SNOWFLAKE side only.** That is the precise, minimal change that
   makes Compare enforce the same spine predicate the views enforce,
   without breaking the discriminator the whole tool is built on.
   It is specified in §4, not implemented here, because the task
   for this generation was to investigate first and not to force
   the originally framed change blindly.
3. **No flag-retaining package goes into production while any
   consumer still reads tables directly.** That is the trap this
   cutover exists to close, and it is a STOP condition, not advice.

No NONSPINE gate is flipped anywhere in this package. The
NONSPINE-GATE comments stay comments unless separately approved.

## 1. The v3 views, precisely

Source: `03_views/` in the v3 tree (42 files, 126 views, one file per
CS table, three views per table). All views use unqualified table
names and resolve in the install schema (one schema per source).

| View | Columns | Predicate |
|---|---|---|
| `V_MDM_<tbl>` | Business columns only, in CREATE-file order (table columns minus `DIAG_*`, minus `RAW_*`, minus `SPINE_ROW_YN`, minus the 4 flag columns) | `(SPINE_FILTERED_YN IS NULL OR SPINE_FILTERED_YN = 'N')` |
| `V_CMP_<tbl>` | Business columns **plus** the 4 flag/reason columns, appended last | Same as `V_MDM_` |
| `V_AUDIT_<tbl>` | Business columns plus the 4 flag/reason columns | `SPINE_FILTERED_YN = 'Y' OR NONSPINE_FILTERED_YN = 'Y'` |

Key facts for cutover:

- The `IS NULL` arm is the **legacy rule**: rows written by
  unpatched or v2 loaders carry NULL flags and must keep publishing.
  Only an explicit `'Y'` excludes.
- The audit predicate has **no** NULL arm: NULL means "not
  evaluated", not "flagged", so legacy rows do not pollute the audit.
- The non-spine flag does **not** gate MDM/Compare in v3
  (audit-only, preserving v1 publish behaviour). NONSPINE-GATE added
  comments only. A flipped gate changes the expected results in
  `verify_view_cutover.sql` and must be re-baselined first.
- Views are validated at CREATE time in Snowflake (unlike
  procedures), so a broken view fails at install, not at first run.
- The views carry **no `DATA_SOURCE` column**. They were designed
  for the ETL schema, where a CS table holds only Snowflake ETL rows
  written by the loaders. That single fact is what breaks the
  original Compare framing (§2).

The 42 tables: `C_S_LU_TOA`; PTY, PTY_RLE, PTY_RLE_ADDR,
PTY_RLE_ALT_ID, PTY_RLE_PHN for CRE, ECI, FSS, TRS, TTF, WIC as
applicable (TTF has no ADR; see the file list in `03_views/`);
PTY_MNG_ATTR, PTY_NM, PTY_RLE_PLN, PTY_RLE_REL_PROV,
PTY_RLE_TOA for TRS; PTY_RLE_REL for ECI, FSS, TRS;
PTY_RLE_EADDR for ECI, FSS, TRS, WIC. The verification SQL lists
all 42 explicitly.

## 2. Read-surface map (evidence, not assumption)

### 2a. Compare tool v5.4 — reads TABLES, split by DATA_SOURCE

Working source: `~/workspace/trs_compare/` (v5.4.0 lineage).
Relevant code, all verified by reading the files:

- `app/services/compare_service.py` (module docstring and
  `_key_sets`, `_version_sets`, `_compare_dimension`,
  `_spine_key_compare`, `_spine_section`, `run_compare`):
  > "Both sides already live in Snowflake by compare time, in the
  > SAME table in TRS_ETL_WRK: IDQ rows carry
  > DATA_SOURCE='IDQ', Snowflake rows carry DATA_SOURCE='SNOWFLAKE'.
  > The entire compare therefore runs Snowflake-to-Snowflake,
  > filtered by DATA_SOURCE."
  Per dimension it compares: row counts per side; key sets in both
  directions (EXCEPT); for `C_S_*` tables, `(PKEY_SRC_OBJECT,
  VERSION_SEQ)` sets in both directions; duplicate notes when a
  count exceeds its distinct-key count. The spine section compares
  distinct `INDV_ID` in `STG_TRS_VALID_MEMBERS` and distinct
  `PKEY_SRC_OBJECT` in `C_S_TRS_PTY_RLE`, each IDQ vs SNOWFLAKE,
  plus per-dimension coverage (distinct first segments of
  `PKEY_SRC_OBJECT`) for every Member `C_S_TRS_*` dimension.
- `app/repositories/snowflake_repository.py`
  (`count_rows`, `distinct_count`, `key_difference`,
  `coverage_count`, `delete_discriminator_rows`): every compare
  query takes a `discriminator` and filters
  `table.c.DATA_SOURCE == discriminator`. The ETL clear step
  deletes only `DATA_SOURCE='SNOWFLAKE'` rows, leaving IDQ rows
  untouched.
- `app/domain/catalog.py` (`EXPECTED_TABLES`): the compared
  dimensions are the TRS target tables — `C_S_TRS_PTY`,
  `C_S_TRS_PTY_RLE`, `C_S_TRS_PTY_NM`, `C_S_TRS_PTY_RLE_ALT_ID`,
  `C_S_TRS_PTY_RLE_PLN`, `C_S_TRS_PTY_RLE_TOA`,
  `C_S_TRS_PTY_RLE_PHN`, `C_S_TRS_PTY_RLE_EADDR`,
  `C_S_TRS_PTY_RLE_ADDR`, `C_S_TRS_PTY_MNG_ATTR`,
  `C_S_TRS_PTY_RLE_REL`, `C_S_TRS_PTY_RLE_REL_PROV`,
  `C_S_LU_TOA`, plus non-C_S targets `STG_TRS_VALID_MEMBERS`,
  `DQM_ADDRESS`, `STG_TRS_D_UNQ_ADDR`, `EXC_STG_BAD_REC_MEMB`,
  `STG_TRS_DEACTIVED_MEMBERS`,
  `STG_TRS_DEACTIVATED_RELATIONSHIPS`.
- `app/domain/tables.py` (`COLUMN_TYPES`): the Compare tool's
  checked-in column lists for these tables are the Oracle DDL
  columns **plus `DATA_SOURCE` as the last column** — and they do
  **not** include the 4 flag columns, the `DIAG_*` columns, or
  the `RAW_*` columns. Example: `C_S_TRS_PTY` ends with
  `..., ('RACE_CD', ...), ('DATA_SOURCE', String(20))`.
- `sql/01_etl_wrk.sql`: every target table is created with
  `DATA_SOURCE VARCHAR(20) NOT NULL DEFAULT 'SNOWFLAKE'`.
- A grep over both `~/workspace/trs_compare/` and
  `~/workspace/trs_compare_pipe/` finds **zero** references to
  `V_CMP_*`, `V_MDM_*`, or `V_AUDIT_*`. The Compare tool has
  never read a view.

Scope note: the v5.4 Compare tool is TRS-only (Member domain).
The v3 views exist for all six sources, but Compare covers only
TRS. The other sources have no Compare surface to cut over; their
cutover is the MDM batch only.

### 2b. Pipeline v5.5 — reads SQLite copies of TABLES, not views

Working source: `~/workspace/trs_compare_pipe/`.
`app/services/pipeline_compare.py` (step F) compares one output
table at a time between two SQLite files (`Prod_SQLite` vs
`Dev_SQLite`), streaming rows in PK order and merging in Python
(MATCHED / DIFFERENT / ONLY_IN_PROD / ONLY_IN_DEV). The Dev side
is populated by `app/repositories/pipeline_repository.py`
(`TableStore.stream_rows`) copying **tables by registry name**
from the Snowflake Dev schema into SQLite. No view is read
anywhere in the pipeline. The pipeline cutover question is
therefore a copy-step question (§4c), not a compare-engine
question, and no pipeline code is changed by this package.

### 2c. MDM batch — reads C_S_* TABLES (per estate docs; code not in estate)

The MDM batch code itself is **not in this estate** and is the
user's team's to change; nothing here modifies or fabricates it.
What the estate does establish:

- `DESIGN_COMMON_CS.md`: legacy `C_S_<SRC>_*` names "are the
  downstream contract; renaming breaks MDM batch + Compare."
- `DESIGN_V3.md` §5: "MDM batch reads `V_MDM_*` instead of the
  table: same business shape as before, spine rows only. The only
  code change is the object name."
- `VIEWS_AND_FLAGS.md`: `V_MDM_*` is business columns only, in
  CREATE-file order.

Two cautions the batch team must check themselves (this package
cannot check them from here):

1. **Column order / `SELECT *`:** `V_MDM_*` selects business
   columns in the unified CREATE-file order. If the batch reads
   by column name, that is fine. If it reads positionally
   (`SELECT *` or ordinal access), the view's column order must
   be diffed against the batch's expected order before cutover —
   the unified schema added columns, and positional consumers
   were already flagged as a must-check in the v2 docs. Do not
   assume "same shape" means "same order".
2. **Per-source schemas:** the batch presumably reads one schema
   per source (the v3 install rule). The view names are
   per-table (`V_MDM_C_S_TRS_PTY`, …), so the batch change is
   one object name per table per source schema. There is no
   cross-source view.

## 3. Verdict: Compare-to-V_CMP_* is the wrong surface

**Verdict: DO NOT move the Compare tool to the shipped `V_CMP_*`
views.** Four independent reasons, each sufficient on its own:

1. **The discriminator disappears.** The shipped `V_CMP_*` views
   do not select `DATA_SOURCE` (see the PTY view: business columns
   plus 4 flag columns, no `DATA_SOURCE`). Every Compare query
   filters on `table.c.DATA_SOURCE`. Pointing the repository at
   the view would fail on the missing column — or, if the
   discriminator filter were dropped to "make it work", the view
   would return **both sides mixed**: IDQ rows (flags NULL, so
   they pass the legacy rule) plus SNOWFLAKE spine rows. The
   "Snowflake side" would then contain the IDQ baseline, key sets
   would nearly always match, and the tool would report false
   MATCHes. That is worse than the current behaviour, not better.
2. **The column shapes do not match.** Compare's checked-in
   column lists (Oracle DDL + `DATA_SOURCE`) differ from the
   v3 unified view column lists (unified business columns + 4
   flag columns, no `DATA_SOURCE`, extra columns such as
   `PRFRD_LANG_CD` and `BIRTH_WGHT_GRMS` on PTY that the Compare
   table list does not carry). The repository builds its queries
   from the checked-in lists; a view with a different column set
   is not a drop-in replacement for the table.
3. **The IDQ side must not be spine-filtered.** The IDQ baseline
   is IDQ's own output, produced by IDQ's own spine logic and
   copied from Oracle with NULL flags. Applying the v3 spine
   predicate to the IDQ side would be harmless today (NULL passes
   the legacy rule) but conceptually wrong: the baseline is not
   supposed to be re-filtered by Snowflake flags. Any cutover
   mechanism must filter **only the SNOWFLAKE side**. The shipped
   views cannot express that distinction, because they have no
   side to filter on.
4. **The design docs assumed the answer.** `DESIGN_V3.md` §5 says
   "Compare reads `V_CMP_*`", but the shipped Compare code does
   not and never has (zero references, §2a). The doc describes
   the intended consumer contract, not the built tool. Following
   the doc over the code would have broken the tool. This
   package follows the code.

**What about the spine check the views were meant to give
Compare?** It is still achievable, and §4 specifies how — by
filtering the table reads the tool already makes, not by
replacing the tables with views. A `V_CMP_*` view remains useful
as an **audit surface** (a human or a report can read flagged
Snowflake rows with reasons from it), but it is not the Compare
tool's read surface.

## 4. The correct cutover, in order

### 4a. MDM batch → V_MDM_* (user's team; this package verifies)

1. Install the v3 views (`03_views/`) into each source schema
   (after `00_common`, `01_unified_tables`, `02_common`, per the
   v3 install order). Views only — this step alone changes
   nothing any consumer reads.
2. Run `verify_view_cutover.sql` sections 0–2 in each source
   schema. All checks must PASS (see §5 for what each means).
3. The batch team changes one object name per table per source
   schema (`C_S_<SRC>_*` → `V_MDM_C_S_<SRC>_*`), after diffing
   column name **and order** against batch expectations (§2c).
4. Re-run sections 1–2 after the switch (same expected results:
   the views did not change, but this proves the batch now reads
   the verified surface) and confirm MDM intake counts equal the
   `V_MDM_*` counts.
5. Only after steps 2–4 pass for a source may that source's
   flag-retaining loads be relied on in production. Until then,
   flagged rows land in tables that table-readers would publish
   unfiltered — the trap this cutover closes.

### 4b. Compare → SNOWFLAKE-side spine-flag filter (Compare team; specified, not built here)

Prerequisite: the v3 flag ALTERs (`01_unified_tables/01c_*`)
applied to the Compare schema, so the 4 flag columns exist on
the `C_S_*` target tables there. (Without them there is nothing
to filter on; the verification script's section 0b catches this.)

Change, in the Compare tool only, for `C_S_*` expected tables:

- `app/domain/tables.py`: add the 4 flag columns
  (`SPINE_FILTERED_YN`, `SPINE_FILTER_REASON`,
  `NONSPINE_FILTERED_YN`, `NONSPINE_FILTER_REASON`) to each
  `C_S_*` table's checked-in column list. Additive only; no
  existing column moves or is removed.
- `app/repositories/snowflake_repository.py`: in `count_rows`,
  `distinct_count`, `key_difference`, and `coverage_count`,
  when the table is a `C_S_*` expected table **and** the
  discriminator is `'SNOWFLAKE'`, add the predicate
  `(SPINE_FILTERED_YN IS NULL OR SPINE_FILTERED_YN = 'N')`.
  The IDQ side (`discriminator='IDQ'`) is **never** filtered.
  Non-`C_S_*` tables (staging, DQM, EXC, deactivation captures)
  are **never** filtered — they have no spine flag.
- No change to verdict logic, key sets, version sets, spine
  definitions, or the `DATA_SOURCE` mechanism.

Effect: the Snowflake side of every `C_S_*` dimension, the
party-role spine, and per-dimension coverage all exclude
spine-flagged rows, exactly as the views do — while the IDQ
baseline, the discriminator, and every other behaviour stay
identical. A flagged Snowflake row that previously counted as
published (false MATCH risk) now correctly appears as a
snowflake-only / count-difference signal to be dispositioned
(expected flag vs investigation, per the PARITY-RUN runbook).

Testing for that change (when it is built): the Compare tool's
existing test suite from a clean copy (fake-repository tests
must still pass unchanged); a Snowflake-schema rehearsal using
`verify_view_cutover.sql` section 3, whose per-table
SNOWFLAKE-side check is the same predicate the filter applies;
and a before/after Compare run on one dimension, where the only
count movement is the flagged-row count. The pipeline UC1
rehearsal (6-member sample pack) is **not** a test of this
change: the pipeline compares SQLite files, not Snowflake
tables, and is unaffected by it.

Known delta this change will surface (not a failure): EXC rows
written with the EXC-CATALOG placeholder description
(`LOOKUP_MISSING: …`) will appear on the Snowflake side of the
Exceptions dimension with no IDQ counterpart until the
catalogue row is added and the reconciliation update heals
them. Disposition those as catalogue gaps, not code defects.

### 4c. Pipeline v5.5 — no engine change; copy-step decision

The pipeline compare engine needs no change. If the pipeline's
Dev side is to reflect "what MDM would receive", its Dev-copy
step must either copy from the `V_MDM_*` views instead of the
tables, or apply the §4b spine predicate at copy time. Both
require pipeline code changes (registry/table definitions, which
are checked-in column lists like the v5 tool's) and are **not**
in this package. Until one of them is built, pipeline Dev
compares see table contents — flagged rows included — and
pipeline verdicts must be read with that in mind. Do not
present a pipeline verdict as a publish-surface verdict until
the copy step is cut over.

### 4d. What must NOT happen

- Installing a flag-retaining package (FLAG-OUT onward) into a
  production schema while the MDM batch or Compare still reads
  tables directly. Flagged rows would publish unfiltered.
- Flipping any NONSPINE gate as part of cutover. Gates stay
  commented unless separately approved per dimension; flipping
  one changes `verify_view_cutover.sql`'s expected results.
- Replacing a Compare table read with a `V_CMP_*` view read
  (§3). If anyone proposes it again, the discriminator objection
  (§3 reason 1) is the answer.
- Treating a section-2 FAIL as "close enough". A FAIL in
  `CHK_TABLE_MINUS_MDM` means rejects leak or good rows vanish;
  a FAIL in `CHK_CMP_EQ_MDM` means the two consumers disagree;
  a FAIL in `CHK_AUDIT_UNION` means the audit cannot be trusted.
  All three are STOP conditions.

## 5. Verification SQL — what it checks

File: `verify_view_cutover.sql` (read-only: SELECT statements
only; no DDL, no DML, no temp objects). Replace `__DATABASE__`
and `__SCHEMA__` at the top; do not hard-code production names.

- **Section 0a:** 126 views exist (42 × 3). Failure = incomplete
  views install.
- **Section 0b:** 4 flag columns exist on all 42 tables.
  Failure = `01c` ALTERs not applied; view queries would fail.
- **Section 1:** per-table detail (42 rows): table / MDM / CMP /
  audit counts, spine-Y / non-spine-Y / both-Y / legacy-NULL
  counts, stray-value counts, and the four PASS/FAIL checks.
- **Section 2:** summary verdict. ALL 42 tables must pass all
  four checks, or the verdict is FAIL and cutover stops.
- **Section 3:** Compare-schema variant (13 TRS tables,
  `DATA_SOURCE='SNOWFLAKE'`-filtered, table-side simulation).
  Run ONLY in a Compare schema; it errors in a plain ETL schema
  (no `DATA_SOURCE` column), which is by design — the section
  header says so.

Check semantics (the overlap point): audit rows flagged at both
stages are counted once (`SPINE_Y + NONSPINE_Y - BOTH_Y`).
Legacy-NULL rows are reported, not asserted: non-zero is normal
during migration (pre-flag loads) and is not a failure.

Verification performed for this package (honest scope):

- The reconciliation arithmetic was proven on SQLite stub
  tables/views covering every flag combination (Y/Y, Y/N, Y/NULL,
  N/Y, N/NULL, NULL/Y, NULL/NULL, N/N): table−MDM = spine-Y,
  CMP = MDM, audit = spine-Y + non-spine-Y − both-Y (overlap
  counted once), legacy-NULL rows included in MDM. All held.
- The Snowflake script itself was **parse-checked only**
  (balanced parentheses, 5 statements, one per section plus the
  two pre-checks) — it was **not executed against Snowflake**,
  because there is no confirmed production target and no
  scratch ETL schema with the full 42-table install was spun up
  for this package. The first live run of sections 0–2 in a real
  target schema is itself a cutover step, and its output must be
  kept as the cutover evidence.
- No Compare code was changed by this package, so the Compare
  test suite was not re-run (nothing to re-test). The §4b change,
  when built, must run that suite from a clean copy.

## 6. What is still NOT validated

- No live run of `verify_view_cutover.sql` against a real target
  schema (see §5). Counts, MDM intake, and batch column-order
  checks are all still to be performed by the owning teams.
- No full driver CALLs on real data and no row-count parity vs
  IDQ in this package (same standing caveat as every v3
  generation; the PARITY-RUN runbook is the vehicle for it).
- The 7 reference objects still need real definitions/data
  before any ETL run; views do not depend on them, but loaders
  and passes do.
- The §4b Compare filter and the §4c pipeline copy-step change
  are specified here, not built or tested. Building either
  without the section-3 rehearsal would repeat the exact
  mistake this package corrects (changing a consumer surface
  without verifying it against the tool that reads it).
- MDM batch internals (column access style, per-source schemas,
  intake logic) are outside this estate and unverified here;
  §2c lists exactly what the batch team must confirm.

-- ============================================================================
-- reference_objects_for_barebones_install.sql
-- Placeholder definitions for the 7 reference objects that the bare-bones
-- v2.1 lookup functions (00_common/02_snow_common_lookups.sql,
-- fn_snow_helper40_common .. fn_snow_helper47_common) read at CREATE time.
--
-- PURPOSE: let option 1 from the 2026-10-27 DDL correction ("define the
-- 7 objects first, then run the live install") actually run, without
-- waiting for the real Oracle definitions. Run this file BEFORE the
-- bare-bones install, in the same target database, with the install
-- schema as the current schema.
--
-- WHAT THIS IS NOT:
--   * These tables are EMPTY. Empty lookups let CREATE succeed, but they
--     do NOT make ETL results correct: code translations, junk-name
--     checks, phone area-code checks and exception descriptions will
--     all come back empty until the real reference DATA is loaded.
--   * This is NOT a substitute for the real Oracle definitions.
--     Three objects below are the full Oracle-translated definitions
--     already in the Compare package; the other four are the MINIMAL
--     shapes the lookup functions actually query (same caveat as the
--     Compare package's 04_missing_tables.sql: replace them with the
--     real definitions before treating any ETL run as sign-off).
--   * V_LOOKUP_CODE_VALUE is a VIEW in Oracle. It is created here as a
--     TABLE (as in 04_missing_tables.sql) so it can be created and
--     loaded like the others; replacing it later with the real view
--     means DROP TABLE first, then CREATE VIEW.
--
-- SCHEMA TRAP (the part the correction did not spell out):
--   Six objects are referenced UNQUALIFIED, so they land in / are read
--   from the install schema. The seventh, RDM.REF_PHN_AREA_CD, is
--   referenced QUALIFIED by fn_snow_helper44_common, so creating it
--   in the install schema does NOT satisfy the function: it must be
--   in a schema literally named RDM in the SAME database as the
--   install. An existing RDM database elsewhere does not satisfy a
--   two-part schema.object reference in the install database.
--
-- ORDERING TRAP (proven in the earlier scratch runs): in Snowflake,
-- CREATE SCHEMA switches the session's CURRENT_SCHEMA to the new
-- schema. So the RDM schema is deliberately created LAST in this
-- file, after all six unqualified tables -- creating it first would
-- silently land those tables in RDM instead of the install schema.
-- The RDM table itself is fully qualified, so it is unaffected.
--
-- PROVENANCE (columns copied, not re-derived):
--   * EXC_LOOKUP_CODE_VALUE, LOOKUP_CODE_VALUE, REF_DYLGHT_SVNGS_TM:
--     full Oracle-translated definitions from
--     workspace/trs_compare_pipe/sql/01_etl_wrk.sql
--     (Oracle STAGING, translated; TRS_ETL_WRK qualification removed
--     so they land in the install schema).
--   * V_LOOKUP_CODE_VALUE, REF_JUNK_NAME_LIST, REF_MATCHCODE_DESC,
--     REF_PHN_AREA_CD: minimal shapes from
--     workspace/trs_compare_pipe/sql/04_missing_tables.sql
--     (columns taken verbatim from the fn_snow_helper* functions).
--   * The write_ddls_to_snowflake.py installer executes only CREATE
--     statements, so every statement below is runnable by it; run
--     this file first, then the bare-bones install, then (once the
--     real definitions/data exist) re-check the lookups file.
-- ============================================================================

-- fn_snow_helper40_common: EXCEPTION_CODE -> DESC, TYPE
CREATE TABLE IF NOT EXISTS EXC_LOOKUP_CODE_VALUE (
    EXC_LOOKUP_CODE_VALUE_ID NUMBER(10,0),
    CREATED_BY VARCHAR(50),
    CREATE_DATE DATE DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_BY VARCHAR(50),
    LAST_UPDATE_DATE DATE,
    EXCEPTION_CODE VARCHAR(300),
    EXCEPTION_DESC VARCHAR(300),
    EXCEPTION_TYPE VARCHAR(300)
);

-- fn_snow_helper41/42_common: code-type / source-code translation.
-- Oracle view; table here as a placeholder (see header).
CREATE TABLE IF NOT EXISTS V_LOOKUP_CODE_VALUE (
    CODE_TYPE VARCHAR,
    SRC_SYS VARCHAR,
    SRC_CODE_VALUE VARCHAR,
    MSTR_CODE_VALUE VARCHAR
);

-- fn_snow_helper43_common: junk first/last names.
CREATE TABLE IF NOT EXISTS REF_JUNK_NAME_LIST (
    NAME VARCHAR,
    EDIT_LIMITATION VARCHAR
);

-- fn_snow_helper45_common: master-code translation.
CREATE TABLE IF NOT EXISTS LOOKUP_CODE_VALUE (
    CREATED_BY VARCHAR(50),
    CREATE_DATE DATE DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_BY VARCHAR(50),
    LAST_UPDATE_DATE DATE,
    CODE_TYPE VARCHAR(50),
    MSTR_REF_CODE VARCHAR(20),
    MSTR_REF_LABEL VARCHAR(255),
    MSTR_REF_DESC VARCHAR(2500),
    SRC_CODE_VALUE VARCHAR(255),
    SRC_SYS VARCHAR(10),
    SRC_CODE_DESC VARCHAR(2500)
);

-- fn_snow_helper46_common: AddressDoctor match-code text.
CREATE TABLE IF NOT EXISTS REF_MATCHCODE_DESC (
    MATCH_CODE VARCHAR,
    DESCRIPTION VARCHAR
);

-- fn_snow_helper47_common: daylight-saving change instants.
CREATE TABLE IF NOT EXISTS REF_DYLGHT_SVNGS_TM (
    IND VARCHAR(20),
    DST TIMESTAMP_NTZ(6)
);

-- fn_snow_helper44_common: phone area codes. LAST in the file, for
-- the ordering reason in the header: CREATE SCHEMA switches the
-- session's current schema, so nothing unqualified may follow it.
-- Schema for the one qualified reference only; no other object
-- goes in RDM.
CREATE SCHEMA IF NOT EXISTS RDM;
CREATE TABLE IF NOT EXISTS RDM.REF_PHN_AREA_CD (
    NPA_ID VARCHAR,
    SERVICE VARCHAR,
    IN_SERVICE VARCHAR,
    IN_SERVICE_DT DATE,
    COUNTRY VARCHAR
);

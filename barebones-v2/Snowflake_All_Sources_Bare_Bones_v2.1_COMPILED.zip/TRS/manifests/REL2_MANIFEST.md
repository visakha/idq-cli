# Manifest — m_Tgt_C_S_TRS_Pty_Rle_Rel_2_Mem_To_PCP (TRS, bare-bones)

Workflow: `wf_TRS_Stage_Load_1_Ongoing`. Driver file: `drivers/driver_sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_2_Mem_To_PCP.sql`.

## Driver

New driver signature (v2.1 signature minus the run-id parameter; all
original parameters kept, in order, with their defaults):

```sql
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_2_Mem_To_PCP (

    P_PCP_REL_TP VARCHAR DEFAULT '100' -- $PCP_REL_TP

) RETURNS VARCHAR
```

Driver behaviour: step 5 drops the mapping work tables (bare `DROP TABLE
IF EXISTS`, no completion record); every step runs unconditionally, in
order; ONE publish transaction calls all branch procs in order, then
COMMIT; on error the exception block does ROLLBACK + RAISE only. Work
tables are NOT dropped at the end of a run. The driver RETURNs
`l_summary`.

## Steps

| STEP_NO | Proc | Kind | Step name | Produces | Consumes | Original params used |
|---|---|---|---|---|---|---|
| 10 | `sp_snow_step_TRS_REL2_S10_SRC` | TRANSFORM | SRC_MANAGED_CARE | `WRK_TRS_REL2_S1_SRC` | (base tables only) | none |
| 20 | `sp_snow_step_TRS_REL2_S20_KEYED` | TRANSFORM | KEYED | `WRK_TRS_REL2_S2_KEYED` | WRK_TRS_REL2_S1_SRC | P_PCP_REL_TP |
| 30 | `sp_snow_step_TRS_REL2_S30_ROUTER` | TRANSFORM | ROUTER_EXCEPTIONS | `WRK_TRS_REL2_S3_ROUTER` | WRK_TRS_REL2_S2_KEYED | none |
| 40 | `sp_snow_step_TRS_REL2_S40_CONSOL` | TRANSFORM | CONSOLIDATED | `WRK_TRS_REL2_S4_CONSOL` | WRK_TRS_REL2_S2_KEYED | none |
| 50 | `sp_snow_step_TRS_REL2_S50_PREP` | TRANSFORM | PREPARED | `WRK_TRS_REL2_S5_PREP` | WRK_TRS_REL2_S4_CONSOL | none |
| 60 | `sp_snow_step_TRS_REL2_S60_TIMELINE` | TRANSFORM | TIMELINE | `WRK_TRS_REL2_S6_TIMELINE` | WRK_TRS_REL2_S5_PREP | none |

Step proc signatures: the step's used original params (in original order)
+ `P_RUN_TS TIMESTAMP_NTZ DEFAULT NULL`. Every step proc returns `NUMBER`
(row count), has no exception block, no transaction, no target write.

Step files: `steps/sp_snow_step_*.sql` (same file names as v2.1).

## Publish branches

| STEP_NO | Proc | Kind | Step name | Target | Consumes | Keeps P_RUN_TS |
|---|---|---|---|---|---|---|
| 70 | `sp_snow_pub_TRS_REL2_EXC_STG_BAD_REC_MEMB_DATES` | EXCEPTION | PUBLISH_EXC_DATES | `EXC_STG_BAD_REC_MEMB` | WRK_TRS_REL2_S3_ROUTER | Y |
| 80 | `sp_snow_pub_TRS_REL2_EXC_STG_BAD_REC_MEMB_DEFAULT` | EXCEPTION | PUBLISH_EXC_DEFAULT | `EXC_STG_BAD_REC_MEMB` | WRK_TRS_REL2_S3_ROUTER | Y |
| 90 | `sp_snow_pub_TRS_REL2_C_S_TRS_PTY_RLE_REL_PROV` | SPINE | PUBLISH_C_S_TRS_PTY_RLE_REL_PROV | `C_S_TRS_PTY_RLE_REL_PROV` | WRK_TRS_REL2_S6_TIMELINE | Y |

Branch proc signatures: the branch's used original params (in original
order) + `P_RUN_TS TIMESTAMP_NTZ DEFAULT NULL` ONLY where the INSERT body
references the run-timestamp parameter (Keeps P_RUN_TS = Y above). Branch
procs contain no transaction control and return `SQLROWCOUNT`; the driver
calls them inside ONE publish transaction.

Branch files: `publish/sp_snow_pub_*.sql` (same file names as v2.1).

## Summary flow

The driver RETURNs `l_summary`. Each step appends one line via
`fn_snow_helper36_common` (mapping, step label, row count); each publish
branch appends its line the same way, reusing `l_rows`, inside the publish
transaction. The workflow runner calls each driver with ZERO arguments,
captures each RETURN string, and concatenates them with one per-mapping
header line plus newlines into one big summary string, which it RETURNs.

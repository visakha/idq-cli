# Manifest — m_Tgt_C_S_TRS_Addr_2 (TRS, bare-bones)

Workflow: `wf_TRS_Stage_Load_1_Ongoing`. Driver file: `drivers/driver_sp_snow_main_m_Tgt_C_S_TRS_Addr_2.sql`.

## Driver

New driver signature (v2.1 signature minus the run-id parameter; all
original parameters kept, in order, with their defaults):

```sql
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Addr_2 (

    P_MEMBER_ROLE_TYPE      VARCHAR DEFAULT 'Member',
    P_MEMBER_HIERARCHY_CODE VARCHAR DEFAULT 'Member',
    P_MEMBER_HM_REL_TP_CD   VARCHAR DEFAULT 'Member Addr'

) RETURNS VARCHAR
```

Driver behaviour: step 5 drops the mapping work tables (bare `DROP TABLE
IF EXISTS`, no completion record); every step runs unconditionally, in
order; ONE publish transaction calls all branch procs in order, then
COMMIT; on error the exception block does ROLLBACK + RAISE only. Work
tables are NOT dropped at the end of a run. The driver RETURNs
`l_summary`.

## Steps

| STEP_NO | Proc | Kind | Step name | Produces | Consumes | Original params used |
|---|---|---|---|---|---|---|
| 10 | `sp_snow_step_TRS_ADDR2_S10_DEDUP` | TRANSFORM | ADDR_DEDUP | `WRK_TRS_ADDR2_S10_DEDUP` | (base tables only) | none |
| 20 | `sp_snow_step_TRS_ADDR2_S20_SRC` | TRANSFORM | SRC_VALIDATED_JOIN | `WRK_TRS_ADDR2_S20_SRC` | WRK_TRS_ADDR2_S10_DEDUP | none |
| 30 | `sp_snow_step_TRS_ADDR2_S30_KEYED` | TRANSFORM | KEYED_ADDR | `WRK_TRS_ADDR2_S30_KEYED` | WRK_TRS_ADDR2_S20_SRC | P_MEMBER_ROLE_TYPE |
| 40 | `sp_snow_step_TRS_ADDR2_S40_SCORED` | TRANSFORM | SCORED_VERSIONED | `WRK_TRS_ADDR2_S40_SCORED` | WRK_TRS_ADDR2_S30_KEYED | none |
| 50 | `sp_snow_step_TRS_ADDR2_S50_READY` | TRANSFORM | READY_TO_PUBLISH | `WRK_TRS_ADDR2_S50_READY` | WRK_TRS_ADDR2_S40_SCORED | P_MEMBER_ROLE_TYPE, P_MEMBER_HIERARCHY_CODE, P_MEMBER_HM_REL_TP_CD |

Step proc signatures: the step's used original params (in original order)
+ `P_RUN_TS TIMESTAMP_NTZ DEFAULT NULL`. Every step proc returns `NUMBER`
(row count), has no exception block, no transaction, no target write.

Step files: `steps/sp_snow_step_*.sql` (same file names as v2.1).

## Publish branches

| STEP_NO | Proc | Kind | Step name | Target | Consumes | Keeps P_RUN_TS |
|---|---|---|---|---|---|---|
| 60 | `sp_snow_pub_TRS_ADDR2_DQM_ADDRESS` | VALIDATION | PUBLISH_DQM_ADDRESS | `DQM_ADDRESS` | WRK_TRS_ADDR2_S50_READY | N |
| 70 | `sp_snow_pub_TRS_ADDR2_C_S_TRS_PTY_RLE_ADDR` | SPINE | PUBLISH_C_S_TRS_PTY_RLE_ADDR | `C_S_TRS_PTY_RLE_ADDR` | WRK_TRS_ADDR2_S50_READY | N |
| 80 | `sp_snow_pub_TRS_ADDR2_EXC_STG_BAD_REC_MEMB` | EXCEPTION | PUBLISH_EXC_STG_BAD_REC_MEMB | `EXC_STG_BAD_REC_MEMB` | WRK_TRS_ADDR2_S50_READY | N |

Branch proc signatures: the branch's used original params (in original
order) + `P_RUN_TS TIMESTAMP_NTZ DEFAULT NULL` ONLY where the INSERT body
references the run-timestamp parameter (Keeps P_RUN_TS = Y above). Branch
procs contain no transaction control and return `SQLROWCOUNT`; the driver
calls them inside ONE publish transaction.

Branch files: `publish/sp_snow_pub_*.sql` (same file names as v2.1).

## Summary flow

The driver RETURNs `l_summary`. Each step appends one line via
`fn_snow_helper36_common` (mapping, step label, row count); each publish
branch appends its line the same way, reusing `l_rows`, inside the publish
transaction. The workflow runner calls each driver with ZERO arguments,
captures each RETURN string, and concatenates them with one per-mapping
header line plus newlines into one big summary string, which it RETURNs.

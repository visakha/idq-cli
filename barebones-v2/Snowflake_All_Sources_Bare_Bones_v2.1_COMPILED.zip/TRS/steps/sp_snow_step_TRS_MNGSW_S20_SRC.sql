-- ============================================================================
-- sp_snow_step_TRS_MNGSW_S20_SRC  --  BARE-BONES STEP (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_Mng_Attr_Sw, workflow wf_TRS_Stage_Load_1_Ongoing.
-- Step name: VALID_SRC. Produces: WRK_TRS_MNGSW_S20_SRC.
-- Consumes (v2.1 declared inputs): WRK_TRS_MNGSW_S10_DAILY.
-- Original params used: none; plus P_RUN_TS (run timestamp).
--
-- The CTAS below is the v2.1 step SELECT verbatim. The only removals
-- were the work-table existence check and the step completion call.
-- No exception block (errors propagate to the driver handler), no
-- transactions, no target writes. Returns the row count.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_MNGSW_S20_SRC (

    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL

)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    l_rows       NUMBER DEFAULT 0;
BEGIN

    -- ---- Step 20: VALID_SRC (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_MNGSW_S20_SRC AS
    SELECT dly.INDV_ID, dly.FILE_CLEARANCE_SW, dly.SSA_VALIDATION_SW, dly.EFF_BEGIN_DT, dly.TW_CONVERT_IND,
           dly.LTC_CONVERT_IND, dly.PTY_PK, dly.CREATE_DT, dly.SRC_TBL
      FROM WRK_TRS_MNGSW_S10_DAILY dly
      JOIN STG_TRS_VALID_MEMBERS IM ON dly.INDV_ID = IM.INDV_ID AND dly.SRC_TBL = IM.SRC_TBL
     WHERE dly.KEY_RN = 1;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_MNGSW_S20_SRC;
    RETURN :l_rows;
END;$$;

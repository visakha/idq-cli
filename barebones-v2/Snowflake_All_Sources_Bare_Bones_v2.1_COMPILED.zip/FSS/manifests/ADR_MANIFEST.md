# ADR Manifest -- m_Tgt_C_S_FSS_Pty_Addr, bare-bones step driver (FSS ONLY)

Prefix: `FSS_ADR`. Base dir: `snowflake_all_barebones/FSS/`.

Bare-bones strip of the v2.1 config-driven driver: NO config table, NO checkpoints, NO job-run id, NO seed file. Every step and every publish branch runs unconditionally, in order. Business SQL (step CTAS bodies, publish INSERT bodies) is verbatim from v2.1.

## Driver

File: `drivers/driver_sp_snow_main_m_Tgt_C_S_FSS_Pty_Addr.sql`

New driver signature (`P_JOB_RUN_ID` removed; all other parameters unchanged, in order, with their defaults):

```sql
sp_snow_main_m_Tgt_C_S_FSS_Pty_Addr (
    P_MEMBER_HIERARCHY_CODE VARCHAR DEFAULT 'Member',
    P_MEMBER_HM_REL_TP_CD   VARCHAR DEFAULT 'Member Addr'
) RETURNS VARCHAR
```

Driver behaviour: step 5 cleanup (bare `DROP TABLE IF EXISTS` for each work table below, no checkpoint) -> unconditional work steps in order -> ONE publish transaction calling the branches in order -> `RETURN l_summary`. Exception block: `ROLLBACK` + `RAISE` only. Work tables are left standing after the run; a restart is simply a new run.

Work tables dropped at step 5: `WRK_FSS_ADDR_S1_SRC`, `WRK_FSS_ADDR_S2_VALIDATED`, `WRK_FSS_ADDR_S3_FLAT`, `WRK_FSS_ADDR_S4_SCORED`.

## Steps

| STEP_NO | Proc | Produces | Consumes | Original params used | Description |
|---|---|---|---|---|---|
| 10 | `sp_snow_step_FSS_ADR_S10_SRC` | `WRK_FSS_ADDR_S1_SRC` | `(none)` | none | Source addresses with address key built, deactivated parties removed |
| 20 | `sp_snow_step_FSS_ADR_S20_VALIDATED` | `WRK_FSS_ADDR_S2_VALIDATED` | `WRK_FSS_ADDR_S1_SRC` | none | Address validation result attached, state code translated |
| 30 | `sp_snow_step_FSS_ADR_S30_FLAT` | `WRK_FSS_ADDR_S3_FLAT` | `WRK_FSS_ADDR_S2_VALIDATED` | none | Validation result flattened into plain columns, match-code description resolved |
| 40 | `sp_snow_step_FSS_ADR_S40_SCORED` | `WRK_FSS_ADDR_S4_SCORED` | `WRK_FSS_ADDR_S3_FLAT` | `P_MEMBER_HIERARCHY_CODE`, `P_MEMBER_HM_REL_TP_CD` | Good / exception score, held address lines, exception details, insert-only guards |

Step proc signatures: the step's used original params (in original order) + `P_RUN_TS`. Every step proc returns `NUMBER` (row count), has no exception block, no transaction, no target write, and no existence check. `P_RUN_TS` carries `DEFAULT NULL` only where a preceding original param carries a default (Snowflake forbids a required parameter after an optional one; drivers pass everything positionally, so behaviour is unchanged).

`sp_snow_step_FSS_ADR_S10_SRC` signature:
```sql
sp_snow_step_FSS_ADR_S10_SRC (
    P_RUN_TS       TIMESTAMP_NTZ
) RETURNS NUMBER
```

`sp_snow_step_FSS_ADR_S20_VALIDATED` signature:
```sql
sp_snow_step_FSS_ADR_S20_VALIDATED (
    P_RUN_TS       TIMESTAMP_NTZ
) RETURNS NUMBER
```

`sp_snow_step_FSS_ADR_S30_FLAT` signature:
```sql
sp_snow_step_FSS_ADR_S30_FLAT (
    P_RUN_TS       TIMESTAMP_NTZ
) RETURNS NUMBER
```

`sp_snow_step_FSS_ADR_S40_SCORED` signature:
```sql
sp_snow_step_FSS_ADR_S40_SCORED (
    P_MEMBER_HIERARCHY_CODE VARCHAR DEFAULT 'Member',
    P_MEMBER_HM_REL_TP_CD VARCHAR DEFAULT 'Member Addr',
    P_RUN_TS       TIMESTAMP_NTZ DEFAULT NULL
) RETURNS NUMBER
```


## Publish branches

One transaction, branches in the order below. Each branch proc returns `SQLROWCOUNT` as `NUMBER`, with no transaction control and no checkpoint calls.

| STEP_NO | Proc | Kind | Target | Consumes | Keeps P_RUN_TS | Description |
|---|---|---|---|---|---|---|
| 50 | `sp_snow_pub_FSS_ADR_DQM_ADDRESS` | VALIDATION | `DQM_ADDRESS` | `WRK_FSS_ADDR_S4_SCORED` | N | Every active address to the validation mart |
| 60 | `sp_snow_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR` | SPINE | `C_S_FSS_PTY_RLE_ADDR` | `WRK_FSS_ADDR_S4_SCORED` | N | Good addresses |
| 70 | `sp_snow_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB` | EXCEPTION | `EXC_STG_BAD_REC_MEMB` | `WRK_FSS_ADDR_S4_SCORED` | N | Exception addresses |

Branch proc signatures: `P_RUN_TS` is kept ONLY where the INSERT body references `:P_RUN_TS`; every other branch takes no arguments. A `run_ts` / `exc_mapping` COLUMN read from a step table does NOT count as a `:P_RUN_TS` reference.

`sp_snow_pub_FSS_ADR_DQM_ADDRESS` signature:
```sql
sp_snow_pub_FSS_ADR_DQM_ADDRESS () RETURNS NUMBER
```

`sp_snow_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR` signature:
```sql
sp_snow_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR () RETURNS NUMBER
```

`sp_snow_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB` signature:
```sql
sp_snow_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB () RETURNS NUMBER
```


## Summary flow

The driver appends one `fn_snow_helper36_common` line per step and per publish branch, in order, to `l_summary`, and `RETURN`s `l_summary` (no job-run-id prefix). The workflow runner `sp_etl_run_wf_FSS_Stage_Load` (called with zero arguments) concatenates each mapping driver's returned summary under a `== <mapping> ==` header line, in run order, and returns the one combined string.


## Files

- Driver: `drivers/driver_sp_snow_main_m_Tgt_C_S_FSS_Pty_Addr.sql`

- Step: `steps/sp_snow_step_FSS_ADR_S10_SRC.sql`

- Step: `steps/sp_snow_step_FSS_ADR_S20_VALIDATED.sql`

- Step: `steps/sp_snow_step_FSS_ADR_S30_FLAT.sql`

- Step: `steps/sp_snow_step_FSS_ADR_S40_SCORED.sql`

- Branch: `publish/sp_snow_pub_FSS_ADR_DQM_ADDRESS.sql`

- Branch: `publish/sp_snow_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR.sql`

- Branch: `publish/sp_snow_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB.sql`

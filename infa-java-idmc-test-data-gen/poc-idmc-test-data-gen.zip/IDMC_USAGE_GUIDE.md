# IDMC Login Usage Guide

This guide explains how to use the IDMCLogin class and run the associated JUnit tests.

## Overview

The `IDMCLogin` class provides functionality to:
- Authenticate with Informatica Data Management Cloud (IDMC)
- Store and manage session information (sessionId and baseApiUrl)
- Validate session expiry (30-minute timeout)
- Handle various error scenarios gracefully

## Class Location
- **Main Class**: `src/main/java/com/example/demoidmctestdatagen/idmc/IDMCLogin.java`
- **Configuration**: `src/main/java/com/example/demoidmctestdatagen/config/IDMCProperties.java`
- **Unit Test Class**: `src/test/java/com/example/demoidmctestdatagen/idmc/IDMCLoginTest.java`
- **Integration Test Class**: `src/test/java/com/example/demoidmctestdatagen/idmc/IDMCLoginIntegrationTest.java`

## Running the Tests

### Prerequisites
- Java 24 or compatible version
- Maven 3.x
- Internet connection (required for integration tests)
- Valid IDMC credentials configured in application.properties

### Running All Tests
```bash
# Run all tests in the project
mvn test

# Run only the integration tests (real HTTP calls)
mvn test -Dtest=IDMCLoginIntegrationTest

# Run both unit and integration tests
mvn test -Dtest=IDMCLogin*Test

# Run with verbose output
mvn test -Dtest=IDMCLoginIntegrationTest -X
```

### Running Specific Test Groups
The tests are organized into nested classes for different scenarios:

```bash
# Run only login functionality tests
mvn test -Dtest=IDMCLoginTest$LoginTests

# Run only session management tests
mvn test -Dtest=IDMCLoginTest$SessionManagementTests

# Run only integration-like tests
mvn test -Dtest=IDMCLoginTest$IntegrationTests
```

### Running Individual Tests
```bash
# Run a specific unit test method
mvn test -Dtest=IDMCLoginTest#shouldLoginSuccessfully

# Run a specific integration test method
mvn test -Dtest=IDMCLoginIntegrationTest#shouldLoginSuccessfullyWithRealCredentials

# Run multiple specific tests
mvn test -Dtest=IDMCLoginTest#shouldLoginSuccessfully,shouldFailLoginWithInvalidCredentials
```

## Integration Tests (Real HTTP Calls)

The integration tests make actual HTTP calls to IDMC servers using credentials from `application.properties`.

### Configuration Required
Ensure your `application.properties` contains:
```properties
idmc.login.username=your_idmc_username
idmc.login.password=your_idmc_password
```

### Integration Test Features
```bash
# Run all integration tests
mvn test -Dtest=IDMCLoginIntegrationTest

# Run with integration profile
mvn test -Dtest=IDMCLoginIntegrationTest -Dspring.profiles.active=integration

# Run specific integration test
mvn test -Dtest=IDMCLoginIntegrationTest#shouldLoginSuccessfullyWithRealCredentials
```

### Integration Test Coverage
- **Real Authentication**: Tests actual login with configured credentials
- **Invalid Credentials**: Tests failure scenarios with wrong passwords
- **Session Management**: Tests real session timeout and validation
- **Concurrent Access**: Tests multiple simultaneous login attempts
- **Response Validation**: Validates actual IDMC response structure
- **Network Error Handling**: Tests behavior with network issues

## Using IDMCLogin in Your Code

### Basic Usage Example
```java
import com.example.demoidmctestdatagen.idmc.IDMCLogin;

@Component
public class MyService {
    
    @Autowired
    private IDMCLogin idmcLogin;
    
    public void performIDMCOperations() {
        // Login to IDMC
        IDMCLogin.LoginResult result = idmcLogin.login("your-username", "your-password");
        
        if (result.isSuccess()) {
            System.out.println("Login successful!");
            System.out.println("Session ID: " + result.getSessionId());
            System.out.println("Base API URL: " + result.getBaseApiUrl());
            
            // Use session for subsequent API calls
            String sessionId = idmcLogin.getSessionId();
            String baseUrl = idmcLogin.getBaseApiUrl();
            
            // Check session validity before API calls
            if (idmcLogin.isSessionValid()) {
                // Make API calls using sessionId and baseUrl
                makeAPICall(sessionId, baseUrl);
            } else {
                // Re-login if session expired
                result = idmcLogin.login("your-username", "your-password");
            }
            
        } else {
            System.err.println("Login failed: " + result.getMessage());
        }
    }
    
    private void makeAPICall(String sessionId, String baseUrl) {
        // Your IDMC API calls here
        // Use sessionId in headers: "INFA-SESSION-ID": sessionId
    }
}
```

### Session Management
```java
// Check if session is still valid
if (idmcLogin.isSessionValid()) {
    long remainingMinutes = idmcLogin.getSessionRemainingMinutes();
    System.out.println("Session expires in " + remainingMinutes + " minutes");
}

// Clear session when done
idmcLogin.clearSession();

// Get login time
LocalDateTime loginTime = idmcLogin.getLoginTime();
```

## Test Structure

### LoginTests
- **shouldLoginSuccessfully**: Tests successful login with valid credentials
- **shouldFailLoginWithInvalidCredentials**: Tests handling of authentication failures
- **shouldHandleNetworkErrors**: Tests network error handling
- **shouldHandleMalformedResponse**: Tests handling of malformed API responses
- **shouldHandleNonOkStatus**: Tests handling of HTTP error status codes

### SessionManagementTests
- **shouldValidateSessionWhenValid**: Tests session validation logic
- **shouldInvalidateSessionWhenNoLogin**: Tests behavior when no login has occurred
- **shouldClearSession**: Tests session clearing functionality
- **shouldCalculateRemainingTimeCorrectly**: Tests session timeout calculations

### IntegrationTests (Mocked)
- **shouldPerformCompleteLoginFlow**: Tests complete login workflow with realistic data
- **shouldHandleMultipleProducts**: Tests handling of responses with multiple products

### Integration Tests (Real HTTP Calls)
- **shouldLoginSuccessfullyWithRealCredentials**: Tests actual IDMC login with configured credentials
- **shouldFailLoginWithInvalidCredentials**: Tests failure with wrong credentials
- **shouldFailLoginWithEmptyCredentials**: Tests validation of empty credential inputs
- **shouldManageSessionStateCorrectly**: Tests real session lifecycle management
- **shouldHandleMultipleLoginAttemptsCorrectly**: Tests session replacement on re-login
- **shouldValidateResponseStructureFromRealIDMC**: Tests real IDMC response format
- **shouldHandleConcurrentLoginAttempts**: Tests thread safety with multiple logins
- **shouldDemonstrateSessionTimeoutBehavior**: Tests session timeout calculations
- **shouldProvideMeaningfulErrorMessages**: Tests error message quality

## Test Configuration

### Unit Tests (IDMCLoginTest)

### Integration Tests (IDMCLoginIntegrationTest)
The integration tests make **real HTTP calls**, providing:
- **Real-world validation**: Tests against actual IDMC servers
- **End-to-end verification**: Complete authentication workflow testing
- **Configuration validation**: Ensures proper credential setup

## Expected Test Output

### Unit Tests Output
When running unit tests successfully, you should see output like:
```
[INFO] Running com.example.demoidmctestdatagen.idmc.IDMCLoginTest
[INFO] Tests run: 11, Failures: 0, Errors: 0, Skipped: 0
```

### Integration Tests Output
When running integration tests successfully, you should see output like:
```
[INFO] Running com.example.demoidmctestdatagen.idmc.IDMCLoginIntegrationTest
[INFO] Tests run: 9, Failures: 0, Errors: 0, Skipped: 0
```

**Note**: Integration tests will show actual HTTP logging and may take longer to complete due to network calls.

## Troubleshooting

### Common Issues

1. **Java Version Mismatch**
   ```bash
   # Check Java version
   java -version
   # Should show Java 24 or compatible
   ```

2. **Maven Dependencies**
   ```bash
   # Clean and reinstall dependencies
   mvn clean install
   ```

3. **Test Compilation Errors**
   ```bash
   # Compile tests specifically
   mvn test-compile
   ```

4. **Mockito Issues**
   - Ensure `spring-boot-starter-test` dependency is present in pom.xml
   - This includes JUnit 5 and Mockito automatically

### Debugging Tests
```bash
# Run with debug information
mvn test -Dtest=IDMCLoginTest -Dmaven.surefire.debug

# Run with stack traces
mvn test -Dtest=IDMCLoginTest -e -X
```

## Integration with Real IDMC

To test with real IDMC credentials (not recommended for unit tests):

1. Create a separate integration test class
2. Use `@ActiveProfiles("integration")` 
3. Configure real credentials in application-integration.properties
4. Use `TestRestTemplate` instead of mocked `RestTemplate`

**Important**: Never commit real credentials to version control!

## Security Notes

- The login credentials in tests are mock data only
- Real credentials should be externalized (environment variables, secure config)
- Sessions expire after 30 minutes - implement proper re-authentication
- Always clear sessions when done to prevent session leaks

## Next Steps

After successful login, you can:
1. Use the sessionId for subsequent IDMC API calls
2. Implement business entity operations (Create, Read, Update, Delete)
3. Add proper error handling and retry logic
4. Implement session refresh before expiry
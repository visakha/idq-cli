package com.example.demoidmctestdatagen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIdmcTestDataGenApplicationTests {

	@Test
	void contextLoads() {
	}

}

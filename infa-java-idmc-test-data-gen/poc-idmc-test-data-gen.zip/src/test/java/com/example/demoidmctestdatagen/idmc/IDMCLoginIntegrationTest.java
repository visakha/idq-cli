package com.example.demoidmctestdatagen.idmc;

import com.example.demoidmctestdatagen.config.IDMCProperties;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations = "classpath:application.properties")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class IDMCLoginIntegrationTest {

    @Autowired
    private IDMCProperties idmcProperties;
    
    private IDMCLogin idmcLogin;
    
    @BeforeEach
    void setUp() {
        idmcLogin = new IDMCLogin(new RestTemplate());
    }
    
    @AfterEach
    void tearDown() {
        if (idmcLogin != null) {
            idmcLogin.clearSession();
        }
    }
    
    @Test
    @Order(1)
    @DisplayName("Should successfully login to IDMC with real credentials")
    void shouldLoginSuccessfullyWithRealCredentials() {
        assertNotNull(idmcProperties.getUsername(), "Username should be configured in application.properties");
        assertNotNull(idmcProperties.getPassword(), "Password should be configured in application.properties");
        assertFalse(idmcProperties.getUsername().isEmpty(), "Username should not be empty");
        assertFalse(idmcProperties.getPassword().isEmpty(), "Password should not be empty");
        
        IDMCLogin.LoginResult result = idmcLogin.login(
            idmcProperties.getUsername(), 
            idmcProperties.getPassword()
        );
        
        assertTrue(result.isSuccess(), "Login should be successful with valid credentials");
        assertEquals("Login successful", result.getMessage());
        assertNotNull(result.getSessionId(), "Session ID should be returned");
        assertNotNull(result.getBaseApiUrl(), "Base API URL should be returned");
        
        assertTrue(result.getSessionId().length() > 10, "Session ID should be a meaningful string");
        assertTrue(result.getBaseApiUrl().startsWith("https://"), "Base API URL should be HTTPS");
        assertTrue(result.getBaseApiUrl().contains("informaticacloud.com"), "Should be Informatica cloud URL");
        
        assertEquals(result.getSessionId(), idmcLogin.getSessionId());
        assertEquals(result.getBaseApiUrl(), idmcLogin.getBaseApiUrl());
        assertTrue(idmcLogin.isSessionValid());
        
        assertNotNull(idmcLogin.getLoginTime());
        assertTrue(idmcLogin.getLoginTime().isBefore(LocalDateTime.now().plusSeconds(5)));
        assertTrue(idmcLogin.getLoginTime().isAfter(LocalDateTime.now().minusSeconds(30)));
    }
    
    @Test
    @Order(2)
    @DisplayName("Should fail login with invalid credentials")
    void shouldFailLoginWithInvalidCredentials() {
        IDMCLogin.LoginResult result = idmcLogin.login("invalid_user", "wrong_password");
        
        assertFalse(result.isSuccess(), "Login should fail with invalid credentials");
        assertTrue(result.getMessage().contains("HTTP error during login") || 
                   result.getMessage().contains("401") ||
                   result.getMessage().contains("Unauthorized"), 
                   "Error message should indicate authentication failure");
        assertNull(result.getSessionId(), "No session ID should be returned for failed login");
        assertNull(result.getBaseApiUrl(), "No base API URL should be returned for failed login");
        
        assertNull(idmcLogin.getSessionId());
        assertNull(idmcLogin.getBaseApiUrl());
        assertFalse(idmcLogin.isSessionValid());
    }
    
    @Test
    @Order(3)
    @DisplayName("Should fail login with empty credentials")
    void shouldFailLoginWithEmptyCredentials() {
        IDMCLogin.LoginResult result1 = idmcLogin.login("", idmcProperties.getPassword());
        assertFalse(result1.isSuccess(), "Login should fail with empty username");
        
        IDMCLogin.LoginResult result2 = idmcLogin.login(idmcProperties.getUsername(), "");
        assertFalse(result2.isSuccess(), "Login should fail with empty password");
        
        IDMCLogin.LoginResult result3 = idmcLogin.login("", "");
        assertFalse(result3.isSuccess(), "Login should fail with both empty credentials");
    }
    
    @Test
    @Order(4)
    @DisplayName("Should manage session state correctly")
    void shouldManageSessionStateCorrectly() {
        assertFalse(idmcLogin.isSessionValid(), "Initially no session should be valid");
        assertEquals(0, idmcLogin.getSessionRemainingMinutes(), "No remaining time initially");
        
        IDMCLogin.LoginResult result = idmcLogin.login(
            idmcProperties.getUsername(), 
            idmcProperties.getPassword()
        );
        
        assertTrue(result.isSuccess(), "Login should succeed");
        assertTrue(idmcLogin.isSessionValid(), "Session should be valid after login");
        
        long remainingMinutes = idmcLogin.getSessionRemainingMinutes();
        assertTrue(remainingMinutes > 25 && remainingMinutes <= 30, 
                   "Remaining time should be close to 30 minutes, got: " + remainingMinutes);
        
        String originalSessionId = idmcLogin.getSessionId();
        String originalBaseUrl = idmcLogin.getBaseApiUrl();
        
        assertNotNull(originalSessionId);
        assertNotNull(originalBaseUrl);
        
        idmcLogin.clearSession();
        
        assertFalse(idmcLogin.isSessionValid(), "Session should be invalid after clear");
        assertNull(idmcLogin.getSessionId(), "Session ID should be null after clear");
        assertNull(idmcLogin.getBaseApiUrl(), "Base URL should be null after clear");
        assertEquals(0, idmcLogin.getSessionRemainingMinutes(), "No remaining time after clear");
    }
    
    @Test
    @Order(5)
    @DisplayName("Should handle multiple login attempts correctly")
    void shouldHandleMultipleLoginAttemptsCorrectly() {
        IDMCLogin.LoginResult result1 = idmcLogin.login(
            idmcProperties.getUsername(), 
            idmcProperties.getPassword()
        );
        assertTrue(result1.isSuccess(), "First login should succeed");
        
        String firstSessionId = result1.getSessionId();
        String firstBaseUrl = result1.getBaseApiUrl();
        
        IDMCLogin.LoginResult result2 = idmcLogin.login(
            idmcProperties.getUsername(), 
            idmcProperties.getPassword()
        );
        assertTrue(result2.isSuccess(), "Second login should also succeed");
        
        String secondSessionId = result2.getSessionId();
        String secondBaseUrl = result2.getBaseApiUrl();
        
        assertNotNull(firstSessionId);
        assertNotNull(secondSessionId);
        assertNotNull(firstBaseUrl);
        assertNotNull(secondBaseUrl);
        
        assertEquals(secondSessionId, idmcLogin.getSessionId(), "Should store the latest session");
        assertEquals(secondBaseUrl, idmcLogin.getBaseApiUrl(), "Should store the latest base URL");
    }
    
    @Test
    @Order(6)
    @DisplayName("Should validate response structure from real IDMC")
    void shouldValidateResponseStructureFromRealIDMC() {
        IDMCLogin.LoginResult result = idmcLogin.login(
            idmcProperties.getUsername(), 
            idmcProperties.getPassword()
        );
        
        assertTrue(result.isSuccess(), "Login should succeed");
        
        String sessionId = result.getSessionId();
        String baseApiUrl = result.getBaseApiUrl();
        
        assertNotNull(sessionId, "Session ID should not be null");
        assertNotNull(baseApiUrl, "Base API URL should not be null");
        
        assertTrue(sessionId.length() >= 15, "Session ID should be substantial length: " + sessionId);
        assertTrue(baseApiUrl.startsWith("https://"), "Base URL should use HTTPS: " + baseApiUrl);
        assertTrue(baseApiUrl.contains("informaticacloud.com"), "Should be Informatica domain: " + baseApiUrl);
        assertTrue(baseApiUrl.endsWith("/saas"), "Should end with /saas: " + baseApiUrl);
        
        assertFalse(sessionId.contains(" "), "Session ID should not contain spaces");
        assertFalse(baseApiUrl.contains(" "), "Base URL should not contain spaces");
    }
    
    @Test
    @Order(7)
    @DisplayName("Should handle concurrent login attempts")
    void shouldHandleConcurrentLoginAttempts() throws InterruptedException {
        final int numberOfThreads = 3;
        final IDMCLogin[] loginInstances = new IDMCLogin[numberOfThreads];
        final IDMCLogin.LoginResult[] results = new IDMCLogin.LoginResult[numberOfThreads];
        final Thread[] threads = new Thread[numberOfThreads];
        
        for (int i = 0; i < numberOfThreads; i++) {
            final int index = i;
            loginInstances[index] = new IDMCLogin(new RestTemplate());
            
            threads[index] = new Thread(() -> {
                results[index] = loginInstances[index].login(
                    idmcProperties.getUsername(), 
                    idmcProperties.getPassword()
                );
            });
        }
        
        for (Thread thread : threads) {
            thread.start();
        }
        
        for (Thread thread : threads) {
            thread.join(10000); // Wait up to 10 seconds per thread
        }
        
        for (int i = 0; i < numberOfThreads; i++) {
            assertNotNull(results[i], "Result " + i + " should not be null");
            assertTrue(results[i].isSuccess(), "Login " + i + " should succeed");
            assertNotNull(results[i].getSessionId(), "Session ID " + i + " should not be null");
            assertNotNull(results[i].getBaseApiUrl(), "Base URL " + i + " should not be null");
        }
        
        for (IDMCLogin instance : loginInstances) {
            instance.clearSession();
        }
    }
    
    @Test
    @Order(8)
    @DisplayName("Should demonstrate session timeout behavior")
    @Timeout(value = 2, unit = TimeUnit.MINUTES)
    void shouldDemonstrateSessionTimeoutBehavior() {
        IDMCLogin.LoginResult result = idmcLogin.login(
            idmcProperties.getUsername(), 
            idmcProperties.getPassword()
        );
        
        assertTrue(result.isSuccess(), "Login should succeed");
        assertTrue(idmcLogin.isSessionValid(), "Session should be valid immediately after login");
        
        long initialRemainingMinutes = idmcLogin.getSessionRemainingMinutes();
        assertTrue(initialRemainingMinutes > 25, "Should have close to 30 minutes remaining");
        
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        long laterRemainingMinutes = idmcLogin.getSessionRemainingMinutes();
        assertTrue(laterRemainingMinutes <= initialRemainingMinutes, 
                   "Remaining time should decrease or stay same");
        assertTrue(idmcLogin.isSessionValid(), "Session should still be valid after 2 seconds");
    }
    
    @Test
    @Order(9)
    @DisplayName("Should provide meaningful error messages for network issues")
    void shouldProvideMeaningfulErrorMessages() {
        IDMCLogin networkTestLogin = new IDMCLogin(new RestTemplate());
        
        IDMCLogin.LoginResult result = networkTestLogin.login("testuser", "testpass");
        
        if (!result.isSuccess()) {
            String message = result.getMessage();
            assertNotNull(message, "Error message should not be null");
            assertFalse(message.isEmpty(), "Error message should not be empty");
            assertTrue(message.length() > 10, "Error message should be descriptive");
        }
    }
}
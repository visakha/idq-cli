package com.example.demoidmctestdatagen.idmc;

import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.LocalDateTime;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

@Component
public class IDMCLogin {
    
    private static final Logger logger = Logger.getLogger(IDMCLogin.class.getName());
    private static final String LOGIN_URL = "https://dmp-us.informaticacloud.com/saas/public/core/v3/login";
    
    private String sessionId;
    private String baseApiUrl;
    private LocalDateTime loginTime;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    
    public IDMCLogin() {
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
    }
    
    public IDMCLogin(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        this.objectMapper = new ObjectMapper();
    }
    
    public LoginResult login(String username, String password) {
        try {
            LoginRequest loginRequest = new LoginRequest(username, password);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            HttpEntity<LoginRequest> entity = new HttpEntity<>(loginRequest, headers);
            
            logger.info("Attempting to login to IDMC with username: " + username);
            
            ResponseEntity<LoginResponse> response = restTemplate.postForEntity(
                LOGIN_URL, entity, LoginResponse.class);

            return getLoginResult(response);

        } catch (HttpClientErrorException e) {
            String errorMessage = "HTTP error during login: " + e.getStatusCode() + " - " + e.getResponseBodyAsString();
            logger.log(Level.SEVERE, errorMessage, e);
            return new LoginResult(false, errorMessage, null, null);
        } catch (RestClientException e) {
            String errorMessage = "Network error during login: " + e.getMessage();
            logger.log(Level.SEVERE, errorMessage, e);
            return new LoginResult(false, errorMessage, null, null);
        } catch (Exception e) {
            String errorMessage = "Unexpected error during login: " + e.getMessage();
            logger.log(Level.SEVERE, errorMessage, e);
            return new LoginResult(false, errorMessage, null, null);
        }
    }

    private LoginResult getLoginResult(ResponseEntity<LoginResponse> response) {
        if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
            LoginResponse loginResponse = response.getBody();

            if (loginResponse.getUserInfo() != null &&
                loginResponse.getUserInfo().getSessionId() != null) {

                this.sessionId = loginResponse.getUserInfo().getSessionId();
                this.loginTime = LocalDateTime.now();

                if (loginResponse.getProducts() != null && !loginResponse.getProducts().isEmpty()) {
                    this.baseApiUrl = loginResponse.getProducts().get(0).getBaseApiUrl();
                }

                logger.info("Login successful. Session ID: " + sessionId);
                return new LoginResult(true, "Login successful", sessionId, baseApiUrl);
            } else {
                logger.warning("Login response missing session information");
                return new LoginResult(false, "Invalid response format - missing session info", null, null);
            }
        } else {
            logger.warning("Login failed with status: " + response.getStatusCode());
            return new LoginResult(false, "Login failed with status: " + response.getStatusCode(), null, null);
        }
    }

    public boolean isSessionValid() {
        if (sessionId == null || loginTime == null) {
            return false;
        }
        
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiryTime = loginTime.plusMinutes(30);
        
        return now.isBefore(expiryTime);
    }
    
    public String getSessionId() {
        return isSessionValid() ? sessionId : null;
    }
    
    public String getBaseApiUrl() {
        return isSessionValid() ? baseApiUrl : null;
    }
    
    public LocalDateTime getLoginTime() {
        return loginTime;
    }
    
    public void clearSession() {
        this.sessionId = null;
        this.baseApiUrl = null;
        this.loginTime = null;
        logger.info("Session cleared");
    }
    
    public long getSessionRemainingMinutes() {
        if (!isSessionValid()) {
            return 0;
        }
        
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiryTime = loginTime.plusMinutes(30);
        
        return java.time.Duration.between(now, expiryTime).toMinutes();
    }
    
    public static class LoginRequest {
        private String username;
        private String password;
        
        public LoginRequest() {}
        
        public LoginRequest(String username, String password) {
            this.username = username;
            this.password = password;
        }
        
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LoginResponse {
        private List<Product> products;
        private UserInfo userInfo;
        
        public List<Product> getProducts() { return products; }
        public void setProducts(List<Product> products) { this.products = products; }
        
        public UserInfo getUserInfo() { return userInfo; }
        public void setUserInfo(UserInfo userInfo) { this.userInfo = userInfo; }
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Product {
        private String name;
        
        @JsonProperty("baseApiUrl")
        private String baseApiUrl;
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public String getBaseApiUrl() { return baseApiUrl; }
        public void setBaseApiUrl(String baseApiUrl) { this.baseApiUrl = baseApiUrl; }
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class UserInfo {
        @JsonProperty("sessionId")
        private String sessionId;
        
        private String id;
        private String name;
        private String orgId;
        private String orgName;
        private String status;
        
        public String getSessionId() { return sessionId; }
        public void setSessionId(String sessionId) { this.sessionId = sessionId; }
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public String getOrgId() { return orgId; }
        public void setOrgId(String orgId) { this.orgId = orgId; }
        
        public String getOrgName() { return orgName; }
        public void setOrgName(String orgName) { this.orgName = orgName; }
        
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }
    
    public static class LoginResult {
        private final boolean success;
        private final String message;
        private final String sessionId;
        private final String baseApiUrl;
        
        public LoginResult(boolean success, String message, String sessionId, String baseApiUrl) {
            this.success = success;
            this.message = message;
            this.sessionId = sessionId;
            this.baseApiUrl = baseApiUrl;
        }
        
        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public String getSessionId() { return sessionId; }
        public String getBaseApiUrl() { return baseApiUrl; }
        
        @Override
        public String toString() {
            return String.format("LoginResult{success=%s, message='%s', sessionId='%s', baseApiUrl='%s'}", 
                success, message, sessionId != null ? sessionId.substring(0, Math.min(sessionId.length(), 8)) + "..." : null, baseApiUrl);
        }
    }
}
package com.example.demoidmctestdatagen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoIdmcTestDataGenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoIdmcTestDataGenApplication.class, args);
	}

}

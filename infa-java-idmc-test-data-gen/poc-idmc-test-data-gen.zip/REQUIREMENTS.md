# About this project
This project is based on SpringBoot, uses java 17,
it logins into the IDMC and then makes API calls to perform Create, Update, Delete operations via API

# API Specifications and Examples
See the Sample CURL API examples at dir: C:\Users\vamsi\wrk-java\poc-idmc-test-data-gen\API-SAMPLES

# Instructions
Use latest and best practices for Java
do not encode the URL query parameters when generating the HTTP API calls




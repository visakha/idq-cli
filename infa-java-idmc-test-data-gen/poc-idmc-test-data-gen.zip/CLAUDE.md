# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Spring Boot Java application that demonstrates integration with Informatica Data Management Cloud (IDMC) APIs. The project performs CRUD operations on business entities through REST API calls after authenticating with the IDMC platform.

**Technology Stack:**
- Spring Boot 3.5.4
- Java 24
- Maven build system
- Spring Web starter for REST API interactions

## Development Commands

### Build and Run
```bash
# Build the project
mvn clean compile

# Run tests
mvn test

# Run the application
mvn spring-boot:run
# Alternative using wrapper
./mvnw spring-boot:run

# Package the application
mvn clean package

# Run the packaged jar
java -jar target/demo-idmc-test-data-gen-0.0.1-SNAPSHOT.jar
```

### Maven Wrapper
The project includes Maven wrapper scripts (`mvnw` and `mvnw.cmd`) for consistent Maven version usage across environments.

## Architecture and Code Structure

**Package Structure:**
- `com.example.demoidmctestdatagen` - Main application package
- `com.example.demoidmctestdatagen.idmc` - IDMC integration components
- `DemoIdmcTestDataGenApplication.java` - Spring Boot main class
- `IDMCLogin.java` - IDMC authentication and session management

**Key Directories:**
- `src/main/java/` - Application source code
- `src/main/resources/` - Configuration files and static resources
- `src/test/java/` - Test source code
- `API-SAMPLES/` - CURL examples and API documentation
- `target/` - Maven build output

## IDMC Integration

The application integrates with Informatica Data Management Cloud (IDMC) APIs for data operations. Key integration points:

**Authentication Flow:**
- Login endpoint: `https://dmp-us.informaticacloud.com/saas/public/core/v3/login`
- Session-based authentication using `INFA-SESSION-ID` header
- Session expires after 30 minutes of inactivity
- Must re-authenticate when session expires

**API Operations Available:**
- Login/Logout (V3 API)
- Search Business Entities (with/without criteria)
- Update operations via PUT and POST
- Find by location
- Metadata retrieval for business entities

**API Sample Files:**
- `001_Login_V3_CURL.txt` - Authentication examples
- `002_SearchBE_No_Criteria_CURL.txt` - Basic search operations
- `003_SearchBE_By_SourceName_SourceKey_CURL.txt` - Filtered searches
- `004_PUT_update_By_SourceName_Source_Key_CURL.txt` - Update operations
- `021_LogOut_V3_CURL.txt` - Session cleanup

## Development Guidelines

**Java Best Practices:**
- Use Java 24 features and latest best practices
- Follow Spring Boot conventions for configuration and structure

**API Development:**
- Do not encode URL query parameters when generating HTTP API calls
- Handle session management and expiration properly
- Use proper error handling for API failures

**Configuration:**
- Application properties in `src/main/resources/application.properties`
- Default application name: `demo-idmc-test-data-gen`

## Testing

Run the test suite with:
```bash
# Run all tests
mvn test

# Run specific IDMC tests
mvn test -Dtest=IDMCLoginTest

# Run specific test methods
mvn test -Dtest=IDMCLoginTest#shouldLoginSuccessfully
```

**Test Coverage:**
- Basic Spring Boot test configuration with context loading verification
- Comprehensive IDMC authentication tests with mocked HTTP interactions
- Session management and validation tests
- Error handling tests for various failure scenarios

**Usage Guide:**
See `IDMC_USAGE_GUIDE.md` for detailed instructions on using the IDMC login functionality and running specific tests.
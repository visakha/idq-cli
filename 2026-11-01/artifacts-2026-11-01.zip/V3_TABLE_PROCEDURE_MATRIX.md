# v3 table ↔ procedure matrix

**Scope.** All 59 tables the v3 ETL writes: the 44 tables installed by
`01_unified_tables` DDL (42 `C_S_*` landing tables + `DQM_ADDRESS` +
`EXC_STG_BAD_REC_MEMB`) and the 15 `STG_*` run-time work tables. Source
input staging tables (e.g. `STG_TRS_D_CV_*`) are not listed: the ETL
only reads them, never writes them. The 7 reference/lookup objects
(`V_LOOKUP_CODE_VALUE`, `REF_JUNK_NAME_LIST`, `REF_MATCHCODE_DESC`,
`RDM.REF_PHN_AREA_CD`, `EXC_LOOKUP_CODE_VALUE`, `LOOKUP_CODE_VALUE`,
`REF_DYLGHT_SVNGS_TM`) are likewise excluded: they are lookup inputs
owned elsewhere and read only through the `00_common` table functions,
not written by any procedure here.

**How to read the "creates" column.** In v3, **no stored procedure
executes `CREATE TABLE`** — creation happens only in
`01_unified_tables` DDL, and the `STG_*` tables are not created by this
tree at all (they pre-exist in the staging schema). So "creates" here
means the procedure that **writes the table's rows in a run** (the
populating procedure). Where a procedure updates rows in place rather
than inserting them, it is marked "updated by". Drivers are not listed
per row: a driver depends on a table only through the loader or pass
it CALLs.

**How the lists were built.** Static scan of v3 `loaders/`, `drivers/`,
and `02_common/` for `INSERT INTO <table>`, `UPDATE <table>`, and
`FROM`/`JOIN <table>`. This tree contains no dynamic SQL, so a static
scan is reliable here. Every `C_S_*` table also has one
`<table>_views.sql` file in `03_views` holding its three views
(`V_MDM_*`, `V_CMP_*`, `V_AUDIT_*`); the views are noted as "+ 3 views"
rather than listed as procedures. Downstream of this tree, the Compare
tool reads the TRS `C_S_*` tables with its own spine filter, and the
MDM batch reads the `V_MDM_*` views.

**Dimension glossary (for the Reason column).** PTY = party spine (one
row per member: grain, identity, dedup, flags). PTY_RLE = party-role
rows (a member in a role/program). ADDR = addresses. PHN = phones.
EADDR = emails. ALT_ID = alternate identifiers. REL = relationships.
REL_PROV = provider relationships. PLN = plans. TOA = type of
assistance. NM = names. MNG_ATTR = managed attributes. LU_TOA = TOA
lookup staging.

## A. Run-time work tables (17)

### A1. STG work tables (15)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `STG_TRS_VALID_MEMBERS` | `sp_sf_load_TRS_PTY` (table pre-exists in staging schema; not created by this tree) | The TRS valid-member list: deduped member spine from the converted TOA/DC sources, filtered to active, non-deleted members | `sp_sf_load_TRS_PTY`, `sp_sf_load_TRS_ADDR2`, `sp_sf_load_TRS_ALT`, `sp_sf_load_TRS_AUTHREP`, `sp_sf_load_TRS_MNGSW`, `sp_sf_load_TRS_NM`, `sp_sf_load_TRS_PHN`, `sp_sf_load_TRS_PLN`, `sp_sf_load_TRS_PTYDEACT`, `sp_sf_load_TRS_REL1`, `sp_sf_load_TRS_REL2`, `sp_sf_load_TRS_RELDEACT`, `sp_sf_load_TRS_TOA` |
| `STG_TRS_D_UNQ_ADDR` | `sp_sf_load_TRS_ADDR1` (pre-existing staging table) | Deduped unique-address set: one row per distinct address, built from the address-parts key | `sp_sf_load_TRS_ADDR1`, `sp_sf_load_TRS_ADDR2` |
| `STG_TRS_DEACTIVED_MEMBERS` | `sp_sf_load_TRS_PTYDEACT` (pre-existing staging table) | TRS deactivated-member list | `sp_sf_load_TRS_PTY`, `sp_sf_load_TRS_PTYDEACT` |
| `STG_TRS_DEACTIVATED_RELATIONSHIPS` | `sp_sf_load_TRS_RELDEACT` (pre-existing staging table) | TRS deactivated-relationship list | `sp_sf_load_TRS_RELDEACT` |
| `STG_ECI_D_MEDICAID` | `sp_sf_load_ECI_RFM` (pre-existing staging table) | Reactivated-family Medicaid staging for ECI | `sp_sf_load_ECI_RFM`, `sp_sf_load_ECI_ALT` |
| `STG_ECI_D_FAMILY_PHONE` | `sp_sf_load_ECI_RFP` (pre-existing staging table) | Reactivated-family phone staging for ECI | `sp_sf_load_ECI_RFP` |
| `STG_ECI_D_FAMILY_ADDRESS` | `sp_sf_load_ECI_RFA` (pre-existing staging table) | Reactivated-family address staging for ECI | `sp_sf_load_ECI_RFA` |
| `STG_ECI_PTY_INACTIVE_STS` | `sp_sf_load_ECI_VAL` (pre-existing staging table) | Live inactive-member list for ECI: members on it are held out of the spine by the ongoing loaders | `sp_common_pass_val_exc`, `sp_sf_load_ECI_VAL`, `sp_sf_load_ECI_PTY`, `sp_sf_load_ECI_ADR`, `sp_sf_load_ECI_PHN`, `sp_sf_load_ECI_ALT`, `sp_sf_load_ECI_REL` |
| `STG_ECI_PTY_INACTIVE_LOG` | `sp_sf_load_ECI_VAL` (pre-existing staging table) | Write-only audit log of ECI inactive members; read by nothing in this tree | — (none in-tree) |
| `STG_FSS_PTY_INACTIVE_STS` | `sp_sf_load_FSS_VAL` (pre-existing staging table) | Live inactive-member list for FSS | `sp_common_pass_val_exc`, `sp_sf_load_FSS_VAL`, `sp_sf_load_FSS_PTY`, `sp_sf_load_FSS_ADR`, `sp_sf_load_FSS_PHN`, `sp_sf_load_FSS_ALT`, `sp_sf_load_FSS_REL` |
| `STG_FSS_PTY_INACTIVE_LOG` | `sp_sf_load_FSS_VAL` (pre-existing staging table) | Write-only audit log of FSS inactive members; read by nothing in this tree | — (none in-tree) |
| `STG_TTF_PTY_INACTIVE_STS` | `sp_sf_load_TTF_VAL` (pre-existing staging table) | Live inactive-member list for TTF | `sp_common_pass_val_exc`, `sp_sf_load_TTF_VAL`, `sp_sf_load_TTF_PTY`, `sp_sf_load_TTF_PHN`, `sp_sf_load_TTF_ALT` |
| `STG_TTF_PTY_INACTIVE_LOG` | `sp_sf_load_TTF_VAL` (pre-existing staging table) | Write-only audit log of TTF inactive members; read by nothing in this tree | — (none in-tree) |
| `STG_WIC_PTY_INACTIVE_STS` | `sp_sf_load_WIC_VAL` (pre-existing staging table) | Live inactive-member list for WIC | `sp_common_pass_val_exc`, `sp_sf_load_WIC_VAL`, `sp_sf_load_WIC_PTY`, `sp_sf_load_WIC_ADR`, `sp_sf_load_WIC_PHN`, `sp_sf_load_WIC_ALT` |
| `STG_WIC_PTY_INACTIVE_LOG` | `sp_sf_load_WIC_VAL` (pre-existing staging table) | Write-only audit log of WIC inactive members; read by nothing in this tree | — (none in-tree) |

### A2. DDL-created auxiliary tables (2)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `EXC_STG_BAD_REC_MEMB` | All 28 EXC passes (`sp_common_pass_adr_exc`, `sp_common_pass_alt_exc`, `sp_common_pass_alt_medicaid`, `sp_common_pass_alt_medicaid_alt`, `sp_common_pass_alt_ssn`, `sp_common_pass_alt_ssn_alt`, `sp_common_pass_phn_email`, `sp_common_pass_phn_extension`, `sp_common_pass_phn_phone`, `sp_common_pass_pln_exc`, `sp_common_pass_pty_birth`, `sp_common_pass_pty_death`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_language`, `sp_common_pass_pty_name`, `sp_common_pass_pty_race`, `sp_common_pass_pty_suffix`, `sp_common_pass_rel_dates`, `sp_common_pass_rel_exc`, `sp_common_pass_rel_lookup`, `sp_common_pass_rel_main_alt_id`, `sp_common_pass_rel_prov_dates`, `sp_common_pass_rel_prov_default`, `sp_common_pass_rel_ref_alt_id`, `sp_common_pass_toa_bad_value`, `sp_common_pass_toa_dates`, `sp_common_pass_val_exc`); each also reconciles it with an UPDATE at pass start. Table itself created by `01_unified_tables/EXC_STG_BAD_REC_MEMB.sql` | The exception queue: one row per failed check (exception code, attribute name/value, description), including `LOOKUP_MISSING` marker rows | All 28 EXC passes read it back for their NOT EXISTS guard (so re-runs write nothing twice); plus `sp_sf_load_ECI_ALT` reads it. Operations monitoring reads it outside this tree |
| `DQM_ADDRESS` | `sp_common_pass_adr_dqm` (called by the 4 `adr_dqm` drivers: TRS ADDR2, ECI/FSS/WIC PTY_ADDR). Table itself created by `01_unified_tables/DQM_ADDRESS.sql` | AddressDoctor output: one row per landed address with doctor result values and scores; appends on every re-run (known DQM-RERUN limitation) | — (none in-tree; read by operations/analysis outside this tree) |

## B. Landing tables (42)

### B1. CRE (5)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `C_S_CRE_PTY` | `sp_sf_load_CRE_CARE` (table created by `01_unified_tables/C_S_PTY.sql`) | CRE party spine: one row per CRE client, with `is_member` = rank-1 pick | `sp_sf_load_CRE_CARE`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_name`, `sp_common_pass_pty_race`, `sp_common_pass_pty_suffix` + 3 views |
| `C_S_CRE_PTY_RLE` | `sp_sf_load_CRE_CARE` (table created by `01_unified_tables/C_S_PTY_RLE.sql`) | CRE party-role rows | `sp_sf_load_CRE_CARE` + 3 views |
| `C_S_CRE_PTY_RLE_ADDR` | `sp_sf_load_CRE_CARE` (table created by `01_unified_tables/C_S_PTY_RLE_ADDR.sql`) | CRE party-role addresses | `sp_sf_load_CRE_CARE`, `sp_common_pass_adr_exc` + 3 views |
| `C_S_CRE_PTY_RLE_ALT_ID` | `sp_sf_load_CRE_CARE` (table created by `01_unified_tables/C_S_PTY_RLE_ALT_ID.sql`) | CRE alternate identifiers | `sp_sf_load_CRE_CARE`, `sp_common_pass_alt_medicaid_alt`, `sp_common_pass_alt_ssn_alt` + 3 views |
| `C_S_CRE_PTY_RLE_PHN` | `sp_sf_load_CRE_CARE` (table created by `01_unified_tables/C_S_PTY_RLE_PHN.sql`); updated in place by `sp_common_enrich_phn_type` | CRE phones; phone type standardized by the enrich pass | `sp_sf_load_CRE_CARE`, `sp_common_pass_phn_phone` + 3 views |

### B2. ECI (7)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `C_S_ECI_PTY` | `sp_sf_load_ECI_PTY` (table created by `01_unified_tables/C_S_PTY.sql`); updated in place by `sp_common_enrich_pty_ethnicity`, `sp_common_enrich_pty_gender`, `sp_common_enrich_pty_language` | ECI party spine | `sp_sf_load_ECI_PTY`, `sp_common_pass_pty_birth`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_language`, `sp_common_pass_pty_race` + 3 views |
| `C_S_ECI_PTY_RLE` | `sp_sf_load_ECI_PTY` (table created by `01_unified_tables/C_S_PTY_RLE.sql`) | ECI party-role rows | `sp_sf_load_ECI_PTY` + 3 views |
| `C_S_ECI_PTY_RLE_ADDR` | `sp_sf_load_ECI_ADR` (table created by `01_unified_tables/C_S_PTY_RLE_ADDR.sql`) | ECI addresses | `sp_sf_load_ECI_ADR`, `sp_common_pass_adr_dqm`, `sp_common_pass_adr_exc` + 3 views |
| `C_S_ECI_PTY_RLE_ALT_ID` | `sp_sf_load_ECI_ALT` (table created by `01_unified_tables/C_S_PTY_RLE_ALT_ID.sql`) | ECI alternate identifiers | `sp_sf_load_ECI_ALT`, `sp_common_pass_alt_medicaid`, `sp_common_pass_alt_ssn` + 3 views |
| `C_S_ECI_PTY_RLE_EADDR` | `sp_sf_load_ECI_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_EADDR.sql`) | ECI emails | `sp_sf_load_ECI_PHN`, `sp_common_pass_phn_email` + 3 views |
| `C_S_ECI_PTY_RLE_PHN` | `sp_sf_load_ECI_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_PHN.sql`); updated in place by `sp_common_enrich_phn_type` | ECI phones; phone type standardized by the enrich pass | `sp_sf_load_ECI_PHN`, `sp_common_pass_phn_phone` + 3 views |
| `C_S_ECI_PTY_RLE_REL` | `sp_sf_load_ECI_REL` (table created by `01_unified_tables/C_S_PTY_RLE_REL.sql`) | ECI relationships | `sp_sf_load_ECI_REL`, `sp_common_pass_rel_exc` + 3 views |

### B3. FSS (7)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `C_S_FSS_PTY` | `sp_sf_load_FSS_PTY` (table created by `01_unified_tables/C_S_PTY.sql`); updated in place by `sp_common_enrich_pty_ethnicity` | FSS party spine | `sp_sf_load_FSS_PTY`, `sp_common_pass_pty_birth`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_language`, `sp_common_pass_pty_race`, `sp_common_pass_pty_suffix` + 3 views |
| `C_S_FSS_PTY_RLE` | `sp_sf_load_FSS_PTY` (table created by `01_unified_tables/C_S_PTY_RLE.sql`) | FSS party-role rows | `sp_sf_load_FSS_PTY` + 3 views |
| `C_S_FSS_PTY_RLE_ADDR` | `sp_sf_load_FSS_ADR` (table created by `01_unified_tables/C_S_PTY_RLE_ADDR.sql`) | FSS addresses | `sp_sf_load_FSS_ADR`, `sp_common_pass_adr_dqm`, `sp_common_pass_adr_exc` + 3 views |
| `C_S_FSS_PTY_RLE_ALT_ID` | `sp_sf_load_FSS_ALT` (table created by `01_unified_tables/C_S_PTY_RLE_ALT_ID.sql`) | FSS alternate identifiers | `sp_sf_load_FSS_ALT` + 3 views |
| `C_S_FSS_PTY_RLE_EADDR` | `sp_sf_load_FSS_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_EADDR.sql`) | FSS emails | `sp_sf_load_FSS_PHN`, `sp_common_pass_phn_email` + 3 views |
| `C_S_FSS_PTY_RLE_PHN` | `sp_sf_load_FSS_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_PHN.sql`); updated in place by `sp_common_enrich_phn_type` | FSS phones; phone type standardized by the enrich pass | `sp_sf_load_FSS_PHN`, `sp_common_pass_phn_extension`, `sp_common_pass_phn_phone` + 3 views |
| `C_S_FSS_PTY_RLE_REL` | `sp_sf_load_FSS_REL` (table created by `01_unified_tables/C_S_PTY_RLE_REL.sql`) | FSS relationships | `sp_sf_load_FSS_REL`, `sp_common_pass_rel_exc` + 3 views |

### B4. TRS (13)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `C_S_TRS_PTY` | `sp_sf_load_TRS_PTY` (table created by `01_unified_tables/C_S_PTY.sql`); updated in place by `sp_common_enrich_pty_ethnicity` | TRS party spine | `sp_sf_load_TRS_PTY`, `sp_common_pass_pty_birth`, `sp_common_pass_pty_death`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_name`, `sp_common_pass_pty_race` + 3 views |
| `C_S_TRS_PTY_RLE` | `sp_sf_load_TRS_PTY` (table created by `01_unified_tables/C_S_PTY_RLE.sql`) | TRS party-role rows | `sp_sf_load_TRS_PTY` + 3 views |
| `C_S_TRS_PTY_RLE_ADDR` | `sp_sf_load_TRS_ADDR2` (table created by `01_unified_tables/C_S_PTY_RLE_ADDR.sql`) | TRS addresses, with `DIAG_ADDR_DQM_CD` written by the loader for every landed row | `sp_sf_load_TRS_ADDR2`, `sp_common_pass_adr_dqm`, `sp_common_pass_adr_exc` + 3 views |
| `C_S_TRS_PTY_RLE_ALT_ID` | `sp_sf_load_TRS_ALT` (table created by `01_unified_tables/C_S_PTY_RLE_ALT_ID.sql`) | TRS alternate identifiers | `sp_sf_load_TRS_ALT`, `sp_common_pass_alt_exc` + 3 views |
| `C_S_TRS_PTY_RLE_EADDR` | `sp_sf_load_TRS_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_EADDR.sql`) | TRS emails | `sp_sf_load_TRS_PHN`, `sp_common_pass_phn_email` + 3 views |
| `C_S_TRS_PTY_RLE_PHN` | `sp_sf_load_TRS_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_PHN.sql`); updated in place by `sp_common_enrich_phn_type` | TRS phones; phone type standardized by the enrich pass | `sp_sf_load_TRS_PHN`, `sp_common_pass_phn_phone` + 3 views |
| `C_S_TRS_PTY_RLE_PLN` | `sp_sf_load_TRS_PLN` (table created by `01_unified_tables/C_S_PTY_RLE_PLN.sql`) | TRS plans | `sp_sf_load_TRS_PLN`, `sp_common_pass_pln_exc` + 3 views |
| `C_S_TRS_PTY_RLE_REL` | `sp_sf_load_TRS_REL1` (table created by `01_unified_tables/C_S_PTY_RLE_REL.sql`) | TRS relationships | `sp_sf_load_TRS_REL1`, `sp_common_pass_rel_dates`, `sp_common_pass_rel_lookup`, `sp_common_pass_rel_main_alt_id`, `sp_common_pass_rel_ref_alt_id` + 3 views |
| `C_S_TRS_PTY_RLE_REL_PROV` | `sp_sf_load_TRS_REL2` (table created by `01_unified_tables/C_S_PTY_RLE_REL_PROV.sql`) | TRS provider relationships | `sp_sf_load_TRS_REL2`, `sp_common_pass_rel_prov_dates`, `sp_common_pass_rel_prov_default` + 3 views |
| `C_S_TRS_PTY_RLE_TOA` | `sp_sf_load_TRS_TOA` (table created by `01_unified_tables/C_S_PTY_RLE_TOA.sql`) | TRS type-of-assistance rows (version-1 pick from the source query) | `sp_sf_load_TRS_TOA`, `sp_common_pass_toa_bad_value`, `sp_common_pass_toa_dates` + 3 views |
| `C_S_TRS_PTY_NM` | `sp_sf_load_TRS_NM` (table created by `01_unified_tables/C_S_PTY_NM.sql`) | TRS names | `sp_sf_load_TRS_NM` + 3 views |
| `C_S_TRS_PTY_MNG_ATTR` | `sp_sf_load_TRS_MNGSW` and `sp_sf_load_TRS_AUTHREP` (table created by `01_unified_tables/C_S_PTY_MNG_ATTR.sql`) | TRS managed attributes, from both the Sw and Auth_Rep flows | `sp_sf_load_TRS_MNGSW`, `sp_sf_load_TRS_AUTHREP` + 3 views |
| `C_S_LU_TOA` | `sp_sf_load_TRS_STGTOA` (table created by `01_unified_tables/C_S_LU_TOA.sql`) | TRS TOA lookup staging: lookup-table load writing literal `VERSION_SEQ = '1'` | `sp_sf_load_TRS_STGTOA` + 3 views |

### B5. TTF (4)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `C_S_TTF_PTY` | `sp_sf_load_TTF_PTY` (table created by `01_unified_tables/C_S_PTY.sql`); updated in place by `sp_common_enrich_pty_ethnicity`, `sp_common_enrich_pty_gender` | TTF party spine | `sp_sf_load_TTF_PTY`, `sp_common_pass_pty_birth`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_race` + 3 views |
| `C_S_TTF_PTY_RLE` | `sp_sf_load_TTF_PTY` (table created by `01_unified_tables/C_S_PTY_RLE.sql`) | TTF party-role rows | `sp_sf_load_TTF_PTY` + 3 views |
| `C_S_TTF_PTY_RLE_ALT_ID` | `sp_sf_load_TTF_ALT` (table created by `01_unified_tables/C_S_PTY_RLE_ALT_ID.sql`) | TTF alternate identifiers | `sp_sf_load_TTF_ALT` + 3 views |
| `C_S_TTF_PTY_RLE_PHN` | `sp_sf_load_TTF_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_PHN.sql`); updated in place by `sp_common_enrich_phn_type` | TTF phones; phone type standardized by the enrich pass | `sp_sf_load_TTF_PHN`, `sp_common_pass_phn_phone` + 3 views |

### B6. WIC (6)

| Table | Procedure that writes it | Reason | Procedures dependent on it (use it) |
|---|---|---|---|
| `C_S_WIC_PTY` | `sp_sf_load_WIC_PTY` (table created by `01_unified_tables/C_S_PTY.sql`); updated in place by `sp_common_enrich_pty_ethnicity`, `sp_common_enrich_pty_gender`, `sp_common_enrich_pty_language` | WIC party spine | `sp_sf_load_WIC_PTY`, `sp_common_pass_pty_birth`, `sp_common_pass_pty_ethnicity`, `sp_common_pass_pty_gender`, `sp_common_pass_pty_language`, `sp_common_pass_pty_race` + 3 views |
| `C_S_WIC_PTY_RLE` | `sp_sf_load_WIC_PTY` (table created by `01_unified_tables/C_S_PTY_RLE.sql`) | WIC party-role rows | `sp_sf_load_WIC_PTY` + 3 views |
| `C_S_WIC_PTY_RLE_ADDR` | `sp_sf_load_WIC_ADR` (table created by `01_unified_tables/C_S_PTY_RLE_ADDR.sql`) | WIC addresses | `sp_sf_load_WIC_ADR`, `sp_common_pass_adr_dqm`, `sp_common_pass_adr_exc` + 3 views |
| `C_S_WIC_PTY_RLE_ALT_ID` | `sp_sf_load_WIC_ALT` (table created by `01_unified_tables/C_S_PTY_RLE_ALT_ID.sql`) | WIC alternate identifiers | `sp_sf_load_WIC_ALT` + 3 views |
| `C_S_WIC_PTY_RLE_EADDR` | `sp_sf_load_WIC_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_EADDR.sql`) | WIC emails | `sp_sf_load_WIC_PHN`, `sp_common_pass_phn_email` + 3 views |
| `C_S_WIC_PTY_RLE_PHN` | `sp_sf_load_WIC_PHN` (table created by `01_unified_tables/C_S_PTY_RLE_PHN.sql`); updated in place by `sp_common_enrich_phn_type` | WIC phones; phone type standardized by the enrich pass | `sp_sf_load_WIC_PHN`, `sp_common_pass_phn_phone` + 3 views |

## Patterns worth noticing

- **One writer per landing table, almost everywhere.** The only landing
  table with two writers is `C_S_TRS_PTY_MNG_ATTR` (Sw + Auth_Rep
  flows). Everything else has exactly one loader.
- **PTY_RLE tables have no pass readers.** The role tables are read
  back only by their own party loader (later blocks joining on
  `VERSION_SEQ = 1`) and by their views. All pass activity (EXC,
  enrich, DQM) happens on the PTY, ADDR, PHN, EADDR, ALT_ID, REL, PLN,
  and TOA tables, not on the role tables.
- **The exception table is the most-read table in the tree.** All 28
  EXC passes read `EXC_STG_BAD_REC_MEMB` for their NOT EXISTS guard —
  that read is what makes re-runs write nothing twice.
- **Four work tables are write-only in-tree** (`*_PTY_INACTIVE_LOG`
  for all four sources) and `DQM_ADDRESS` has no in-tree reader at all.
  Those five are outputs for operations/analysis, not inputs to any
  later step.
- **Enrich coverage differs by source.** Every PHN table gets
  `sp_common_enrich_phn_type`. PTY enrichment varies: ECI and WIC get
  ethnicity + gender + language; TTF gets ethnicity + gender; TRS and
  FSS get ethnicity only; CRE gets none (standardized in-loader).

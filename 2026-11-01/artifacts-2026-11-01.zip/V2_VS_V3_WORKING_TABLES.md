# Working tables in Common-CS v2 vs v3: counts and purposes

**Question.** How many working temporary tables are created in v2, how many
in v3, and in v3 what are they and what purpose does each serve?

**Headline answer, before the detail.** The work-table inventory did not
change at all between v2 and v3. What changed in v3 was flags and views,
not tables. And one terminology correction up front: neither version
creates a single Snowflake `TEMPORARY` table.

| What you might mean by "working temporary table" | v2 | v3 |
|---|---|---|
| Snowflake `TEMPORARY` tables (session-scoped, auto-dropped) | **0** | **0** |
| Tables created by the ETL's own DDL (`01_unified_tables`) | **44** | **44** — identical set |
| Run-time work tables the ETL writes mid-run for later steps to read (`STG_*`) | **15** | **15** — identical writers and identical readers |
| Views (the downstream interface, not tables) | **0** (no `03_views` directory) | **126** (42 files × `V_MDM_*` / `V_CMP_*` / `V_AUDIT_*`) |

## Terminology: what "working temporary table" means in these trees

There are three layers, and they behave differently:

1. **Standing target tables (`C_S_*`, 42).** The landing tables the
   loaders write. These are not working tables and not temporary: they
   are the ETL's output, kept after the run (and since the 2026-10-31
   no-delete decision, kept with all flags and reasons, never purged).
2. **DDL-created auxiliary tables (2).** `DQM_ADDRESS` and
   `EXC_STG_BAD_REC_MEMB`. Created once by install DDL, written every
   run by the passes, kept after the run. Working tables in the sense
   that they hold pass output rather than landed business rows — but
   they are permanent tables, not temporary ones.
3. **Run-time staging work tables (`STG_*`, 15).** Tables the ETL itself
   writes during a run and later loaders/passes read back. These are the
   tables that function as "working temporary" storage in this estate:
   they exist to pass intermediate results between steps of the same
   run. But note two facts about them: they are **not created by the
   v2 or v3 DDL** (no `CREATE TABLE` for any `STG_*` table exists in
   either tree — they must already exist in the staging schema, provided
   by the source load / IDQ estate), and they are **never dropped,
   deleted, or truncated by any procedure in either tree** (zero
   `DELETE FROM STG_*`, zero table-level `TRUNCATE`; the only
   `TRUNCATE` hits in either tree are comments about string truncation
   to a port precision). As written, the ETL only appends to them.

One caution on wording: the `run_scripts` in the v3 tree still carry a
comment saying "the mapping cleans up the previous run's WRK tables at
its start (step 5)". There are **no `WRK_*` objects and no step 5** in
either the v2 or the v3 common-CS tree (zero `WRK_` identifiers anywhere
in either tree). That comment is leftover language from the step-driver
line, not something these trees do. If you were thinking of "WRK
tables" from those comments, they do not exist here.

## The 15 run-time work tables in v3 (same 15 in v2)

Writer = the loader that `INSERT`s into it. Readers = loaders/passes
that `SELECT`/`JOIN` it. Writer and reader sets were diffed v2-vs-v3:
**identical for all 15 tables**.

### TRS work tables (4)

| Table | Written by | Read by | Purpose |
|---|---|---|---|
| `STG_TRS_VALID_MEMBERS` | `sp_sf_load_TRS_PTY` | 13 loaders: PTY, ADDR2, ALT, AUTHREP, MNGSW, NM, PHN, PLN, REL1, REL2, PTYDEACT, RELDEACT, TOA | **The TRS valid-member list — the hub of the TRS run.** The PTY loader builds it from the deduped member spine (distinct member IDs from the converted TOA/DC sources, filtered to active, non-deleted). Every downstream TRS dimension joins it so only valid members land. TOA also joins it. |
| `STG_TRS_D_UNQ_ADDR` | `sp_sf_load_TRS_ADDR1` | ADDR1 (itself) and ADDR2 | **The deduped unique-address set.** ADDR1 writes one row per distinct address (built from the address parts key); ADDR2 reads it to land addresses and to write the AddressDoctor `DQM_ADDRESS` rows. |
| `STG_TRS_DEACTIVED_MEMBERS` (spelling as in the database) | `sp_sf_load_TRS_PTYDEACT` | PTY and PTYDEACT | **The TRS deactivated-member list.** The deactivation loader writes it; the PTY loader reads it to know who is deactivated, and the deactivation loader reads it back. |
| `STG_TRS_DEACTIVATED_RELATIONSHIPS` | `sp_sf_load_TRS_RELDEACT` | RELDEACT only | **The TRS deactivated-relationship list.** Written and consumed inside the relationship-deactivation loader. |

### ECI reactivation work tables (3)

| Table | Written by | Read by | Purpose |
|---|---|---|---|
| `STG_ECI_D_MEDICAID` | `sp_sf_load_ECI_RFM` (reactivation family Medicaid) | RFM (itself) and `sp_sf_load_ECI_ALT` | **Reactivated-family Medicaid staging.** Family-level Medicaid rows for reactivated families, staged so the ALT loader can pick up reactivated Medicaid IDs. |
| `STG_ECI_D_FAMILY_PHONE` | `sp_sf_load_ECI_RFP` (reactivation family phone) | RFP (itself) | **Reactivated-family phone staging.** Family phone rows for reactivated families, written by the reactivation loader and read back by the same loader in a later block to publish. |
| `STG_ECI_D_FAMILY_ADDRESS` | `sp_sf_load_ECI_RFA` (reactivation family address) | RFA (itself) | **Reactivated-family address staging.** Same pattern as phone, for family addresses. |

### Inactive-member work tables (8 = 4 sources × LOG + STS)

Each source's Validation loader (`*_VAL`) writes both tables. They split
by purpose:

| Tables | Written by | Read by | Purpose |
|---|---|---|---|
| `STG_ECI_PTY_INACTIVE_STS`, `STG_FSS_PTY_INACTIVE_STS`, `STG_TTF_PTY_INACTIVE_STS`, `STG_WIC_PTY_INACTIVE_STS` | `sp_sf_load_ECI_VAL`, `FSS_VAL`, `TTF_VAL`, `WIC_VAL` respectively | The source's ongoing loaders (PTY, ADR, PHN, ALT, REL where the source has them) **and** the common `sp_common_pass_val_exc` pass | **The live inactive-member list.** This is the list the ongoing loaders filter on: members on it are held out of the spine. The valexc pass maintains it, which is why it runs first in the four Validation drivers. |
| `STG_ECI_PTY_INACTIVE_LOG`, `STG_FSS_PTY_INACTIVE_LOG`, `STG_TTF_PTY_INACTIVE_LOG`, `STG_WIC_PTY_INACTIVE_LOG` | Same `*_VAL` loaders | **Nothing in either tree** | **Write-only audit log of inactive members.** Written every run, read by no loader or pass in v2 or v3. It is kept for record/operations, not consumed by the ETL itself. If anything outside these trees reads it (ops queries, MDM batch), that read is not visible here — worth confirming before assuming it is dead, but inside this estate it is write-only. |

## The 2 DDL-created auxiliary tables (both versions, unchanged)

| Table | Written by | Purpose |
|---|---|---|
| `EXC_STG_BAD_REC_MEMB` | All EXC passes (`sp_common_pass_*`, 29 files in v3) | **The exception queue.** One row per failed check (exception code, attribute name/value, description). The EXC-CATALOG marker rows (`LOOKUP_MISSING…`) land here too. Read by operations monitoring, not by the ETL. |
| `DQM_ADDRESS` | The 4 `adr_dqm` drivers (TRS ADDR2, ECI/FSS/WIC PTY_ADDR) | **The AddressDoctor output.** One row per landed address with the doctor result values and scores. Appends on every re-run (the known DQM-RERUN limitation you accepted as no-fix). |

## What actually changed between v2 and v3 (it was not the tables)

- **Table inventory: zero change.** Same 44 DDL tables, same 15
  `STG_*` work tables, same writers, same readers. The v3 `01_unified_tables`
  directory has one more file than v2's (17 vs 16), but the extra file is
  `01c_alter_v3_only.sql` — ALTERs for the flag columns, not a new table.
- **What v3 added instead:** flag columns on the `C_S_*` tables (spine
  and non-spine flag sets + reasons, RAW columns), DIAG writes, CRE
  runtime handling, the EXC-catalogue outer joins, and the **126 views**
  (`03_views`, absent entirely in v2) that now form the downstream
  interface: `V_MDM_*` (business rows only), `V_CMP_*` (business + flags),
  `V_AUDIT_*` (flagged rows only).
- **Lifecycle caveat (both versions).** Because no procedure deletes or
  truncates any `STG_*` work table, a re-run appends to whatever the
  previous run left — unless the source-load step that runs before the
  ETL truncates these tables first. That step is outside both trees and
  was not verified here. If the source load does not truncate them,
  re-runs will double up rows in `STG_TRS_VALID_MEMBERS`,
  `STG_TRS_D_UNQ_ADDR`, and the inactive tables, the same way the
  insert-only C_S loads behave. Worth one check against the source-load
  job before treating re-runs as clean.

## Bottom line

- Temporary tables in the Snowflake sense: **0 in v2, 0 in v3**.
- Work tables the ETL writes mid-run and later steps read: **15 in v2,
  15 in v3, the same 15**, listed above with writers, readers, and
  purposes.
- Standing tables installed by DDL: **44 in both**, identical.
- The v2→v3 story is flags + views, not tables. If you expected the
  count to move, the thing that moved is the 126 views v3 added on top
  of the unchanged tables.

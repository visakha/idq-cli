# Versioning as technical debt: what the IDQ exports actually show

**Question.** You agreed with every spine characteristic except one: **versioning**.
Your claim: versioning is wastage, technical debt carried in the ETL and never
fixed. You gave two reasons, could not recollect a third, and asked me to go
into the XML files from your perspective and report where each reason holds
true and where it does not.

**Short verdict.**

| Reason | Verdict |
|---|---|
| 1. Timeline abandoned, processes hardcoded to `VERSION_SEQ = 1` | **PARTLY HOLDS** — the forced-to-1 half is proven in six mappings plus TOA; the blanket "everything is hardcoded" half is false, because five version computations are still live |
| 2. Non-spine paths converge as duplicates, dedup cleans up, version sneaks in as a recalculation, flow picks version = 1 instead of calling it dedup | **HOLDS, with one nuance** — TOA is your hypothesis verbatim; in PTY/ALT_ID the `= 1` filter is a no-op because the version was already forced to 1 upstream |
| 3. (Yours, unrecalled) — proposed here: **entrenchment** | **MEDIUM confidence** — the always-1 column is baked into row identity and downstream contracts, so removing it costs more than carrying it |

**Files checked.** `wf_TRS_Stage_Load_1_Ongoing.xml` (full probe),
`wf_TRS_Stage_Load_TOA.xml`, and all 8 deactivation exports. All expressions
below are URL-decoded. Counts: 124 `VERSION_SEQ` hits in the ongoing file,
0 in any deactivation file. Across the whole ongoing file, the only two
version filter conditions are `VERSION_SEQ = 1` and `VERSION_SEQ_NUM = 1` —
there is no `> 1`, `>= 2`, `<> 1`, or `!= 1` comparison, and no `VERSION_SEQ`
in any join or lookup condition, anywhere.

---

## Reason 1: timeline abandoned, hardcoded to 1

### Evidence FOR — the forced-to-1 sites

Six version outputs are computed and then thrown away, replaced by a literal `1`:

| Mapping | Transformation | What the file shows |
|---|---|---|
| `m_Tgt_C_S_TRS_Pty_OnGoing` (PTY, and PTY_RLE inherits it) | `exp_Party_Consolidation` | `v_VERS_SEQ_NUM` = commented-out `IIF(v_CUR_PKEY_SRC_OBJECT <> v_LST_PKEY_SRC_OBJECT, 1, IIF(v_MD5 = v_LAST_MD5, v_VERS_SEQ_NUM, v_VERS_SEQ_NUM + 1))`, followed by literal `1`. The original semantics survive only as a comment: version incremented when the MD5 content hash changed — version as a content-change counter |
| `m_Tgt_C_S_TRS_Pty_Rle_Alt_Id` (ALT_ID) | `exp_Rank` | `v_CUR_RANK` computed live, then `VERSION_SEQ` = commented-out `--v_CUR_RANK`, followed by literal `1`. Rank computed, then discarded |
| `m_Tgt_C_S_TRS_Pty_Rle_Pln` (PLN) | `exp_Safe_C_S_TRS_PTY_RLE_PLN` | `v_VERS_SEQ_NUM` = commented-out `IIF(PKEY_SRC_OBJECT <> V_LAST_PKEY, 1, --v_VERS_SEQ_NUM + 1)`, followed by literal `1` |
| `m_Tgt_C_S_TRS_Pty_Mng_Attr_Sw` (MNG_ATTR Sw) | `exp_Version_Seq_No` | `v_VERSION_SEQ_NUM` = live `IIF(PKEY_SRC_OBJECT1 <> v_LAST_PK, 1, v_LAST_VER_SEQ + 1)`, then `VERSION_SEQ_NUM` = commented-out `--v_VERSION_SEQ_NUM`, followed by literal `1` |
| `m_Tgt_C_S_TRS_Pty_Mng_Attr_Auth_Rep_Ongoing` (MNG_ATTR Auth_Rep) | `exp_Rank` | `v_RANK` = live `IIF(INDV_ID <> v_LAST_INDV_ID, 1, v_RANK + 1)`, then `VERSION_SEQ_NUM` = commented-out `--v_RANK`, followed by literal `1` |
| `m_Tgt_C_S_TRS_Pty_Nm` (NM) | `exp_Party_Consolidation` | `v_VERSION_SEQ_RANK` = `IIF(v_CUR_PKEY_SRC_OBJECT <> v_LST_PKEY_SRC_OBJECT, 1, IIF(PERIOD_START_DATE <> v_LAST_STRT_DATE, v_LST_VERSION_SEQ_RANK + 1, v_LST_VERSION_SEQ_RANK))` — **the timeline-aware rank**: a new timeline period is a new version. Then `VERSION_SEQ_NUM` = commented-out `--v_VERSION_SEQ_RANK`, followed by literal `1`. The timeline rank is computed, then thrown away |

Plus the TOA lookup load (`m_Tgt_C_S_TRS_Stg_TOA`, `Exp_TOA_Load`):
`VERSION_SEQ` = `'1'`, a string literal — no rank, no variable, nothing
commented out.

### Evidence FOR — the timeline is not a timeline

- `PERIOD_REFERENCE_TIME` in REL_1/REL_2, ADDR, and PLN is
  `IIF(NOT ISNULL(PERIOD_END_DATE), $sys.MappingRunStartTime, NULL)` — run
  start time for end-dated rows, NULL otherwise. It is never a varying
  business snapshot time. Timeline Validation uses
  `iif(not isnull(PERIOD_END_DATE), PERIOD_END_DATE, null)`.
- `TIMELINE_ACTION` in REL is `IIF(NOT ISNULL(PERIOD_END_DATE), '2', NULL)`
  — 2 marks end-dated rows only. **In PLN it is commented out and literal
  `NULL`: TIMELINE_ACTION is always NULL in PLN even for end-dated rows.**
- No `9999-12-31`, no `SYSDATE`, no fixed-date constant appears in any
  period expression in the ongoing file.
- All 8 deactivation exports contain **zero** `VERSION_SEQ` references, and
  `PERIOD_END_DATE` appears in them only as a target-column definition,
  never as an expression. The end-dating lifecycle that replaced timeline
  handling never touches versioning at all.

### Evidence AGAINST — the live minority

Five version computations are **not** commented out, and no `= 1` filter
follows any of them:

- REL consolidation (`mplt_Member_Pty_Rle_Rel_Consolidation`):
  `VERSION_SEQ` = `v_CUR_RANK`, live.
- PHN consolidation (`mplt_Member_Pty_Rle_Phn_Consolidation`, `exp_Rank`):
  `VERSION_SEQ` = `v_CUR_RANK`, live, preceded by a DISTINCT sorter.
- EAddr consolidation (`mplt_Member_Pty_Rle_EAddr_Consolidation`,
  `exp_Version_Seq`): same pattern, live.
- REL Timeline Validation (`mplt_Pty_Rle_Rel_Timeline_Validation`,
  `exp_RANK` after sorter `SRT_PKEY_FOR_RANK`): `o_VERSION_SEQ` =
  `v_CUR_RANK`, live.
- ADDR (`m_Tgt_C_S_TRS_Addr_2`,
  `exp_Party_Role_Address_Attribute_Hold`):
  `v_VERSION_SEQ_NUM` =
  `IIF(PKEY_SRC_OBJECT_PTY_RL_OBJECT <> v_LAST_PKEY, 1, v_VERSION_SEQ_NUM + 1)`,
  live — and `SRC_ROWID` =
  `PKEY_SRC_OBJECT_PTY_RL_OBJECT || '|' || TO_CHAR(VERSION_SEQ_NUM)`, so the
  version is embedded in the row identity.

Aggregators in these flows group by `VERSION_SEQ`, so multi-version rows
would survive aggregation as separate rows rather than collapsing. The
mechanism is live. **Whether any `VERSION_SEQ > 1` row ever reaches a target
cannot be proven from XML alone — that needs a data check**, e.g. on
`C_S_TRS_PTY_RLE_PHN`, `C_S_TRS_PTY_RLE_EADDR`, `C_S_TRS_PTY_RLE_ADDR`, and
`C_S_TRS_PTY_RLE_REL`.

### Verdict on reason 1: PARTLY HOLDS

The forced-to-1 half is proven (PTY, ALT_ID, PLN, both MNG_ATTR flows, NM,
LU_TOA), and the timeline-abandoned half is proven for
`PERIOD_REFERENCE_TIME` / `TIMELINE_ACTION` semantics. But "everything is
hardcoded to 1" is false as a blanket claim: a live minority survives, and
only data — not XML — can say whether it ever emits anything above 1.

---

## Reason 2: convergence duplicates, dedup, version as recalculation, pick 1

### The verbatim specimen: TOA

`m_Tgt_C_S_TRS_Pty_Rle_TOA`, source SQL over `STG_TRS_D_CV_MCI_EDG_INDV_TOA`
joined to `STG_TRS_VALID_MEMBERS`: multiple eligibility-period rows per
source key converge in SQL via

```sql
ROW_NUMBER() OVER (
  PARTITION BY toa.INDV_ID || '|' || toa.EDG_NUM || '|' || toa.PROGRAM_CD || '|' || toa.MCI_CREATE_SEQ
  ORDER BY toa.CREATE_Dt DESC
) as VERSION_SEQ
```

and then the outer query does

```sql
where version_seq = 1 -- keep only the last records per source key
```

The "version" is a recency rank. The dedup pick is `= 1`. The author's own
comment says the pick is "keep only the last records." No `VERSION_SEQ > 1`
ever leaves the source query. This is your hypothesis word for word,
including the admission in the comment.

### Supporting specimens

- **MNG_ATTR Auth_Rep**: `exp_Rank` (rank computed, version forced to 1)
  → `srtr_Rank` → aggregator literally named
  `agg_Dedup_TRS_Pty_Mng_Attr`, grouping by
  (`VERSION_SEQ`, `PTY_PK`, `ATTR_TP`, `LAST_UPDATE_DATE`, `CREATE_DT`).
  The dedup is the aggregator grouping; version contributes nothing because
  it is 1 for every row. The flow calls itself "Dedup" while version rides
  along as a constant group key.
- **PLN**: dedups via a separate `RANK` variable with `fltr_Rank: RANK = 1`
  — a rank by another name, with version forced to 1 alongside it.
- **PHN/EAddr**: phone/email normalization mapplets → DISTINCT sorter
  `srtr_Pkey_Src_Object` (exact duplicates removed by the sorter itself) →
  live-rank consolidation → aggregators (`out_Period_End_Date =
  MAX(PERIOD_END_DATE)`, `VERSION_SEQ` a group-by passthrough). No version
  filter follows the live rank anywhere in this mapping.

### The nuance: in PTY and ALT_ID the `= 1` filter is a no-op

- **PTY** (`m_Tgt_C_S_TRS_Pty_OnGoing`): source → consolidation
  (MD5 version + `v_DUP_RANK`) → sorter `srtr_Dedup_Rec` → filter
  `fltr_Dups`: `VERSION_SEQ_NUM = 1` → valid-members staging → targets.
  Since `VERSION_SEQ_NUM` is already always 1, `fltr_Dups` passes
  everything. `v_DUP_RANK` itself is never filtered on anywhere in the
  file. The real dedup, if any, happened upstream in normalization and
  sorting; the version filter is decorative.
- **ALT_ID**: same shape — live rank discarded to literal 1, then filter
  `fltr_Rank`: `VERSION_SEQ = 1`, which passes everything.

So reason 2 holds as the *mechanism* (rank, then pick first), but in
PTY/ALT_ID the version filter is not even doing the picking anymore. One
caveat: whether the five PTY validation mapplets (Gender, Name
Standardization, BirthDate, Ethnicity, Race) feed back into the main PTY
flow was not established from the mapping links, so PTY convergence through
the mapplets is unstated here, not disproven. Likewise the REL router group
predicates were not surfaced — only the group names (`End_Dated_Records`,
`Default`) are confirmed, and REL Timeline Validation re-joins split
streams at `union_All_Records` and re-ranks them with no `= 1` filter after.

### Verdict on reason 2: HOLDS, with that nuance

The rank-then-pick-first mechanism is proven, TOA states it outright, and
the "instead of calling it dedup" framing fits MNG_ATTR Auth_Rep best
(the aggregator is literally named Dedup while version rides as a
constant). The nuance strengthens rather than weakens your point: in two
of the biggest flows the version filter does not even function — it is
ceremony around a dedup that already happened elsewhere.

---

## Reason 3 (proposed): entrenchment — the always-1 column is load-bearing for contracts, not for data

You asked me to figure out the third reason. This is my proposal, at
**medium confidence**: the mechanism is proven by the files; the survival
motive is inference.

Versioning survives not because it does work, but because removing it
touches too many contracts:

1. **Row identity.** ADDR `SRC_ROWID` embeds the version:
   `PKEY || '|' || TO_CHAR(VERSION_SEQ_NUM)`. Removing the column means
   redefining what identifies a row.
2. **Every target schema.** Every `Write_C_S_*` target in the estate
   carries `VERSION_SEQ`. It is in the grain of every table, even where it
   is always 1.
3. **Hub-state logic.** REL Timeline Validation keys "open record" on
   `VERSION_SEQ = 1` (`iif(isnull(PERIOD_END_DATE) and isnull(HUB_STATE_IND)
   and VERSION_SEQ = 1, 1, HUB_STATE_IND)` — forced active, to address a
   PRT error when all xrefs are soft-deleted before end-dating). That is
   the one genuine consumer of a version value in the exports, and it only
   tests `= 1` — it never distinguishes 2 from 3.
4. **Comparison keys.** The Compare tool compares `(PKEY, VERSION_SEQ)`
   sets, so the column is also in the comparison contract.

Removing versioning is therefore not a one-line IDQ cleanup. It is a row
identity change, a target schema change, a hub-state logic change, and a
comparison change. That is a plausible explanation for why dead code
survives: nobody wants to fund the contract change, so the column stays
and everyone routes around it with `= 1`.

**Secondary color, not the reason itself — the debt charges rent even
where it does no work.** PTY still computes `v_MD5 = MD5(TO_CHAR(...))`
for every row and carries `v_LAST_MD5`, although the only consumer (the
version IIF) is commented out. Every sorter that exists to feed a
discarded rank (`srtr_Dedup_Rec`, `srtr_Rank`, `srtr_TRS_Pty_Nm`,
`SRT_PKEY_FOR_RANK`) still pays the sort cost. And in ADDR, a second rank
(`v_UNIQUE_RANK`) is computed and then never used — the ADDR block
contains no filter at all, on either rank.

---

## The debt carried into the Snowflake rewrite

The rewrite did not remove the debt; it preserved it in three shapes:

- **TRS loaders pass `VERSION_SEQ` through** from staging into `C_S_*`
  (e.g. `sp_sf_load_TRS_PTY`), and child loaders join their parents with
  `WHERE VERSION_SEQ = 1` filters throughout. The `= 1` pattern is now in
  the new code too.
- **CRE computes version as a rank and picks 1.**
  `sp_sf_load_CRE_CARE` computes `version_seq_num` as
  `ROW_NUMBER() OVER (PARTITION BY valid_member, CARE_ID ORDER BY REC_TYPE DESC)`
  for valid members only, and `is_member = (version_seq_num = 1)`. That is
  reason 2 in the new estate: a dedup pick wearing a version's name.
- **Compare keeps the column in its keys** via `(PKEY, VERSION_SEQ)`
  sets — which, if the value is always 1, is just the PKEY set wearing an
  extra column.

---

## What would settle the open questions

1. **Data check, not XML:** do any `VERSION_SEQ > 1` rows exist in
   `C_S_TRS_PTY_RLE_PHN`, `C_S_TRS_PTY_RLE_EADDR`, `C_S_TRS_PTY_RLE_ADDR`,
   or `C_S_TRS_PTY_RLE_REL`? If none do, the live minority is dead in
   practice as well as in the forced sites, and reason 1 upgrades from
   PARTLY to HOLDS outright.
2. **PTY mapplet feedback:** trace whether the five PTY validation
   mapplets feed back into the main PTY flow. That decides whether PTY
   convergence through the mapplets is real or not.
3. **REL router predicates:** surface the `rtr_Active_Records` group
   predicates to complete the Timeline Validation picture.

## Bottom line for the spine story

Your objection stands, with one correction to its scope. Versioning is
debt — but it is not uniformly dead. The timeline-driven version (NM's
period rank, PTY's MD5-change counter) is dead: computed and discarded,
or commented out. The rank-as-dedup version (TOA, CRE, MNG_ATTR
aggregator) is alive but misnamed: it is dedup, not versioning. And a
live minority (REL, PHN, EAddr, ADDR, Timeline Validation) still computes
real per-key counters whose only proven consumer is an `= 1` test — which
is why the honest verdict on "everything is hardcoded to 1" is PARTLY,
not fully, and why the data check in item 1 above is the thing that
would close it.

One consequence for the spine terminology you asked about earlier:
grain, identity, and dedup stand as spine work. Versioning, as
implemented here, does not belong in that list without a footnote — it
is the one spine characteristic that is, in your words, wastage carried
forward. I have not changed the decks or the story guide on the back of
this; say the word and I will add that footnote where versioning is
listed as a spine characteristic.

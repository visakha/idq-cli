# Two ETL approaches — team guide

## Purpose

This document explains the two designs we have used to load source data into the
C_S_* tables for the MDM hub, why the second design exists, and the rules the
team works under now. It is the companion to the "Two ETL Approaches"
presentation: the deck is for walking through together, this document is the
reference to keep.

Both approaches load the same sources (TRS, ECI, FSS, WIC, TTF, CRE) into the
same C_S_* tables. The difference is one decision:

> **What happens to a row that fails a check?**

- **Approach 1** answers: it never lands. The table is the filter.
- **Approach 2** answers: it lands, flagged, with its reason. The flags are
  the filter, and views apply them for downstream.

---

## Approach 1 — single target, everything decided before the write

### How it flows

1. Source rows arrive in staging.
2. All processing runs up front — spine checks and non-spine checks alike:
   dedup, filters, lookups, validation.
3. Only rows that pass are written to the C_S_* table, the single target.
   Processing stops at the target.
4. Downstream consumers read the C_S_* table directly.

### What this gives you

- One pipeline, one terminal target, nothing for a consumer to interpret.
- The table's contract is trivially stated: if a row is in C_S_*, it is final,
  clean data.

### What it costs

- A row that fails a check leaves no trace in C_S_* — no row, no flag, no
  reason. After the run there is nothing in the target to inspect.
- Diagnostics can be destroyed by the load itself. Values that were distinct
  in staging can collapse to the same value on the table (for example, an
  invalid code and a legitimate "unknown" code can both end up NULL), so a
  later pass reading only the table cannot tell them apart; it has to
  re-derive the verdict from staging.
- Answering "why is this count wrong?" means a re-run or a staging
  investigation, not a query against the run you already did.

An intermediate shape of this design ran some passes after loading but purged
diagnostic rows before commit. The effect for the reader was the same: the
committed table contained only the passing rows.

---

## Approach 2 — two flows over the same tables, flag-based, nothing deleted

### Flow 1 — spine

- Spine routines run first and land rows on the C_S_* tables.
- Every row lands — pass or fail.
- Each row is stamped with the spine verdict:
  - `SPINE_FILTERED_YN` — `'Y'` means this row was filtered out at the spine
    stage; `'N'` means it passed.
  - `SPINE_FILTER_REASON` — why, when the flag is `'Y'` (NULL when `'N'`).

### Flow 2 — non-spine

- Non-spine routines then run against those same C_S_* rows:
  - **Enrichment** updates rows in place (for example, standardising a code
    through a dictionary lookup). The pre-standardisation value is kept in a
    raw carrier column, so the evidence of what arrived is never overwritten.
  - **Exception (EXC) and diagnostic (DQM) passes** record their verdicts on
    the rows and write exception detail to the exception table.
- Non-spine verdicts use the second flag pair:
  - `NONSPINE_FILTERED_YN` — `'Y'` means the row failed a non-spine check
    (today, typically a lookup miss in an enrichment pass).
  - `NONSPINE_FILTER_REASON` — the reason code(s), NULL when `'N'`.

### What did not change

- Grain-defining dedup still collapses duplicate rows into one. The flag
  applies to predicate filters on deduped rows, not to the dedup itself — a
  dropped duplicate never had a grain of its own, so it does not get a flag
  row.
- Validation that must run before the party spine exists (VAL_EXC) is still
  staging-based. It cannot read this run's C_S_* party rows because they do
  not exist yet at that point in the runner.

---

## The no-delete rule

No data is deleted from the C_S_* tables at the tail end of a run — or
anywhere else in this design.

- Earlier shapes purged diagnostic/flagged rows before commit. That purge is
  gone, and the generator now fails loudly if a `DELETE FROM C_S_*` reappears
  in generated drivers, so the rule cannot silently regress on regeneration.
- The same rule holds in the Snowflake procedures (v3), the Oracle mirror of
  those procedures, and the Java runner: the runner holds no ETL logic and its
  flush hooks do not delete; the MDM batch reads the views.

**Why:** after the ETL jobs run, the C_S_* tables still hold the complete
data — every row, with its complete flags and reasons. That is what makes the
tables usable for analysis, and it is the starting point for building
solutions to data problems instead of reconstructing what was thrown away.

---

## Downstream reads views, not tables

Filtering moved from "the row is absent" to "a view applies the flag". There
are three view families per table — 42 C_S_* tables × 3 = 126 views.

| View | Who reads it | Columns | Predicate |
|---|---|---|---|
| `V_MDM_<table>` | MDM batch / downstream business consumers | Business columns only | `SPINE_FILTERED_YN IS NULL OR SPINE_FILTERED_YN = 'N'` |
| `V_CMP_<table>` | Compare | Business columns + the 4 flag/reason columns | Same spine predicate as `V_MDM_*` |
| `V_AUDIT_<table>` | Bad-data audit | Business columns + the 4 flag/reason columns | `SPINE_FILTERED_YN = 'Y' OR NONSPINE_FILTERED_YN = 'Y'` |

Rules that follow from the predicates:

- **Flag `'Y'` = filtered out.** A row flagged `'Y'` is not shown downstream
  through `V_MDM_*` / `V_CMP_*`. Flag `'N'` (or NULL, below) flows through.
- **NULL means "not evaluated", not "failed".** Rows loaded by older or
  unpatched loaders carry NULL flags. The `IS NULL` arm of the MDM/Compare
  predicate keeps those rows publishing, exactly as before. Only an explicit
  `'Y'` excludes a row. The audit view deliberately has no NULL arm, so
  unevaluated rows do not pollute the audit.
- **Today, only the spine flag gates publishing.** The non-spine flag is
  audit-only in `V_MDM_*` / `V_CMP_*`, preserving the earlier behaviour where
  a row with a lookup failure still published (with a NULL standardised
  value). If we later decide non-spine failures should also block publishing,
  it is a one-line change to those two view families — add
  `AND (NONSPINE_FILTERED_YN IS NULL OR NONSPINE_FILTERED_YN = 'N')` — but it
  changes what MDM receives, so it must be a deliberate, announced decision,
  never a silent edit.

---

## Side by side

| Question | Approach 1 — single target | Approach 2 — two flows, flag-based |
|---|---|---|
| Where does processing happen? | All before the write | Flow 1 (spine) lands rows; Flow 2 (non-spine) works on them in place |
| What happens to a failing row? | Never lands | Lands, flagged `'Y'`, reason recorded |
| What is the filter? | The table itself | The flags, applied by views |
| What does downstream read? | The C_S_* table directly | `V_MDM_*` / `V_CMP_*` / `V_AUDIT_*` |
| What remains after the run? | Only clean, passing data | Complete data + flags + reasons, for analysis |
| Is data deleted from C_S_*? | Filtering effectively removes it | No — no DELETE from C_S_* |
| How do you debug a bad run? | Re-run or dig in staging | Query the table and the audit view |

---

## Working rules for the team

1. **Never delete from C_S_*.** Treat any DELETE against a C_S_* table as a
   defect against this design.
2. **Downstream reads views, not tables.** Reading the raw table means
   reading rows that were meant to be filtered out.
3. **Respect flag polarity.** `'Y'` on a `*_FILTERED_YN` column means
   *filtered out*. Do not reuse older flag columns whose polarity was the
   opposite; the v3 flag names exist precisely so nobody has to guess.
4. **NULL is not a failure.** NULL flag = the row was never evaluated by the
   flagging code. Only `'Y'` excludes.
5. **Keep the raw value.** Enrichment standardises into the business column
   and leaves the raw carrier untouched, so a flagged row keeps its evidence.
6. **Change the generator, not the generated files.** View and driver changes
   belong in the generator specs, so a regeneration cannot silently overwrite
   this design.

## Open items

- **Comparator:** whether Compare keeps reading tables plus its spine-flag
  filter, or moves to the `V_CMP_*` views, is recorded as a to-do. No
  comparator code changes until that decision is taken.
- **Non-spine gating:** whether the non-spine flag should also gate
  `V_MDM_*` / `V_CMP_*` publishing is a future, deliberate decision (see
  above) — the views are built so it is a one-line change when taken.

# Two ETL approaches: single target vs. two-flow, flag-based

## The decision in one page

We have used two different designs for getting data into the C_S_* target tables.

**Approach 1 — single target, filter before the write.** All checks run before a row is written. Only rows that pass land in C_S_*. The table itself is the filter, and downstream reads the tables directly.

**Approach 2 — two flows, flags instead of deletion.** This is the current design. Flow 1, the spine flow, lands every row in C_S_* and stamps a flag and a reason on it. Flow 2, the non-spine flow, then works on those same rows in place and stamps its own flags. Nothing is deleted. Downstream does not read the tables directly — it reads views that apply the flags.

The one sentence to remember is this:

> In Approach 1 the **table** is the filter. In Approach 2 the **flags** are the filter, and the **views** apply them.

Everything else in this document explains what that change means, why we made it, and what each team has to do differently because of it.

### Who should read this

- ETL builders, who write and maintain the loaders and passes
- Downstream consumers, including the MDM batch, who read the results
- Analysts and support, who investigate why a row did or did not go downstream

### Terms used in this document

- **C_S_* tables** — the target tables in the hub staging area. Examples in this estate include the party, party role, address, phone, and alternate ID tables.
- **Spine** — the core set of rows and checks that decide whether a record is fundamentally loadable. The spine runs first.
- **Non-spine** — everything that runs after the spine: enrichment, exception recording, and diagnostics for dimensions such as address, phone, email, and alternate ID.
- **Flag** — a column on the C_S_* row that records a verdict. `Y` means filtered out, `N` or no value means passed.
- **Views** — the flag-aware views over C_S_*, including the `V_MDM_*` views for the MDM batch and the `V_CMP_*` views used for comparison and audit.

## Approach 1: all processing happens before the target, then processing stops

In the first design there is one pipeline and one terminal target.

```text
Source / staging
      |
      v
All checks in one place
(spine checks + non-spine checks, before the write)
      |
      +-- Row fails a check --> row does not land
      |                         (not in C_S_*, reason is not in C_S_*)
      |
      +-- Row passes --------> row is written to C_S_*
                                  |
                                  v
                         Downstream reads C_S_* directly
                         Processing stops at the target
```

### How it works

1. Staging data is checked before anything is written to the target.
2. Spine and non-spine checks are not separated into two flows. They are all part of the decision about whether a row may land.
3. A row that fails any check never lands in C_S_*.
4. A row that lands is, by definition, good. No further verdict needs to be recorded on it.
5. Downstream consumers read the C_S_* tables directly, because the tables contain only passed data.

### What this design does well

- **Simple to explain.** If a row is in the table, it passed. If it is not in the table, it did not.
- **Safe by default for downstream.** A consumer cannot accidentally pick up a rejected row, because the rejected row is not there.
- **Less to store and scan.** The target holds only the passed subset.

### Where this design hurts

- **Rejected data is invisible in the target.** To find out why a record is missing, you have to go back to staging, logs, or a separate exception source. The C_S_* tables cannot answer the question on their own.
- **No complete picture after the run.** After the ETL finishes, the target does not contain the full input with its verdicts. Analysis that needs the failures as well as the passes cannot start from C_S_*.
- **Recovery is harder.** A row that was filtered out cannot be recovered, re-judged, or carried into a new solution from the target, because it was never written there. Recovery means going back upstream and reprocessing.
- **The reason is separated from the row.** Even where a reason is recorded somewhere, it is not sitting on the target row next to the data it describes.

Approach 1 is not a bad design. It is the right design when the only question downstream asks is "give me the good data." It becomes a problem when the team also needs to ask "show me everything, and show me why each row passed or failed" — which is the question we kept needing to answer.

## Approach 2: Flow 1 lands the spine, Flow 2 judges the rest — on the same tables

In the second design the same C_S_* tables are used, but the work is split into two flows, and no row is dropped in either flow.

```text
Source / staging
      |
      v
FLOW 1 — SPINE
Spine routines land EVERY row in C_S_*
Each row is stamped: spine flag + reason
(flag = Y means spine-filtered, flag = N / NULL means passed)
      |
      v
C_S_* tables — complete data, with flags and reasons
      |
      v
FLOW 2 — NON-SPINE
Enrichment updates rows in place
Exception passes record verdicts on the rows
Diagnostic (DQM / DIAG) passes record their verdicts
Exception detail is written to the EXC tables
Each pass stamps its own flags — still no deletion
      |
      v
C_S_* tables — complete data, fully flagged
      |
      v
Flag-aware views (V_MDM_*, V_CMP_*)
      |
      v
Downstream reads the VIEWS, not the tables
```

### Flow 1 — the spine flow

1. The spine routines run first, in driver order for each source.
2. Every row lands in C_S_*, whether it passes the spine checks or not.
3. Each row is stamped with the spine flag and the reason. A row that is filtered out by the spine is marked `Y`; a row that passes is marked `N` or left with no value.
4. At the end of Flow 1, C_S_* is a complete copy of what was presented, with a spine verdict on every row.

### Flow 2 — the non-spine flow

1. The non-spine routines then run against the rows already in C_S_*.
2. Enrichment updates rows in place — for example, filling in looked-up values.
3. Exception passes record their verdicts on the rows, and write the detailed exception rows to the exception (EXC) tables.
4. Diagnostic passes record their results on the rows, including address diagnostics.
5. Each non-spine pass stamps its own flags, scoped to its own dimension and reason. A phone problem flags the phone dimension; it does not, by itself, hide the whole party record.
6. At the end of Flow 2, the same C_S_* tables hold the complete data, now with both spine and non-spine verdicts.

### The key difference from Approach 1

A failing row is no longer removed or kept out. It is **landed, flagged, and explained**. Filtering still happens — it just happens later, at read time, through the views, instead of at write time, through deletion or non-delivery.

## No data is deleted from C_S_*, and downstream reads through views

This rule is part of Approach 2, and it applies at the tail end of the run as well as during it.

> **No data is deleted from the C_S_* tables.** There is no purge step at the end of a run. The full data, with all flags and all reasons, stays in C_S_* after the ETL jobs finish.

### How downstream gets its data

Downstream does not read C_S_* directly. It reads the views built over C_S_*, and the views take the flags into account:

- If the flag says a row is filtered out (`Y`), the view does not show that row downstream.
- If the flag says a row passed (`N`), or there is no flag value, the view shows the row.

In practice that is the spine filter already used by the views:

```sql
-- Illustrative form of the view filter
WHERE SPINE_FILTERED_YN IS NULL
   OR SPINE_FILTERED_YN = 'N'
```

The MDM batch reads through the `V_MDM_*` views. Comparison and audit use the `V_CMP_*` views. Each view applies the flags that are relevant to its purpose.

### Why we keep everything

Keeping the complete, flagged data in C_S_* after the run gives the team three things Approach 1 could not:

- **Analysis from the target itself.** You can count, group, and investigate passes and failures, by flag and by reason, directly in C_S_* — no need to reconstruct the run from staging and logs.
- **A starting point for solutions.** A pattern in the flagged rows — a bad lookup, a systematic source problem, a recoverable formatting issue — can be worked on from the data that is already landed, with its reasons attached.
- **An audit trail for every decision.** For any row, the table itself shows what was decided, by which flow, and why.

### The responsibility that comes with it

This design is only safe if downstream honours the views. A consumer that reads C_S_* directly will see filtered-out rows as if they were good data. That is the single most important rule in this document:

> **If you are downstream, read the views. Do not read the C_S_* tables directly.**

The C_S_* tables are the complete record. The views are the downstream contract.

## The two approaches, side by side

| Question | Approach 1: single target | Approach 2: two-flow, flag-based |
|---|---|---|
| When are checks applied? | Before the write, all together | Flow 1 spine, then Flow 2 non-spine |
| Where do checks run? | Upstream of the target | On rows already in C_S_* |
| Does a failing row land? | No | Yes, flagged with its reason |
| Is any data deleted? | Failing rows never arrive | No — no purge, no tail-end delete |
| What is the filter? | The table itself | The flags, applied by the views |
| What does downstream read? | C_S_* tables directly | Flag-aware views only |
| Can you see why a row failed? | Not from C_S_* | Yes — flag and reason on the row |
| Is the full run in the target? | No, passes only | Yes, passes and failures |
| Can analysis start from C_S_*? | Only for passed data | Yes, for the complete run |
| Main risk | Failures are invisible | A reader bypassing the views |

## The same row, in both approaches

Take one illustrative row: a party record whose phone type cannot be resolved against the lookup.

**In Approach 1**, the check runs before the write. The row fails, so it does not land. Downstream never sees it — which is correct — but neither does anyone else. A week later, when someone asks why that member has no phone record, C_S_* has nothing to show. The investigation starts again from staging.

**In Approach 2**, Flow 1 lands the party row and stamps its spine verdict. In Flow 2, the phone pass records the lookup failure on the row, with its reason, and writes the exception detail to the EXC table. The verdict is on the row for the downstream views to apply, so downstream is still protected. But the row, the flag, and the reason are all still in C_S_*. The same question a week later is answered with one query against the target, and if the lookup is later fixed, the flagged rows are exactly the list of what needs to be recovered.

The downstream result is the same in both designs. What changes is whether we can still see, explain, and act on the rows that did not go downstream.

## What each team does differently under Approach 2

### ETL builders

- Write loaders and passes that land and update rows in C_S_*; do not add a delete or purge of C_S_* data at any point in the run, including the tail end.
- Stamp the flag and the reason for every verdict your pass makes. A flag without a reason is only half a verdict.
- Keep non-spine flags scoped to their dimension and reason. Do not use a dimension-level problem to hide a whole record unless the design for that dimension says so.
- If you generate code, the generator must not reintroduce a C_S_* delete. In the current v3 line, regeneration is guarded so that a `DELETE FROM C_S_` fails the build loudly instead of silently restoring the old behaviour.

### Downstream consumers, including the MDM batch

- Read the views — `V_MDM_*` for the MDM batch, `V_CMP_*` where comparison or audit views apply — never the C_S_* tables directly.
- Treat the views as the contract. If a row you expected is not in the view, the answer is in the flags on the underlying C_S_* row, not in a missing load.
- If you are building a new consumer, start from the views. Raise it with the ETL team before reading a table directly for any reason.

### Analysts and support

- Start investigations in C_S_*. The complete run is there, with flags and reasons.
- Group by flag and reason to separate genuine source problems from lookup or catalogue gaps. A cluster of rows sharing one reason usually points to one fix.
- Use the EXC tables for exception detail that does not fit on the row itself.

## Rules to work by

1. No deletion from C_S_* — not during the run, not at the tail end, not as a cleanup step.
2. Every verdict gets a flag and a reason, recorded on the row.
3. Downstream reads views only. The views apply the flags: `Y` hides the row, `N` or no value lets it through.
4. Spine first, non-spine second. Flow 2 works on what Flow 1 landed; it does not re-land it.
5. Flags are scoped. A non-spine flag applies to its dimension and reason, not automatically to the whole record.

## Open item

One decision is deliberately left open, and is recorded as a to-do rather than settled here:

- **Comparator.** Whether the compare tooling should keep reading the tables with its own flag filter, or move to reading the downstream views like other consumers. No change has been made to the comparator for this design, and none should be assumed until that decision is taken.

## Summary

Approach 1 made the target table the filter: clean, simple, and blind to its own failures. Approach 2 keeps the same tables but splits the work into a spine flow that lands everything and a non-spine flow that judges it in place, records every verdict as flags and reasons, deletes nothing, and lets flag-aware views decide what downstream sees. Downstream gets the same clean data in both designs. Approach 2 is the design we run now because, in addition, the team keeps the complete evidence of the run — and can analyse it and build on it after the jobs finish.

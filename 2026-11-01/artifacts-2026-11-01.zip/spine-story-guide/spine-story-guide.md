# Spine and non-spine: the story behind the words

## Why it is called a spine

Yes — "spine" was chosen because it is load-bearing.

Not as an acronym. Not as a technical term borrowed from a tool. As a picture: the backbone.

Think about a body for a moment. A body has many parts, and many of them matter a great deal. Muscles move it. Skin protects it. Senses tell it what is happening in the world. But the spine does something different from all of them. The spine holds the body up. Everything else is attached to it, aligned by it, and supported by it.

Remove the cleansing, the senses, the fine detail, and a body is diminished — but there is still a body there. Damage the spine, and nothing else works as it should, however good the rest is. The structure itself fails.

That is exactly the picture behind the word in our ETL.

Some work in the ETL holds everything else up. Some work is attached to that work, improves it, and depends on it — but does not hold it up. The first kind is the spine. The second kind is non-spine.

Once you hear the metaphor that way, the boundary in v3 stops sounding like jargon. It is simply this: first, build a spine that can bear the load. Then do everything else off that spine.

## What load-bearing means in an ETL

In a body, load-bearing means the weight passes through the spine. In an ETL, the load is trust. Everything downstream — every view, every batch to MDM, every comparison, every audit — trusts that the records it is looking at are the right records, in the right shape, under the right keys.

That trust rests on five things, and all five are spine work.

- **What exists.** Which records are in the C_S_* tables at all. If a record should exist and does not, no cleansing will invent it. If a record should not exist and does, no enrichment will quietly remove the problem.

- **Grain.** One row means one thing, at one level. One row for this party, this address, this phone — not two meanings mixed into one row, and not one meaning split carelessly across rows that look alike.

- **Identity and keys.** This row is this member, this party, this role. The keys are how the rest of the system points at a record and says "that one." If identity is wrong, every later statement about that record is about the wrong thing.

- **Deduplication.** At that grain, under that identity, duplicates are collapsed so the grain holds. If dedup fails, downstream does not see one record done well or badly — it sees the same record twice, and counts, versions, and matches all bend around that error.

- **Versioning.** Which version of the record this is, and in what order versions arrived. Without versioning, "latest" is a guess, and history cannot be told honestly.

That is the load. Grain, identity, dedup, and versioning are not four items on a checklist next to the real work. They are the structure the real work stands on.

If the spine is wrong, everything built on it is wrong — no matter how good the cleansing or enrichment is. A perfectly standardised address attached to the wrong identity is still wrong. A beautifully translated lookup on a duplicated row still produces a duplicate downstream. Good non-spine work cannot rescue bad spine work, in the same way that strong muscles cannot compensate for a broken backbone.

## What hangs off the spine

Non-spine work is everything that hangs off that structure.

It is not lesser work. In a body, movement, protection, and sensation are not "extra" — a life without them is a poor one. In an ETL, cleansing, standardisation, enrichment, and exception detection are how a landed record becomes a usable, believable record. The point is not that this work matters less. The point is that it comes second in dependency: it assumes a record already exists to work on.

Listen to how each example begins — always with a record that is already there:

- **Address cleansing** begins, "Here is an address on a landed row — is it clean, is it standard, can it be verified?"

- **Name standardisation** begins, "Here is a name that arrived — what is its standard form?"

- **Phone, raw versus standardised** begins, "Here is a phone value — keep what arrived as the raw value, and add the standardised value beside it," instead of overwriting the evidence of what the source actually sent.

- **Gender translated to Unknown** begins, "Here is a gender code that is not a recognised male or female value — translate it to the default value, Unknown," so downstream gets a defined value instead of an unexplained code.

- **Exception detection** begins, "Here is a person on a landed row — is what the row says believable?" A date of birth in the future is bad data. A date of death in the future is bad data. That should be flagged as an exception and explained, not processed into MDM as if it were normal.

- **Audits, diagnostics, and lookups** begin the same way: here is a record — enrich it, explain it, record why it looks wrong, so the problem can be counted, investigated, and fixed.

If a non-spine step did not run, the record still exists. It is less clean, less standard, or less well explained — but it is there, with its grain, its key, and its version intact. That is the tell. Non-spine failure diminishes a record. Spine failure removes, duplicates, misidentifies, or misorders it.

That is also why the everyday reading lines up with this one. Calling the spine "the core of the core ETL" and non-spine "the nicer things to have" says the same thing in plain language that "load-bearing" says in the metaphor: the core is what must exist for anything else to be possible, and the rest — however valuable — builds on top of it.

## The test that tells them apart

When a new piece of work arrives and the team is unsure where it belongs, there is one question that settles most cases:

> If this step did not run, would there be a correct record at all?

- If the answer is **no** — no record, the wrong grain, the wrong key, a duplicate that should have been collapsed, a version out of order — it is spine.

- If the answer is **yes, there would still be a record, just a less clean, less standard, or less well-explained one** — it is non-spine.

Two follow-up questions make the test practical:

1. Does it decide whether the record exists, or what grain or key it has? Then it belongs in Flow 1, the spine flow.

2. Does it start from a record already on the C_S_* tables and clean it, enrich it, check it, or explain it? Then it belongs in Flow 2, the non-spine flow.

| Characteristic | Spine | Non-spine |
|---|---|---|
| Picture | The backbone | What is attached to the backbone |
| Load-bearing? | Yes — everything else rests on it | No — it rests on the spine |
| Question it answers | Does this record exist, at what grain, under what key? | Is this record clean, standard, complete, and believable? |
| If it is skipped | There is no correct record | The record exists, but is not cleansed, enriched, or explained |
| Typical work | Landing, grain, identity and keys, dedup, versioning | Address cleansing, name standardisation, lookups, defaults, exception detection, diagnostics, audits |
| Timing | First — when rows land on C_S_* | After landing — working off C_S_* |

## Why the story explains the design

The metaphor is not decoration. Each design choice in v3 follows from it.

**The order follows.** You do not attach things to a backbone that is not yet in place. So Flow 1, the spine, lands records on the C_S_* tables first. Flow 2, the non-spine work, then kicks in off those landed tables.

**The separation follows.** If core and nice-to-have are tangled in one flow, a problem in a nice-to-have step sits in the same path as the load itself, and changing an enrichment means touching the thing that holds everything up. Drawing the boundary keeps the spine small, focused, and judgeable on one question: did the right records land, at the right grain?

**Keeping everything follows.** A spine is evidence as well as structure. In v3 nothing is deleted from the C_S_* tables. Rows that fail a check stay, flagged with their reasons, and flag-aware views decide what downstream sees — a flagged row is hidden downstream, an unflagged row flows through. After a run, the team still has the complete data, the complete flags, and the complete reasons to analyse and to build solutions from, instead of reconstructing what was filtered away.

**The shared Flow 2 follows.** Because Flow 2 works off the C_S_* tables — and because we closed the roughly 5–10% variation between sources by adding the missing columns, so the C_S_* tables now look exactly the same across TRS, ECI, WIC, and the other sources — the non-spine logic can be exactly the same across all sources. One true implementation, behind very thin per-source wrappers; or, where the code is duplicated, duplicated-but-identical code. Fix the logic once, and it is fixed everywhere. None of that would hold if Flow 2 worked off each source's own staging, because staging is where sources genuinely differ.

## The story in one paragraph

We call it the spine because it bears the load: what exists, at what grain, under what identity, deduplicated, and versioned. Everything else — address cleansing, name standardisation, raw versus standardised phone, gender translated to Unknown, exception detection for a future date of birth or date of death, enrichment, diagnostics, and audits — hangs off that spine and assumes the record is already there. Build the spine first and keep it clean. Do the rest off the landed tables, keep every row and flag its story honestly, and let the views decide what goes downstream.

**Land the core. Refine off the tables. Keep Flow 2 the same everywhere.**

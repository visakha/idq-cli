# Spine and non-spine: the v3 boundary

## The idea in one page

In v3 we drew a boundary that the earlier design did not have.

- **Flow 1 — spine.** The core of the core ETL. It lands records on the C_S_* tables. If Flow 1 has not run, there is no record to talk about.
- **Flow 2 — non-spine.** Everything that works *off* the C_S_* tables once those records exist: cleansing, standardisation, enrichment, exception detection, diagnostics, and audits.

That boundary is the whole point of this guide. It explains what "spine" and "non-spine" mean, how the two approaches differ, and why making the C_S_* tables identical across sources turns Flow 2 into one logic instead of a copy per source.

Nothing is deleted from the C_S_* tables in this design. Rows that fail a check stay in the table, flagged with their reason, and flag-aware views decide what downstream sees.

## Spine and non-spine — the terminology first

The words come before the approaches, because the approaches only make sense once the words do.

### Spine: load-bearing

"Spine" was chosen in the sense of a backbone. The spine is the load-bearing part of the load:

- It decides **what exists** — which records are in the C_S_* tables at all.
- It fixes the **grain** — one row means one thing, at one level, and not two things mixed together.
- It carries **identity** — the keys that say this row is this member, this party, this address.
- It does **deduplication** at that grain — duplicates are collapsed so the grain holds.
- It does **versioning** — which version of the record this is, and in what order versions arrived.

If the spine is wrong, everything built on it is wrong, no matter how good the cleansing or enrichment is. That is why the spine is also, in plain terms, **the core of the core ETL**.

A useful test: *if this step did not run, would there be a correct record downstream at all?* If the answer is no, it is spine.

### Non-spine: work that assumes the record exists

"Non-spine" does not mean unimportant. It means the work **assumes the record already exists** and improves, checks, or explains that record:

- **Address cleansing** — checking and cleaning an address that is already on the row.
- **Name standardisation** — putting a landed name into a standard form.
- **Enrichment and lookup translation** — for example, keeping the raw phone value and adding the standardised phone value, rather than overwriting what arrived.
- **Defaulting from lookups** — for example, a gender code that is not a recognised male or female value is translated to the default value **Unknown**.
- **Exception detection** — for example, a date of birth in the future, or a date of death in the future. That is bad data, and it should be flagged as an exception rather than processed into MDM as if it were normal.
- **Diagnostics and audits** — recording why a row looks wrong, so the problem can be counted, investigated, and fixed.

If a non-spine step did not run, the record still exists. It is less clean, less standard, or less well explained — but it is there. That is why these are fairly called the **nice-to-have** parts of the ETL: valuable, often essential for quality, but not what creates the record.

The two readings line up. "Spine versus non-spine" in the load-bearing sense, and "core versus non-core" in the everyday sense, are describing the same boundary.

### Characteristics side by side

| Characteristic | Spine | Non-spine |
|---|---|---|
| Question it answers | Does this record exist, at what grain, under what key? | Is this record clean, standard, complete, and believable? |
| Load-bearing? | Yes — everything else rests on it | No — it rests on the spine |
| Timing | First, when rows land on C_S_* | After landing, working off C_S_* |
| If it fails or is skipped | There is no correct record | The record exists, but is not cleansed, enriched, or explained |
| Typical work | Landing, grain, identity and keys, dedup, versioning | Address cleansing, name standardisation, lookups, defaults, exception detection, diagnostics, audits |
| Examples | Landing a party row with its key and version | Raw phone vs standardised phone; gender translated to Unknown; future date of birth flagged |
| Where it reads and writes | Source and staging into C_S_* | C_S_* itself, updating and flagging rows in place |

When the team is unsure where a new piece of work belongs, ask two questions in order:

1. Does it decide whether the record exists, or what grain or key it has? Then it is spine, and it belongs in Flow 1.
2. Does it start from a record that is already on C_S_* and clean it, enrich it, check it, or explain it? Then it is non-spine, and it belongs in Flow 2.

## Approach 1 — no boundary

In the first approach there is no boundary between spine and non-spine.

- Spine work and non-spine work run together in one pipeline, with everything decided as part of getting to the single target: the C_S_* tables.
- Cleansing, lookups, enrichment, validation, and landing are mixed together. A problem in a nice-to-have step sits in the same path as the core load itself.
- Because each source's pipeline is built end to end, the same kind of non-spine logic tends to be written again inside each source's flow, in whatever shape that flow happens to take.
- Once a row reaches the target, processing stops. There is no second flow whose job is to work over the landed records.

This approach is simple to describe, and it can work. Its cost is structural: the core and the nice-to-have are tangled, so changing an enrichment or adding a check means touching the load itself, and nothing in the design encourages the non-spine logic to be the same from one source to the next.

## Approach 2 — the v3 boundary: Flow 1, then Flow 2

In v3 the boundary is explicit.

### Flow 1 — the spine lands the record

- Flow 1 focuses only on the core: landing rows on the C_S_* tables with the right grain, identity, deduplication, and versioning.
- Every row lands, pass or fail, stamped with its spine flag and, where it was filtered, its reason.
- Flow 1 does not try to finish the record. It establishes that the record exists.

### Flow 2 — non-spine works off C_S_*

- Flow 2 then kicks in against the landed C_S_* rows — address cleansing, name standardisation, enrichment, lookup translation, exception detection, diagnostics, and audits.
- It updates rows in place and records its own verdicts with non-spine flags and reasons. Exception detail is recorded rather than used as a reason to discard the row.
- Downstream does not read the raw tables. It reads flag-aware views over C_S_*: a row flagged to be filtered out is hidden downstream, and a row that is not flagged flows through.

The separation is what makes each flow easier to reason about. Flow 1 can be judged on one question — did the right records land, at the right grain? Flow 2 can be judged on a different question — are the landed records clean, standard, and honestly flagged?

## The second benefit — identical C_S_* tables make Flow 2 one logic

The boundary alone would be worth having. The second benefit is bigger in day-to-day work.

Across sources — TRS, ECI, WIC, and the others — the C_S_* tables were already more or less the same: same tables, same columns, same definitions. That was not exactly true. There was roughly a **5–10% variation** from source to source — a column present for one source and missing for another, or present under a slightly different shape.

We closed that gap deliberately, by adding the missing columns so that the C_S_* tables now look **exactly the same across all sources**.

That buys one thing, and it is a large one:

> Because Flow 2 starts from C_S_*, and C_S_* is now identical for every source, the Flow 2 logic can be exactly the same for every source.

In practice that means:

- **One true implementation.** Address cleansing, name standardisation, exception detection, enrichment, and diagnostics follow the same code logic, whatever the source was.
- **Very thin wrappers.** Where a per-source entry point is still needed, it should be a thin wrapper that calls the true shared logic behind it, not a fresh copy of that logic with local variations.
- **Duplicated-but-identical is still acceptable.** Where the code is physically duplicated per source, it is exactly the same code — so a reader, a reviewer, and a tester see one behaviour, not several near-behaviours.
- **Fix once, benefit everywhere.** A correction to a non-spine rule is made in one logic and applies consistently, instead of being hunted down in several source-specific versions that may already have drifted.

None of this would follow if Flow 2 worked off each source's own staging shape, because staging is where sources genuinely differ. It follows precisely because Flow 2 works off C_S_*, and C_S_* is the one place we made uniform.

## What this buys the team

- **A core that stays core.** Flow 1 stays small and focused on landing correct records. New checks and enrichments do not keep bloating the load path.
- **Non-spine work can grow safely.** A future exception check — a new date rule, a new lookup, a new diagnostic — is added in Flow 2, off C_S_*, without redesigning the spine.
- **Cleaner code.** One Flow 2 logic across sources is easier to read, review, test, and maintain than a version per source.
- **Evidence stays available.** Because nothing is deleted from C_S_* and failures are flagged with reasons, the team can analyse a completed run as it actually happened and build solutions from the flagged data, instead of reconstructing what was filtered away.
- **A shared language.** "Spine" now means load-bearing — grain, identity, dedup, versioning, what exists. "Non-spine" means everything that assumes the record exists and cleans, enriches, checks, or explains it. Using the words that way, consistently, is what keeps the boundary real.

## Working rules

1. **Keep the boundary.** If work decides existence, grain, identity, dedup, or versioning, it belongs in Flow 1. If it cleans, enriches, checks, or explains a landed record, it belongs in Flow 2.
2. **Flow 2 reads C_S_*, not source staging,** wherever the check can be made from the landed row. That is what keeps its logic source-independent.
3. **Keep C_S_* identical across sources.** If a Flow 2 need requires a new column, add it consistently so the tables stay uniform — do not let a 5–10% variation creep back in source by source.
4. **Never delete from C_S_*.** Flag the row and record the reason. Views, not deletion, decide what downstream sees.
5. **Keep wrappers thin.** A per-source wrapper calls the shared Flow 2 logic; it does not become a new local version of it.
6. **Make changes in the generator specs,** not only in generated code, so a regeneration cannot silently overwrite the boundary or bring back a delete.

## In short

Approach 1 had no boundary: spine and non-spine ran together, source by source, on the way to a single target.

Approach 2, in v3, separates them. Flow 1 is the load-bearing core — it lands records on the C_S_* tables. Flow 2 is everything that works off those tables. And because the C_S_* tables are now identical across sources, Flow 2 is one exact logic across sources, behind thin wrappers.

Keep everything. Flag honestly. Let the views decide.

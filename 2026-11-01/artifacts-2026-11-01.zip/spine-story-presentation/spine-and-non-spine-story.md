# Why “spine”? The story behind spine and non-spine

*The narrated explanation, written down. This is the story of a word — why it was chosen, what it means, and why the v3 boundary follows from it.*

## The short answer

Yes — “spine” was chosen because it is **load-bearing**.

Think of a backbone. It is not the biggest part of the body, and it is not the most visible. But everything else hangs off it, stands on it, or connects through it. Remove it, or get it wrong, and nothing built on top of it can stand — no matter how good the rest is.

That is exactly the role of the spine work in our ETL. So the word was not picked as decoration. It was picked because it describes the job.

## The backbone picture

A spine does three things for a body, and spine work does the same three things for a load:

1. **It holds the shape.** A backbone fixes the body's structure — what connects to what, and in what order. In the ETL, the spine fixes the record's structure: its **grain** — one row means one thing, at one level — and its place in the C_S_* tables.
2. **It carries the load.** The weight of everything above passes through it. In the ETL, every cleansing rule, enrichment, exception check, view, and downstream consumer rests on the landed record. If that record is wrong, all of that work is built on a wrong foundation.
3. **Everything connects through it.** Limbs and organs attach to the spine; they do not attach to each other at random. In the ETL, non-spine work attaches to the landed C_S_* record — it does not invent its own version of the record to work on.

That is the metaphor. Now what “load-bearing” means in practice.

## Load-bearing, in practice

To say the spine is load-bearing is to say: **everything downstream stands or falls on four decisions the spine makes.**

### 1. What exists

The spine decides which records exist at all. After the spine runs, the team can say: these records landed, for this run — and these were filtered, with a flag and a reason. Before the spine runs, there is no record to cleanse, enrich, check, or send anywhere. Existence comes first, and the spine owns it.

### 2. Grain

One row must mean one thing, at one level — one member, one address, one phone. If the grain is wrong — two things mixed into one row, or one thing split across rows that should be one — then every count, join, and comparison downstream inherits the error. No amount of cleansing fixes a wrong grain, because cleansing works on rows; it does not re-decide what a row is.

### 3. Identity and keys

The spine decides that this row *is* this member, this party, this address — through keys and cross-references that say which source rows belong to the same person. Get identity wrong and the ETL does not merely have dirty data; it has the *wrong person's* data, or one person counted as two. Everything downstream — every standardised name, every cleansed address — is then attached to the wrong record, neatly and consistently wrong.

### 4. Deduplication and versioning

The spine decides that two arriving rows are the *same* record, not two records — and, of the versions that arrive, which one is current and in what order they came. Dedup and versioning are load-bearing because they decide how many records there are and which version of each record the world sees. An enrichment cannot repair a duplicate that should have been collapsed, and a lookup cannot repair a stale version presented as current.

Put together: **grain, identity, dedup, and versioning are not four items on a checklist. They are the load path.** Break any one of them and the failure does not stay local — it propagates into every table, view, and file built on top.

## If the spine is wrong, nothing downstream can save it

This is the sentence the metaphor is really carrying.

- A perfectly cleansed address on the **wrong person's** record is still wrong.
- A perfectly standardised name on a **duplicate** record is still a duplicate.
- A perfectly enriched row at the **wrong grain** still counts wrong, joins wrong, and compares wrong.
- A perfectly checked record that is the **old version** is still the old version.

Cleansing makes a record *cleaner*. Enrichment makes it *richer*. Neither makes it *exist correctly*. That work belongs to the spine alone, which is why the spine must be small, strict, protected — and run first.

The reverse is not true, and that asymmetry is the whole point. If a non-spine step is skipped or fails, the record still exists: less clean, less standard, less well explained — but *there*, flagged, ready to be worked on again. A missing spine step leaves nothing. A missing non-spine step leaves work to do. That difference in consequence is what “load-bearing” means.

## Non-spine: everything that assumes the record exists

“Non-spine” was never meant as “unimportant.” It means the work **starts from a record that already exists** and improves, checks, or explains it:

- **Address cleansing** — validating and correcting an address that is already on the landed row.
- **Name standardisation** — putting a landed name into a consistent, comparable form.
- **Raw vs standardised values** — for example, keeping the phone value as received alongside the standardised phone value, instead of overwriting what arrived.
- **Defaults from lookups** — for example, a gender code that is not a recognised value is translated to the default value **Unknown**.
- **Exception detection** — for example, a **date of birth in the future** or a **date of death in the future**. That is bad data; it should be flagged, not processed into MDM as if it were normal.
- **Enrichment and audits** — adding lookup values and derived attributes, and recording what was checked, what changed, and why.

Every one of these is valuable. Several are essential for quality. But none of them decides whether the record exists, what grain it sits at, whose record it is, or which version is current. They rest on the spine; the spine does not rest on them.

In the team's own shorthand, the two readings say the same thing:

- **Spine = load-bearing = the core of the core ETL.**
- **Non-spine = everything that assumes the record exists = the non-core, nice-to-have work around that core.**

“Nice-to-have” does not mean optional forever. It means: not part of the core that decides what exists.

## The test the team can use

When a new piece of work arrives and nobody is sure where it belongs, ask one question:

> **If this step did not run, would there be a correct record at all?**

- If the answer is **no** — the step decides existence, grain, identity, dedup, or versioning — it is **spine**. It belongs in Flow 1, landing on C_S_*.
- If the answer is **yes, the record would still be there** — just less clean, less standard, or less well explained — it is **non-spine**. It belongs in Flow 2, working off C_S_*.

Two follow-up questions settle most arguments:

1. Does it decide whether the record exists, or what grain or key it has? → **Spine.**
2. Does it start from a record already on C_S_* and clean it, enrich it, check it, or explain it? → **Non-spine.**

## Why the boundary follows from the word

Once the word is understood, the v3 design is almost forced by it:

- **Flow 1 is the spine.** It does the load-bearing work only — landing records on the C_S_* tables with the right grain, identity, dedup, and versioning, each row stamped with its flag and reason. Small, strict, reviewable — because everything else will stand on it.
- **Flow 2 is the non-spine.** It works *off* the landed tables — cleansing, standardising, enriching, detecting exceptions, auditing — updating rows in place and recording its verdicts with flags.
- **Nothing is deleted from C_S_*.** A flagged row stays in the table for analysis; flag-aware views decide what downstream sees. The flags are the filter; the views apply them.
- **And because C_S_* was made identical across sources** — the roughly 5–10% variation closed by adding the missing columns — Flow 2 is one exact logic across TRS, ECI, WIC, and the other sources, behind very thin wrappers. The non-spine work can be shared precisely because it all rests on the same spine shape.

Protect the spine, and the rest of the system has something solid to stand on. Let non-spine work leak into the spine, and the load path gets heavier, tangled, and harder to trust — which is how the earlier, boundary-less design felt, and why v3 drew the line where it did.

## In one line

> The spine is called the spine because it carries the load: grain, identity, dedup, and versioning decide what exists — and everything else in the ETL stands on that, or falls with it.

**Land the core. Refine off the tables. Keep Flow 2 the same everywhere.**

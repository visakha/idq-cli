# Spine and non-spine: the v3 boundary — companion guide

This guide goes with the *Spine and Non-Spine Boundary* presentation. It uses the same order: terminology first, then the two approaches, then the payoff.

## 1. The terminology

### Spine — the load-bearing core

Spine is the work that decides **what exists**. In the presenter's original sense, it is load-bearing, like a backbone: remove it and there is no record to stand on.

- **Grain** — one row means one thing, at one level (for example, one member, one address, one phone).
- **Identity** — keys and cross-references decide which source rows belong to the same person.
- **Deduplication** — deciding that two rows are the same record, not two records.
- **Versioning** — sequence and history decide which version is current.
- **What exists** — after the spine runs, the team can say: these records landed, for this run, and these were filtered — with a flag and a reason.

The team's shorthand — **spine = the core of the core ETL** — says the same thing and is used interchangeably in the deck.

### Non-spine — everything that assumes the record exists

Non-spine work starts from a landed record and improves, checks, or explains it. It is valuable, but none of it decides whether the record exists.

- **Address cleansing** — validating and correcting addresses (for example, AddressDoctor-style checks).
- **Name standardisation** — putting names into a consistent, comparable form.
- **Exception detection** — for example, a **date of birth in the future** or a **date of death in the future**. Both are bad data; neither should be processed into MDM unflagged.
- **Defaults from lookups** — for example, a gender code that is not a recognised value is translated to **Unknown**.
- **Raw vs standardised values** — for example, keeping the phone value as received (raw) alongside the standardised phone value.
- **Enrichment** — adding lookup values and derived attributes to the landed row.
- **Audits** — recording what was checked, what changed, and why.

The team's shorthand — **non-spine = non-core / nice-to-have** — is also accepted. "Nice-to-have" does not mean optional forever; it means it is not part of the core that decides what exists.

### Side by side

| Question | Spine | Non-spine |
|---|---|---|
| Core question | Does this record exist, and which version is it? | Is this record clean, complete, and safe to use? |
| Failure means | No trustworthy record to build on | A record exists, with a flag, a default, or an exception |
| Timing | First — Flow 1, landing on C_S_* | Second — Flow 2, working off C_S_* |
| Examples | Grain, identity, dedup, versioning | Address cleansing, name standardisation, future DOB / DOD, gender → Unknown, phone standardisation, audits, enrichment, lookups |

## 2. Approach 1 — no boundary

In the first approach, spine and non-spine work are **not separated**. One pipeline does everything — landing, cleansing, checks, enrichment, and lookups — and the C_S_* tables are the single target at the end of that pipeline.

It works, but it has costs:

- Core and nice-to-have logic are tangled, so a change to a nice-to-have can break the core.
- Core logic is hard to find, review, and protect inside the tangle.
- Each source mixes the work in its own way, so the same fix is made in many places and the copies drift.

## 3. Approach 2 — the v3 boundary

In v3 we drew an explicit boundary **at the C_S_* tables**:

- **Flow 1 — spine.** Land the core record on C_S_* and stamp its spine flag and reason. That is the whole job: small, strict, and reviewable.
- **Flow 2 — non-spine.** Work **off the landed C_S_* tables**: cleanse addresses, standardise names, detect exceptions (including future DOB and future DOD), apply defaults such as gender → Unknown, write raw and standardised phone values, enrich with lookups, and audit — updating the rows in place and recording flags and exception detail.

Supporting detail (not the centrepiece of this design): no data is deleted from C_S_* at the tail end. Downstream consumers read **flag-aware views** over the tables, so a flagged row stays in C_S_* for analysis but is hidden downstream. The flags are the filter; the views apply them.

## 4. The second benefit — identical C_S tables, identical Flow 2

Across all sources — TRS, ECI, WIC, FSS, TTF — the C_S table structures were already more or less the same: same tables, same columns, same definitions, with roughly **5–10% variation**.

We closed that variation by **adding the missing columns**, so the C_S tables now look **exactly the same** for every source.

That buys the team this:

- **Flow 2 logic is identical across all sources.** Address cleansing written once works the same for TRS, ECI, and WIC.
- **Very thin wrappers** per source call the one true implementation behind them.
- Where code is duplicated instead of shared, it is **duplicated-but-identical** code — so a fix, a test, or a review means the same thing everywhere.
- New non-spine work (a new exception check, a new standardisation) is built **once**, not once per source.

## 5. Working rules for the team

1. **Protect Flow 1.** Keep the spine small and strict. If a step does not decide what exists, it does not belong in Flow 1.
2. **Build Flow 2 once.** Write non-spine logic against the common C_S shape; keep per-source wrappers thin.
3. **Keep the C_S shape common.** If a source needs a new column, add it to the common shape rather than forking the table.
4. **Do not delete from C_S_*.** Flag the row and let the views decide what flows downstream.
5. **Add new nice-to-haves in Flow 2.** Future DOB / DOD-style checks, new standardisations, and new audits land in Flow 2 by default.

## The ask

Land the core. Refine off the tables. Keep Flow 2 the same everywhere.

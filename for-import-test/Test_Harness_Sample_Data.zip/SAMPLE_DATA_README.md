# Test Harness Sample Data Pack

Five ETL_INPUT_TABLES and five ETL_OUTPUT_TABLES for the TRS source,
with a few rows each -- enough to run the whole tester pipeline end
to end and see every compare status.

## What is in this zip

- `sample_data/seed_demo.py` -- builds the three demo databases
  (run from the main harness project root).
- `sample_data/White_list_tables_safe_to_truncate.txt` -- the 10
  demo tables, for step (C) in demo mode.
- `sample_data/demo.env` -- environment lines for demo mode.
- `sample_data/README.md` -- short notes on the pack.
- `demo/` -- the three databases prebuilt, so the walkthrough
  works without running the seed script first:
  - `demo_prod.db` -- "Production Oracle": 5 inputs + 5 outputs.
  - `demo_dev_oracle.db` -- "Dev Oracle": the same 10 tables, empty.
  - `demo_snowflake.db` -- "Snowflake Dev": the 5 outputs, empty.

## How to use it

Unpack `Test_Harness_Pipeline_v5.5.0.zip` first, then copy this
zip's contents over it (same relative paths). Then follow
`PIPELINE_USER_GUIDE.md`, section 7, "Demo walkthrough (no real
databases)".

To rebuild the demo databases from scratch at any time (from the
main harness project root):

```bash
python sample_data/seed_demo.py
```

## The sample, in brief

Members (all fictional): 1001 Alice Anderson, 1002 Bob Jones
(inactive), 1003 Carol White, 1004 Dan (blank last name), 1005
Eve Martin (inactive), 1006 Frank Brown.

Inputs: `STG_TRS_D_DC_INDV` (6), `STG_TRS_D_INDV_ADDR` (6),
`STG_TRS_H_DC_INDV` (2), `STG_TRS_D_DC_RELATIONSHIPS` (2),
`LOOKUP_CODE_VALUE` (4).

Outputs (Prod side): `C_S_TRS_PTY` (6), `C_S_TRS_PTY_RLE_PHN`
(5), `STG_TRS_VALID_MEMBERS` (6), `EXC_STG_BAD_REC_MEMB` (1),
`ZZ_UTL_UNMERGE_TREE_SRC_KEY` (2).

The Dev side differs from Prod in exactly four planted places,
so the compare verdict is MISMATCH with something in every
status: member 1003 renamed (DIFFERENT), member 1005 dropped
from the party output (ONLY_IN_PROD), member 1007 added
(ONLY_IN_DEV), one extra Dev-only exception row (ONLY_IN_DEV).

Honesty note: the `ZZ_UTL_UNMERGE_TREE_SRC_KEY` columns are
sample columns, not Oracle DDL -- replace them with the real
column list before using that entry against real Dev Oracle
tables. Everything else uses real Oracle column lists.

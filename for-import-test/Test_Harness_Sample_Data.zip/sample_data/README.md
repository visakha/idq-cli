# Sample data pack

Five ETL_INPUT_TABLES and five ETL_OUTPUT_TABLES for the TRS source,
with a few rows each -- enough to run the whole pipeline end to end
and see every compare status.

- `seed_demo.py` -- builds `demo_prod.db`, `demo_dev_oracle.db` and
  `demo_snowflake.db` (run from the project root).  Re-running it
  rebuilds all three files from scratch.
- `White_list_tables_safe_to_truncate.txt` -- the 10 demo tables,
  for step (C) in demo mode.
- `demo.env` -- environment lines for demo mode (copy into `.env`).

Full walkthrough, expected counts and the planted differences:
see PIPELINE_USER_GUIDE.md, "Demo walkthrough (no real databases)".

The demo databases are also shipped prebuilt in `demo/` at the
project root, so the walkthrough works without running the seed
script first.

"""Seed the demo databases for the pipeline sample pack.

Builds three SQLite files (default directory ./demo):
  * demo_prod.db        -- the "Production Oracle" side: 5 sample
                           ETL_INPUT_TABLES + 5 sample
                           ETL_OUTPUT_TABLES, as the Production ETL
                           would have left them at 8 AM.
  * demo_dev_oracle.db  -- the "Dev Oracle" side: the same 10 tables,
                           empty.  Step (C) truncates and loads them.
  * demo_snowflake.db   -- the "Snowflake Dev" side: the 5 output
                           tables, empty.  Step (D)'s demo simulator
                           fills them.

Run from the project root:
    python sample_data/seed_demo.py
    python sample_data/seed_demo.py --dir ./my-demo

The Prod outputs are built with derive_outputs(..., plant_diffs=False)
-- the exact same derivation the demo simulator uses with
plant_diffs=True -- so Prod and Dev match everywhere except the
planted demo differences (see demo_etl_simulator.py).  Re-running
this script rebuilds all three files from scratch.

Sample members (all fictional):
  1001 Alice Anderson, 1002 Bob Jones (inactive), 1003 Carol White,
  1004 Dan (blank last name -- the bad-record case),
  1005 Eve Martin (inactive), 1006 Frank Brown.
"""

from __future__ import annotations

import argparse
import os
import sys

# Allow running as `python sample_data/seed_demo.py` from the project root.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from sqlalchemy import create_engine

from app.domain.pipeline_catalog import get_source
from app.repositories.pipeline_repository import TableStore
from app.services.demo_etl_simulator import derive_outputs

SAMPLE_INPUTS = [
    "STG_TRS_D_DC_INDV",
    "STG_TRS_D_INDV_ADDR",
    "STG_TRS_H_DC_INDV",
    "STG_TRS_D_DC_RELATIONSHIPS",
    "LOOKUP_CODE_VALUE",
]
SAMPLE_OUTPUTS = [
    "C_S_TRS_PTY",
    "C_S_TRS_PTY_RLE_PHN",
    "STG_TRS_VALID_MEMBERS",
    "EXC_STG_BAD_REC_MEMB",
    "ZZ_UTL_UNMERGE_TREE_SRC_KEY",
]

MEMBERS = [
    {"INDV_ID": 1001, "FIRST_NAME": "Alice", "LAST_NAME": "Anderson", "GENDER_CD": "F",
     "DOB_DT": "1985-03-14", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1002, "FIRST_NAME": "Bob", "LAST_NAME": "Jones", "GENDER_CD": "M",
     "DOB_DT": "1978-11-02", "INACTIVE_IND": "Y", "DELETE_SW": "N"},
    {"INDV_ID": 1003, "FIRST_NAME": "Carol", "LAST_NAME": "White", "GENDER_CD": "F",
     "DOB_DT": "1992-07-19", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1004, "FIRST_NAME": "Dan", "LAST_NAME": "", "GENDER_CD": "M",
     "DOB_DT": "2001-05-30", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1005, "FIRST_NAME": "Eve", "LAST_NAME": "Martin", "GENDER_CD": "F",
     "DOB_DT": "1988-09-09", "INACTIVE_IND": "Y", "DELETE_SW": "N"},
    {"INDV_ID": 1006, "FIRST_NAME": "Frank", "LAST_NAME": "Brown", "GENDER_CD": "M",
     "DOB_DT": "1975-01-25", "INACTIVE_IND": "N", "DELETE_SW": "N"},
]

ADDRESSES = [
    {"INDV_ID": 1001, "ADDR_LINE": "12 Oak St", "ADDR_CITY": "Austin",
     "ADDR_STATE_CD": "TX", "ADDR_ZIP5": "78701", "ADDR_TYPE_CD": "HOME",
     "EFF_BEGIN_DT": "2020-01-01"},
    {"INDV_ID": 1002, "ADDR_LINE": "34 Pine Ave", "ADDR_CITY": "Dallas",
     "ADDR_STATE_CD": "TX", "ADDR_ZIP5": "75201", "ADDR_TYPE_CD": "HOME",
     "EFF_BEGIN_DT": "2019-06-15"},
    {"INDV_ID": 1003, "ADDR_LINE": "56 Cedar Ln", "ADDR_CITY": "Houston",
     "ADDR_STATE_CD": "TX", "ADDR_ZIP5": "77001", "ADDR_TYPE_CD": "HOME",
     "EFF_BEGIN_DT": "2021-03-10"},
    {"INDV_ID": 1004, "ADDR_LINE": "78 Elm Rd", "ADDR_CITY": "El Paso",
     "ADDR_STATE_CD": "TX", "ADDR_ZIP5": "79901", "ADDR_TYPE_CD": "HOME",
     "EFF_BEGIN_DT": "2022-02-20"},
    {"INDV_ID": 1005, "ADDR_LINE": "90 Maple Dr", "ADDR_CITY": "San Antonio",
     "ADDR_STATE_CD": "TX", "ADDR_ZIP5": "78201", "ADDR_TYPE_CD": "HOME",
     "EFF_BEGIN_DT": "2018-11-05"},
    {"INDV_ID": 1006, "ADDR_LINE": "11 Birch Ct", "ADDR_CITY": "Fort Worth",
     "ADDR_STATE_CD": "TX", "ADDR_ZIP5": "76101", "ADDR_TYPE_CD": "HOME",
     "EFF_BEGIN_DT": "2017-08-08"},
]

HISTORY = [
    {"INDV_ID": 1001, "HISTORY_SEQ": 1, "FIRST_NAME": "Alice", "LAST_NAME": "Anderson",
     "GENDER_CD": "F", "DOB_DT": "1985-03-14", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1002, "HISTORY_SEQ": 1, "FIRST_NAME": "Bob", "LAST_NAME": "Jones",
     "GENDER_CD": "M", "DOB_DT": "1978-11-02", "INACTIVE_IND": "N", "DELETE_SW": "N"},
]

RELATIONSHIPS = [
    {"INDV_ID": 1001, "REF_INDV_ID": 1003, "HISTORY_SEQ": 1,
     "RELATIONSHIP_TYPE_CD": "PARENT", "EFF_BEGIN_DT": "2010-01-01"},
    {"INDV_ID": 1002, "REF_INDV_ID": 1005, "HISTORY_SEQ": 1,
     "RELATIONSHIP_TYPE_CD": "SPOUSE", "EFF_BEGIN_DT": "2005-06-01"},
]

LOOKUPS = [
    {"CODE_TYPE": "GENDER", "SRC_SYS": "TRS", "SRC_CODE_VALUE": "M",
     "MSTR_REF_CODE": "M", "MSTR_REF_LABEL": "Male"},
    {"CODE_TYPE": "GENDER", "SRC_SYS": "TRS", "SRC_CODE_VALUE": "F",
     "MSTR_REF_CODE": "F", "MSTR_REF_LABEL": "Female"},
    {"CODE_TYPE": "INACTIVE_IND", "SRC_SYS": "TRS", "SRC_CODE_VALUE": "Y",
     "MSTR_REF_CODE": "Y", "MSTR_REF_LABEL": "Inactive"},
    {"CODE_TYPE": "INACTIVE_IND", "SRC_SYS": "TRS", "SRC_CODE_VALUE": "N",
     "MSTR_REF_CODE": "N", "MSTR_REF_LABEL": "Active"},
]


def _fresh_store(path: str) -> TableStore:
    if os.path.exists(path):
        os.remove(path)
    return TableStore(create_engine(f"sqlite:///{path}"))


def _load(store: TableStore, table_name: str, rows: list[dict]) -> int:
    spec = next(t for t in get_source("TRS").all_tables if t.name == table_name)
    store.ensure_table(table_name, None)
    cleaned = [{c: row.get(c) for c in spec.columns} for row in rows]
    store.insert_rows(table_name, None, cleaned)
    return len(cleaned)


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed the pipeline demo databases.")
    parser.add_argument("--dir", default="./demo", help="Directory for the demo .db files")
    args = parser.parse_args()
    os.makedirs(args.dir, exist_ok=True)

    prod = _fresh_store(os.path.join(args.dir, "demo_prod.db"))
    for table_name, rows in [
        ("STG_TRS_D_DC_INDV", MEMBERS),
        ("STG_TRS_D_INDV_ADDR", ADDRESSES),
        ("STG_TRS_H_DC_INDV", HISTORY),
        ("STG_TRS_D_DC_RELATIONSHIPS", RELATIONSHIPS),
        ("LOOKUP_CODE_VALUE", LOOKUPS),
    ]:
        print(f"demo_prod.db: {table_name}: {_load(prod, table_name, rows)} rows")
    outputs = derive_outputs(MEMBERS, plant_diffs=False)
    for table_name in SAMPLE_OUTPUTS:
        print(f"demo_prod.db: {table_name}: {_load(prod, table_name, outputs[table_name])} rows (Prod outputs)")
    prod.engine.dispose()

    dev = _fresh_store(os.path.join(args.dir, "demo_dev_oracle.db"))
    for table_name in SAMPLE_INPUTS + SAMPLE_OUTPUTS:
        dev.ensure_table(table_name, None)
        print(f"demo_dev_oracle.db: {table_name}: 0 rows (empty, step C fills it)")
    dev.engine.dispose()

    snow = _fresh_store(os.path.join(args.dir, "demo_snowflake.db"))
    for table_name in SAMPLE_OUTPUTS:
        snow.ensure_table(table_name, None)
        print(f"demo_snowflake.db: {table_name}: 0 rows (empty, step D fills it)")
    snow.engine.dispose()
    print(f"Done. Demo databases in {args.dir}/")


if __name__ == "__main__":
    main()

-- ============================================================================
-- sp_snow_step_ECI_REL_S30_TYPED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (ECI ONLY)
--
-- Mapping: m_Tgt_C_S_ECI_Pty_Rle_Rel, workflow wf_ECI_Stage_Load.
-- Step 30, CODED_TRANSLATED. Split out of
-- sp_snow_main_m_Tgt_C_S_ECI_Pty_Rle_Rel; business SQL preserved verbatim
-- (the original coded + typed CTEs, with their FROM pointed at step 20
-- as now).
--
-- WHAT THIS STEP PRODUCES
--   WRK_ECI_REL_S30_TYPED: relationship code built (family code alone
--   for the family-to-child direction; family code plus child gender
--   for the reverse direction) and translated in the code-value table
--   (NULL when the code does not translate).
-- FEEDS THE SPINE: yes -- via step 40 -> publish branch 50
--   (C_S_ECI_PTY_RLE_REL, spine) and branch 60 (EXC_STG_BAD_REC_MEMB,
--   non-spine exception rows).
--
-- P_INPUT_TABLES NOTE (read before changing this proc)
--   P_INPUT_TABLES is a dependency declaration + runtime existence check,
--   NOT dynamic SQL. Snowflake cannot parameterise table names in static
--   SQL, so the CTAS below still names its tables directly, exactly as
--   the current main does. The check below only verifies that the
--   declared work-table inputs exist before the CTAS runs. It lists
--   WORK-TABLE inputs only; base source tables and lookup tables
--   (here STG_ECI_SN_CHILD, LOOKUP_CODE_VALUE) are not work-table
--   dependencies and are not listed or checked.
--
-- SUBSTITUTIONS vs the current main (only these; nothing else changed)
--   * :l_run_ts -> :P_RUN_TS (accepted for a uniform step signature;
--     this step does not stamp run_ts, so P_RUN_TS is unused here).
--   * :c_mapping -> local DECLARE constant with the same value.
--   * The step's own checkpoint, previously written inline in the main,
--     is written here with the same STEP_NAME and message as the current step checkpoint (v2 10-argument form; STEP_NO, row count, and work-table arguments dropped).
--
-- STYLE
--   TRANSIENT work table only, same name as now. No exception block
--   (errors propagate to the driver handler), no transactions, no target
--   writes. No drop checkpoint, no resume-step parameter, no row-by-row processing.
--
-- SIGNATURE
--   P_JOB_RUN_ID   VARCHAR                              -- workflow-level run id
--   P_RUN_TS       TIMESTAMP_NTZ                        -- run timestamp (driver's)
--   P_INPUT_TABLES VARCHAR DEFAULT 'WRK_ECI_REL_S20_KEYED'
-- RETURNS NUMBER (row count of the work table created).
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_ECI_REL_S30_TYPED (
    P_JOB_RUN_ID   VARCHAR,
    P_RUN_TS       TIMESTAMP_NTZ,
    P_INPUT_TABLES VARCHAR DEFAULT 'WRK_ECI_REL_S20_KEYED'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source   VARCHAR DEFAULT 'ECI';
    c_workflow VARCHAR DEFAULT 'wf_ECI_Stage_Load';
    c_mapping  VARCHAR DEFAULT 'm_Tgt_C_S_ECI_Pty_Rle_Rel';
    l_rows     NUMBER DEFAULT 0;
    l_missing  VARCHAR;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is NULL/empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(UPPER(TRIM(f.value)), ', ') INTO :l_missing
          FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|'))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = UPPER(TRIM(f.value)));
        IF (l_missing IS NOT NULL AND l_missing <> '') THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 30: RELATIONSHIP CODE + TRANSLATION (verbatim from the main)
    -- Purpose: build the relationship code (family code alone for the
    -- family-to-child direction; family code plus child gender for the
    -- reverse direction) and translate it in the code-value table.
    -- Reads ONLY step 20. This is the original coded + typed CTEs.
    CREATE OR REPLACE TRANSIENT TABLE WRK_ECI_REL_S30_TYPED AS
    WITH
    coded AS (
        SELECT k.*,
               IFF(k.RELATION_DIRECTION = 'To Child', TO_VARCHAR(k.FAMILY_CD),
                   NVL(TO_VARCHAR(k.FAMILY_CD), '') || '|' || NVL(ch.GENDER, ''))     AS rel_family_cd
          FROM WRK_ECI_REL_S20_KEYED k
          LEFT JOIN (SELECT c.ID_CHILD, c.GENDER FROM STG_ECI_SN_CHILD c
                     QUALIFY ROW_NUMBER() OVER (PARTITION BY c.ID_CHILD ORDER BY c.GENDER) = 1) ch
                 ON ch.ID_CHILD = k.ID_CHILD
    )
    SELECT c.*, lk.MSTR_REF_CODE AS mstr_ref_code
      FROM coded c
      LEFT JOIN (SELECT l.SRC_CODE_VALUE, l.MSTR_REF_CODE FROM LOOKUP_CODE_VALUE l
                  WHERE l.CODE_TYPE IN ('REL_TP', 'INVERSE_REL') AND l.SRC_SYS = 'ECI'
                QUALIFY ROW_NUMBER() OVER (PARTITION BY l.SRC_CODE_VALUE ORDER BY l.CODE_TYPE DESC,
                                           l.MSTR_REF_CODE) = 1) lk
             ON lk.SRC_CODE_VALUE = c.rel_family_cd;
    SELECT COUNT(*) INTO :l_rows FROM WRK_ECI_REL_S30_TYPED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'CODED_TRANSLATED', 'COMPLETED', NULL, 'Step 30 complete.', NULL);
    RETURN :l_rows;
END;
$$;

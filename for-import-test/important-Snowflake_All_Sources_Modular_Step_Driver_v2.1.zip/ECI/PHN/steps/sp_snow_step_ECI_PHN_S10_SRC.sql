-- ============================================================================
-- sp_snow_step_ECI_PHN_S10_SRC  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (ECI ONLY)
--
-- Mapping: m_Tgt_C_S_ECI_Pty_Rle_Phn_And_EAddr, workflow wf_ECI_Stage_Load.
-- Step 10: SRC_PHN_EADDR -- Phone and e-mail source rows with party, role and record keys.
-- Produces: TRANSIENT TABLE WRK_ECI_PHN_S10_SRC.
-- Feeds: SPINE-FEEDING (via step 50): produces the combined phone/e-mail source rows that ultimately feed BOTH spine targets (step 60/80) and both exception branches (step 70/90).
--
-- WHAT THIS PROCEDURE IS
--   One step of the original mapping, re-housed unchanged. The CTAS below
--   is the original step's SELECT verbatim, with its FROM clause pointed
--   at the fixed work-table names exactly as in the original main
--   procedure. No business expression, filter, guard or column list was
--   changed. Allowed substitutions only: :l_run_ts -> :P_RUN_TS (step 50),
--   :l_job_run_id -> :P_JOB_RUN_ID in the checkpoint call.
--
-- P_INPUT_TABLES IS A DEPENDENCY DECLARATION + RUNTIME CHECK, NOT DYNAMIC SQL
--   Snowflake cannot parameterise table names in static SQL, so the CTAS
--   still names its input work table(s) literally. P_INPUT_TABLES is the
--   config-supplied list (pipe-delimited) of work-table inputs for this
--   step; this procedure only CHECKS that each named table exists in the
--   current schema (INFORMATION_SCHEMA.TABLES) before running the CTAS.
--   It never builds SQL from P_INPUT_TABLES, except for the single
--   missing-table error probe documented below.
--
-- INPUT EXISTENCE CHECK
--   Skipped when P_INPUT_TABLES is NULL or empty (step 10's default).
--   Otherwise the first missing name is found with a set-based query
--   (MIN over SPLIT_TO_TABLE parts not present in INFORMATION_SCHEMA).
--   On a missing table this procedure raises the native object-not-exists
--   error via EXECUTE IMMEDIATE 'SELECT 1 FROM <missing table>' -- see
--   PHN_MANIFEST.md for why the RAISE form was NOT used (documented
--   Snowflake RAISE syntax takes an exception name only, so a dynamic
--   table name cannot be embedded in a RAISE message; the native error
--   names the missing table). The error propagates to the driver, whose
--   exception handler writes the TERMINATING 999 FAILED row.
--
-- CHECKPOINT / RETURN / NO SIDE EFFECTS
--   Writes exactly its own checkpoint in the v2 10-argument form
--   (STEP_NAME 'SRC_PHN_EADDR', STEP_STATUS 'COMPLETED', TARGET_TABLE NULL,
--   MESSAGE 'Step 10 complete.', ERROR_MESSAGE NULL). STEP_NO, row count,
--   work-table name/action/purpose are no longer checkpoint arguments.
--   Returns the work-table row count (NUMBER). No exception block (errors
--   propagate to the driver), no transaction control, no target writes.
--
-- SIGNATURE
--   P_JOB_RUN_ID  VARCHAR  (no default -- the driver always passes it)
--   P_RUN_TS      TIMESTAMP_NTZ
--   P_INPUT_TABLES VARCHAR DEFAULT ''  (work-table inputs only;
--                 base source tables and target guard tables are NOT
--                 work-table dependencies and are not listed)
--   Original parameters of this mapping: NONE (only P_JOB_RUN_ID was
--   appended by the modular rewrite, and it is carried here).
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_ECI_PHN_S10_SRC (
    P_JOB_RUN_ID   VARCHAR,
    P_RUN_TS       TIMESTAMP_NTZ,
    P_INPUT_TABLES VARCHAR DEFAULT ''
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'ECI';
    c_workflow   VARCHAR DEFAULT 'wf_ECI_Stage_Load';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_ECI_Pty_Rle_Phn_And_EAddr';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR;
    l_probe_sql  VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is NULL/empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT MIN(s.tbl) INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(SPLIT_TO_TABLE(:P_INPUT_TABLES, '|'))
                 WHERE TRIM(value) <> '') s
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = s.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || :l_missing;
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 10 CTAS (verbatim from the original main procedure) ----
CREATE OR REPLACE TRANSIENT TABLE WRK_ECI_PHN_S10_SRC AS
    SELECT s.SOURCE_TABLE, s.WORK_EXT, s.PHONE_TP, s.USG_TP, s.PREF_LVL, s.PERIOD_START_DATE,
           s.PHONE_EMAIL_TYPE, s.PHONE_EMAIL, s.ID_CASE, s.ID, s.ID_FAMILY_PHONE,
           NVL(s.PHONE_EMAIL_TYPE = 'EADDRESS', FALSE)                                    AS is_email,
           NVL(TO_VARCHAR(s.ID), '') || IFF(s.SOURCE_TABLE = 'ECI_FAMILY', 'F', '')      AS pty_src_key,
           NVL(TO_VARCHAR(s.ID), '') || IFF(s.SOURCE_TABLE = 'ECI_FAMILY', 'F', '') || '|Member' AS pty_rle_fk,
           IFF(NVL(s.PHONE_EMAIL_TYPE = 'EADDRESS', FALSE),
               NVL(TO_VARCHAR(s.ID), '') || IFF(s.SOURCE_TABLE = 'ECI_FAMILY', 'F', '') || '|Member|001|'
               || NVL(TO_VARCHAR(s.ID_FAMILY_PHONE), '') || '|' || NVL(TRIM(s.PHONE_EMAIL), ''),
               NVL(TO_VARCHAR(s.ID), '') || IFF(s.SOURCE_TABLE = 'ECI_FAMILY', 'F', '') || '|Member|'
               || NVL(s.PHONE_TP, '') || '|' || NVL(s.USG_TP, '') || '|' || NVL(TO_VARCHAR(s.ID_FAMILY_PHONE), '')
               || '|' || NVL(TRIM(s.PHONE_EMAIL), ''))                                     AS pkey_src_object,
           IFF(NVL(s.PHONE_EMAIL_TYPE = 'EADDRESS', FALSE),
               NVL(TO_VARCHAR(s.ID), '') || IFF(s.SOURCE_TABLE = 'ECI_FAMILY', 'F', '') || '|Member|001|'
               || NVL(TO_VARCHAR(s.ID_FAMILY_PHONE), '') || '|' || NVL(s.PHONE_EMAIL, ''),
               NVL(TO_VARCHAR(s.ID), '') || IFF(s.SOURCE_TABLE = 'ECI_FAMILY', 'F', '') || '|Member|'
               || NVL(s.PHONE_TP, '') || '|' || NVL(s.USG_TP, '') || '|' || NVL(TO_VARCHAR(s.ID_FAMILY_PHONE), '')
               || '|' || NVL(s.PHONE_EMAIL, ''))                                           AS src_rowid
      FROM V_ECI_ETL_SRC_FAMILY_PHONE s;
    SELECT COUNT(*) INTO :l_rows FROM WRK_ECI_PHN_S10_SRC;
    CALL sp_etl_checkpoint('ECI', :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'SRC_PHN_EADDR', 'COMPLETED', NULL, 'Step 10 complete.', NULL);
    RETURN :l_rows;
END;
$$;

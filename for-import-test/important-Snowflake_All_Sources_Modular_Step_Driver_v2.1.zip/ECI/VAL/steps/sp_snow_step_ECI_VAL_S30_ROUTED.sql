-- ============================================================================
-- sp_snow_step_ECI_VAL_S30_ROUTED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (ECI)
--
-- Mapping: m_Tgt_C_S_ECI_Pty_Validation, workflow wf_ECI_Stage_Load,
-- step 30. Step name (checkpoint): ROUTED_GROUPS.
--
-- WHAT THIS STEP PRODUCES
--   WRK_ECI_VAL_S30_ROUTED: the routing decisions. A row can belong to
--   more than one group: blank-name rows are both exception rows and
--   deactivation rows. Missing first name wins over missing last name.
--   Reads ONLY step 20. This is the original named + routed CTEs plus
--   the final SELECT (exception description/type lookup, run
--   timestamp, action labels, first-row-per-exception-key flag
--   uq_exc_name).
--
-- DOES IT FEED THE STATUS PATH?
--   Yes, DIRECTLY: this table is the sole source of all four publish
--   branches, including the STATUS branches (STG_ECI_PTY_INACTIVE_LOG
--   deactivation + reactivation, STG_ECI_PTY_INACTIVE_STS). It writes
--   no target itself.
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only; default
--   'WRK_ECI_VAL_S20_ENRICHED'. Snowflake cannot parameterise table
--   names in static SQL, so P_INPUT_TABLES is a dependency declaration
--   + runtime check, NOT dynamic SQL: the CTAS below still names its
--   sources literally, as in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-30 SELECT verbatim. Only
--   substitutions: :l_run_ts -> :P_RUN_TS, :c_mapping -> the local
--   constant below (same value, 'm_Tgt_C_S_ECI_Pty_Validation').
--   No business expression, filter, guard or column list was changed.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   with the same STEP_NAME, STEP_STATUS, TARGET_TABLE string and
--   message as the current step-30 checkpoint, in the v2 10-argument
--   form (its purpose text, which still says "Published in step 40",
--   is no longer passed -- the v2 form carries no purpose argument;
--   step 40 is now the first publish branch).
--   P_JOB_RUN_ID is present in every new proc in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_ECI_VAL_S30_ROUTED (
    P_JOB_RUN_ID   VARCHAR,
    P_RUN_TS       TIMESTAMP_NTZ,
    P_INPUT_TABLES VARCHAR DEFAULT 'WRK_ECI_VAL_S20_ENRICHED'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'ECI';
    c_workflow   VARCHAR DEFAULT 'wf_ECI_Stage_Load';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_ECI_Pty_Validation';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 30: ROUTING -- exception / deactivation / reactivation (verbatim from current main)
    CREATE OR REPLACE TRANSIENT TABLE WRK_ECI_VAL_S30_ROUTED AS
    WITH
    lkp_exc AS (SELECT * FROM TABLE(fn_snow_helper40_common())),
    named AS (
        SELECT n.*,
               n.nm:first_name::VARCHAR  AS std_first_name,
               n.nm:middle_name::VARCHAR AS std_mdl_name,
               n.nm:last_name::VARCHAR   AS std_lst_name,
               (fn_snow_helper03_common(n.nm:first_name::VARCHAR)
                OR fn_snow_helper03_common(n.nm:last_name::VARCHAR)) AS name_missing
          FROM WRK_ECI_VAL_S20_ENRICHED n
    ),
    routed AS (
        SELECT r.*,
               (r.name_missing AND r.fam_inactive_yn = 'N')                                  AS grp_invalid_party_name,
               (r.name_missing OR r.omit_id IS NOT NULL OR r.fam_inactive_yn = 'Y')          AS grp_deactivation,
               (r.deactivation_sts IS NOT NULL AND NOT r.name_missing AND r.omit_id IS NULL
                AND r.fam_inactive_yn = 'N')                                                 AS grp_reactivation,
               CASE WHEN fn_snow_helper03_common(r.std_first_name) THEN 'Missing_First_Name'
                    WHEN fn_snow_helper03_common(r.std_lst_name) THEN 'Missing_Last_Name' END AS exc_code_name,
               CASE WHEN fn_snow_helper03_common(r.std_first_name) THEN 'First Name'
                    WHEN fn_snow_helper03_common(r.std_lst_name) THEN 'Last Name' END        AS exc_attribute_name,
               CASE WHEN fn_snow_helper03_common(r.std_first_name) THEN r.std_first_name
                    WHEN fn_snow_helper03_common(r.std_lst_name) THEN r.std_lst_name END     AS exc_attribute_value,
               fn_snow_helper02_common(r.hub_state_ind)                                      AS new_deactivation_sts
          FROM named r
    )
    SELECT r.*,
           ex.EXCEPTION_DESC     AS exc_desc_name,
           ex.EXCEPTION_TYPE     AS exc_type_name,
           :P_RUN_TS             AS run_ts,
           :c_mapping            AS mapping_name,
           'Deactivation'        AS action_deactivation,
           'Reactivation'        AS action_reactivation,
           ROW_NUMBER() OVER (PARTITION BY r.grp_invalid_party_name, r.src_system, r.pkey_src_object,
                                           ex.EXCEPTION_TYPE, r.exc_code_name
                                  ORDER BY r.ID) = 1 AS uq_exc_name
      FROM routed r
      LEFT JOIN lkp_exc ex ON ex.EXCEPTION_CODE = r.exc_code_name;
    SELECT COUNT(*) INTO :l_rows FROM WRK_ECI_VAL_S30_ROUTED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'ROUTED_GROUPS', 'COMPLETED', 'EXC_STG_BAD_REC_MEMB, STG_ECI_PTY_INACTIVE_LOG, STG_ECI_PTY_INACTIVE_STS',
        'Step 30 complete.', NULL);
    RETURN :l_rows;
END;
$$;

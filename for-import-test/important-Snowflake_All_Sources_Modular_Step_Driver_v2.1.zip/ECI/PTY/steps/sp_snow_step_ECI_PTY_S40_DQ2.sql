-- ============================================================================
-- sp_snow_step_ECI_PTY_S40_DQ2  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (ECI)
--
-- Mapping: m_Tgt_C_S_ECI_Pty, workflow wf_ECI_Stage_Load, step 40.
-- Step name (checkpoint): DQ_EXCEPTIONS_RESOLVED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_ECI_PTY_S40_DQ2: standardised fields unpacked and every rule's
--   exception code, description and type resolved from the exception
--   catalogue. A future birth date becomes NULL here. Reads ONLY
--   step 30. This is the original dq2 CTE.
--
-- DOES IT FEED THE SPINE?
--   Indirectly: the publish spine branches read step 50, which derives
--   from this step. It writes no target itself.
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only. Default:
--   'WRK_ECI_PTY_S30_DQ'. Snowflake cannot parameterise table names
--   in static SQL, so P_INPUT_TABLES is a dependency declaration +
--   runtime check, NOT dynamic SQL: the CTAS below still names its
--   source literally, as in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-40 SELECT verbatim. Only
--   substitution: :c_mapping -> the local constant below (used by the
--   checkpoint). No business expression, filter, guard or column list
--   was changed. This step uses neither original parameter and does
--   not use the run timestamp.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   with the same STEP_NAME and message as the current step-40 checkpoint (v2 10-argument form; STEP_NO, row count, and work-table arguments dropped).
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_ECI_PTY_S40_DQ2 (
    P_JOB_RUN_ID   VARCHAR,
    P_RUN_TS       TIMESTAMP_NTZ,
    P_INPUT_TABLES VARCHAR DEFAULT 'WRK_ECI_PTY_S30_DQ'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'ECI';
    c_workflow   VARCHAR DEFAULT 'wf_ECI_Stage_Load';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_ECI_Pty';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 40: VALIDATION RULES, STEP 2 (verbatim from current main)
    CREATE OR REPLACE TRANSIENT TABLE WRK_ECI_PTY_S40_DQ2 AS
    WITH
    lkp_exc AS (SELECT * FROM TABLE(fn_snow_helper40_common()))
    SELECT d.*,
           d.nm:first_name::VARCHAR                       AS std_first_name,
           d.nm:middle_name::VARCHAR                      AS std_mdl_name,
           d.nm:last_name::VARCHAR                        AS std_lst_name,
           d.nm:full_name::VARCHAR                        AS std_full_name,
           d.nm:src_full_name::VARCHAR                    AS std_src_full_name,
           d.nm:prfx_name::VARCHAR                        AS std_prfx_name,
           d.gd:mdm_gender_code::VARCHAR                  AS mdm_gender_code,
           d.gd:exception_code::VARCHAR                   AS gender_exception_code,
           xg.EXCEPTION_DESC                              AS gender_exception_description,
           xg.EXCEPTION_TYPE                              AS gender_exception_type,
           IFF(d.birth_exception_code IS NULL, d.DOB, NULL) AS std_birth_date,
           xb.EXCEPTION_DESC                              AS birth_exception_description,
           xb.EXCEPTION_TYPE                              AS birth_exception_type,
           xe.EXCEPTION_CODE                              AS ethnicity_exception_code,
           xe.EXCEPTION_DESC                              AS ethnicity_exception_desc,
           xe.EXCEPTION_TYPE                              AS ethnicity_exception_type,
           d.rc:mdm_race_cd::VARCHAR                      AS mdm_race_cd,
           d.rc:src_race_ind_list::VARCHAR                AS src_race_ind_list,
           xr.EXCEPTION_CODE                              AS race_exception_cd,
           xr.EXCEPTION_DESC                              AS race_exception_desc,
           xr.EXCEPTION_TYPE                              AS race_exception_type,
           xl.EXCEPTION_CODE                              AS language_exception_code,
           xl.EXCEPTION_DESC                              AS language_exception_desc,
           xl.EXCEPTION_TYPE                              AS language_exception_type
      FROM WRK_ECI_PTY_S30_DQ d
      LEFT JOIN lkp_exc xg ON xg.EXCEPTION_CODE = d.gd:exception_code::VARCHAR
      LEFT JOIN lkp_exc xb ON xb.EXCEPTION_CODE = d.birth_exception_code
      LEFT JOIN lkp_exc xe ON xe.EXCEPTION_CODE = fn_snow_helper18_common(d.ethnicity_mstr, 'Invalid_Ethnicity')
      LEFT JOIN lkp_exc xr ON xr.EXCEPTION_CODE = d.rc:exception_code::VARCHAR
      LEFT JOIN lkp_exc xl ON xl.EXCEPTION_CODE = fn_snow_helper18_common(d.language_mstr, 'Invalid_Language');
    SELECT COUNT(*) INTO :l_rows FROM WRK_ECI_PTY_S40_DQ2;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'DQ_EXCEPTIONS_RESOLVED', 'COMPLETED', NULL, 'Step 40 complete.', NULL);
    RETURN :l_rows;
END;
$$;

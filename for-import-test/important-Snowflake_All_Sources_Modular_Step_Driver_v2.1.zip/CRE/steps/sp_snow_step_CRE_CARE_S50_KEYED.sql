-- ============================================================================
-- sp_snow_step_CRE_CARE_S50_KEYED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (CRE)
--
-- Mapping: m_Tgt_C_S_CRE_CARE_Clients, workflow wf_CRE_Stage_Load_Ongoing, step 50.
-- Step name (checkpoint): KEYED_ROUTES_GUARDS.
--
-- WHAT THIS STEP PRODUCES
--   WRK_CRE_CARE_S5_KEYED: route flags + unique-key guards (keyed + final select).
--   The rows the publish step writes, with the county rule (non-Texas state -> 996, missing county FIPS -> 998, else the county FIPS), the address / phone / alternate-id keys, the route flag for every target and exception class (every flag NVL-ed: a NULL router condition does not route), the run constants, the SRC_ROWIDs cut to 30 characters, and the insert-only guards: keys already in a target (VERSION_SEQ = 1) are skipped, and the first row per exception key wins (record type descending). Reads ONLY step 40.
--
-- DOES IT FEED THE SPINE?
--   YES, directly: all eighteen publish branches read ONLY this table. It writes no target itself.
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only. Default: 'WRK_CRE_CARE_S4_FLAT'
--   (empty for step 10: it reads base source tables, not work tables, so
--   the existence check below is skipped). Snowflake cannot parameterise
--   table names in static SQL, so P_INPUT_TABLES is a dependency
--   declaration + runtime check, NOT dynamic SQL: the CTAS below still
--   names its sources literally, as in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-50 SELECT verbatim. Only
--   substitutions: :l_run_ts -> :P_RUN_TS, :c_mapping -> the local
--   constant below (used by the checkpoint), original-parameter refs -> this proc's params of the same names. No business
--   expression, filter, guard or column list was changed. This step uses
--   original parameters: P_PHYSICAL_ADDR_TYPE_CD, P_RLE_BO_CLASS_CD_MEMBER, P_DEFAULT_TX_STATE_CD, P_COUNTY_CD_NONTX, P_COUNTYCD_DEFAULTALL.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   with the same STEP_NAME and message as the current step-50
--   checkpoint (v2 10-argument form; STEP_NO, row count, and work-table
--   arguments dropped). P_JOB_RUN_ID is present in every new proc in
--   this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_CRE_CARE_S50_KEYED (
    P_PHYSICAL_ADDR_TYPE_CD      VARCHAR DEFAULT '002',
    P_RLE_BO_CLASS_CD_MEMBER     VARCHAR DEFAULT 'Member',
    P_DEFAULT_TX_STATE_CD        VARCHAR DEFAULT '48',
    P_COUNTY_CD_NONTX            VARCHAR DEFAULT '996',
    P_COUNTYCD_DEFAULTALL        VARCHAR DEFAULT '998',
    -- Live-compile fix: Snowflake forbids a required parameter after an
    -- optional one, so P_JOB_RUN_ID / P_RUN_TS carry DEFAULT NULL here.
    -- Drivers always pass all parameters positionally, so behaviour is unchanged.
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_CRE_CARE_S4_FLAT'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'CRE';
    c_workflow   VARCHAR DEFAULT 'wf_CRE_Stage_Load_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_CRE_CARE_Clients';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 50: KEYED_ROUTES_GUARDS (verbatim from current main)
    CREATE OR REPLACE TRANSIENT TABLE WRK_CRE_CARE_S5_KEYED AS
    WITH
    keyed AS (
        SELECT f.*,
               /* EXP_PTY_RLE_ADDR_HOLD.out_COUNTY_CD */
               CASE WHEN f.a_state <> :P_DEFAULT_TX_STATE_CD THEN :P_COUNTY_CD_NONTX
                    WHEN f.a_county_fips IS NULL THEN :P_COUNTYCD_DEFAULTALL
                    ELSE f.a_county_fips END                                           AS a_county,
               f.rle_key || '|' || :P_PHYSICAL_ADDR_TYPE_CD                            AS addr_key,
               IFF(f.care_alt_id IN ('U', 'N'), NULL, f.care_alt_id)                   AS care_alt_val,
               IFF(f.medicaid_alt_id IN ('U', 'N'), NULL, f.medicaid_alt_id)           AS medicaid_alt_val,
               f.rle_key || '|' || NVL(f.care_tp_cd, '') || '|' || NVL(f.care_alt_id, '')         AS care_alt_key,
               f.rle_key || '|' || NVL(f.medicaid_tp_cd, '') || '|' || NVL(f.medicaid_alt_id, '') AS medicaid_alt_key,
               f.rle_key || '|' || NVL(f.ssn_tp_cd, '') || '|' || NVL(f.ssn_out, '')              AS ssn_alt_key,
               /* routes (every flag NVL'd: a NULL router condition does not route) */
               NOT f.grp_deletes AND NVL(f.orig_rowid_object_desc = 'N', FALSE)        AS grp_mrg,
               NOT f.valid_member AND (f.fn_exception_code IS NOT NULL OR f.fn_exception_desc IS NOT NULL
                                       OR f.fn_exception_type IS NOT NULL)            AS grp_first_name,
               NOT f.valid_member AND (f.ln_exception_code IS NOT NULL OR f.ln_exception_desc IS NOT NULL
                                       OR f.ln_exception_type IS NOT NULL)            AS grp_last_name,
               f.is_member AND f.gender_exception_description IS NOT NULL              AS grp_gender,
               f.is_member AND f.suffix_exception_code IS NOT NULL                     AS grp_suffix,
               f.is_member AND f.ethnicity_exception_code IS NOT NULL                  AS grp_ethnicity,
               f.is_member AND f.race_exception_code IS NOT NULL                       AS grp_race,
               f.is_member AND f.addr_valid                                            AS grp_addr,
               f.is_member AND NOT f.addr_valid                                        AS grp_addr_exc,
               f.is_member AND f.PHONE IS NOT NULL AND f.phone_exception_code IS NULL  AS grp_phone,
               f.is_member AND f.PHONE IS NOT NULL AND f.phone_exception_code IS NOT NULL AS grp_phone_exc,
               f.is_member AND f.care_alt_id IS NOT NULL                               AS grp_care_alt,
               f.is_member AND f.medicaid_alt_id IS NOT NULL AND f.medicaid_exception_code IS NULL
                                                                                       AS grp_medicaid_alt,
               f.is_member AND f.medicaid_alt_id IS NOT NULL AND f.medicaid_exception_code IS NOT NULL
                                                                                       AS grp_medicaid_exc,
               f.is_member AND f.ssn_out IS NOT NULL AND f.ssn_exception_code IS NULL  AS grp_ssn_alt,
               f.is_member AND f.ssn_out IS NOT NULL AND f.ssn_exception_code IS NOT NULL AS grp_ssn_exc
          FROM WRK_CRE_CARE_S4_FLAT f
    )
    SELECT k.*,
           'CRE'                                             AS src_sys,
           :P_RUN_TS                                         AS run_ts,
           :c_mapping                                        AS mapping_name,
           'Indv'                                            AS pty_bo_class_cd,
           :P_RLE_BO_CLASS_CD_MEMBER                         AS rle_bo_class_cd,
           :P_PHYSICAL_ADDR_TYPE_CD                          AS addr_tp,
           'Payer'                                           AS hierarchy_code,
           'Primary'                                         AS pref_lvl,
           'Member Addr'                                     AS hm_rel_tp_cd,
           'US'                                              AS src_cntry,
           'Telephone'                                       AS phn_tp,
           '001'                                             AS usg_tp_phone,
           'Issued'                                          AS sts_cd,
           'First Name'                                      AS attr_first_name,
           'Last Name'                                       AS attr_last_name,
           'Gender'                                          AS attr_gender,
           'Name Suffix'                                     AS attr_suffix,
           'FEDETH'                                          AS attr_fedeth,
           'RACE'                                            AS attr_race,
           'Address'                                         AS attr_address,
           'Telephone'                                       AS attr_phone,
           CAST(NULL AS TIMESTAMP_NTZ)                       AS null_timestamp,   -- TIMELINE: not linked
           CAST(NULL AS NUMBER)                              AS null_number,      -- TIMELINE: not linked
           /* BAD DATA: SRC_ROWID is 30 characters */
           LEFT(k.addr_key, 30)                              AS addr_src_rowid,
           LEFT(k.phn_key, 30)                               AS phn_src_rowid,
           LEFT(k.care_alt_key, 30)                          AS care_alt_src_rowid,
           LEFT(k.medicaid_alt_key, 30)                      AS medicaid_alt_src_rowid,
           LEFT(k.ssn_alt_key, 30)                           AS ssn_alt_src_rowid,
           /* BAD DATA: unique keys Snowflake does not enforce */
           ROW_NUMBER() OVER (PARTITION BY k.grp_first_name, k.CARE_ID, k.fn_exception_type, k.fn_exception_code
                              ORDER BY k.REC_TYPE DESC) = 1  AS uq_first_name,
           ROW_NUMBER() OVER (PARTITION BY k.grp_last_name, k.CARE_ID, k.ln_exception_type, k.ln_exception_code
                              ORDER BY k.REC_TYPE DESC) = 1  AS uq_last_name,
           xpty.PKEY_SRC_OBJECT IS NULL                      AS uq_pty,
           xrle.PKEY_SRC_OBJECT IS NULL                      AS uq_rle,
           xadr.PKEY_SRC_OBJECT IS NULL                      AS uq_addr,
           xphn.PKEY_SRC_OBJECT IS NULL                      AS uq_phone,
           xca.PKEY_SRC_OBJECT IS NULL                       AS uq_care_alt,
           xma.PKEY_SRC_OBJECT IS NULL                       AS uq_medicaid_alt,
           xsa.PKEY_SRC_OBJECT IS NULL                       AS uq_ssn_alt,
           ROW_NUMBER() OVER (PARTITION BY k.grp_medicaid_exc, k.mrg_care_id, k.medicaid_exception_type,
                                           k.medicaid_exception_code ORDER BY k.REC_TYPE DESC) = 1
                                                             AS uq_medicaid_exc,
           ROW_NUMBER() OVER (PARTITION BY k.grp_ssn_exc, k.mrg_care_id, k.ssn_exception_type,
                                           k.ssn_exception_code ORDER BY k.REC_TYPE DESC) = 1
                                                             AS uq_ssn_exc
      FROM keyed k
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY WHERE VERSION_SEQ = 1) xpty
             ON xpty.PKEY_SRC_OBJECT = k.pty_key
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY_RLE WHERE VERSION_SEQ = 1) xrle
             ON xrle.PKEY_SRC_OBJECT = k.rle_key
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY_RLE_ADDR WHERE VERSION_SEQ = 1) xadr
             ON xadr.PKEY_SRC_OBJECT = k.addr_key
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY_RLE_PHN WHERE VERSION_SEQ = 1) xphn
             ON xphn.PKEY_SRC_OBJECT = k.phn_key
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY_RLE_ALT_ID WHERE VERSION_SEQ = 1) xca
             ON xca.PKEY_SRC_OBJECT = k.care_alt_key
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY_RLE_ALT_ID WHERE VERSION_SEQ = 1) xma
             ON xma.PKEY_SRC_OBJECT = k.medicaid_alt_key
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_CRE_PTY_RLE_ALT_ID WHERE VERSION_SEQ = 1) xsa
             ON xsa.PKEY_SRC_OBJECT = k.ssn_alt_key;
    SELECT COUNT(*) INTO :l_rows FROM WRK_CRE_CARE_S5_KEYED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'KEYED_ROUTES_GUARDS', 'COMPLETED', 'CRE_SRC_MRG, C_S_CRE_PTY, C_S_CRE_PTY_RLE, C_S_CRE_PTY_RLE_ADDR, C_S_CRE_PTY_RLE_PHN, C_S_CRE_PTY_RLE_ALT_ID, EXC_STG_BAD_REC_MEMB', 'Step 50 complete.', NULL);
    RETURN :l_rows;
END;
$$;

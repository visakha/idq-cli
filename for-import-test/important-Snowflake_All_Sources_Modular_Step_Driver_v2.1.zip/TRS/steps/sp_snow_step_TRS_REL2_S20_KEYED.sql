-- ============================================================================
-- sp_snow_step_TRS_REL2_S20_KEYED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_Rle_Rel_2_Mem_To_PCP, workflow wf_TRS_Stage_Load_1_Ongoing, step 20.
-- Step name (checkpoint): KEYED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_REL2_S2_KEYED: KEYING -- resolve provider, build keys (BR-37)
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_REL2_S1_SRC'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-20 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   P_PCP_REL_TP.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_REL2_S20_KEYED (
    P_PCP_REL_TP VARCHAR DEFAULT '100',
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_REL2_S1_SRC'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Rle_Rel_2_Mem_To_PCP';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 20: KEYED (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_REL2_S2_KEYED AS
    WITH
    tpi_src_key AS (
        SELECT bo.alt_id_val, xr.pkey_src_object
          FROM C_B_PTY_RLE_ALT_ID bo
         INNER JOIN C_B_PTY_RLE_ALT_ID_XREF xr ON bo.rowid_object = xr.rowid_object
         WHERE bo.alt_id_tp = '006' AND TRIM(xr.rowid_system) = 'C21' AND xr.hub_state_ind = 1
       QUALIFY ROW_NUMBER() OVER (PARTITION BY bo.alt_id_val ORDER BY xr.src_last_upd_dt DESC) = 1
    ),
    keyed AS (
        SELECT s.*,
               IFF(s.PTY_PK IS NULL, NULL, TRIM(s.PTY_PK) || '|Member')                        AS pty_rle_fk_1,
               SUBSTR(TRIM(t.pkey_src_object), 1, REGEXP_INSTR(TRIM(t.pkey_src_object), '[|]', 1, 2) - 1)
                                                                                              AS pty_rle_fk_2,
               IFF(CONTAINS(TRIM(t.pkey_src_object), '|HCO'), 'Member PCO', 'Member PCP')     AS rel_type_code
          FROM WRK_TRS_REL2_S1_SRC s
          LEFT JOIN tpi_src_key t ON t.alt_id_val = s.PROVIDER_NUM
    )
    SELECT k.*,
           NVL(k.pty_rle_fk_1, '') || '|' || NVL(k.pty_rle_fk_2, '') || '|' || :P_PCP_REL_TP AS pkey_src_object,
           /* VALIDATION */ NVL(k.BEGIN_DT > k.END_DT, FALSE)                              AS dates_reversed,
           /* VALIDATION */ (k.pty_rle_fk_1 IS NOT NULL AND k.pty_rle_fk_2 IS NOT NULL
                             AND NVL(k.BEGIN_DT <= k.END_DT OR k.END_DT IS NULL, FALSE))   AS is_valid
      FROM keyed k;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_REL2_S2_KEYED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'KEYED', 'COMPLETED', NULL, 'Step 20 complete.', NULL);
    RETURN :l_rows;
END;
$$;

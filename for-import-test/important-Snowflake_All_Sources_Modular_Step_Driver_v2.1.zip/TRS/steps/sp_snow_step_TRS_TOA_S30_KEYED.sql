-- ============================================================================
-- sp_snow_step_TRS_TOA_S30_KEYED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_Rle_TOA, workflow wf_TRS_Stage_Load_1_Ongoing, step 30.
-- Step name (checkpoint): TOA_KEYED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_TOA_S30_KEYED: TRANSLATE + KEY + FAILURE FLAGS (BR-27)
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_TOA_S20_SRC'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-30 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   none.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_TOA_S30_KEYED (
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_TOA_S20_SRC'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Rle_TOA';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 30: TOA_KEYED (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_TOA_S30_KEYED AS
    SELECT s.*,
           lk.MSTR_REF_CODE AS toa_cd,
           DECODE(s.SRC_TBL, 'LTSS_ELIG_PER', 'DADS', 'MCI_EDG_INDV', 'TIERS') AS toa_source,
           NVL(TO_VARCHAR(s.EDG_NUM), '') || '|' || NVL(TO_VARCHAR(s.PROGRAM_CD), '') || '|'
           || NVL(TO_VARCHAR(s.MCI_CREATE_SEQ), '') AS sgmnt_key,
           s.INDV_ID || '|Member' AS pty_rle_fk,
           s.INDV_ID || '|Member|' || NVL(lk.MSTR_REF_CODE, '') || '|'
           || NVL(DECODE(s.SRC_TBL, 'LTSS_ELIG_PER', 'DADS', 'MCI_EDG_INDV', 'TIERS'), '') || '|'
           || NVL(TO_VARCHAR(s.EDG_NUM), '') || '|' || NVL(TO_VARCHAR(s.PROGRAM_CD), '') || '|'
           || NVL(TO_VARCHAR(s.MCI_CREATE_SEQ), '') AS pkey_src_object,
           lk.MSTR_REF_CODE IS NULL AS grp_bad_value,
           NVL(s.BEGIN_DT > s.END_DT, FALSE) AS grp_dates
      FROM WRK_TRS_TOA_S20_SRC s
      LEFT JOIN (SELECT l.SRC_CODE_VALUE, l.MSTR_REF_CODE FROM LOOKUP_CODE_VALUE l
                  WHERE l.CODE_TYPE = 'TOA' AND l.SRC_SYS = 'TRS'
                QUALIFY ROW_NUMBER() OVER (PARTITION BY l.SRC_CODE_VALUE ORDER BY l.MSTR_REF_CODE) = 1) lk
             ON lk.SRC_CODE_VALUE = s.TYPE_OF_ASSISTANCE_CD;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_TOA_S30_KEYED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'TOA_KEYED', 'COMPLETED', NULL, 'Step 30 complete.', NULL);
    RETURN :l_rows;
END;
$$;

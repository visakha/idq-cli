-- ============================================================================
-- sp_snow_step_TRS_PTY_S40_DEDUP  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_OnGoing, workflow wf_TRS_Stage_Load_1_Ongoing, step 40.
-- Step name (checkpoint): DEDUP_VALID.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_PTY_S4_DEDUP: DEDUP + RANK -- valid rows (BR-12)
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_PTY_S2_DQ'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-40 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   P_RLE_BO_CLASS_CD_MEMBER.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_PTY_S40_DEDUP (
    P_RLE_BO_CLASS_CD_MEMBER VARCHAR DEFAULT 'Member',
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_PTY_S2_DQ'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_OnGoing';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 40: DEDUP_VALID (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_PTY_S4_DEDUP AS
    WITH
    dedup AS (
        SELECT DISTINCT pkey_trim, CREATE_DT, INDV_ID, SRC_TBL, mdm_gender_code, std_sfx_name, std_first_name,
               std_prfx_name, std_lst_name, std_mdl_name, std_birth_date, std_full_name, DEATH_DT, src_full_name,
               RACE_CD, race_mstr, race_exception_code, race_exception_desc, race_exception_type, ETHNICITY_CD,
               ethnicity_mstr, ethnicity_exception_code, ethnicity_exception_desc, ethnicity_exception_type
          FROM WRK_TRS_PTY_S2_DQ
         WHERE std_first_name IS NOT NULL OR std_lst_name IS NOT NULL
    )
    SELECT x.*,
           ROW_NUMBER() OVER (PARTITION BY x.pkey_trim
                              ORDER BY x.CREATE_DT DESC NULLS FIRST, x.INDV_ID DESC NULLS FIRST,
                                       x.SRC_TBL DESC NULLS FIRST, x.mdm_gender_code DESC NULLS FIRST,
                                       x.std_sfx_name DESC NULLS FIRST, x.std_first_name DESC NULLS FIRST,
                                       x.std_prfx_name DESC NULLS FIRST, x.std_lst_name DESC NULLS FIRST,
                                       x.std_mdl_name DESC NULLS FIRST, x.std_birth_date DESC NULLS FIRST,
                                       x.std_full_name DESC NULLS FIRST)               AS rn_pty,
           vm.PTY_PK IS NOT NULL                                                       AS is_valid_member,
           xp.PKEY_SRC_OBJECT IS NULL                                                  AS uq_pty,
           xr2.PKEY_SRC_OBJECT IS NULL                                                 AS uq_rle,
           ROW_NUMBER() OVER (PARTITION BY x.race_exception_code IS NOT NULL, x.pkey_trim,
                                           x.race_exception_type, x.race_exception_code
                                  ORDER BY x.CREATE_DT DESC NULLS FIRST, x.INDV_ID) = 1       AS uq_exc_race,
           ROW_NUMBER() OVER (PARTITION BY x.ethnicity_exception_code IS NOT NULL, x.pkey_trim,
                                           x.ethnicity_exception_type, x.ethnicity_exception_code
                                  ORDER BY x.CREATE_DT DESC NULLS FIRST, x.INDV_ID) = 1       AS uq_exc_ethnicity
      FROM dedup x
      LEFT JOIN (SELECT DISTINCT PTY_PK FROM STG_TRS_VALID_MEMBERS) vm ON vm.PTY_PK = x.pkey_trim
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_TRS_PTY WHERE VERSION_SEQ = 1) xp
             ON xp.PKEY_SRC_OBJECT = x.pkey_trim
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_TRS_PTY_RLE WHERE VERSION_SEQ = 1) xr2
             ON xr2.PKEY_SRC_OBJECT = x.pkey_trim || '|' || :P_RLE_BO_CLASS_CD_MEMBER;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_PTY_S4_DEDUP;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'DEDUP_VALID', 'COMPLETED', NULL, 'Step 40 complete.', NULL);
    RETURN :l_rows;
END;
$$;

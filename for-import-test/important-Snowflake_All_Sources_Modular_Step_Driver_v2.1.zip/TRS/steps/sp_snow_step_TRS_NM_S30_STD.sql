-- ============================================================================
-- sp_snow_step_TRS_NM_S30_STD  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_Nm, workflow wf_TRS_Stage_Load_1_Ongoing, step 30.
-- Step name (checkpoint): STANDARDISED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_NM_S30_STD: STANDARDISED NAMES (BR-15)
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_NM_S20_NAMED'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-30 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   none.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_NM_S30_STD (
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_NM_S20_NAMED'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Nm';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 30: STANDARDISED (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_NM_S30_STD AS
    WITH lkp_junk AS (SELECT * FROM TABLE(fn_snow_helper43_common()))
    SELECT n.*,
           fn_snow_helper15_common(n.tn:first_name::VARCHAR, n.tn:middle_name::VARCHAR, n.tn:last_name::VARCHAR,
                                   n.src_full_name, n.PREFIX_NAME, n.SUFX_NAME, NULL, NULL,
                                   jf.NAME IS NOT NULL, jl.NAME IS NOT NULL) AS nm
      FROM WRK_TRS_NM_S20_NAMED n
      LEFT JOIN lkp_junk jf ON jf.NAME = UPPER(TRIM(n.tn:first_name::VARCHAR)) AND jf.IS_FIRST_JUNK
      LEFT JOIN lkp_junk jl ON jl.NAME = UPPER(TRIM(n.tn:last_name::VARCHAR)) AND jl.IS_LAST_JUNK;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_NM_S30_STD;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'STANDARDISED', 'COMPLETED', NULL, 'Step 30 complete.', NULL);
    RETURN :l_rows;
END;
$$;

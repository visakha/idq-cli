-- ============================================================================
-- sp_snow_step_TRS_ADDR1_S40_READY  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Addr_1, workflow wf_TRS_Stage_Load_1_Ongoing, step 40.
-- Step name (checkpoint): READY_TO_PUBLISH.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_ADDR1_S40_READY: READY -- match-code description, guards
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_ADDR1_S30_VALIDATED'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-40 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   none.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_ADDR1_S40_READY (
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_ADDR1_S30_VALIDATED'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Addr_1';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 40: READY_TO_PUBLISH (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_ADDR1_S40_READY AS
    WITH
    lkp_mc AS (SELECT * FROM TABLE(fn_snow_helper46_common()))
    SELECT v.ADDR_ID, v.av:delivery_address_line1::VARCHAR AS ADDR_LN_1,
           v.av:delivery_address_line2::VARCHAR AS ADDR_LN_2,
           v.av:building_name::VARCHAR AS BLDNG_NM, v.av:sub_building_number::VARCHAR AS FLR_NUM,
           v.av:city::VARCHAR AS CITY, v.av:county_fips_cd::VARCHAR AS COUNTY,
           v.av:state_fips_cd::VARCHAR AS STATE, v.av:country_iso2_char::VARCHAR AS CNTRY_CD,
           v.av:zip_cd_5::VARCHAR AS PSTL_CD, v.av:zip_cd_4_extn::VARCHAR AS PSTL_CD_EXT,
           v.av:geocoding_latitude::NUMBER(38, 6) AS LATTD,
           v.av:geocoding_longitude::NUMBER(38, 6) AS LNGTD,
           v.av:match_code::VARCHAR AS VLDTN_MSG, mc.DESCRIPTION AS VLDTN_DESC,
           v.av:mailability_score::VARCHAR AS MLBLTY_SCR, v.av:address_type::VARCHAR AS ADDR_TP_CD,
           v.av:organization_descriptor::VARCHAR AS ORG_DESC,
           v.av:organization_name::VARCHAR AS ORG_NM, v.av:building_number::VARCHAR AS BLDG_NMBR,
           v.av:sub_building_complete::VARCHAR AS SUB_BLDG_NM,
           v.av:sub_building_descriptor::VARCHAR AS SUB_BLDG_DESC,
           v.av:geocoding_status::VARCHAR AS GEOCD_STS_CD,
           v.av:residential_delivery_indicator::VARCHAR AS RSDNTL_DLVRY_IND,
           v.av:status_info_result_percentage::VARCHAR AS ADDRDR_RSLT_PCT,
           v.av:early_warning_system_return_cd::VARCHAR AS ERLY_WRNG_CD,
           v.av:cass_error_code::VARCHAR AS CASS_ERR_CD,
           v.av:dpv_confirmation::VARCHAR AS DLVRY_PNT_VLDN,
           v.addr_line_1 AS SRC_ADDR_LN_1, v.addr_line_2 AS SRC_ADDR_LN_2,
           v.ADDR_CITY AS SRC_CITY, NULL AS SRC_COUNTY,
           v.ADDR_STATE_CD AS SRC_STATE, 'US' AS SRC_CNTRY,
           v.ADDR_ZIP5 AS SRC_PSTL_CD, v.ADDR_ZIP4 AS SRC_PSTL_CD_EXT,
           v.av:organization_department::VARCHAR AS ORG_DEPT
      FROM WRK_TRS_ADDR1_S30_VALIDATED v
      LEFT JOIN lkp_mc mc ON mc.MATCH_CODE = v.av:status_info_match_code::VARCHAR
      LEFT JOIN (SELECT DISTINCT ADDR_ID FROM STG_TRS_D_UNQ_ADDR) xu ON xu.ADDR_ID = v.ADDR_ID
     WHERE xu.ADDR_ID IS NULL
    QUALIFY ROW_NUMBER() OVER (PARTITION BY v.ADDR_ID ORDER BY v.addr_line_1) = 1;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_ADDR1_S40_READY;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'READY_TO_PUBLISH', 'COMPLETED', 'STG_TRS_D_UNQ_ADDR', 'Step 40 complete.', NULL);
    RETURN :l_rows;
END;
$$;

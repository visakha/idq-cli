-- ============================================================================
-- sp_snow_step_TRS_NM_S40_DEDUP  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_Nm, workflow wf_TRS_Stage_Load_1_Ongoing, step 40.
-- Step name (checkpoint): DEDUP_KEYED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_NM_S40_DEDUP: DE-DUPLICATE + KEY (BR-15)
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_NM_S30_STD'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-40 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   P_MEMBER_NAME_TYPE_CODE.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_NM_S40_DEDUP (
    P_MEMBER_NAME_TYPE_CODE VARCHAR DEFAULT '002',
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_NM_S30_STD'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Nm';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 40: DEDUP_KEYED (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_NM_S40_DEDUP AS
    SELECT DISTINCT s.PKEY_PTY, s.CREATE_DT, s.nm:sfx_name::VARCHAR AS sfx_nm,
           s.nm:first_name::VARCHAR AS frst_nm, s.nm:prfx_name::VARCHAR AS prfx_nm,
           s.nm:last_name::VARCHAR AS lst_nm, s.nm:middle_name::VARCHAR AS mdl_nm,
           s.nm:full_name::VARCHAR AS full_nm, s.src_full_name, s.SEQUENCE_NUM,
           NVL(s.PKEY_PTY, '') || '|' || :P_MEMBER_NAME_TYPE_CODE || '|' || NVL(TO_VARCHAR(s.SEQUENCE_NUM), '')
                                                                                        AS pkey_src_object
      FROM WRK_TRS_NM_S30_STD s;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_NM_S40_DEDUP;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'DEDUP_KEYED', 'COMPLETED', NULL, 'Step 40 complete.', NULL);
    RETURN :l_rows;
END;
$$;

-- ============================================================================
-- sp_snow_step_TRS_PLN_S30_RANKED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- Mapping: m_Tgt_C_S_TRS_Pty_Rle_Pln, workflow wf_TRS_Stage_Load_1_Ongoing, step 30.
-- Step name (checkpoint): RANKED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_TRS_PLN_S30_RANKED: RANK + GUARD + EXCEPTION TEXT (BR-26/02)
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (pipe-delimited). Default: 'WRK_TRS_PLN_S20_PLANNED'.
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-30 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (where used); :c_mapping is
--   the local constant below. No business expression, filter, guard
--   or column list was changed. This step uses original parameters:
--   none.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the 10-argument form. P_JOB_RUN_ID is present in every new proc
--   in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_TRS_PLN_S30_RANKED (
    P_JOB_RUN_ID             VARCHAR DEFAULT NULL,
    P_RUN_TS                 TIMESTAMP_NTZ DEFAULT NULL,
    P_INPUT_TABLES           VARCHAR DEFAULT 'WRK_TRS_PLN_S20_PLANNED'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Rle_Pln';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 30: RANKED (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_PLN_S30_RANKED AS
    WITH lkp_exc AS (SELECT * FROM TABLE(fn_snow_helper40_common()))
    SELECT p.*,
           ROW_NUMBER() OVER (PARTITION BY p.pkey_prty_rl_plan
                              ORDER BY p.BEGIN_DT DESC NULLS FIRST, p.END_DT DESC NULLS FIRST,
                                       p.pty_rle_fk DESC NULLS FIRST, p.CREATE_DT DESC NULLS FIRST) AS rn_key,
           ROW_NUMBER() OVER (PARTITION BY p.INDV_ID, p.pln_mstr_cd IS NULL
                              ORDER BY p.MC_PLAN, p.BEGIN_DT, p.END_DT) AS rn_invalid,
           xp.PKEY_SRC_OBJECT IS NULL AS uq_pln,
           1 AS version_seq,
           'TRS' AS src_sys,
           :P_RUN_TS AS run_ts,
           :c_mapping AS mapping_name,
           'Plan' AS attr_plan,
           'Invalid_Plan' AS exc_code,
           ex.EXCEPTION_DESC AS exc_desc,
           ex.EXCEPTION_TYPE AS exc_type,
           TO_VARCHAR(p.BEGIN_DT, 'YYYY-MM-DD') AS begin_dt_text
      FROM WRK_TRS_PLN_S20_PLANNED p
      LEFT JOIN lkp_exc ex ON ex.EXCEPTION_CODE = 'Invalid_Plan'
      LEFT JOIN (SELECT DISTINCT PKEY_SRC_OBJECT FROM C_S_TRS_PTY_RLE_PLN WHERE VERSION_SEQ = 1) xp
             ON xp.PKEY_SRC_OBJECT = p.pkey_prty_rl_plan;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_PLN_S30_RANKED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'RANKED', 'COMPLETED', NULL, 'Step 30 complete.', NULL);
    RETURN :l_rows;
END;
$$;

-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_1  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (TRS)
--
-- IDQ mapping: m_Tgt_C_S_TRS_Pty_Deactivation_1, workflow wf_TRS_Stage_Load_1_Ongoing.
-- Driver name and signature are EXACTLY as the current main procedure,
-- so every existing CALL still works. Install schema is TRS_ETL_WRK in
-- database MDM_ETL_TRS; all table names below are unqualified, except
-- the config table, which is COMMON-qualified (COMMON.ETL_RUN_CONFIG_TBL).
--
-- BUSINESS FLOW (read this top to bottom -- it IS the business flow)
    Step  5  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
                                  previous run (drops only, no
                                  checkpoint), then rebuild from step 10
    Step  10  DEACTIVATED_INDIVIDUALS WRK_TRS_DEACT1_S10_DEACTV
    Step  20  DEACTIVATED_PER_INDIVIDUAL WRK_TRS_DEACT1_S20_DEACTV_ID
    Step  30  READY_TO_PUBLISH       WRK_TRS_DEACT1_S30_READY
    Step  40  PUBLISH_STG_TRS_DEACTIVED_MEMBERS STG_TRS_DEACTIVED_MEMBERS (Deactivated members)
    Step  50  DELETE_VALID_STAGE_NOT_PERFORMED checkpoint only, writes NO data (see manifest)
    End    TERMINATING             work tables are NOT dropped: they
                                  stay in the database until the next
                                  run of this mapping cleans them up
--
-- CONFIG-DRIVEN NOTES (COMMON.ETL_RUN_CONFIG_TBL)
--   * The driver reads IS_RUN_ENABLED (per STEP_NO) and
--     WORK_TABLES_CONSUMED (per STEP_NO) in ONE SELECT at the start.
--     Flags and consumed strings are pre-initialised to their defaults
--     ('Y' / the step's normal input), so a missing or unreadable
--     config table leaves every step enabled with its normal inputs:
--     the config can only disable steps, never break a run by absence.
--   * A driver row with STEP_NO = 0 and IS_RUN_ENABLED = 'N' skips the
--     WHOLE mapping before step 5 cleanup (no work tables are dropped).
--   * A step/branch row with IS_RUN_ENABLED = 'N' skips just that
--     step/branch: a SKIPPED checkpoint row is written and a plain-text
--     summary line is appended. No other step is auto-skipped: if a
--     downstream step stays enabled while its input step was skipped,
--     that step's input-existence check raises the missing table
--     loudly instead of running on stale data. Disable downstream
--     steps explicitly if you disable an upstream one.
--   * Config columns IS_DEPENDENT, DEPENDENT_ON and
--     WORK_TABLES_PRODUCED are present in the table but are NOT read
--     by this driver; gating is by IS_RUN_ENABLED only.
--   * SKIPPED vocabulary: JOB_CONTROL_ETL.STEP_STATUS has NO CHECK
--     constraint, so 'SKIPPED' rows are used here as in the ECI v2.1
--     template.
--
-- TRANSACTION EDGES (framework rule)
--   Never call a checkpoint between BEGIN TRANSACTION and COMMIT.
--   Steps run (autocommitted) with their own checkpoints first; then
--   ONE publish transaction calls the branch procs (which contain NO
--   checkpoint calls and NO transaction control); then COMMIT; then,
--   and only then, the driver checkpoints each executed branch and
--   writes SKIPPED rows for skipped branches. The exception handler
--   ROLLBACKs first, then checkpoints, so its rows are not rolled back.
--
-- WORK TABLES (all TRANSIENT)
--   WRK_TRS_DEACT1_S10_DEACTV, WRK_TRS_DEACT1_S20_DEACTV_ID, WRK_TRS_DEACT1_S30_READY. They live in the same schema as the targets (unqualified
--   names, as in the original code) and are prefixed WRK_TRS_. They
--   survive a session crash (TRANSIENT, not TEMP), which is what makes
--   inspection after a run possible. No cursor was used: every step
--   here is set-based by design.
--
-- PARITY NOTES (kept deliberately, do not "fix" silently; condensed
-- from the current main header -- see the manifest for the full text)
----   (kept deliberately, do not "fix" silently)
--     * Insert-only, as in the original Snowflake code: no TRUNCATE, no
--       DELETE of targets.  In particular, the IDQ DD_DELETE of
--       STG_TRS_VALID_MEMBERS is NOT performed here (step 50).  That means
--       deactivated members STAY in the valid-member list in the Snowflake
--       version, whereas IDQ removes them -- so downstream Snowflake
--       mappings that join STG_TRS_VALID_MEMBERS will still see
--       deactivated members until some other process removes them.  This
--       is the single largest parity gap in this mapping, and it is a
--       business decision, not a bug to fix in passing: the original
--       Snowflake comment cites it as a deliberate insert-only rule.
--     * STG_TRS_DEACTIVED_MEMBERS has primary key INDV_ID, which Snowflake
--       does not enforce.  An individual can be a valid member under two
--       party keys (INDV_ID|DC_INDV and INDV_ID for MCI); IDQ writes the
--
-- SIGNATURE
--   The original parameters are unchanged and in the same order, so
--   every existing CALL still works. One parameter was APPENDED:
--     P_JOB_RUN_ID   VARCHAR  DEFAULT NULL  -- NULL = start a new run
--                                             (a run id is generated and
--                                             returned in the summary).
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
--   Procedure-call return capture uses `l_rows := (CALL proc(...));`
--   (Snowflake Scripting scalar-call form) -- a compile-time
--   verification item, since there is no live Snowflake here.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_1 (

    P_JOB_RUN_ID  VARCHAR DEFAULT NULL

)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'TRS';
    c_workflow   VARCHAR DEFAULT 'wf_TRS_Stage_Load_1_Ongoing';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Deactivation_1';
    l_run_ts     TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
    l_job_run_id VARCHAR;
    l_rows       NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
    -- Config flags (STEP_NO 0 = driver row, then steps, then branches)
    l_flag_TRS_PTYDEACT_DRIVER     VARCHAR DEFAULT 'Y';
    l_flag_TRS_PTYDEACT_S10_DEACTV VARCHAR DEFAULT 'Y';
    l_flag_TRS_PTYDEACT_S20_DEACTV_ID VARCHAR DEFAULT 'Y';
    l_flag_TRS_PTYDEACT_S30_READY VARCHAR DEFAULT 'Y';
    l_flag_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS VARCHAR DEFAULT 'Y';
    l_flag_TRS_PTYDEACT_S50_NOTPERFORMED VARCHAR DEFAULT 'Y';
    -- Config consumed strings (work-table inputs, per STEP_NO)
    l_in_TRS_PTYDEACT_S10_DEACTV VARCHAR DEFAULT '';
    l_in_TRS_PTYDEACT_S20_DEACTV_ID VARCHAR DEFAULT 'WRK_TRS_DEACT1_S10_DEACTV';
    l_in_TRS_PTYDEACT_S30_READY VARCHAR DEFAULT 'WRK_TRS_DEACT1_S20_DEACTV_ID';
    l_in_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS VARCHAR DEFAULT 'WRK_TRS_DEACT1_S30_READY';
    l_in_TRS_PTYDEACT_S50_NOTPERFORMED VARCHAR DEFAULT '';
    -- Per-branch publish counts (one variable per branch)
    l_pub_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS NUMBER DEFAULT 0;
BEGIN
    -- ---- STARTING: job-run-id generation exactly as in the current main
    IF (l_job_run_id IS NULL OR l_job_run_id = '') THEN
        l_job_run_id := COALESCE(NULLIF(:P_JOB_RUN_ID, ''),
            'TRS_' || TO_CHAR(CURRENT_TIMESTAMP(), 'YYYYMMDD_HH24MISS')
            || '_' || UUID_STRING());
    END IF;
    CALL sp_etl_job_begin('TRS', :c_workflow, :c_mapping, :l_job_run_id);

    -- ---- GATHER config: one SELECT; on exception the pre-initialised
    -- defaults stand (covers a missing/unreadable config table).
    BEGIN
        SELECT COALESCE(MAX(CASE WHEN STEP_NO = 0 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 10 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 20 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 30 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 40 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 50 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 10 THEN WORK_TABLES_CONSUMED END), ''),
               COALESCE(MAX(CASE WHEN STEP_NO = 20 THEN WORK_TABLES_CONSUMED END), 'WRK_TRS_DEACT1_S10_DEACTV'),
               COALESCE(MAX(CASE WHEN STEP_NO = 30 THEN WORK_TABLES_CONSUMED END), 'WRK_TRS_DEACT1_S20_DEACTV_ID'),
               COALESCE(MAX(CASE WHEN STEP_NO = 40 THEN WORK_TABLES_CONSUMED END), 'WRK_TRS_DEACT1_S30_READY'),
               COALESCE(MAX(CASE WHEN STEP_NO = 50 THEN WORK_TABLES_CONSUMED END), '')
          INTO :l_flag_TRS_PTYDEACT_DRIVER, :l_flag_TRS_PTYDEACT_S10_DEACTV, :l_flag_TRS_PTYDEACT_S20_DEACTV_ID, :l_flag_TRS_PTYDEACT_S30_READY, :l_flag_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS, :l_flag_TRS_PTYDEACT_S50_NOTPERFORMED,
               :l_in_TRS_PTYDEACT_S10_DEACTV, :l_in_TRS_PTYDEACT_S20_DEACTV_ID, :l_in_TRS_PTYDEACT_S30_READY, :l_in_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS, :l_in_TRS_PTYDEACT_S50_NOTPERFORMED
          FROM COMMON.ETL_RUN_CONFIG_TBL
         WHERE WORKFLOW_NAME = :c_workflow
           AND MAPPING_NAME = :c_mapping;
    EXCEPTION
        WHEN OTHER THEN
            -- Defaults stand: re-assert them explicitly.
            l_flag_TRS_PTYDEACT_DRIVER := 'Y'; l_flag_TRS_PTYDEACT_S10_DEACTV := 'Y'; l_flag_TRS_PTYDEACT_S20_DEACTV_ID := 'Y'; l_flag_TRS_PTYDEACT_S30_READY := 'Y'; l_flag_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS := 'Y'; l_flag_TRS_PTYDEACT_S50_NOTPERFORMED := 'Y';
            l_in_TRS_PTYDEACT_S10_DEACTV := ''; l_in_TRS_PTYDEACT_S20_DEACTV_ID := 'WRK_TRS_DEACT1_S10_DEACTV'; l_in_TRS_PTYDEACT_S30_READY := 'WRK_TRS_DEACT1_S20_DEACTV_ID'; l_in_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS := 'WRK_TRS_DEACT1_S30_READY'; l_in_TRS_PTYDEACT_S50_NOTPERFORMED := '';
    END;

    -- ---- Driver-row disable: skip the whole mapping BEFORE step 5 cleanup
    IF (:l_flag_TRS_PTYDEACT_DRIVER = 'N') THEN
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'MAPPING_SKIPPED', 'SKIPPED', NULL, 'Mapping skipped by ETL_RUN_CONFIG_TBL (STEP_NO = 0, IS_RUN_ENABLED = N).', NULL);
        l_summary := 'm_Tgt_C_S_TRS_Pty_Deactivation_1 SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
        CALL sp_etl_job_finish('TRS', :l_job_run_id, :c_workflow, :c_mapping,
            'm_Tgt_C_S_TRS_Pty_Deactivation_1 skipped by config. JOB_RUN_ID = ' || :l_job_run_id);
        RETURN 'JOB_RUN_ID=' || :l_job_run_id || CHR(10) || l_summary;
    END IF;

    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Drops only, no checkpoint call for drops. UNCHANGED from current main.
    DROP TABLE IF EXISTS WRK_TRS_DEACT1_S10_DEACTV;
    DROP TABLE IF EXISTS WRK_TRS_DEACT1_S20_DEACTV_ID;
    DROP TABLE IF EXISTS WRK_TRS_DEACT1_S30_READY;

    -- ---- Step 10: DEACTIVATED_INDIVIDUALS
    IF (:l_flag_TRS_PTYDEACT_S10_DEACTV = 'Y') THEN
        l_rows := (CALL sp_snow_step_TRS_PTYDEACT_S10_DEACTV(:l_job_run_id, :l_run_ts, :l_in_TRS_PTYDEACT_S10_DEACTV));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 DEACTIVATED_INDIVIDUALS', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'DEACTIVATED_INDIVIDUALS', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 10 DEACTIVATED_INDIVIDUALS: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- Step 20: DEACTIVATED_PER_INDIVIDUAL
    IF (:l_flag_TRS_PTYDEACT_S20_DEACTV_ID = 'Y') THEN
        l_rows := (CALL sp_snow_step_TRS_PTYDEACT_S20_DEACTV_ID(:l_job_run_id, :l_run_ts, :l_in_TRS_PTYDEACT_S20_DEACTV_ID));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 DEACTIVATED_PER_INDIVIDUAL', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'DEACTIVATED_PER_INDIVIDUAL', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 20 DEACTIVATED_PER_INDIVIDUAL: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- Step 30: READY_TO_PUBLISH
    IF (:l_flag_TRS_PTYDEACT_S30_READY = 'Y') THEN
        l_rows := (CALL sp_snow_step_TRS_PTYDEACT_S30_READY(:l_job_run_id, :l_run_ts, :l_in_TRS_PTYDEACT_S30_READY));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 READY_TO_PUBLISH', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'READY_TO_PUBLISH', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 30 READY_TO_PUBLISH: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- PUBLISH: ONE transaction, all enabled branches, in order ----
    -- This is the ONLY step that writes to final targets. Branch procs
    -- contain no checkpoint calls and no transaction control; the
    -- driver checkpoints each branch AFTER COMMIT below.
    BEGIN TRANSACTION;
    IF (:l_flag_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS = 'Y') THEN
        l_pub_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS := (CALL sp_snow_pub_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS(:l_job_run_id, :l_run_ts, :l_in_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS));
    END IF;
    COMMIT;

    -- ---- Publish checkpoints AFTER COMMIT (one per branch) ----
    IF (:l_flag_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS = 'Y') THEN
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_STG_TRS_DEACTIVED_MEMBERS', 'COMPLETED', 'STG_TRS_DEACTIVED_MEMBERS', 'Published Deactivated members to STG_TRS_DEACTIVED_MEMBERS.', NULL);
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 40 PUBLISH_STG_TRS_DEACTIVED_MEMBERS', :l_pub_TRS_PTYDEACT_STG_TRS_DEACTIVED_MEMBERS) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_STG_TRS_DEACTIVED_MEMBERS', 'SKIPPED', 'STG_TRS_DEACTIVED_MEMBERS', 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 40 PUBLISH_STG_TRS_DEACTIVED_MEMBERS: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- Step 50: DELETE_VALID_STAGE_NOT_PERFORMED (checkpoint-only, AFTER publish -- original order)
    IF (:l_flag_TRS_PTYDEACT_S50_NOTPERFORMED = 'Y') THEN
        l_rows := (CALL sp_snow_step_TRS_PTYDEACT_S50_NOTPERFORMED(:l_job_run_id, :l_run_ts, :l_in_TRS_PTYDEACT_S50_NOTPERFORMED));
        l_summary := l_summary || 'step 50 DELETE_VALID_STAGE_NOT_PERFORMED: recorded, no data written (deliberate, see manifest)' || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'DELETE_VALID_STAGE_NOT_PERFORMED', 'SKIPPED', 'STG_TRS_VALID_MEMBERS', 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 50 DELETE_VALID_STAGE_NOT_PERFORMED: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- TERMINATING ------------------------------------------------------
    CALL sp_etl_job_finish('TRS', :l_job_run_id, :c_workflow, :c_mapping,
        'm_Tgt_C_S_TRS_Pty_Deactivation_1 completed. JOB_RUN_ID = ' || :l_job_run_id);
    RETURN 'JOB_RUN_ID=' || :l_job_run_id || CHR(10) || l_summary;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        CALL sp_etl_checkpoint('TRS', :l_job_run_id, :c_workflow, :c_mapping, 'TERMINATING',
            'JOB_END', 'FAILED', NULL, 'Job failed; work tables left in place until the next run of this mapping cleans them up at its start. ' || 'See INFORMATION_SCHEMA.TABLES for WRK_% tables in this schema and VW_ETL_JOB_STORY for the last completed step.', 'See Snowflake query history for this JOB_RUN_ID for the underlying error.');
        CALL sp_etl_job_fail('TRS', :l_job_run_id, :c_workflow, :c_mapping,
            'm_Tgt_C_S_TRS_Pty_Deactivation_1 failed; work tables left in place until the next run of this mapping cleans them up at its start.');
        RAISE;
END;
$$;

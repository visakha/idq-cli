# All-sources modular step drivers — v2.1 style

Every `_main_` procedure from the multi-source simplified package,
refactored the way the ECI example was: each main is now a thin
**driver** that reads a config table and conditionally calls separate
**step** procedures and per-branch **publish** procedures. Business
SQL is preserved verbatim; nothing was fixed, nothing was invented.

## Contents

| Source | Mappings (drivers) | Steps | Publish branches | Seed rows |
|---|---|---|---|---|
| TRS | 15 | 66 | 38 | 119 |
| ECI | 9 | 32 | 26 | 67 |
| WIC | 5 | 17 | 19 | 41 |
| TTF | 4 | 12 | 13 | 29 |
| FSS | 6 | 21 | 23 | 50 |
| CRE | 1 | 5 | 18 | 24 |
| **Total** | **40** | **153** | **137** | **330** |

Steps include one checkpoint-only step (TRS party-deactivation
`DELETE_VALID_STAGE_NOT_PERFORMED`, step 50, which records a status
and writes no data — see its manifest). ECI's portion is copied
verbatim from the ECI v2.1 example package (content-diff verified);
the other five sources were rebuilt in exactly that style.

## Layout

```
00_framework/          shared framework (ONE copy, not per source)
  01_job_control_ddl.sql      JOB_CONTROL_ETL + views (v2.1 form)
  02_job_control_procs.sql    sp_etl_job_begin/checkpoint/finish/fail
  03_etl_run_config_ddl.sql   ETL_RUN_CONFIG_TBL
  common/                     the 2 shared helper files, unchanged
ECI/                   v2.1 layout, verbatim (per-mapping folders)
TRS/ WIC/ TTF/ FSS/ CRE/
  drivers/             one driver per mapping, name/signature identical
                       to the current main
  steps/               sp_snow_step_<PREFIX>_S<nn>_<NAME>
  publish/             sp_snow_pub_<PREFIX>_<TARGET>[_<BRANCH>]
  manifests/           one manifest per mapping, with a phase-flow diagram
  runners/             workflow runners, verbatim from the multi-source
                       package (driver names unchanged, so calls resolve)
  seed_etl_run_config_<SRC>.sql
  <SRC>_STEP_MAP.md    <SRC>_DEPENDENCIES.md
README.md  DEPENDENCIES.md  STEP_MAP_ALL_SOURCES.md  COMPILE_NOTES.md
```

ECI keeps its v2.1 per-mapping folder layout; the five rebuilt
sources use the `drivers/steps/publish/manifests` layout. ECI's 9
manifests are the v2.1 originals and predate the phase-flow diagrams
— the 31 rebuilt mappings' manifests each carry one; the generic
driver flow below applies to all 40 drivers identically.

## Install topology

Shared framework goes to the COMMON schema (established topology:
`MDM_ETL_COMMON.COMMON`); each source's drivers, steps, publish
procs, work tables and targets go to its own source schema
(`MDM_ETL_<SRC>.<SRC>_ETL_WRK`). Drivers reference the config table
two-part as `COMMON.ETL_RUN_CONFIG_TBL`, which resolves in the
caller's current database — see the open question on two-part vs
three-part qualification below. **Do not install into a personal
database** (`USER$<name>`): personal databases refuse table creation
(see COMPILE_NOTES.md). **After any `CREATE SCHEMA`, re-issue
`USE SCHEMA`**: creating a schema switches the session's current
schema to the new one (verified by experiment during the ECI v2.1
live compile), so an install script that relies on `USE SCHEMA`
surviving a `CREATE SCHEMA` will silently place objects in the wrong
schema. Prefer fully qualified names in install scripts.

## How a driver runs

```mermaid
flowchart LR
    subgraph P1["Phase 1 - Begin"]
        direction TB
        A["Job begin"]
    end
    subgraph P2["Phase 2 - Configure"]
        direction TB
        B["Config gather"] --> C["Driver gate"]
    end
    subgraph P3["Phase 3 - Clean"]
        direction TB
        D["Step 5 cleanup"]
    end
    subgraph P4["Phase 4 - Transform"]
        direction TB
        E["Work steps 10 to 50"]
    end
    subgraph P5["Phase 5 - Publish"]
        direction TB
        F["Publish branches one transaction"]
    end
    subgraph P6["Phase 6 - Close"]
        direction TB
        G["Job end"] --> H["RETURN summary"] --> I["Work tables left standing"]
    end
    P1 --> P2 --> P3 --> P4 --> P5 --> P6
```

- **Begin.** `sp_etl_job_begin` writes the STARTING row
  (STEP_NO 0). Drivers keep the current mains' names and signatures
  exactly, so existing runner calls work unchanged.
- **Configure.** ONE `SELECT` from `COMMON.ETL_RUN_CONFIG_TBL`
  gathers `IS_RUN_ENABLED` and `WORK_TABLES_CONSUMED` per STEP_NO
  (`MAX(CASE...)` aggregates) into flag variables
  (`l_flag_<UNIT>`) and consumed-table variables (`l_in_<UNIT>`).
  Flags are pre-initialised to `'Y'` and consumed strings to their
  defaults, so a missing table or missing row leaves everything
  enabled with normal inputs. A nested `BEGIN/EXCEPTION` defaults
  everything to `'Y'` if the table is missing or unreadable. The
  driver does **not** validate flag consistency — that is the
  operator's job (see below).
- **Driver gate.** A driver row (STEP_NO 0) with `IS_RUN_ENABLED =
  'N'` skips the whole mapping **before** step-5 cleanup (no work
  tables are dropped) and writes a SKIPPED row.
- **Clean (step 5).** The driver drops **all** of the mapping's work
  tables (`DROP TABLE IF EXISTS`, no checkpoints), regardless of
  which later steps are enabled. Work tables are TRANSIENT
  (`WRK_<SRC>_*`), never TEMP, never cursors.
- **Transform.** Each work step is its own procedure
  (`sp_snow_step_<PREFIX>_S<nn>_<NAME>`), called conditionally on
  its flag. A step takes only the original params its SQL uses (in
  original order) plus `P_JOB_RUN_ID`, `P_RUN_TS`, and
  `P_INPUT_TABLES` (pipe-delimited work-table inputs, defaulted to
  the step's normal inputs). It checks those inputs exist via
  `INFORMATION_SCHEMA.TABLES` plus an `EXECUTE IMMEDIATE` probe —
  `RAISE` cannot carry a dynamic table name, so the native
  missing-table error surfaces — then runs its CTAS verbatim and
  writes its own checkpoint. `P_INPUT_TABLES` is a declaration +
  check, **not** dynamic SQL: CTAS statements still name their
  tables literally.
- **Publish.** Each publish INSERT from the current main is its own
  procedure (`sp_snow_pub_<PREFIX>_<TARGET>[_<BRANCH>]`), in file
  order. The first branch takes the current publish step number,
  +10 per branch. Publish procs contain **no** checkpoint calls and
  **no** transaction statements. The driver opens **one**
  transaction across all enabled branches, calls them, COMMITs, and
  only then checkpoints each executed branch (SKIPPED rows for
  skipped branches). A publish either lands completely or not at
  all. The exception handler ROLLBACKs first, then checkpoints, so
  its rows are not rolled back.
- **Close.** `sp_etl_job_finish` writes the TERMINATING row
  (STEP_NO 999). Work tables are **left standing** until the next
  run of the mapping cleans them up at its step 5. Restart is simply
  a new run. Each procedure RETURNs its row count; the driver
  RETURNs a human-readable summary.

Where a mapping's flow has genuinely distinct stages, its manifest
diagram splits Transform (e.g. Snapshot vs Validate, Keys vs Dedup)
and labels Publish branch groups (spine / status / exception /
validation) — but Publish is always a single subgraph and a single
transaction, never split across columns.

## The config table

`COMMON.ETL_RUN_CONFIG_TBL`, one row per driver row, step, and
publish branch (330 seed rows in this package, all `'Y'`). Columns:
the operator's 8 — `WORKFLOW_NAME`, `MAPPING_NAME`, `IS_DRIVER`,
`IS_RUN_ENABLED`, `IS_DEPENDENT`, `DEPENDENT_ON`,
`WORK_TABLES_PRODUCED`, `WORK_TABLES_CONSUMED` — plus the three
required addressing columns — `STEP_NO`, `STEP_PROC_NAME`,
`STEP_KIND`. There is **no** `SOURCE` column: workflow + mapping
names are already globally unique (`wf_TRS_*`, `wf_ECI_*`, …).

### The toggle contract (the only thing the operator touches)

- You only toggle `IS_RUN_ENABLED`. Every other column is
  informational for a driver run, except `IS_DRIVER` (the STEP_NO 0
  row gates the whole mapping) and `WORK_TABLES_CONSUMED` (passed to
  each unit as `P_INPUT_TABLES`).
- Only exact `'Y'` runs a step/branch; only exact `'N'` on the
  driver row skips the whole mapping. A missing row or missing table
  defaults to `'Y'`.
- Disabling an upstream step while a downstream step stays enabled
  **will fail loudly on the missing work table** (step 5 drops all
  work tables regardless of flags). That is designed behaviour, not
  a bug — disable downstream steps explicitly.

## Checkpoints (v2.1 form, lossy by design)

`sp_etl_checkpoint` takes exactly 10 positional parameters, in this
order: `P_SOURCE`, `P_JOB_RUN_ID`, `P_WORKFLOW_NAME`,
`P_MAPPING_NAME`, `P_STATE` (STARTING | WORKING | TERMINATING),
`P_STEP_NAME`, `P_STEP_STATUS`, `P_TARGET_TABLE`, `P_MESSAGE`,
`P_ERROR_MESSAGE` (last three `DEFAULT NULL`).
`sp_etl_job_begin/finish/fail` are untouched and still write STEP_NO
0/999. DDL consequences, as in ECI v2.1: `STEP_NO` is nullable in
`JOB_CONTROL_ETL`; `VW_ETL_JOB_STEPS` repartitions by `STEP_NAME`;
`VW_ETL_OPEN_WORK_TABLES` is removed, with a documented
`INFORMATION_SCHEMA` replacement query for listing open work tables;
`SKIPPED` is in the `STEP_STATUS` comment. **Lossy by design:**
per-step row counts and work-table registry entries no longer land
in `JOB_CONTROL_ETL` from checkpoint rows — counts survive only in
procedure RETURN summaries, step identity is by `STEP_NAME`,
ordering by `EVENT_ID`. Flag variables are named after their own
unit (`l_flag_<UNIT>`, `l_in_<UNIT>`, `l_pub_<UNIT>`); dependencies
live in `l_in_*` variables, config `DEPENDENT_ON`, and
`DEPENDENCIES.md` — never in flag names.

## Mechanical compile fixes applied (from the ECI v2.1 live compile)

No live Snowflake compile was performed for this package (per
instruction — see COMPILE_NOTES.md). The error classes found by the
ECI v2.1 live compile were applied mechanically throughout:

1. `COMMENT ON ... IS` takes a string literal only — never
   `||`-concatenated comments. (This package emits no `COMMENT ON`
   statements in the rebuilt sources; the framework comments are the
   v2.1 single-literal form.)
2. Never a required parameter after an optional one. Where a step's
   original params carry defaults before `P_JOB_RUN_ID`/`P_RUN_TS`,
   those trailing params carry `DEFAULT NULL`. Parameters are
   **never reordered** — drivers pass positionally.
3. Lookup UDFs are unchanged. Missing reference objects are
   documented, never invented (see below).
4. Install scripts must use fully qualified names or re-issue
   `USE SCHEMA` after any `CREATE SCHEMA`, and must not target
   personal databases (see Install topology above).

## Missing reference objects (documented, never invented)

The shared lookup functions (`fn_snow_helper40–47_common`) read
seven reference objects whose real definitions must exist at install
time: `V_LOOKUP_CODE_VALUE`, `REF_JUNK_NAME_LIST`,
`REF_MATCHCODE_DESC`, `RDM.REF_PHN_AREA_CD` (already flagged as
missing from the Oracle exports) plus `EXC_LOOKUP_CODE_VALUE`,
`LOOKUP_CODE_VALUE`, `REF_DYLGHT_SVNGS_TM` (surfaced by the ECI v2.1
live compile). Until they exist, any mapping path that calls those
helpers fails at runtime — that is a data-supply item, not a code
defect. The ECI v2.1 compile validated the lookup functions against
scratch-only stubs; the stubs are not shipped here.

## Preserved quirks (headlines — full detail in each manifest)

Business logic was preserved, not fixed. Headlines: insert-only
everywhere (no IDQ TRUNCATE; `uq_*` guards); TRS party deactivation
does not delete from the valid-member spine (largest parity gap);
TRS Auth_Rep does not delete its own attribute type before loading;
TRS relationship deactivation capture leaves `PROCESSED_YN` to its
column default; TRS stored filters (`INDV_ID = 504937068`,
`rownum < 100000`) not applied; ECI Medicaid reactivation
default-`'N'` defect; FSS Validation reactivation writes the status
table, not the log; WIC/TTF/FSS/TRS reactivation via the log only
(no IDQ-style status-row delete), so reactivated parties stay
excluded downstream in Snowflake; CRE end-dated B/D timeline
(start = last-update − 1 day, action 2). Thin splits carried over
as flagged: Alt_Id mappings and ECI reactivation mappings.

## What is NOT validated

- **No live Snowflake compile, run, or row-count parity run for this
  package** (per instruction). Compile-time constructs that still
  need a live run to confirm: the `l_rows := (CALL proc(...));`
  scalar-call capture, `IF` blocks inside the publish transaction
  region, multi-variable GATHER `SELECT ... INTO`, and the
  empty-transaction path (all branches of a mapping skipped).
- A run against real source tables is still required before
  production use, as is row-count parity against IDQ.
- Static verification performed instead is documented in
  COMPILE_NOTES.md (184 checks, 0 failures, including full
  business-SQL multiset comparison for the five rebuilt sources).

## Open questions

Carried from ECI v2.1 (still applicable, still awaiting feedback):
one publish transaction vs per-branch transactions; config-consumed
tables passed vs proc defaults; the added config columns
(`STEP_NO`, `STEP_PROC_NAME`, `STEP_KIND`); `IS_DRIVER` (STEP_NO 0)
gating semantics; step 5 drops-all vs enabled-only; per-INSERT
granularity of checkpoints; the ADR `DQM_ADDRESS` validation-mart
branch (present in every source's Addr mapping, preserved in file
order — confirm it belongs); config-table two-part
(`COMMON.ETL_RUN_CONFIG_TBL`) vs three-part
(`MDM_ETL_COMMON.COMMON.ETL_RUN_CONFIG_TBL`) qualification —
two-part resolves in the caller's database, which is wrong if the
table lives in `MDM_ETL_COMMON` while mappings run in
`MDM_ETL_<SRC>`; the `SKIPPED` status value; and confirmation that
the lossy checkpoint simplification is acceptable.

New in this package: the TRS party-deactivation checkpoint-only
step 50 (`DELETE_VALID_STAGE_NOT_PERFORMED`) runs after the publish
transaction commits, preserving the original order (publish 40,
then record 50) — confirm that placement. TRS driver exception
messages mention `VW_ETL_JOB_STORY` alongside the
`INFORMATION_SCHEMA` query; that view exists in the v2.1 framework,
so no change was made. One dropped comment, not business SQL: TRS
Rel_2 step 10's CTAS trailing comment (`-- Filt_Numeric_Prov` after
the final semicolon) is not carried into the step file.

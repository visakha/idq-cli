-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_FSS_Pty_Addr  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (FSS)
--
-- IDQ mapping: m_Tgt_C_S_FSS_Pty_Addr, workflow wf_FSS_Stage_Load.
-- Install schema is FSS_ETL_WRK in database MDM_ETL_FSS; all table
-- names below are unqualified, except the config table, which is
-- COMMON-qualified (COMMON.ETL_RUN_CONFIG_TBL).
-- Driver name and signature are EXACTLY as the current main procedure,
-- so every existing CALL still works.
--
-- WHAT THIS MAPPING DOES, IN PLAIN WORDS
--   Loads FSS party-role addresses: every active address goes to the DQM_ADDRESS validation mart, good addresses (score 100) to the spine, exception addresses (score 40) to the exception log.
--
-- BUSINESS FLOW (read this top to bottom -- it IS the business flow)
--   Step  5  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
--                                  previous run (drops only, no
--                                  checkpoint), then rebuild from step 10
--   Step 10  SRC_ACTIVE             Source addresses with address key built, deactivated parties removed
--   Step 20  VALIDATED              Address validation result attached, state code translated
--   Step 30  FLAT                   Validation result flattened into plain columns, match-code description resolved
--   Step 40  SCORED                 Good / exception score, held address lines, exception details, insert-only guards
--   ---- PUBLISH (one transaction; branches below, in order) --------
--   Step 50  PUBLISH_DQM_ADDRESS    Every active address to the validation mart -> DQM_ADDRESS (VALIDATION)
--   Step 60  PUBLISH_C_S_FSS_PTY_RLE_ADDR Good addresses -> C_S_FSS_PTY_RLE_ADDR (SPINE)
--   Step 70  PUBLISH_EXC            Exception addresses -> EXC_STG_BAD_REC_MEMB (EXCEPTION)
--   End    TERMINATING             work tables are NOT dropped: they
--                                  stay in the database until the next
--                                  run of this mapping cleans them up
--
-- CONFIG-DRIVEN NOTES (COMMON.ETL_RUN_CONFIG_TBL)
--   * The driver reads IS_RUN_ENABLED (per STEP_NO) and
--     WORK_TABLES_CONSUMED (per STEP_NO) in ONE SELECT at the start.
--     Flags and consumed strings are pre-initialised to their defaults
--     ('Y' / the step's normal input), so a missing or unreadable
--     config table leaves every step enabled with its normal inputs:
--     the config can only disable steps, never break a run by absence.
--   * A driver row with STEP_NO = 0 and IS_RUN_ENABLED = 'N' skips the
--     WHOLE mapping before step 5 cleanup (no work tables are dropped).
--   * A step/branch row with IS_RUN_ENABLED = 'N' skips just that
--     step/branch: a SKIPPED checkpoint row is written and a plain-text
--     summary line is appended (helper36 is NOT used for skips -- it
--     renders NULL as '0 row(s)'). No other step is auto-skipped: if a
--     downstream step stays enabled while its input step was skipped,
--     that step's input-existence check raises the missing table
--     loudly instead of running on stale data. Disable downstream
--     steps explicitly if you disable an upstream one.
--   * Config columns IS_DEPENDENT, DEPENDENT_ON and
--     WORK_TABLES_PRODUCED are present in the table but are NOT read
--     by this driver; gating is by IS_RUN_ENABLED only.
--   * SKIPPED vocabulary: JOB_CONTROL_ETL.STEP_STATUS has NO CHECK
--     constraint (a DDL comment that in v2 lists STARTED | COMPLETED | FAILED | SKIPPED), so 'SKIPPED' rows are used here and are flagged to the
--     user as a choice to confirm.
--
-- TRANSACTION EDGES (framework rule)
--   Never call a checkpoint between BEGIN TRANSACTION and COMMIT.
--   Steps run (autocommitted) with their own checkpoints first; then
--   ONE publish transaction calls the branch procs (which contain NO
--   checkpoint calls and NO transaction control); then COMMIT; then,
--   and only then, the driver checkpoints each executed branch and
--   writes SKIPPED rows for skipped branches. The exception handler
--   ROLLBACKs first, then checkpoints, so its rows are not rolled back.
--
-- WORK TABLES (all TRANSIENT)
--   WRK_FSS_ADDR_S1_SRC, WRK_FSS_ADDR_S2_VALIDATED, WRK_FSS_ADDR_S3_FLAT, WRK_FSS_ADDR_S4_SCORED.
--   They live in the same schema as the targets (unqualified names, as
--   in the original code) and are prefixed WRK_FSS_. They survive a
--   session crash (TRANSIENT, not TEMP), which is what makes inspection
--   after a run possible. No CURSOR was used: every step here is
--   set-based by design.
--
-- PARITY NOTES (kept deliberately, do not "fix" silently)
--   * Insert-only: no TRUNCATE, no DELETE of targets. The IDQ truncate of the address table is NOT performed; keys already present are skipped instead (uq_addr guard).
--   * PRESERVED: the address type is the constant '002' (physical mail), so the score depends only on the mailability score and the match code; with the pass-through validator both are blank and every address scores '100' (good).
--   * PRESERVED: the address-quality key adds the family marker 'F' only for source type 'FSS_FAMILY', which never occurs in FSS source rows (carried over from the mapping this one was copied from).
--   * PRESERVED: the zip extension is blank on both the address and the exception rows (the extension port is unfed), and the period end date, period reference time and several address ports are written as NULL (unfed ports), exactly as in the original.
--   * Version sequence is 1, the period start date is the create date, the effective start date is the last-update date, and the effective end date is NULL, exactly as in the original.
--
-- SIGNATURE
--   The original parameters are unchanged and in the same order, so
--   every existing CALL still works. One parameter was APPENDED:
--     P_JOB_RUN_ID   VARCHAR  DEFAULT NULL  -- NULL = start a new run
--                                             (a run id is generated and
--                                             returned in the summary).
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
--   Procedure-call return capture uses `l_rows := (CALL proc(...));`
--   (Snowflake Scripting scalar-call form) -- a compile-time
--   verification item, since there is no live Snowflake here.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_FSS_Pty_Addr (
    P_MEMBER_HIERARCHY_CODE VARCHAR DEFAULT 'Member',
    P_MEMBER_HM_REL_TP_CD   VARCHAR DEFAULT 'Member Addr',
    P_JOB_RUN_ID            VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'FSS';
    c_workflow   VARCHAR DEFAULT 'wf_FSS_Stage_Load';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_FSS_Pty_Addr';
    l_run_ts     TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
    l_job_run_id VARCHAR;
    l_rows       NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
    -- Config flags (STEP_NO 0 = driver row, then steps, then branches)
    l_flag_FSS_ADR_DRIVER                                VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_S10_SRC                               VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_S20_VALIDATED                         VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_S30_FLAT                              VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_S40_SCORED                            VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_DQM_ADDRESS                           VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_C_S_FSS_PTY_RLE_ADDR                  VARCHAR DEFAULT 'Y';
    l_flag_FSS_ADR_EXC_STG_BAD_REC_MEMB                  VARCHAR DEFAULT 'Y';
    -- Config consumed strings (work-table inputs, per STEP_NO)
    l_in_FSS_ADR_S10_SRC                                 VARCHAR DEFAULT '';
    l_in_FSS_ADR_S20_VALIDATED                           VARCHAR DEFAULT 'WRK_FSS_ADDR_S1_SRC';
    l_in_FSS_ADR_S30_FLAT                                VARCHAR DEFAULT 'WRK_FSS_ADDR_S2_VALIDATED';
    l_in_FSS_ADR_S40_SCORED                              VARCHAR DEFAULT 'WRK_FSS_ADDR_S3_FLAT';
    l_in_FSS_ADR_DQM_ADDRESS                             VARCHAR DEFAULT 'WRK_FSS_ADDR_S4_SCORED';
    l_in_FSS_ADR_C_S_FSS_PTY_RLE_ADDR                    VARCHAR DEFAULT 'WRK_FSS_ADDR_S4_SCORED';
    l_in_FSS_ADR_EXC_STG_BAD_REC_MEMB                    VARCHAR DEFAULT 'WRK_FSS_ADDR_S4_SCORED';
    -- Per-branch publish counts (one variable per branch)
    l_pub_FSS_ADR_DQM_ADDRESS                            NUMBER DEFAULT 0;
    l_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR                   NUMBER DEFAULT 0;
    l_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB                   NUMBER DEFAULT 0;
BEGIN
    -- ---- STARTING: job-run-id generation exactly as in the current main
    IF (l_job_run_id IS NULL OR l_job_run_id = '') THEN
        l_job_run_id := COALESCE(NULLIF(:P_JOB_RUN_ID, ''),
            'FSS_' || TO_CHAR(CURRENT_TIMESTAMP(), 'YYYYMMDD_HH24MISS')
            || '_' || UUID_STRING());
    END IF;
    CALL sp_etl_job_begin('FSS', :c_workflow, :c_mapping, :l_job_run_id);

    -- ---- GATHER config: one SELECT; on exception the pre-initialised
    -- defaults stand (covers a missing/unreadable config table).
    BEGIN
        SELECT COALESCE(MAX(CASE WHEN STEP_NO = 0 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 10 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 20 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 30 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 40 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 50 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 60 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 70 THEN IS_RUN_ENABLED END), 'Y'),
               COALESCE(MAX(CASE WHEN STEP_NO = 10 THEN WORK_TABLES_CONSUMED END), ''),
               COALESCE(MAX(CASE WHEN STEP_NO = 20 THEN WORK_TABLES_CONSUMED END), 'WRK_FSS_ADDR_S1_SRC'),
               COALESCE(MAX(CASE WHEN STEP_NO = 30 THEN WORK_TABLES_CONSUMED END), 'WRK_FSS_ADDR_S2_VALIDATED'),
               COALESCE(MAX(CASE WHEN STEP_NO = 40 THEN WORK_TABLES_CONSUMED END), 'WRK_FSS_ADDR_S3_FLAT'),
               COALESCE(MAX(CASE WHEN STEP_NO = 50 THEN WORK_TABLES_CONSUMED END), 'WRK_FSS_ADDR_S4_SCORED'),
               COALESCE(MAX(CASE WHEN STEP_NO = 60 THEN WORK_TABLES_CONSUMED END), 'WRK_FSS_ADDR_S4_SCORED'),
               COALESCE(MAX(CASE WHEN STEP_NO = 70 THEN WORK_TABLES_CONSUMED END), 'WRK_FSS_ADDR_S4_SCORED')
          INTO :l_flag_FSS_ADR_DRIVER, :l_flag_FSS_ADR_S10_SRC, :l_flag_FSS_ADR_S20_VALIDATED, :l_flag_FSS_ADR_S30_FLAT, :l_flag_FSS_ADR_S40_SCORED, :l_flag_FSS_ADR_DQM_ADDRESS, :l_flag_FSS_ADR_C_S_FSS_PTY_RLE_ADDR, :l_flag_FSS_ADR_EXC_STG_BAD_REC_MEMB, :l_in_FSS_ADR_S10_SRC, :l_in_FSS_ADR_S20_VALIDATED, :l_in_FSS_ADR_S30_FLAT, :l_in_FSS_ADR_S40_SCORED, :l_in_FSS_ADR_DQM_ADDRESS, :l_in_FSS_ADR_C_S_FSS_PTY_RLE_ADDR, :l_in_FSS_ADR_EXC_STG_BAD_REC_MEMB
          FROM COMMON.ETL_RUN_CONFIG_TBL
         WHERE WORKFLOW_NAME = :c_workflow
           AND MAPPING_NAME = :c_mapping;
    EXCEPTION
        WHEN OTHER THEN
            -- Defaults stand: re-assert them explicitly.
            l_flag_FSS_ADR_DRIVER := 'Y'; l_flag_FSS_ADR_S10_SRC := 'Y'; l_flag_FSS_ADR_S20_VALIDATED := 'Y'; l_flag_FSS_ADR_S30_FLAT := 'Y'; l_flag_FSS_ADR_S40_SCORED := 'Y'; l_flag_FSS_ADR_DQM_ADDRESS := 'Y'; l_flag_FSS_ADR_C_S_FSS_PTY_RLE_ADDR := 'Y'; l_flag_FSS_ADR_EXC_STG_BAD_REC_MEMB := 'Y';
            l_in_FSS_ADR_S10_SRC := ''; l_in_FSS_ADR_S20_VALIDATED := 'WRK_FSS_ADDR_S1_SRC'; l_in_FSS_ADR_S30_FLAT := 'WRK_FSS_ADDR_S2_VALIDATED'; l_in_FSS_ADR_S40_SCORED := 'WRK_FSS_ADDR_S3_FLAT'; l_in_FSS_ADR_DQM_ADDRESS := 'WRK_FSS_ADDR_S4_SCORED'; l_in_FSS_ADR_C_S_FSS_PTY_RLE_ADDR := 'WRK_FSS_ADDR_S4_SCORED'; l_in_FSS_ADR_EXC_STG_BAD_REC_MEMB := 'WRK_FSS_ADDR_S4_SCORED';
    END;

    -- ---- Driver-row disable: skip the whole mapping BEFORE step 5 cleanup
    IF (:l_flag_FSS_ADR_DRIVER = 'N') THEN
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'MAPPING_SKIPPED', 'SKIPPED', NULL, 'Mapping skipped by ETL_RUN_CONFIG_TBL (STEP_NO = 0, IS_RUN_ENABLED = N).', NULL);
        l_summary := 'm_Tgt_C_S_FSS_Pty_Addr SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
        CALL sp_etl_job_finish('FSS', :l_job_run_id, :c_workflow, :c_mapping,
            'm_Tgt_C_S_FSS_Pty_Addr skipped by config. JOB_RUN_ID = ' || :l_job_run_id);
        RETURN 'JOB_RUN_ID=' || :l_job_run_id || CHR(10) || l_summary;
    END IF;

    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Drops only, no checkpoint call for drops. UNCHANGED from current main.
    DROP TABLE IF EXISTS WRK_FSS_ADDR_S1_SRC;
    DROP TABLE IF EXISTS WRK_FSS_ADDR_S2_VALIDATED;
    DROP TABLE IF EXISTS WRK_FSS_ADDR_S3_FLAT;
    DROP TABLE IF EXISTS WRK_FSS_ADDR_S4_SCORED;

    -- ---- Step 10: SRC_ACTIVE
    IF (:l_flag_FSS_ADR_S10_SRC = 'Y') THEN
        l_rows := (CALL sp_snow_step_FSS_ADR_S10_SRC(:l_job_run_id, :l_run_ts, :l_in_FSS_ADR_S10_SRC));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 SRC_ACTIVE', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'SRC_ACTIVE', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 10 SRC_ACTIVE: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- Step 20: VALIDATED
    IF (:l_flag_FSS_ADR_S20_VALIDATED = 'Y') THEN
        l_rows := (CALL sp_snow_step_FSS_ADR_S20_VALIDATED(:l_job_run_id, :l_run_ts, :l_in_FSS_ADR_S20_VALIDATED));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 VALIDATED', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'VALIDATED', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 20 VALIDATED: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- Step 30: FLAT
    IF (:l_flag_FSS_ADR_S30_FLAT = 'Y') THEN
        l_rows := (CALL sp_snow_step_FSS_ADR_S30_FLAT(:l_job_run_id, :l_run_ts, :l_in_FSS_ADR_S30_FLAT));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 FLAT', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'FLAT', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 30 FLAT: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- Step 40: SCORED
    IF (:l_flag_FSS_ADR_S40_SCORED = 'Y') THEN
        l_rows := (CALL sp_snow_step_FSS_ADR_S40_SCORED(:P_MEMBER_HIERARCHY_CODE, :P_MEMBER_HM_REL_TP_CD, :l_job_run_id, :l_run_ts, :l_in_FSS_ADR_S40_SCORED));
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 40 SCORED', :l_rows) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'SCORED', 'SKIPPED', NULL, 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 40 SCORED: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- PUBLISH: ONE transaction, all enabled branches, in order ----
    -- This is the ONLY step that writes to final targets. Branch procs
    -- contain no checkpoint calls and no transaction control; the
    -- driver checkpoints each branch AFTER COMMIT below.
    BEGIN TRANSACTION;
    IF (:l_flag_FSS_ADR_DQM_ADDRESS = 'Y') THEN
        l_pub_FSS_ADR_DQM_ADDRESS := (CALL sp_snow_pub_FSS_ADR_DQM_ADDRESS(:l_job_run_id, :l_run_ts, :l_in_FSS_ADR_DQM_ADDRESS));
    END IF;
    IF (:l_flag_FSS_ADR_C_S_FSS_PTY_RLE_ADDR = 'Y') THEN
        l_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR := (CALL sp_snow_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR(:l_job_run_id, :l_run_ts, :l_in_FSS_ADR_C_S_FSS_PTY_RLE_ADDR));
    END IF;
    IF (:l_flag_FSS_ADR_EXC_STG_BAD_REC_MEMB = 'Y') THEN
        l_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB := (CALL sp_snow_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB(:l_job_run_id, :l_run_ts, :l_in_FSS_ADR_EXC_STG_BAD_REC_MEMB));
    END IF;
    COMMIT;

    -- ---- Publish checkpoints AFTER COMMIT (one per branch) ----
    IF (:l_flag_FSS_ADR_DQM_ADDRESS = 'Y') THEN
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_DQM_ADDRESS', 'COMPLETED', 'DQM_ADDRESS', 'Published every active address to the validation mart to DQM_ADDRESS.', NULL);
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 50 PUBLISH_DQM_ADDRESS', :l_pub_FSS_ADR_DQM_ADDRESS) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_DQM_ADDRESS', 'SKIPPED', 'DQM_ADDRESS', 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 50 PUBLISH_DQM_ADDRESS: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;
    IF (:l_flag_FSS_ADR_C_S_FSS_PTY_RLE_ADDR = 'Y') THEN
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_C_S_FSS_PTY_RLE_ADDR', 'COMPLETED', 'C_S_FSS_PTY_RLE_ADDR', 'Published good addresses to C_S_FSS_PTY_RLE_ADDR.', NULL);
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 60 PUBLISH_C_S_FSS_PTY_RLE_ADDR', :l_pub_FSS_ADR_C_S_FSS_PTY_RLE_ADDR) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_C_S_FSS_PTY_RLE_ADDR', 'SKIPPED', 'C_S_FSS_PTY_RLE_ADDR', 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 60 PUBLISH_C_S_FSS_PTY_RLE_ADDR: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;
    IF (:l_flag_FSS_ADR_EXC_STG_BAD_REC_MEMB = 'Y') THEN
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_EXC', 'COMPLETED', 'EXC_STG_BAD_REC_MEMB', 'Published exception addresses to EXC_STG_BAD_REC_MEMB.', NULL);
        l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 70 PUBLISH_EXC', :l_pub_FSS_ADR_EXC_STG_BAD_REC_MEMB) || CHR(10);
    ELSE
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'WORKING',
            'PUBLISH_EXC', 'SKIPPED', 'EXC_STG_BAD_REC_MEMB', 'Skipped by ETL_RUN_CONFIG_TBL (IS_RUN_ENABLED = N)', NULL);
        l_summary := l_summary || 'step 70 PUBLISH_EXC: SKIPPED by config (IS_RUN_ENABLED = N)' || CHR(10);
    END IF;

    -- ---- TERMINATING ------------------------------------------------------
    CALL sp_etl_job_finish('FSS', :l_job_run_id, :c_workflow, :c_mapping,
        'm_Tgt_C_S_FSS_Pty_Addr completed. JOB_RUN_ID = ' || :l_job_run_id);
    RETURN 'JOB_RUN_ID=' || :l_job_run_id || CHR(10) || l_summary;
EXCEPTION
    WHEN OTHER THEN
        ROLLBACK;
        CALL sp_etl_checkpoint('FSS', :l_job_run_id, :c_workflow, :c_mapping, 'TERMINATING',
            'JOB_END', 'FAILED', NULL, 'Job failed; work tables left in place until the next run of this mapping cleans them up at its start. ' || 'See INFORMATION_SCHEMA.TABLES for WRK_% tables in this schema and VW_ETL_JOB_STORY for the last completed step.', 'See Snowflake query history for this JOB_RUN_ID for the underlying error.');
        CALL sp_etl_job_fail('FSS', :l_job_run_id, :c_workflow, :c_mapping,
            'm_Tgt_C_S_FSS_Pty_Addr failed; work tables left in place until the next run of this mapping cleans them up at its start.');
        RAISE;
END;
$$;

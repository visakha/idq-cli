-- ============================================================================
-- sp_snow_step_FSS_REL_S20_CODED  --  CONFIG-DRIVEN STEP DRIVER REFACTOR (FSS)
--
-- Mapping: m_Tgt_C_S_FSS_Pty_Rle_Rel, workflow wf_FSS_Stage_Load, step 20.
-- Step name (checkpoint): CODED.
--
-- WHAT THIS STEP PRODUCES
--   WRK_FSS_REL_S2_CODED: Relationship code built (missing code defaults to CAREGIVER), direction code type, output gender, both role keys.
--
-- INPUTS / DEPENDENCY DECLARATION
--   P_INPUT_TABLES lists WORK-TABLE inputs only (default: 'WRK_FSS_REL_S1_SRC').
--   Snowflake cannot parameterise table names in static SQL, so
--   P_INPUT_TABLES is a dependency declaration + runtime check, NOT
--   dynamic SQL: the CTAS below still names its sources literally, as
--   in the current main procedure.
--
-- BUSINESS SQL
--   The CTAS below is the current step-20 SELECT verbatim. Only
--   substitution: :l_run_ts -> :P_RUN_TS (not used by this step),
--   :c_mapping -> the local constant below (used by the checkpoint).
--   No business expression, filter, guard or column list was changed.
--   Original parameters used by this step: none.
--
-- FRAMEWORK
--   No exception block (errors propagate to the driver handler), no
--   transactions, no target writes. This proc writes its own checkpoint
--   in the v2 10-argument form (TARGET_TABLE NULL, as in the current
--   main's step checkpoints; row count survives in the RETURN value
--   and the driver's helper36 summary line).
--   P_JOB_RUN_ID is present in every new proc in this refactor.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_step_FSS_REL_S20_CODED (
    P_JOB_RUN_ID   VARCHAR,
    P_RUN_TS       TIMESTAMP_NTZ,
    P_INPUT_TABLES VARCHAR DEFAULT 'WRK_FSS_REL_S1_SRC'
)
RETURNS NUMBER
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_source     VARCHAR DEFAULT 'FSS';
    c_workflow   VARCHAR DEFAULT 'wf_FSS_Stage_Load';
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_FSS_Pty_Rle_Rel';
    l_rows       NUMBER DEFAULT 0;
    l_missing    VARCHAR DEFAULT NULL;
    l_probe_sql VARCHAR;
BEGIN
    -- ---- Input existence check (skipped when P_INPUT_TABLES is empty)
    IF (:P_INPUT_TABLES IS NOT NULL AND TRIM(:P_INPUT_TABLES) <> '') THEN
        SELECT LISTAGG(f.tbl, ', ') INTO :l_missing
          FROM (SELECT UPPER(TRIM(value)) AS tbl
                  FROM TABLE(FLATTEN(input => SPLIT(:P_INPUT_TABLES, '|')))) f
         WHERE NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES t
                            WHERE t.TABLE_SCHEMA = CURRENT_SCHEMA()
                              AND t.TABLE_NAME = f.tbl);
        IF (:l_missing IS NOT NULL) THEN
            l_probe_sql := 'SELECT 1 FROM ' || TRIM(SPLIT_PART(:l_missing, ',', 1));
            EXECUTE IMMEDIATE :l_probe_sql;
        END IF;
    END IF;

    -- ---- Step 20: CODED (verbatim from current main)
CREATE OR REPLACE TRANSIENT TABLE WRK_FSS_REL_S2_CODED AS
    SELECT s.*,
           NVL(s.CD_RELTSHP_TO_TC, 'CAREGIVER') || '|'
           || NVL(IFF(s.RELATION_DIRECTION = 'To Child', s.RELN_CD_GENDER, s.CD_GENDER), '') AS relation_cd,
           IFF(s.RELATION_DIRECTION = 'To Child', 'REL_TP', 'INVERSE_REL')                    AS code_type,
           IFF(s.RELATION_DIRECTION = 'To Child', s.RELN_CD_GENDER, s.CD_GENDER)              AS out_gender_cd,
           NVL(IFF(s.RELATION_DIRECTION = 'To Child', s.RELN_PTY_SRC_KEY, s.PTY_SRC_KEY), '') || '|Member'
                                                                                              AS rel_fk_1,
           NVL(IFF(s.RELATION_DIRECTION = 'To Child', s.PTY_SRC_KEY, s.RELN_PTY_SRC_KEY), '') || '|Member'
                                                                                              AS rel_fk_2
      FROM WRK_FSS_REL_S1_SRC s;
    SELECT COUNT(*) INTO :l_rows FROM WRK_FSS_REL_S2_CODED;
    CALL sp_etl_checkpoint(:c_source, :P_JOB_RUN_ID, :c_workflow, :c_mapping, 'WORKING',
        'CODED', 'COMPLETED', NULL, 'Step 20 complete.', NULL);
    RETURN :l_rows;
END;
$$;

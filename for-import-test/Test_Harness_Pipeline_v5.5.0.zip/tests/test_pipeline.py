"""Pipeline tests: whitelist, copy, compare, and the API end to end.

Everything here runs on SQLite files only -- no Oracle, no
Snowflake, no network.  The API end-to-end test runs the pipeline
in demo mode against temp SQLite files built the same way the
seed script builds them (derive_outputs with and without the
planted differences).
"""

from __future__ import annotations

import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine

from app.core.config import settings
from app.core.pipeline_engines import PipelineEngines
from app.domain.pipeline_catalog import PipelineTable, get_source
from app.domain.pipeline_models import PipelineTableResult
from app.repositories.pipeline_repository import TableStore
from app.services import pipeline_compare, pipeline_service, whitelist

SAMPLE_INPUTS = [
    "STG_TRS_D_DC_INDV",
    "STG_TRS_D_INDV_ADDR",
    "STG_TRS_H_DC_INDV",
    "STG_TRS_D_DC_RELATIONSHIPS",
    "LOOKUP_CODE_VALUE",
]
SAMPLE_OUTPUTS = [
    "C_S_TRS_PTY",
    "C_S_TRS_PTY_RLE_PHN",
    "STG_TRS_VALID_MEMBERS",
    "EXC_STG_BAD_REC_MEMB",
    "ZZ_UTL_UNMERGE_TREE_SRC_KEY",
]
SAMPLE_TABLES = SAMPLE_INPUTS + SAMPLE_OUTPUTS

MEMBERS = [
    {"INDV_ID": 1001, "FIRST_NAME": "Alice", "LAST_NAME": "Anderson", "GENDER_CD": "F",
     "DOB_DT": "1985-03-14", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1002, "FIRST_NAME": "Bob", "LAST_NAME": "Jones", "GENDER_CD": "M",
     "DOB_DT": "1978-11-02", "INACTIVE_IND": "Y", "DELETE_SW": "N"},
    {"INDV_ID": 1003, "FIRST_NAME": "Carol", "LAST_NAME": "White", "GENDER_CD": "F",
     "DOB_DT": "1992-07-19", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1004, "FIRST_NAME": "Dan", "LAST_NAME": "", "GENDER_CD": "M",
     "DOB_DT": "2001-05-30", "INACTIVE_IND": "N", "DELETE_SW": "N"},
    {"INDV_ID": 1005, "FIRST_NAME": "Eve", "LAST_NAME": "Martin", "GENDER_CD": "F",
     "DOB_DT": "1988-09-09", "INACTIVE_IND": "Y", "DELETE_SW": "N"},
    {"INDV_ID": 1006, "FIRST_NAME": "Frank", "LAST_NAME": "Brown", "GENDER_CD": "M",
     "DOB_DT": "1975-01-25", "INACTIVE_IND": "N", "DELETE_SW": "N"},
]


def _store(path: str) -> TableStore:
    return TableStore(create_engine(f"sqlite:///{path}"))


def _load(store: TableStore, table_name: str, rows: list[dict]) -> None:
    spec = next(t for t in get_source("TRS").all_tables if t.name == table_name)
    store.ensure_table(table_name, None)
    cleaned = [{c: row.get(c) for c in spec.columns} for row in rows]
    store.insert_rows(table_name, None, cleaned)


def _pty_row(pkey: str, last: str, first: str = "X") -> dict:
    return {"PKEY_SRC_OBJECT": pkey, "FRST_NM": first, "LST_NM": last,
            "FULL_NM": f"{first} {last}", "VERSION_SEQ": 1}


def _engines(prod_path: str, dev_path: str, snow_path: str, sqlite_dir: str) -> PipelineEngines:
    return PipelineEngines(
        prod=create_engine(f"sqlite:///{prod_path}"),
        dev=create_engine(f"sqlite:///{dev_path}"),
        snowflake_dev=create_engine(f"sqlite:///{snow_path}"),
        sqlite_dir=sqlite_dir, snowflake_schema="", demo_mode=False,
        prod_label=prod_path, dev_label=dev_path,
    )


# ---------------------------------------------------------------------------
# Whitelist
# ---------------------------------------------------------------------------
def test_whitelist_load_ignores_comments_blanks_and_case(tmp_path):
    path = tmp_path / "wl.txt"
    path.write_text("# comment\n\n  stg_trs_d_dc_indv \nC_S_TRS_PTY\n# C_S_TRS_PTY_RLE_PHN\n")
    loaded = whitelist.load_whitelist(str(path))
    assert loaded == {"STG_TRS_D_DC_INDV", "C_S_TRS_PTY"}
    assert whitelist.check_whitelisted(["STG_TRS_D_DC_INDV", "C_S_TRS_PTY"], loaded) == []
    assert whitelist.check_whitelisted(["C_S_TRS_PTY_RLE_PHN"], loaded) == ["C_S_TRS_PTY_RLE_PHN"]


def test_whitelist_missing_file_fails_closed(tmp_path):
    with pytest.raises(ValueError, match="Whitelist file not found"):
        whitelist.load_whitelist(str(tmp_path / "nope.txt"))


# ---------------------------------------------------------------------------
# Filename safety
# ---------------------------------------------------------------------------
def test_resolve_sqlite_file_rejects_paths(tmp_path):
    for bad in ("../evil.db", "sub/dir.db", "", ".", "..", "/abs.db"):
        with pytest.raises(ValueError, match="bare filename"):
            pipeline_service.resolve_sqlite_file(str(tmp_path), bad, must_exist=False)
    ok = pipeline_service.resolve_sqlite_file(str(tmp_path), "prod_TRS_1.db", must_exist=False)
    assert ok.endswith("prod_TRS_1.db")


# ---------------------------------------------------------------------------
# Copy between SQLite stores
# ---------------------------------------------------------------------------
def test_copy_sqlite_to_sqlite_round_trip(tmp_path):
    src = _store(str(tmp_path / "src.db"))
    dst = _store(str(tmp_path / "dst.db"))
    _load(src, "C_S_TRS_PTY", [_pty_row("TRS-1", "Anderson", "Alice"),
                                _pty_row("TRS-2", "Jones", "Bob")])
    spec = next(t for t in get_source("TRS").output_tables if t.name == "C_S_TRS_PTY")
    results = pipeline_service._copy_tables(src, None, dst, None, [spec],
                                            clear_first=False, verb="COPIED")
    assert results[0].status == "COPIED"
    assert results[0].source_rows == 2 and results[0].target_rows == 2
    assert dst.count_rows("C_S_TRS_PTY", None) == 2


def test_copy_missing_source_table_is_not_found(tmp_path):
    src = _store(str(tmp_path / "src.db"))
    dst = _store(str(tmp_path / "dst.db"))
    spec = next(t for t in get_source("TRS").output_tables if t.name == "C_S_TRS_PTY")
    results = pipeline_service._copy_tables(src, None, dst, None, [spec],
                                            clear_first=False, verb="COPIED")
    assert results[0].status == "NOT_FOUND"


# ---------------------------------------------------------------------------
# Compare engine
# ---------------------------------------------------------------------------
def _compare_files(tmp_path, prod_rows, dev_rows, table_name="C_S_TRS_PTY", diff_cap=10000):
    prod = _store(str(tmp_path / "prod.db"))
    dev = _store(str(tmp_path / "dev.db"))
    _load(prod, table_name, prod_rows)
    _load(dev, table_name, dev_rows)
    spec = next(t for t in get_source("TRS").output_tables if t.name == table_name)
    results_path = str(tmp_path / "compare.db")
    pipeline_compare.create_results_db(results_path)
    summaries, verdict, message = pipeline_compare.compare_tables(
        prod, dev, [spec], results_path, "TRS_TEST_1", "TRS",
        "prod.db", "dev.db", "2026-10-27T00:00:00+00:00", diff_cap=diff_cap)
    return summaries[0], verdict, message, results_path


def test_compare_all_four_statuses(tmp_path):
    summary, verdict, _, _ = _compare_files(
        tmp_path,
        [_pty_row("TRS-1", "Anderson", "Alice"), _pty_row("TRS-2", "Jones", "Bob"),
         _pty_row("TRS-3", "White", "Carol")],
        [_pty_row("TRS-1", "Anderson", "Alice"), _pty_row("TRS-2", "Changed", "Bob"),
         _pty_row("TRS-4", "Only", "Dev")],
    )
    assert summary.status == "MISMATCH"
    assert summary.matched == 1 and summary.different == 1
    assert summary.only_in_prod == 1 and summary.only_in_dev == 1
    assert verdict == "MISMATCH"


def test_compare_diff_detail_names_columns_and_values(tmp_path):
    import sqlite3
    _, _, _, results_path = _compare_files(
        tmp_path,
        [_pty_row("TRS-2", "Jones", "Bob")],
        [_pty_row("TRS-2", "Changed", "Bob")],
    )
    conn = sqlite3.connect(results_path)
    row = conn.execute(
        "SELECT status, pk_json, differing_columns_json, prod_values_json, dev_values_json "
        "FROM row_diffs").fetchone()
    assert row[0] == "DIFFERENT"
    assert "TRS-2" in row[1]
    assert "LST_NM" in row[2] and "FULL_NM" in row[2]
    assert "Jones" in row[3] and "Changed" in row[4]


def test_compare_missing_table_is_partial(tmp_path):
    prod = _store(str(tmp_path / "prod.db"))
    dev = _store(str(tmp_path / "dev.db"))
    _load(prod, "C_S_TRS_PTY", [_pty_row("TRS-1", "Anderson", "Alice")])
    spec = next(t for t in get_source("TRS").output_tables if t.name == "C_S_TRS_PTY")
    results_path = str(tmp_path / "compare.db")
    pipeline_compare.create_results_db(results_path)
    summaries, verdict, _ = pipeline_compare.compare_tables(
        prod, dev, [spec], results_path, "TRS_TEST_2", "TRS",
        "prod.db", "dev.db", "2026-10-27T00:00:00+00:00")
    assert summaries[0].status == "MISSING_IN_DEV"
    assert verdict == "PARTIAL"


def test_compare_count_only_without_pk(tmp_path):
    prod = _store(str(tmp_path / "prod.db"))
    dev = _store(str(tmp_path / "dev.db"))
    spec = PipelineTable(name="LOOKUP_CODE_VALUE", kind="input", columns=["CODE_TYPE"],
                         pk=[])
    _load(prod, "LOOKUP_CODE_VALUE", [{"CODE_TYPE": "GENDER"}])
    _load(dev, "LOOKUP_CODE_VALUE", [{"CODE_TYPE": "GENDER"}])
    results_path = str(tmp_path / "compare.db")
    pipeline_compare.create_results_db(results_path)
    summaries, verdict, _ = pipeline_compare.compare_tables(
        prod, dev, [spec], results_path, "TRS_TEST_3", "TRS",
        "prod.db", "dev.db", "2026-10-27T00:00:00+00:00")
    assert summaries[0].status == "COUNT_ONLY"
    assert verdict == "PARTIAL"


def test_compare_diff_cap_keeps_counts_complete(tmp_path):
    summary, _, _, _ = _compare_files(
        tmp_path,
        [_pty_row(f"TRS-{i}", "A") for i in range(5)],
        [_pty_row(f"TRS-{i}", "B") for i in range(5)],
        diff_cap=2,
    )
    assert summary.different == 5
    assert summary.diff_rows_stored == 2


# ---------------------------------------------------------------------------
# Step (C) safety gates
# ---------------------------------------------------------------------------
def test_sqlite_to_dev_refuses_non_whitelisted_and_truncates_nothing(tmp_path):
    prod_path = tmp_path / "prod.db"
    dev_path = tmp_path / "dev.db"
    snow_path = tmp_path / "snow.db"
    prod = _store(str(prod_path))
    dev = _store(str(dev_path))
    _load(prod, "C_S_TRS_PTY", [_pty_row("TRS-1", "Anderson", "Alice")])
    _load(dev, "C_S_TRS_PTY", [_pty_row("TRS-9", "Old", "Row")])
    wl = tmp_path / "wl.txt"
    wl.write_text("STG_TRS_D_DC_INDV\n")
    old = settings.pipeline_whitelist_path
    settings.pipeline_whitelist_path = str(wl)
    try:
        engines = _engines(str(prod_path), str(dev_path), str(snow_path), str(tmp_path))
        with pytest.raises(ValueError, match="NOT in the whitelist"):
            pipeline_service.sqlite_to_dev(engines, "TRS", "prod.db", ["C_S_TRS_PTY"])
    finally:
        settings.pipeline_whitelist_path = old
    # Nothing was truncated: the old Dev row is still there.
    assert dev.count_rows("C_S_TRS_PTY", None) == 1


def test_sqlite_to_dev_refuses_identical_prod_dev(tmp_path):
    path = tmp_path / "same.db"
    engines = _engines(str(path), str(path), str(tmp_path / "snow.db"), str(tmp_path))
    with pytest.raises(ValueError, match="identical"):
        pipeline_service.sqlite_to_dev(engines, "TRS", "prod.db", ["C_S_TRS_PTY"])


# ---------------------------------------------------------------------------
# API end to end in demo mode (SQLite only)
# ---------------------------------------------------------------------------
def _build_demo_files(demo_dir: str) -> None:
    os.makedirs(demo_dir, exist_ok=True)
    from app.services.demo_etl_simulator import derive_outputs

    prod = _store(os.path.join(demo_dir, "demo_prod.db"))
    _load(prod, "STG_TRS_D_DC_INDV", MEMBERS)
    for table_name in ("STG_TRS_D_INDV_ADDR", "STG_TRS_H_DC_INDV",
                       "STG_TRS_D_DC_RELATIONSHIPS", "LOOKUP_CODE_VALUE"):
        spec = next(t for t in get_source("TRS").all_tables if t.name == table_name)
        prod.ensure_table(table_name, None)
    for table_name, rows in derive_outputs(MEMBERS, plant_diffs=False).items():
        _load(prod, table_name, rows)
    prod.engine.dispose()
    dev = _store(os.path.join(demo_dir, "demo_dev_oracle.db"))
    for table_name in SAMPLE_TABLES:
        dev.ensure_table(table_name, None)
    dev.engine.dispose()
    snow = _store(os.path.join(demo_dir, "demo_snowflake.db"))
    for table_name in SAMPLE_OUTPUTS:
        snow.ensure_table(table_name, None)
    snow.engine.dispose()


def _demo_client(tmp_path):
    from app.api.dependencies import get_run_repository
    from app.api.pipeline_routes import router as _router  # noqa: F401 (ensures import)
    from app.core.pipeline_engines import get_pipeline_engines
    from app.main import app
    from app.repositories.run_repository import RunRepository

    demo_dir = str(tmp_path / "demo")
    _build_demo_files(demo_dir)
    sqlite_dir = str(tmp_path / "pipeline_data")
    os.makedirs(sqlite_dir, exist_ok=True)
    engines = PipelineEngines(
        prod=create_engine(f"sqlite:///{demo_dir}/demo_prod.db"),
        dev=create_engine(f"sqlite:///{demo_dir}/demo_dev_oracle.db"),
        snowflake_dev=create_engine(f"sqlite:///{demo_dir}/demo_snowflake.db"),
        sqlite_dir=sqlite_dir, snowflake_schema="", demo_mode=True,
        prod_label=f"{demo_dir}/demo_prod.db",
        dev_label=f"{demo_dir}/demo_dev_oracle.db",
    )

    def _yield_engines():
        yield engines

    engine = create_engine(f"sqlite:///{tmp_path}/control.db")
    app.dependency_overrides[get_run_repository] = lambda: RunRepository(engine)
    app.dependency_overrides[get_pipeline_engines] = _yield_engines
    return TestClient(app), engines


def test_pipeline_api_end_to_end_demo(tmp_path):
    from app.main import app
    from app.api.dependencies import get_run_repository
    from app.core.pipeline_engines import get_pipeline_engines

    wl = tmp_path / "wl.txt"
    wl.write_text("\n".join(SAMPLE_TABLES) + "\n")
    old_wl = settings.pipeline_whitelist_path
    old_demo = settings.pipeline_demo_mode
    settings.pipeline_whitelist_path = str(wl)
    settings.pipeline_demo_mode = True
    try:
        client, _ = _demo_client(tmp_path)
        # (A) readiness: sample tables exist on the Prod side.
        ready = client.get("/pipeline/readiness", params={"source": "TRS"})
        assert ready.status_code == 200
        by_name = {t["table"]: t for t in ready.json()["tables"]}
        assert all(by_name[t]["exists"] for t in SAMPLE_TABLES)
        # (B) Prod -> Prod_SQLite.
        b = client.post("/pipeline/prod-to-sqlite",
                        json={"source": "TRS", "tables": SAMPLE_TABLES})
        assert b.status_code == 200, b.text
        assert b.json()["status"] == "COMPLETED"
        prod_file = b.json()["sqlite_path"]
        # (C) Prod_SQLite -> Dev (whitelist covers all 10).
        c = client.post("/pipeline/sqlite-to-dev",
                        json={"source": "TRS", "prod_sqlite": prod_file, "tables": SAMPLE_TABLES})
        assert c.status_code == 200, c.text
        assert c.json()["status"] == "COMPLETED"
        # (D) demo simulator run.
        d = client.post("/pipeline/run-snowflake-etl", json={"source": "TRS"})
        assert d.status_code == 200, d.text
        assert d.json()["status"] == "COMPLETED"
        assert "demo-simulator" in d.json()["message"]
        # (E) Snowflake Dev -> Dev_SQLite.
        e = client.post("/pipeline/snowflake-to-sqlite",
                        json={"source": "TRS", "tables": SAMPLE_OUTPUTS})
        assert e.status_code == 200, e.text
        assert e.json()["status"] == "COMPLETED"
        dev_file = e.json()["sqlite_path"]
        # (F) compare: planted diffs -> MISMATCH with exact counts.
        f = client.post("/pipeline/compare",
                        json={"source": "TRS", "prod_sqlite": prod_file,
                              "dev_sqlite": dev_file, "tables": SAMPLE_OUTPUTS})
        assert f.status_code == 200, f.text
        body = f.json()
        assert body["verdict"] == "MISMATCH"
        by_table = {t["table"]: t for t in body["tables"]}
        pty = by_table["C_S_TRS_PTY"]
        assert (pty["matched"], pty["different"], pty["only_in_prod"], pty["only_in_dev"]) == (4, 1, 1, 1)
        assert by_table["C_S_TRS_PTY_RLE_PHN"]["status"] == "MATCH"
        assert by_table["STG_TRS_VALID_MEMBERS"]["status"] == "MATCH"
        assert by_table["ZZ_UTL_UNMERGE_TREE_SRC_KEY"]["status"] == "MATCH"
        assert by_table["EXC_STG_BAD_REC_MEMB"]["only_in_dev"] == 1
        # (G) read-back: the DIFFERENT PTY row names its columns.
        run_id = body["run_id"]
        got = client.get(f"/pipeline/compare/{run_id}",
                         params={"table": "C_S_TRS_PTY", "status": "DIFFERENT"})
        assert got.status_code == 200
        diffs = got.json()["diffs"]
        assert len(diffs) == 1
        assert "LST_NM" in diffs[0]["differing_columns"]
        assert diffs[0]["prod_values"]["LST_NM"] == "White"
        assert diffs[0]["dev_values"]["LST_NM"] == "Changed"
        runs = client.get("/pipeline/compare-runs")
        assert runs.status_code == 200
        assert any(r["run_id"] == run_id for r in runs.json())
    finally:
        settings.pipeline_whitelist_path = old_wl
        settings.pipeline_demo_mode = old_demo
        app.dependency_overrides.pop(get_run_repository, None)
        app.dependency_overrides.pop(get_pipeline_engines, None)


def test_pipeline_compare_unknown_table_is_400(tmp_path):
    client, _ = _demo_client(tmp_path)
    try:
        resp = client.post("/pipeline/prod-to-sqlite",
                           json={"source": "TRS", "tables": ["NO_SUCH_TABLE"]})
        assert resp.status_code == 400
    finally:
        from app.main import app
        from app.api.dependencies import get_run_repository
        from app.core.pipeline_engines import get_pipeline_engines
        app.dependency_overrides.pop(get_run_repository, None)
        app.dependency_overrides.pop(get_pipeline_engines, None)


def test_pipeline_sources_lists_registry(tmp_path):
    client, _ = _demo_client(tmp_path)
    try:
        resp = client.get("/pipeline/sources")
        assert resp.status_code == 200
        by_source = {s["source"]: s for s in resp.json()}
        assert by_source["TRS"]["runners"]["toa"] == "sp_etl_run_wf_TRS_Stage_Load_TOA"
        assert "C_S_TRS_PTY" in by_source["TRS"]["output_tables"]
        assert by_source["ECI"]["runners"]["stage-load"] == "sp_etl_run_wf_ECI_Stage_Load"
    finally:
        from app.main import app
        from app.api.dependencies import get_run_repository
        from app.core.pipeline_engines import get_pipeline_engines
        app.dependency_overrides.pop(get_run_repository, None)
        app.dependency_overrides.pop(get_pipeline_engines, None)

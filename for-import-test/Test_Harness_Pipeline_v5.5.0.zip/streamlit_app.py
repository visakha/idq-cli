"""Compare Results Explorer -- step (G) of the tester pipeline.

A local Streamlit UI for manually verifying a compare run.  It reads
a Compare_Results_SQLite file (produced by POST /pipeline/compare)
with the Python standard library only -- no API calls, no
credentials -- and shows:

  * one row per compared table: Prod/Dev counts, matched rows,
    different rows, rows only on one side, and the table status;
  * the differing rows for a selected table, filterable by status
    (DIFFERENT / ONLY_IN_PROD / ONLY_IN_DEV);
  * a record detail view: the PK plus, for a DIFFERENT row, the
    differing columns with the Prod and Dev values side by side;
    for a one-sided row, the full row from the side that has it.

Run it (from the project root):
    pip install -r requirements-streamlit.txt
    streamlit run streamlit_app.py

Then type (or accept) the path to a Compare_Results_SQLite file.
By default it offers the newest compare_*.db in ./pipeline_data.

This is a LOCAL operator tool: it has no login, so run it on your
own machine, not on a shared server.
"""

from __future__ import annotations

import glob
import json
import os
import sqlite3

import pandas as pd
import streamlit as st

DEFAULT_DIR = "./pipeline_data"


def newest_results_file(directory: str) -> str:
    """Newest compare_*.db in a directory, or '' if there is none."""
    files = sorted(
        glob.glob(os.path.join(directory, "compare_*.db")),
        key=os.path.getmtime,
        reverse=True,
    )
    return files[0] if files else ""


def load_run(conn: sqlite3.Connection, run_id: str) -> dict:
    row = conn.execute(
        "SELECT run_id, source, prod_sqlite, dev_sqlite, started_at, "
        "finished_at, status, verdict, message FROM compare_runs WHERE run_id = ?",
        (run_id,),
    ).fetchone()
    if row is None:
        return {}
    keys = ["run_id", "source", "prod_sqlite", "dev_sqlite", "started_at",
            "finished_at", "status", "verdict", "message"]
    return dict(zip(keys, row))


def load_summary(conn: sqlite3.Connection, run_id: str) -> pd.DataFrame:
    rows = conn.execute(
        "SELECT table_name, status, prod_count, dev_count, matched, different, "
        "only_in_prod, only_in_dev, diff_rows_stored, message "
        "FROM table_summary WHERE run_id = ? ORDER BY table_name",
        (run_id,),
    ).fetchall()
    return pd.DataFrame(rows, columns=[
        "Table", "Status", "Prod rows", "Dev rows", "Matched", "Different",
        "Only in Prod", "Only in Dev", "Diff rows stored", "Message",
    ])


def load_diffs(conn: sqlite3.Connection, run_id: str, table: str,
               status: str, limit: int) -> pd.DataFrame:
    query = ("SELECT status, pk_json, differing_columns_json, "
             "prod_values_json, dev_values_json FROM row_diffs "
             "WHERE run_id = ? AND table_name = ?")
    params: list = [run_id, table]
    if status != "ALL":
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY status LIMIT ?"
    params.append(limit)
    rows = conn.execute(query, params).fetchall()
    out = []
    for st_, pk, diff_cols, prod_vals, dev_vals in rows:
        out.append({
            "Status": st_,
            "PK": pk,
            "Differing columns": diff_cols,
            "Prod values": prod_vals,
            "Dev values": dev_vals,
        })
    return pd.DataFrame(out)


def main() -> None:
    st.set_page_config(page_title="Compare Results Explorer", layout="wide")
    st.title("Compare Results Explorer")
    st.caption(
        "Step (G): manual verification of a pipeline compare run. "
        "Reads a Compare_Results_SQLite file produced by POST /pipeline/compare."
    )

    with st.sidebar:
        st.header("Results file")
        default_path = newest_results_file(DEFAULT_DIR)
        db_path = st.text_input("Compare_Results_SQLite file", value=default_path)
        if st.button("Reload"):
            st.rerun()
        if not db_path or not os.path.exists(db_path):
            st.warning(
                "No results file found. Run the pipeline through step (F) "
                "first, or type the path to a compare_*.db file."
            )
            return
        conn = sqlite3.connect(db_path)
        run_ids = [r[0] for r in conn.execute(
            "SELECT run_id FROM compare_runs ORDER BY started_at DESC")]
        if not run_ids:
            st.warning("This file has no compare runs.")
            return
        run_id = st.selectbox("Compare run", run_ids)

    run = load_run(conn, run_id)
    st.subheader(f"Run {run['run_id']} -- verdict: {run['verdict']}")
    st.write(
        f"Source **{run['source']}** | Prod_SQLite `{run['prod_sqlite']}` | "
        f"Dev_SQLite `{run['dev_sqlite']}` | Started {run['started_at']} | "
        f"Finished {run['finished_at'] or '-'}"
    )
    st.write(run["message"])

    summary = load_summary(conn, run_id)
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Tables", len(summary))
    col2.metric("Matched rows", int(summary["Matched"].sum()) if len(summary) else 0)
    col3.metric("Different rows", int(summary["Different"].sum()) if len(summary) else 0)
    col4.metric("One-sided rows",
                int(summary["Only in Prod"].sum() + summary["Only in Dev"].sum())
                if len(summary) else 0)
    st.subheader("Tables")
    st.dataframe(summary, use_container_width=True)

    problem_tables = summary[summary["Status"] != "MATCH"]["Table"].tolist()
    st.subheader("Row differences")
    if not problem_tables:
        st.success("Every compared table matched exactly. Nothing to verify.")
        return
    table = st.selectbox("Table", problem_tables)
    status = st.selectbox("Diff status", ["ALL", "DIFFERENT", "ONLY_IN_PROD", "ONLY_IN_DEV"])
    limit = st.slider("Max diff rows to show", 10, 1000, 200)
    diffs = load_diffs(conn, run_id, table, status, limit)
    if diffs.empty:
        st.info("No diff rows for this filter.")
        return
    st.dataframe(diffs, use_container_width=True)

    st.subheader("Record detail")
    pk_options = diffs["PK"].tolist()
    chosen = st.selectbox("Row (PK)", pk_options)
    detail = diffs[diffs["PK"] == chosen].iloc[0]
    st.write(f"**Status:** {detail['Status']}")
    if detail["Status"] == "DIFFERENT":
        cols = json.loads(detail["Differing columns"])
        prod_vals = json.loads(detail["Prod values"])
        dev_vals = json.loads(detail["Dev values"])
        st.table(pd.DataFrame([
            {"Column": c, "Prod value": prod_vals.get(c), "Dev value": dev_vals.get(c)}
            for c in cols
        ]))
    elif detail["Status"] == "ONLY_IN_PROD":
        st.write("Present in Prod only:")
        st.json(detail["Prod values"])
    else:
        st.write("Present in Dev only:")
        st.json(detail["Dev values"])


if __name__ == "__main__":
    main()

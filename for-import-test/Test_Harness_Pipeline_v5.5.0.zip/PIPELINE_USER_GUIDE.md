# Tester Pipeline User Guide (v5.5.0)

The daily flow for testing a Snowflake ETL build against that day's
Production IDQ results. It is a second flow inside the TRS Compare
API: the v5 flow (`/runs/copy`, `/runs/etl`, `/runs/compare`) is
unchanged, and this pipeline adds `/pipeline/*` endpoints plus a
Streamlit results UI.

## 1. The daily flow, step by step

| Step | Who acts | What happens | Endpoint / tool |
|---|---|---|---|
| (A) | Production ETL (not this tool) | By 8 AM the Production ETL has completed. `ETL_INPUT_TABLES` (the `_D_` and `_H_` tables and other supporting tables) and `ETL_OUTPUT_TABLES` (the `C_S_*` target tables, the Status/State-tracking tables, the `ZZ_*` tables) are ready in Oracle Production. These tables are mostly source-specific. | Precondition. Check it with the readiness endpoint below. |
| (B) | Tester | Copy the tables from Oracle Production into a SQLite database, `Prod_SQLite`. | `POST /pipeline/prod-to-sqlite` |
| (C) | Tester | Copy the data from `Prod_SQLite` into Dev Oracle, truncating first ONLY the tables listed in `White_list_tables_safe_to_truncate.txt`. | `POST /pipeline/sqlite-to-dev` |
| (D) | Tester | Run the Snowflake ETL for a given source in Dev. | `POST /pipeline/run-snowflake-etl` |
| (E) | Tester | Copy the tables from Snowflake Dev into a SQLite database, `Dev_SQLite`. | `POST /pipeline/snowflake-to-sqlite` |
| (F) | Tester | Compare table by table and record by record from `Dev_SQLite` and `Prod_SQLite`, and write the results into another SQLite database, `Compare_Results_SQLite`, for manual verification. | `POST /pipeline/compare` |
| (G) | Tester | Open a Streamlit application and check the results by looking at `Compare_Results_SQLite`. | `streamlit run streamlit_app.py` |

What is compared, precisely: the `ETL_OUTPUT_TABLES` only. The inputs
are not compared, because Dev gets them verbatim from Prod in step
(C) -- comparing them would only re-prove the copy. The copy steps
report row counts for every table, so a bad copy is visible before
the compare runs.

## 2. How the code is laid out

New files, following the existing house style (thin routes, services
own rules, repositories own SQL, Pydantic models, explicit table
definitions, no ORM, no runtime reflection):

- `app/domain/pipeline_catalog.py` -- the registry: per-source
  `ETL_INPUT_TABLES` / `ETL_OUTPUT_TABLES`, columns, compare keys
  (PKs), and the runner-procedure allowlist. TRS is fully
  registered (30 inputs, 20 outputs, built from `catalog.py` +
  `tables.py`); ECI, WIC, TTF, FSS, CRE are registered with their
  real runner procedures and empty table lists (see §10).
- `app/domain/pipeline_models.py` -- request/response models.
- `app/repositories/pipeline_repository.py` -- `TableStore`: one
  class that copies rows between Oracle, Snowflake and SQLite.
- `app/services/pipeline_service.py` -- steps (A)-(F) orchestration
  and every safety gate.
- `app/services/pipeline_compare.py` -- the record-by-record
  compare engine and the `Compare_Results_SQLite` schema.
- `app/services/whitelist.py` -- the whitelist loader and check.
- `app/services/demo_etl_simulator.py` -- DEMO ONLY simulator for
  step (D) in demo mode (never used with real databases).
- `app/core/pipeline_engines.py` -- the three engines (Prod, Dev,
  Snowflake Dev) and the FastAPI dependency that disposes them.
- `app/api/pipeline_routes.py` -- the `/pipeline/*` endpoints.
- `streamlit_app.py` -- step (G).
- `sample_data/` -- the sample pack (§8).
- `config/White_list_tables_safe_to_truncate.txt` -- the TRS
  whitelist for real use (46 tables).

Design rules worth knowing before you run anything:

- **Table names come only from the registry.** A request naming an
  unknown table is a 400, never a name reaching SQL unchecked.
  Columns are explicit lists from `tables.py`, never reflected
  from a live database, and every SELECT names its columns (no
  `SELECT *`): the Prod Oracle tables do not carry the v5
  `DATA_SOURCE` column, so a `SELECT *` copy would break.
- **File arguments are bare filenames** inside
  `PIPELINE_SQLITE_DIR`, never paths. Step (B) returns a filename;
  step (C) takes it; step (F) takes both. A request cannot point
  the API at an arbitrary file.
- **One run id everywhere.** A compare run's id is the
  control-store run id, the results DB's run id, and part of the
  results filename, so `GET /pipeline/compare/{run_id}` always
  finds the diff rows it recorded.
- **Per-table failures don't hide the rest.** A table that fails
  is recorded as FAILED/NOT_FOUND and the run continues; the
  overall status is COMPLETED (all ok), PARTIAL (some ok) or
  FAILED (none ok). A validation failure (unknown
  source/table/workflow, whitelist refusal, prod==dev) is a 400
  raised before anything is written.

## 3. Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill it in (see §4)
uvicorn app.main:app --reload
```

For the Streamlit UI only, on the machine that runs it:

```bash
pip install -r requirements-streamlit.txt
streamlit run streamlit_app.py
```

Docs (local Swagger UI, no CDN): `http://localhost:8000/docs`.
If `API_KEY` is set, every endpoint except `/health` and
`/pipeline/sources` needs the `X-API-Key` header.

## 4. Configuration

Existing Snowflake settings (`SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_USER`,
authenticator/token/password, warehouse, role) are reused for the
Snowflake Dev connection. New settings:

| Variable | Default | Meaning |
|---|---|---|
| `PIPELINE_DEMO_MODE` | `false` | `true` = demo mode: all three sides are SQLite files under `PIPELINE_DEMO_DIR`. A missing demo file is an error naming the seed script, never a silent empty database. |
| `PIPELINE_DEMO_DIR` | `./demo` | Demo database directory. |
| `PIPELINE_SQLITE_DIR` | `./pipeline_data` | Directory for `prod_*`, `dev_*` and `compare_*` files. |
| `PIPELINE_ORACLE_PROD_URL` | — (required in real mode) | Full SQLAlchemy URL for Oracle Production, e.g. `oracle+oracledb://user:password@host:1521/service`. Production is read-only to this API: it is never written. |
| `PIPELINE_ORACLE_DEV_URL` | — (required in real mode) | Full SQLAlchemy URL for Dev Oracle. |
| `PIPELINE_WHITELIST_PATH` | `./config/White_list_tables_safe_to_truncate.txt` | Whitelist file for step (C). |
| `PIPELINE_SNOWFLAKE_DATABASE` | `MDM_ETL_<SOURCE>` | Snowflake Dev database. |
| `PIPELINE_SNOWFLAKE_SCHEMA` | `<SOURCE>_ETL_WRK` | Snowflake Dev schema. |
| `PIPELINE_COMPARE_DIFF_CAP` | `10000` | Stored diff rows per table (counts are always complete). |

## 5. Real-use setup checklist

1. **Dev Oracle mirrors Production's schemas.** Step (C) never
   creates Dev tables: a Dev table that doesn't exist is reported
   NOT_FOUND and the run goes PARTIAL. Create the Dev tables first
   (same names, same Oracle schemas as Production).
2. **Whitelist.** Edit
   `config/White_list_tables_safe_to_truncate.txt` so it lists
   exactly the Dev tables a reload may safely empty, one per line.
   The shipped file lists the 46 TRS tables that exist in the
   exports (the 4 missing objects are not listed, because they
   can't be truncated in Dev until they exist there). Never list
   a Production table.
3. **Snowflake Dev install.** Install the source's procedures into
   `PIPELINE_SNOWFLAKE_DATABASE.PIPELINE_SNOWFLAKE_SCHEMA` (the
   bare-bones or step-driver package) before the first (D) run.
4. **Re-runs and insert-only runners.** The Snowflake runners are
   insert-only with existing-key guards, so re-running (D) without
   clearing Dev outputs suppresses rows. Either run (D) with
   `"reset_outputs": true` (truncates the Dev output tables first)
   or re-install into a fresh schema. Demo mode always resets
   (the simulator truncates its own outputs).
5. **Step (E) copies all rows** from the Snowflake Dev output
   tables (no `DATA_SOURCE` filter): in a fresh Dev schema the
   only rows are the ones (D) just wrote. If your Dev schema also
   holds older rows, clear it first (see point 4).

## 6. Endpoint reference

All endpoints are under `/pipeline`. `source` defaults to `TRS`.

### GET /pipeline/sources

The registry: sources, runner keys and procedures, table names.
No API key required.

### GET /pipeline/readiness?source=TRS -- step (A) check

Reports every input + output table's existence and row count on
the Prod side. `ready` is true only when every registered table
exists. Empty tables do not block readiness (an empty exception
table is normal); readiness proves existence, not freshness -- it
cannot tell you whether the 8 AM ETL actually ran, only that its
tables are there. Confirm the ETL finished by hand, as before.

```bash
curl "http://localhost:8000/pipeline/readiness?source=TRS"
```

### POST /pipeline/prod-to-sqlite -- step (B)

Body: `{"source": "TRS", "tables": [...]}` (`tables` omitted =
all input + output tables). Creates a fresh
`prod_TRS_<timestamp>_<id>.db` in `PIPELINE_SQLITE_DIR` and copies
every table, verifying row counts. Returns the filename in
`sqlite_path` -- pass it to step (C).

### POST /pipeline/sqlite-to-dev -- step (C)

Body: `{"source": "TRS", "prod_sqlite": "prod_TRS_....db",
"tables": [...]}`. Loads the file into Dev Oracle:

- refuses (400) if Prod and Dev connections are identical;
- refuses (400, naming every offender) if any requested table is
  not in the whitelist file -- and truncates nothing;
- truncates each whitelisted Dev table, loads it from
  `Prod_SQLite`, verifies row counts.

`tables` omitted = all registry tables for the source, which must
then all be whitelisted.

### POST /pipeline/run-snowflake-etl -- step (D)

Body: `{"source": "TRS", "workflows": ["toa", "ongoing"],
"reset_outputs": false}`. `workflows` omitted = the source's
stage-load runners in order (TRS: TOA, then Ongoing). TRS also
accepts `deactivation-initial`, `deactivation-relationship`,
`deactivation-history`, `deactivation-complete`. A failure stops
later workflows (later ones report NOT_RUN). In demo mode the
response names the demo simulator, so a demo run can never be
mistaken for a real one.

### POST /pipeline/snowflake-to-sqlite -- step (E)

Body: `{"source": "TRS", "tables": [...], "include_inputs": false}`.
`tables` omitted = all output tables. Creates a fresh
`dev_TRS_<timestamp>_<id>.db` from Snowflake Dev. Returns the
filename in `sqlite_path` -- pass it to step (F).

### POST /pipeline/compare -- step (F)

Body: `{"source": "TRS", "prod_sqlite": "prod_TRS_....db",
"dev_sqlite": "dev_TRS_....db", "tables": [...]}`. Compares the
output tables record by record and writes
`compare_TRS_<timestamp>_<id>.db`. Response fields: `run_id`,
`status`, `verdict`, `results_db`, and one summary per table.

Verdicts: **MATCH** = every compared table matched exactly.
**MISMATCH** = at least one table differs (a successful compare
with a negative answer -- HTTP 200, not an error). **PARTIAL** =
the evidence is incomplete: a table missing on a side, a table
with no PK compared by counts only, or a table that failed.

Per-row statuses in the results file: **DIFFERENT** (same PK,
columns differ -- differing columns and both values stored),
**ONLY_IN_PROD**, **ONLY_IN_DEV**. For a DIFFERENT row only the
differing columns' values are stored; for a one-sided row the full
row from the side that has it is stored.

Results file schema: `compare_runs` (one row per run),
`table_summary` (one row per table, complete counts),
`row_diffs` (one row per differing/one-sided row, capped per
table by `PIPELINE_COMPARE_DIFF_CAP`; counts stay complete when
the cap bites).

### GET /pipeline/compare/{run_id} -- read results back

Query params: `table`, `status` (`DIFFERENT`, `ONLY_IN_PROD`,
`ONLY_IN_DEV`), `limit` (default 200, max 5000). The results file
is taken from the run record, never from the request.

### GET /pipeline/compare-runs

Recent pipeline compare runs, newest first, with verdicts and
results filenames.

## 7. Demo walkthrough (no real databases)

Everything below was run against the shipped sample pack and
produces exactly the outputs shown. The demo uses 5 input tables
and 5 output tables with 6 fictional members (see §8).

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# Demo databases are shipped prebuilt in demo/; rebuild them any time with:
python sample_data/seed_demo.py
# Point the API at the demo (or copy sample_data/demo.env into .env):
export PIPELINE_DEMO_MODE=true PIPELINE_DEMO_DIR=./demo
export PIPELINE_SQLITE_DIR=./pipeline_data
export PIPELINE_WHITELIST_PATH=./sample_data/White_list_tables_safe_to_truncate.txt
uvicorn app.main:app --port 8000
```

In a second shell (API key is empty in demo mode, so no header):

```bash
TABLES='["STG_TRS_D_DC_INDV","STG_TRS_D_INDV_ADDR","STG_TRS_H_DC_INDV","STG_TRS_D_DC_RELATIONSHIPS","LOOKUP_CODE_VALUE","C_S_TRS_PTY","C_S_TRS_PTY_RLE_PHN","STG_TRS_VALID_MEMBERS","EXC_STG_BAD_REC_MEMB","ZZ_UTL_UNMERGE_TREE_SRC_KEY"]'
OUTS='["C_S_TRS_PTY","C_S_TRS_PTY_RLE_PHN","STG_TRS_VALID_MEMBERS","EXC_STG_BAD_REC_MEMB","ZZ_UTL_UNMERGE_TREE_SRC_KEY"]'

# (A) readiness: the 10 sample tables exist on the Prod side
# (ready is false overall because the demo only seeds 10 of the
# 50 registry tables -- the other 40 are simply not in the demo).
curl "http://localhost:8000/pipeline/readiness?source=TRS"

# (B) Prod -> Prod_SQLite
PROD=$(curl -s -X POST http://localhost:8000/pipeline/prod-to-sqlite \
  -H 'Content-Type: application/json' \
  -d "{\"source\":\"TRS\",\"tables\":$TABLES}" | python -c "import json,sys; print(json.load(sys.stdin)['sqlite_path'])")

# (C) Prod_SQLite -> Dev
curl -s -X POST http://localhost:8000/pipeline/sqlite-to-dev \
  -H 'Content-Type: application/json' \
  -d "{\"source\":\"TRS\",\"prod_sqlite\":\"$PROD\",\"tables\":$TABLES}" | python -c "import json,sys; print(json.load(sys.stdin)['status'])"
# -> COMPLETED

# (D) demo simulator run
curl -s -X POST http://localhost:8000/pipeline/run-snowflake-etl \
  -H 'Content-Type: application/json' -d '{"source":"TRS"}' \
  | python -c "import json,sys; print(json.load(sys.stdin)['status'])"
# -> COMPLETED

# (E) Snowflake Dev -> Dev_SQLite
DEV=$(curl -s -X POST http://localhost:8000/pipeline/snowflake-to-sqlite \
  -H 'Content-Type: application/json' \
  -d "{\"source\":\"TRS\",\"tables\":$OUTS}" | python -c "import json,sys; print(json.load(sys.stdin)['sqlite_path'])")

# (F) compare
curl -s -X POST http://localhost:8000/pipeline/compare \
  -H 'Content-Type: application/json' \
  -d "{\"source\":\"TRS\",\"prod_sqlite\":\"$PROD\",\"dev_sqlite\":\"$DEV\",\"tables\":$OUTS}"
```

Expected step (F) result (verdict MISMATCH -- the planted demo
differences, §8):

| Table | Status | Prod | Dev | Matched | Different | Only Prod | Only Dev |
|---|---|---|---|---|---|---|---|
| C_S_TRS_PTY | MISMATCH | 6 | 6 | 4 | 1 | 1 | 1 |
| C_S_TRS_PTY_RLE_PHN | MATCH | 5 | 5 | 5 | 0 | 0 | 0 |
| STG_TRS_VALID_MEMBERS | MATCH | 6 | 6 | 6 | 0 | 0 | 0 |
| EXC_STG_BAD_REC_MEMB | MISMATCH | 1 | 2 | 1 | 0 | 0 | 1 |
| ZZ_UTL_UNMERGE_TREE_SRC_KEY | MATCH | 2 | 2 | 2 | 0 | 0 | 0 |

Then step (G):

```bash
pip install -r requirements-streamlit.txt
streamlit run streamlit_app.py
```

The app offers the newest `compare_*.db` in `./pipeline_data`.
Pick the run, then the `C_S_TRS_PTY` table: it shows one
DIFFERENT row (member 1003, `LST_NM`/`FULL_NM` White -> Changed),
one ONLY_IN_PROD row (1005) and one ONLY_IN_DEV row (1007).
The record detail view shows Prod vs Dev values side by side.

## 8. Sample data pack

`sample_data/` holds 5 ETL_INPUT_TABLES and 5 ETL_OUTPUT_TABLES
for TRS, with real table names and real Oracle column lists (from
`tables.py`), and a few rows each:

Inputs: `STG_TRS_D_DC_INDV` (6 members), `STG_TRS_D_INDV_ADDR`
(6 addresses), `STG_TRS_H_DC_INDV` (2 history rows),
`STG_TRS_D_DC_RELATIONSHIPS` (2 relationships),
`LOOKUP_CODE_VALUE` (4 code rows).

Outputs: `C_S_TRS_PTY` (6 rows), `C_S_TRS_PTY_RLE_PHN` (5 rows),
`STG_TRS_VALID_MEMBERS` (6 spine rows), `EXC_STG_BAD_REC_MEMB`
(1 bad-record row: member 1004, blank last name),
`ZZ_UTL_UNMERGE_TREE_SRC_KEY` (2 rows: inactive members 1002,
1005).

Members (all fictional): 1001 Alice Anderson, 1002 Bob Jones
(inactive), 1003 Carol White, 1004 Dan (blank last name), 1005
Eve Martin (inactive), 1006 Frank Brown.

The Prod outputs are built by the same derivation the demo
simulator uses (`derive_outputs` in
`app/services/demo_etl_simulator.py`), with the planted
differences switched off for Prod and on for Dev:

- member 1003 renamed in Dev (DIFFERENT on `C_S_TRS_PTY`);
- member 1005 dropped from Dev party output (ONLY_IN_PROD);
- member 1007 added in Dev (ONLY_IN_DEV);
- one extra Dev-only exception row (ONLY_IN_DEV on
  `EXC_STG_BAD_REC_MEMB`);
- everything else matches exactly.

One sample-data honesty note: the `ZZ_UTL_UNMERGE_TREE_SRC_KEY`
columns (`INDV_ID`, `SRC_KEY`, `TREE_LEVEL`, `PROCESSED_YN`) are
sample columns, not Oracle DDL -- the ZZ table is written by the
deactivation workflows and was not in the supplied exports.
Replace them with the real column list before using that entry
against real Dev Oracle tables. Everything else in the pack uses
real column lists.

## 9. Adding a source or a table

Tables are data in `app/domain/pipeline_catalog.py`, not code
changes elsewhere. To add a table to a source:

1. Add its Oracle column list to `app/domain/tables.py`
   `COLUMN_TYPES` (from the Oracle DDL -- same rule as the v5
   catalog: never reflected at runtime).
2. Add one `PipelineTable` to that source's `input_tables` or
   `output_tables`: name, kind, Oracle schema, and for outputs
   the PK (`pk`) the compare sorts and matches on. A PK-less
   output table still copies, but compares by counts only and
   forces the verdict to PARTIAL.
3. If Dev Oracle may truncate it in step (C), add its name to
   the whitelist file.
4. Add a row to the tests (`tests/test_pipeline.py`) the same
   way the sample tables are covered.

To add a source: add a `SourceSpec` with its runner procedures
(keys are the workflow names step (D) accepts) and its table
lists. Until its tables are registered, copy/compare requests
for it return a 400 naming the gap instead of an empty run.

## 10. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `Whitelist file not found` | Step (C) fails closed without the file. Create it, or point `PIPELINE_WHITELIST_PATH` at the right one. |
| `NOT in the whitelist` naming tables, nothing truncated | Add those tables to the whitelist file, or remove them from the request. This is the safety gate working as designed. |
| `Refusing to run: the Prod and Dev connections are identical` | `PIPELINE_ORACLE_PROD_URL` equals `PIPELINE_ORACLE_DEV_URL`. Fix the URLs -- step (C) must never run against Production. |
| `NOT_FOUND` for a table in step (C) | The table doesn't exist in Dev. Create it there first (Dev mirrors Production); step (C) never creates Dev tables. |
| `No tables registered for source ...` | That source's table list is empty (ECI/WIC/TTF/FSS/CRE today). Register its tables (§9). |
| `Demo mode is on but demo database file(s) are missing` | Run `python sample_data/seed_demo.py` (from the project root). |
| Step (D) succeeds but step (F) shows everything as ONLY_IN_DEV / missing | The Dev schema still held rows from an earlier run, or (D) ran against a different schema than (E) reads. Re-run (D) with `"reset_outputs": true` and check `PIPELINE_SNOWFLAKE_DATABASE` / `PIPELINE_SNOWFLAKE_SCHEMA`. |
| A second (D) run changes nothing | Insert-only runners with existing-key guards suppress rows on re-runs. Same fix as above. |
| Verdict PARTIAL with COUNT_ONLY | A compared table has no PK in the registry. Register its PK (§9). |
| Verdict PARTIAL with MISSING_IN_DEV | The table is missing from `Dev_SQLite` -- usually (E) ran with a table filter that excluded it, or (D) never created it. |
| `Invalid SQLite filename` | File arguments must be bare filenames inside `PIPELINE_SQLITE_DIR`, not paths. Use the filename step (B)/(E) returned. |
| Compare shows a difference in a float column that looks equal | Values compare on their shortest decimal string form (see §11). For bit-exact float work, compare that table by another means. |

## 11. Limitations (stated plainly)

- **No scheduler.** Step (A) is a precondition, not a cron job:
  the readiness endpoint checks table existence, not whether the
  8 AM ETL actually ran. Confirm the ETL finished by hand.
- **The compare needs PKs.** Tables without a registered PK get
  count-only comparison and a PARTIAL verdict.
- **Value normalisation.** Dates compare as ISO strings, numbers
  as shortest decimal strings, bytes as hex, so Oracle NUMBER
  (Decimal) and SQLite integers compare equal. Exotic floats
  compare on their shortest string form (see troubleshooting).
- **Diff storage is capped** per table (`PIPELINE_COMPARE_DIFF_CAP`,
  default 10000); counts are always complete, only stored detail
  is capped.
- **The demo simulator is not the ETL.** It mimics the shape of a
  stage load at sample scale, with planted differences. Never
  point it at a real database -- it only runs in demo mode.
- **Merge compare streams in PK order.** Both sides must sort
  the same way; that is why the PK is required and why the copy
  SELECTs explicit columns.
- **Other sources' tables are not registered yet** (ECI, WIC,
  TTF, FSS, CRE). Their runners are; their table lists await
  their Oracle DDL (§9).
- **The v5 caveats still apply** to the v5 flow: the 4 missing
  Oracle definitions, the COMMON database location, and live
  Oracle/Snowflake testing of the v5 endpoints (see USER_GUIDE.md).

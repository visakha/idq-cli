"""Pipeline endpoints: the daily tester flow, steps (A) to (F).

Thin routes, in the same style as app/api/routes.py: validate the
request, call the pipeline service, record the run, return the
response.  No route touches a database directly, and no route
builds SQL.  Step (G), the Streamlit UI, is not an endpoint: it is
a separate local app (streamlit_app.py) that reads the
Compare_Results_SQLite file step (F) produces.

Authentication: same rule as the rest of the API -- if API_KEY is
set, every endpoint except /pipeline/sources requires X-API-Key.
(File arguments are bare filenames inside PIPELINE_SQLITE_DIR;
see pipeline_service.resolve_sqlite_file.)

Failure shape: a validation failure (unknown source/table/
workflow, whitelist refusal, prod==dev, bad filename) is a 400
raised BEFORE anything is written.  A step that ran but hit
per-table problems returns 200 with status PARTIAL/FAILED and the
per-table results, exactly like the v5 endpoints.
"""

from __future__ import annotations

import json
import os
import sqlite3
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Security
from fastapi.security import APIKeyHeader

from app.api.dependencies import get_run_repository
from app.core.config import settings
from app.core.pipeline_engines import PipelineEngines, get_pipeline_engines
from app.domain import pipeline_catalog
from app.domain.pipeline_models import (
    PipelineCompareRequest,
    PipelineCompareResponse,
    PipelineRunResponse,
    ProdToSqliteRequest,
    ReadinessResponse,
    RowDiffOut,
    RunSnowflakeEtlRequest,
    SnowflakeToSqliteRequest,
    SourceInfo,
    SqliteToDevRequest,
)
from app.repositories.run_repository import RunRepository
from app.services import pipeline_service

router = APIRouter(prefix="/pipeline", tags=["pipeline"])

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _require_api_key(x_api_key: str | None = Security(_api_key_header)) -> None:
    if settings.api_key and x_api_key != settings.api_key:
        raise HTTPException(status_code=401, detail="Missing or incorrect X-API-Key header.")


def _record(runs: RunRepository, run_type: str, status: str, message: str, summary,
            run_id: str | None = None) -> str:
    record = runs.new_run(run_id or str(uuid.uuid4()), run_type)
    finished = runs.finish_run(record, status, message, summary)
    return finished.id


def _table_results_to_json(results) -> list[dict]:
    return [r.model_dump() for r in results]


@router.get("/sources", response_model=list[SourceInfo])
def list_sources() -> list[SourceInfo]:
    """The pipeline registry: sources, runners, table names."""
    out = []
    for spec in pipeline_catalog.SOURCES.values():
        out.append(SourceInfo(
            source=spec.source,
            runners=dict(spec.runners),
            input_tables=[t.name for t in spec.input_tables],
            output_tables=[t.name for t in spec.output_tables],
        ))
    return out


@router.get("/readiness", response_model=ReadinessResponse, dependencies=[Depends(_require_api_key)])
def get_readiness(
    engines: Annotated[PipelineEngines, Depends(get_pipeline_engines)],
    source: str = "TRS",
) -> ReadinessResponse:
    """Step (A) check: do all input + output tables exist in Production?

    This is the check the tester runs after 8 AM, before step (B).
    It reports every table's existence and row count; `ready` is
    true only when every registered table exists.  Empty tables do
    not block readiness (an empty exception table is normal).
    """
    try:
        spec = pipeline_catalog.get_source(source)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    try:
        return pipeline_service.readiness(engines, spec.source)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"{type(exc).__name__}: {exc}") from exc


@router.post("/prod-to-sqlite", response_model=PipelineRunResponse, dependencies=[Depends(_require_api_key)])
def post_prod_to_sqlite(
    request: ProdToSqliteRequest,
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    engines: Annotated[PipelineEngines, Depends(get_pipeline_engines)],
) -> PipelineRunResponse:
    """Step (B): copy ETL_INPUT_TABLES + ETL_OUTPUT_TABLES from
    Oracle Production into a new Prod_SQLite file."""
    try:
        results, overall, filename = pipeline_service.prod_to_sqlite(
            engines, request.source, request.tables)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = f"Prod -> Prod_SQLite {overall}: {filename}."
    run_id = _record(runs, "pipeline-prod-to-sqlite", overall, message,
                     {"sqlite_file": filename, "tables": _table_results_to_json(results)})
    record = runs.get_run(run_id)
    response = PipelineRunResponse(
        run_id=record.id, run_type=record.run_type, status=record.status,
        message=record.message, started_at=record.started_at,
        finished_at=record.finished_at, results=_table_results_to_json(results),
        sqlite_path=filename,
    )
    return response


@router.post("/sqlite-to-dev", response_model=PipelineRunResponse, dependencies=[Depends(_require_api_key)])
def post_sqlite_to_dev(
    request: SqliteToDevRequest,
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    engines: Annotated[PipelineEngines, Depends(get_pipeline_engines)],
) -> PipelineRunResponse:
    """Step (C): load Prod_SQLite into Dev Oracle, truncating ONLY
    tables listed in White_list_tables_safe_to_truncate.txt.

    Anything not whitelisted is a 400 and nothing is truncated.
    The step also refuses to run when Prod and Dev connections are
    identical, so a misconfiguration cannot truncate Production.
    """
    try:
        results, overall = pipeline_service.sqlite_to_dev(
            engines, request.source, request.prod_sqlite, request.tables)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = f"Prod_SQLite -> Dev Oracle {overall}."
    run_id = _record(runs, "pipeline-sqlite-to-dev", overall, message,
                     {"prod_sqlite": request.prod_sqlite, "tables": _table_results_to_json(results)})
    record = runs.get_run(run_id)
    return PipelineRunResponse(
        run_id=record.id, run_type=record.run_type, status=record.status,
        message=record.message, started_at=record.started_at,
        finished_at=record.finished_at, results=_table_results_to_json(results),
    )


@router.post("/run-snowflake-etl", response_model=PipelineRunResponse, dependencies=[Depends(_require_api_key)])
def post_run_snowflake_etl(
    request: RunSnowflakeEtlRequest,
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    engines: Annotated[PipelineEngines, Depends(get_pipeline_engines)],
) -> PipelineRunResponse:
    """Step (D): run the Snowflake ETL for a source in Dev.

    Default workflows are the source's stage-load runners in order.
    A failure stops later workflows.  In demo mode this runs the
    demo simulator instead (PIPELINE_DEMO_MODE=true) -- the response
    says so, so a demo run can never be mistaken for a real one.
    """
    try:
        results, overall, summaries = pipeline_service.run_snowflake_etl(
            engines, request.source, request.workflows, request.reset_outputs)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = "; ".join(f"{r.get('workflow')}: {r.get('status')}" for r in results)
    run_id = _record(runs, "pipeline-run-snowflake-etl", overall, message,
                     {"workflows": results, "summaries": summaries})
    record = runs.get_run(run_id)
    return PipelineRunResponse(
        run_id=record.id, run_type=record.run_type, status=record.status,
        message=record.message, started_at=record.started_at,
        finished_at=record.finished_at, results=results,
    )


@router.post("/snowflake-to-sqlite", response_model=PipelineRunResponse, dependencies=[Depends(_require_api_key)])
def post_snowflake_to_sqlite(
    request: SnowflakeToSqliteRequest,
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    engines: Annotated[PipelineEngines, Depends(get_pipeline_engines)],
) -> PipelineRunResponse:
    """Step (E): copy ETL_OUTPUT_TABLES from Snowflake Dev into a
    new Dev_SQLite file (inputs too, with include_inputs=true)."""
    try:
        results, overall, filename = pipeline_service.snowflake_to_sqlite(
            engines, request.source, request.tables, request.include_inputs)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = f"Snowflake Dev -> Dev_SQLite {overall}: {filename}."
    run_id = _record(runs, "pipeline-snowflake-to-sqlite", overall, message,
                     {"sqlite_file": filename, "tables": _table_results_to_json(results)})
    record = runs.get_run(run_id)
    return PipelineRunResponse(
        run_id=record.id, run_type=record.run_type, status=record.status,
        message=record.message, started_at=record.started_at,
        finished_at=record.finished_at, results=_table_results_to_json(results),
        sqlite_path=filename,
    )


@router.post("/compare", response_model=PipelineCompareResponse, dependencies=[Depends(_require_api_key)])
def post_compare(
    request: PipelineCompareRequest,
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    engines: Annotated[PipelineEngines, Depends(get_pipeline_engines)],
) -> PipelineCompareResponse:
    """Step (F): compare Prod_SQLite vs Dev_SQLite record by record
    into a new Compare_Results_SQLite file.

    Verdict MATCH means every compared table matched exactly;
    MISMATCH means at least one table differs; PARTIAL means the
    evidence is incomplete (a table missing on a side, a table
    with no PK compared by counts only, or a table that failed).
    A MISMATCH is a successful compare with a negative answer
    (200, not an error) -- the detail is in the results file,
    readable via GET /pipeline/compare/{run_id} and the
    Streamlit app (step G).
    """
    try:
        summaries, verdict, status, filename, pipeline_run_id = pipeline_service.compare_sqlites(
            engines, request.source, request.prod_sqlite, request.dev_sqlite, request.tables)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    message = f"Compare {verdict} over {len(summaries)} tables: {filename}."
    run_id = _record(runs, "pipeline-compare", status, message,
                     {"results_db": filename,
                      # Full path, written by this endpoint itself when
                      # the run was recorded: GET /pipeline/compare/{id}
                      # reads the file back from here, so a test or
                      # demo run whose SQLite directory differs from
                      # the configured one still resolves.  The path
                      # never comes from a request.
                      "results_path": os.path.join(engines.sqlite_dir, filename),
                      "tables": [s.model_dump() for s in summaries],
                      "verdict": verdict},
                     run_id=pipeline_run_id)
    return PipelineCompareResponse(
        run_id=run_id, status=status, verdict=verdict, message=message,
        results_db=filename, tables=summaries,
    )


@router.get("/compare/{run_id}", dependencies=[Depends(_require_api_key)])
def get_compare(
    run_id: str,
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    table: str | None = None,
    status: str | None = None,
    limit: int = Query(default=200, ge=1, le=5000),
) -> dict:
    """Read a compare run's results back from its results file.

    The results file is taken from the run record, never from the
    request, so a caller cannot point this at an arbitrary file.
    Optional filters: table name, diff status (DIFFERENT,
    ONLY_IN_PROD, ONLY_IN_DEV).  Returns the run's table summaries
    plus the matching diff rows (capped by `limit`).
    """
    record = runs.get_run(run_id)
    if record is None or record.run_type != "pipeline-compare":
        raise HTTPException(status_code=404, detail=f"No pipeline compare run with id {run_id!r}.")
    summary = json.loads(record.summary_json) if record.summary_json else {}
    filename = summary.get("results_db")
    if not filename:
        raise HTTPException(status_code=404, detail="This compare run has no results file recorded.")
    # Prefer the path recorded with the run (it is the directory the
    # compare step actually wrote to); fall back to the configured
    # directory for runs recorded before this field existed.
    path = summary.get("results_path") or os.path.join(settings.pipeline_sqlite_dir, filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail=f"Results file not found: {filename}.")
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    try:
        tables = [dict(r) for r in conn.execute(
            "SELECT table_name, status, prod_count, dev_count, matched, different, "
            "only_in_prod, only_in_dev, diff_rows_stored, message FROM table_summary "
            "WHERE run_id = ? ORDER BY table_name", (run_id,))]
        query = ("SELECT table_name, status, pk_json, differing_columns_json, "
                 "prod_values_json, dev_values_json FROM row_diffs WHERE run_id = ?")
        params: list = [run_id]
        if table:
            query += " AND table_name = ?"
            params.append(table)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY table_name, status LIMIT ?"
        params.append(limit)
        diffs = []
        for r in conn.execute(query, params):
            diffs.append(RowDiffOut(
                table=r["table_name"], status=r["status"],
                pk=json.loads(r["pk_json"]),
                differing_columns=json.loads(r["differing_columns_json"]),
                prod_values=json.loads(r["prod_values_json"]),
                dev_values=json.loads(r["dev_values_json"]),
            ).model_dump())
        return {
            "run_id": run_id, "verdict": summary.get("verdict"),
            "results_db": filename, "tables": tables, "diffs": diffs,
        }
    finally:
        conn.close()


@router.get("/compare-runs", dependencies=[Depends(_require_api_key)])
def list_compare_runs(
    runs: Annotated[RunRepository, Depends(get_run_repository)],
    limit: int = Query(default=50, ge=1, le=200),
) -> list[dict]:
    """Recent pipeline compare runs, newest first."""
    records = runs.list_runs(run_type="pipeline-compare", limit=limit)
    out = []
    for record in records:
        summary = json.loads(record.summary_json) if record.summary_json else {}
        out.append({
            "run_id": record.id, "status": record.status,
            "message": record.message, "started_at": record.started_at,
            "finished_at": record.finished_at,
            "verdict": summary.get("verdict"),
            "results_db": summary.get("results_db"),
        })
    return out

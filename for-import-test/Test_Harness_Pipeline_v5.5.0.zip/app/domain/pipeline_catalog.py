"""Pipeline catalog: per-source ETL_INPUT_TABLES and ETL_OUTPUT_TABLES.

The daily tester flow (see PIPELINE_USER_GUIDE.md) works per source,
because the tables are mostly source-specific:

  * ETL_INPUT_TABLES  -- the _D_ and _H_ tables and other supporting
    tables the Production ETL reads.  In the TRS catalog these are
    the "input" tables (STG_TRS_D_*, STG_TRS_H_*, reference tables).
    They are copied Prod Oracle -> Prod_SQLite -> Dev Oracle, and
    they are NOT compared: the Dev side gets them verbatim from the
    Prod side, so comparing them would only re-prove the copy.
  * ETL_OUTPUT_TABLES -- the tables the Production ETL writes: the
    C_S_* target tables, the Status/State-tracking tables, and the
    ZZ_* work tables.  In the TRS catalog these are the "expected"
    tables.  These ARE compared, record by record, between
    Prod_SQLite (IDQ results, from Oracle Production) and
    Dev_SQLite (Snowflake results, from Snowflake Dev).

Table shapes: TRS entries are built from the two checked-in sources
that already describe them -- app/domain/catalog.py (role, Oracle
schema, compare key) and app/domain/tables.py COLUMN_TYPES (explicit
column lists, generated from the Oracle DDL, never reflected at
runtime).  The DATA_SOURCE discriminator column is dropped here on
purpose: it exists only on the Snowflake side of the v5 flow, not in
Oracle Production, so a Prod Oracle copy must not ask for it.  The
copy always SELECTs the listed columns by name, never SELECT *.

Other sources (ECI, WIC, TTF, FSS, CRE) are registered with their
real stage-load runner procedures (taken from the bare-bones
packages) and empty table lists.  That is deliberate, not an
oversight: their Oracle table lists were not part of this delivery,
and inventing them would be worse than leaving them blank.  Add a
source's tables exactly like the TRS entries below -- one
PipelineTable per table, columns from that source's Oracle DDL --
and the endpoints work unchanged.  The guide shows a worked example
(adding ZZ_UTL_UNMERGE_TREE_SRC_KEY is already done this way).

Runner keys: the (D) endpoint accepts these short keys, never a raw
procedure name from a request.  A procedure name reaches SQL only
from this allowlist.
"""

from __future__ import annotations

from pydantic import BaseModel

from app.domain import catalog
from app.domain.tables import COLUMN_TYPES


class PipelineTable(BaseModel):
    """One pipeline table: name, kind, Oracle schema, columns, PK."""

    name: str
    kind: str  # "input" | "output"
    oracle_schema: str | None = None
    columns: list[str] = []
    pk: list[str] = []  # empty for inputs (copied, never compared)
    note: str = ""
    missing_from_exports: bool = False


class SourceSpec(BaseModel):
    """Everything the pipeline needs to know about one source."""

    source: str
    # workflow key -> runner procedure, in default run order
    runners: dict[str, str] = {}
    input_tables: list[PipelineTable] = []
    output_tables: list[PipelineTable] = []

    @property
    def all_tables(self) -> list[PipelineTable]:
        return self.input_tables + self.output_tables


def _trs_tables(specs, kind: str) -> list[PipelineTable]:
    tables: list[PipelineTable] = []
    for spec in specs:
        cols = [c for c, _ in COLUMN_TYPES.get(spec.name, [])]
        # The v5 discriminator column lives only in Snowflake, not
        # in Oracle Production: never ask Oracle for it.
        cols = [c for c in cols if c != "DATA_SOURCE"]
        tables.append(PipelineTable(
            name=spec.name,
            kind=kind,
            oracle_schema=spec.oracle_schema,
            columns=cols,
            pk=list(spec.compare_key) if kind == "output" else [],
            note="Missing from the supplied Oracle exports; supply its definition first."
            if spec.missing_from_exports else "",
            missing_from_exports=spec.missing_from_exports,
        ))
    return tables


# ZZ work tables are written by the deactivation workflows, not by
# the stage-load mappings, so they are not in the TRS catalog.  They
# belong in ETL_OUTPUT_TABLES all the same (the user named ZZ*
# tables explicitly), so they are registered here.  Columns are
# SAMPLE columns for the demo pack, not Oracle DDL: replace them
# with the real column list from your Oracle DDL before using this
# entry against real Dev Oracle tables.
ZZ_TABLES: list[PipelineTable] = [
    PipelineTable(
        name="ZZ_UTL_UNMERGE_TREE_SRC_KEY",
        kind="output",
        oracle_schema="STAGING",
        columns=["INDV_ID", "SRC_KEY", "TREE_LEVEL", "PROCESSED_YN"],
        pk=["INDV_ID"],
        note="SAMPLE columns for the demo pack -- replace with the real Oracle DDL columns before production use.",
    ),
]

_TRS_INPUTS = _trs_tables(catalog.INPUT_TABLES, "input")
_TRS_OUTPUTS = _trs_tables(catalog.EXPECTED_TABLES, "output") + ZZ_TABLES

SOURCES: dict[str, SourceSpec] = {
    "TRS": SourceSpec(
        source="TRS",
        runners={
            # Stage-load workflows, TOA catalogue first, then Ongoing
            # (same order as the v5 ETL endpoint).
            "toa": "sp_etl_run_wf_TRS_Stage_Load_TOA",
            "ongoing": "sp_etl_run_wf_TRS_Stage_Load_1_Ongoing",
            # Deactivation workflows (bare-bones package).  These are
            # opt-in: pass them explicitly in the workflows list.
            "deactivation-initial": "sp_etl_run_wf_TRS_Deactivation_Initial",
            "deactivation-relationship": "sp_etl_run_wf_TRS_Relationship_Deactivation",
            "deactivation-history": "sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History",
            "deactivation-complete": "sp_etl_run_wf_TRS_Deactivation_Complete",
        },
        input_tables=_TRS_INPUTS,
        output_tables=_TRS_OUTPUTS,
    ),
    # Runner procedures below are real (bare-bones packages).  Table
    # lists are empty until their Oracle DDL is supplied -- see the
    # module docstring.  Requesting a copy/compare for one of these
    # sources today returns a 400 naming the gap, not an empty run
    # pretending to have compared something.
    "ECI": SourceSpec(source="ECI", runners={"stage-load": "sp_etl_run_wf_ECI_Stage_Load"}),
    "WIC": SourceSpec(source="WIC", runners={"stage-load": "sp_etl_run_wf_WIC_Stage_Load"}),
    "TTF": SourceSpec(source="TTF", runners={"stage-load": "sp_etl_run_wf_TTF_Stage_Load"}),
    "FSS": SourceSpec(source="FSS", runners={"stage-load": "sp_etl_run_wf_FSS_Stage_Load"}),
    "CRE": SourceSpec(source="CRE", runners={"stage-load": "sp_etl_run_wf_CRE_Stage_Load_Ongoing"}),
}


def get_source(source: str) -> SourceSpec:
    """SourceSpec for a source name (case-insensitive), or KeyError."""
    key = (source or "").upper()
    if key not in SOURCES:
        raise KeyError(f"Unknown source: {source!r}. Known sources: {sorted(SOURCES)}")
    return SOURCES[key]


def tables_for_pipeline(
    source: str,
    kinds: list[str] | None,
    requested: list[str] | None,
) -> list[PipelineTable]:
    """Tables for a pipeline step, in registry order.

    kinds filters to "input"/"output" (None = both).  requested, when
    given, must name tables in the registry -- an unknown name is a
    400, never a table name reaching SQL unchecked.
    """
    spec = get_source(source)
    pool = [t for t in spec.all_tables if kinds is None or t.kind in kinds]
    if requested is None:
        return pool
    by_name = {t.name: t for t in pool}
    unknown = [n for n in requested if n not in by_name]
    if unknown:
        raise KeyError(
            f"Unknown table(s) for source {spec.source} (kind={kinds}): {unknown}. "
            f"Known: {sorted(by_name)}"
        )
    return [by_name[n] for n in requested]


def default_workflows(source: str) -> list[str]:
    """The stage-load runners for a source, in order (deactivation excluded)."""
    spec = get_source(source)
    stage_keys = [k for k in spec.runners if not k.startswith("deactivation-")]
    return stage_keys

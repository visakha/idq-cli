"""Typed models for the pipeline endpoints -- Pydantic only, no ORM.

File arguments are bare FILENAMES inside the configured SQLite
directory, never paths: the service resolves them inside
PIPELINE_SQLITE_DIR and rejects anything with a separator or "..".
That keeps the old harness's rule (no request can point the API at
an arbitrary file) while still letting the tester chain the steps:
(B) returns a Prod_SQLite filename, (C) takes it, (F) takes both.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.domain.models import RunResponse


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------
class ProdToSqliteRequest(BaseModel):
    """POST /pipeline/prod-to-sqlite (step B)."""

    source: str = Field(default="TRS", description="Source, e.g. TRS")
    tables: list[str] | None = Field(default=None, description="Table names to copy; None = all input + output tables for the source")


class SqliteToDevRequest(BaseModel):
    """POST /pipeline/sqlite-to-dev (step C)."""

    source: str = Field(default="TRS")
    prod_sqlite: str = Field(description="Prod_SQLite filename from step B, e.g. prod_TRS_20261027_143022.db")
    tables: list[str] | None = Field(default=None, description="Table names to load; None = all tables in the registry for the source. Every one must be in the whitelist file.")


class RunSnowflakeEtlRequest(BaseModel):
    """POST /pipeline/run-snowflake-etl (step D)."""

    source: str = Field(default="TRS")
    workflows: list[str] | None = Field(default=None, description="Workflow keys from the registry; None = the source's stage-load runners in order")
    reset_outputs: bool = Field(default=False, description="If true, truncate the Dev output tables before calling the runners. Default false: the runners are insert-only with existing-key guards, so re-running without a reset suppresses rows. Demo mode always resets (the simulator truncates its own outputs).")


class SnowflakeToSqliteRequest(BaseModel):
    """POST /pipeline/snowflake-to-sqlite (step E)."""

    source: str = Field(default="TRS")
    tables: list[str] | None = Field(default=None, description="Output table names to copy; None = all output tables for the source")
    include_inputs: bool = Field(default=False, description="Also copy the input tables from Snowflake Dev (off by default: inputs are verified by the copy counts, and the compare covers outputs)")


class PipelineCompareRequest(BaseModel):
    """POST /pipeline/compare (step F)."""

    source: str = Field(default="TRS")
    prod_sqlite: str = Field(description="Prod_SQLite filename from step B")
    dev_sqlite: str = Field(description="Dev_SQLite filename from step E")
    tables: list[str] | None = Field(default=None, description="Output table names to compare; None = all output tables for the source")


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------
class PipelineTableResult(BaseModel):
    table: str
    kind: str = ""  # "input" | "output"
    status: str  # "COPIED" | "LOADED" | "FAILED" | "SKIPPED_MISSING" | "NOT_FOUND"
    source_rows: int | None = None
    target_rows: int | None = None
    message: str = ""


class PipelineRunResponse(RunResponse):
    """A pipeline run response: a RunResponse plus the file it made."""

    sqlite_path: str | None = None  # step B/E: the SQLite file produced
    results_db: str | None = None  # step F: the Compare_Results_SQLite file produced


class TableCompareSummary(BaseModel):
    table: str
    status: str  # "MATCH" | "MISMATCH" | "MISSING_IN_PROD" | "MISSING_IN_DEV" | "COUNT_ONLY" | "FAILED"
    prod_count: int | None = None
    dev_count: int | None = None
    matched: int = 0
    different: int = 0
    only_in_prod: int = 0
    only_in_dev: int = 0
    diff_rows_stored: int = 0
    message: str = ""


class PipelineCompareResponse(BaseModel):
    run_id: str
    status: str
    verdict: str  # "MATCH" | "MISMATCH" | "PARTIAL"
    message: str = ""
    results_db: str | None = None
    tables: list[TableCompareSummary] = []


class ReadinessTable(BaseModel):
    table: str
    kind: str
    exists: bool
    row_count: int | None = None
    message: str = ""


class ReadinessResponse(BaseModel):
    source: str
    ready: bool
    message: str = ""
    tables: list[ReadinessTable] = []


class SourceInfo(BaseModel):
    source: str
    runners: dict[str, str] = {}
    input_tables: list[str] = []
    output_tables: list[str] = []


class RowDiffOut(BaseModel):
    table: str
    status: str  # "DIFFERENT" | "ONLY_IN_PROD" | "ONLY_IN_DEV"
    pk: dict = {}
    differing_columns: list[str] = []
    prod_values: dict = {}
    dev_values: dict = {}

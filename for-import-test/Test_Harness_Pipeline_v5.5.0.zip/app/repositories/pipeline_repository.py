"""Generic table store for the pipeline: copy rows between any engines.

One class serves Oracle, Snowflake and SQLite, because the pipeline
copies the same registry tables between all three.  The rules that
make that safe:

  * Table shapes come from the registry (pipeline_catalog) plus the
    checked-in COLUMN_TYPES -- never from reflecting a database.
    A table's columns are explicit code, so a copy can never silently
    pick up (or drop) a column because a database changed.
  * Every SELECT names its columns explicitly.  No SELECT * anywhere:
    the Prod Oracle tables do not carry the v5 DATA_SOURCE column,
    and a SELECT * would break the moment a side gains a column.
  * Schema handling is per dialect, in one place: SQLite tables are
    unqualified (a SQLite file has no Oracle/Snowflake schemas);
    Oracle tables use the registry's oracle_schema; Snowflake
    tables use the configured pipeline schema.  The caller passes
    the target schema; this class never guesses one.
  * TRUNCATE vs DELETE is also per dialect: SQLite has no TRUNCATE,
    so the Dev-side clear is DELETE FROM there and TRUNCATE TABLE
    everywhere else.  Both leave the DDL (and grants) intact.
"""

from __future__ import annotations

from collections.abc import Iterator

from sqlalchemy import Column, MetaData, Numeric, String, Table, text
from sqlalchemy.engine import Engine

from app.domain.pipeline_catalog import PipelineTable
from app.domain.tables import COLUMN_TYPES

_METADATA = MetaData()

# Fallback types for tables with no COLUMN_TYPES entry (currently
# only the ZZ sample table).  Real tables must get their columns
# from the Oracle DDL via COLUMN_TYPES, not from this map.
_FALLBACK_TYPES: dict[str, object] = {
    "ZZ_UTL_UNMERGE_TREE_SRC_KEY": None,  # built explicitly below
}

def _zz_columns() -> list[Column]:
    """Fresh Column objects on every call: a Column may belong to only
    one Table, and build_table is called once per operation, so the
    objects must never be shared between calls."""
    return [
        Column("INDV_ID", Numeric(38, 0)),
        Column("SRC_KEY", String(255)),
        Column("TREE_LEVEL", Numeric(38, 0)),
        Column("PROCESSED_YN", String(1)),
    ]


def table_columns(table_name: str) -> list[Column]:
    """SQLAlchemy Columns for a registry table, from checked-in data."""
    if table_name == "ZZ_UTL_UNMERGE_TREE_SRC_KEY":
        return _zz_columns()
    cols = COLUMN_TYPES.get(table_name)
    if cols is None:
        raise KeyError(
            f"No column list for table {table_name!r} in app/domain/tables.py. "
            "Add it from the Oracle DDL before copying this table."
        )
    return [Column(name, ctype) for name, ctype in cols if name != "DATA_SOURCE"]


def build_table(table_name: str, schema: str | None) -> Table:
    """A fresh Table object for one side of a copy (see tables.py)."""
    return Table(table_name, MetaData(), *table_columns(table_name), schema=schema)


class TableStore:
    """Row operations for one engine.  No business rules live here."""

    def __init__(self, engine: Engine) -> None:
        self.engine = engine

    @property
    def dialect(self) -> str:
        return self.engine.dialect.name

    @staticmethod
    def schema_for(table: PipelineTable, dialect: str, target_schema: str | None) -> str | None:
        """Schema to use for a table on an engine of this dialect."""
        if dialect == "sqlite":
            return None
        if dialect == "oracle":
            return table.oracle_schema
        # Snowflake (and anything else): the caller-supplied schema.
        return target_schema

    def table_exists(self, table_name: str, schema: str | None) -> bool:
        """True if a COUNT probe succeeds.  Any failure reads as missing.

        A permission failure would also read as missing here, but it
        cannot hide: the copy that follows fails loudly with the real
        error, so a missing table is never silently skipped.
        """
        tbl = build_table(table_name, schema)
        try:
            with self.engine.connect() as conn:
                conn.execute(text(f"SELECT COUNT(*) FROM {tbl.fullname}"))
            return True
        except Exception:
            return False

    def ensure_table(self, table_name: str, schema: str | None) -> None:
        """Create the table if it is missing, keeping existing DDL untouched.

        Implemented as an existence check followed by a plain CREATE,
        not CREATE TABLE IF NOT EXISTS: Oracle (pre-23ai) does not
        accept the IF NOT EXISTS form, and the check-then-create form
        works on all three dialects.
        """
        if self.table_exists(table_name, schema):
            return
        tbl = build_table(table_name, schema)
        from sqlalchemy.schema import CreateTable

        ddl = str(CreateTable(tbl).compile(self.engine))
        with self.engine.begin() as conn:
            conn.execute(text(ddl))

    def count_rows(self, table_name: str, schema: str | None) -> int:
        tbl = build_table(table_name, schema)
        with self.engine.connect() as conn:
            return int(conn.execute(text(f"SELECT COUNT(*) FROM {tbl.fullname}")).scalar() or 0)

    def stream_rows(
        self, table: PipelineTable, schema: str | None, batch_size: int
    ) -> Iterator[list[dict]]:
        """Yield row batches as dicts, in PK order when a PK exists.

        Ordering by PK is what the compare relies on (both sides
        sorted the same way, merged in Python), and it makes a copy
        deterministic too.  Tables without a PK stream in database
        order -- fine for a copy, never used for a compare.
        """
        tbl = build_table(table.name, schema)
        cols = ", ".join(f'"{c}"' for c in table.columns)
        order = ""
        if table.pk:
            order = " ORDER BY " + ", ".join(f'"{c}"' for c in table.pk)
        sql = f"SELECT {cols} FROM {tbl.fullname}{order}"
        with self.engine.connect() as conn:
            result = conn.execute(text(sql))
            keys = result.keys()
            while True:
                batch = result.fetchmany(batch_size)
                if not batch:
                    break
                yield [dict(zip(keys, row)) for row in batch]

    def insert_rows(self, table_name: str, schema: str | None, rows: list[dict]) -> None:
        if not rows:
            return
        tbl = build_table(table_name, schema)
        cols = [c.name for c in tbl.columns]
        placeholders = ", ".join(f":{c}" for c in cols)
        col_list = ", ".join(f'"{c}"' for c in cols)
        sql = text(f'INSERT INTO {tbl.fullname} ({col_list}) VALUES ({placeholders})')
        cleaned = [{c: row.get(c) for c in cols} for row in rows]
        with self.engine.begin() as conn:
            conn.execute(sql, cleaned)

    def clear_table(self, table_name: str, schema: str | None) -> None:
        """Empty a table, keeping its DDL: DELETE on SQLite, TRUNCATE elsewhere."""
        tbl = build_table(table_name, schema)
        sql = f"DELETE FROM {tbl.fullname}" if self.dialect == "sqlite" else f"TRUNCATE TABLE {tbl.fullname}"
        with self.engine.begin() as conn:
            conn.execute(text(sql))

    def call_procedure(self, schema: str, procedure: str) -> str:
        """CALL a Snowflake runner in a schema; return its summary text.

        The procedure name comes only from the registry allowlist,
        never from a request.  Snowflake CALL returns a one-row
        result set holding the procedure's RETURN string.
        """
        with self.engine.connect() as conn:
            if self.dialect == "snowflake":
                conn.execute(text(f"USE SCHEMA {schema}"))
            result = conn.execute(text(f"CALL {procedure}()"))
            row = result.fetchone()
            if row is None:
                return ""
            return "" if row[0] is None else str(row[0])

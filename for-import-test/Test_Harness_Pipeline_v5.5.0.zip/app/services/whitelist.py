"""Whitelist for the (C) step: which Dev Oracle tables may be truncated.

Safety rules, all fail-closed:
  * The file must exist.  A missing file is an error, not an empty
    whitelist: silently truncating nothing would make the (C) step
    report success while loading nothing.
  * One table name per line.  Blank lines and lines starting with
    "#" are ignored.  Names are upper-cased on load, so the file
    may use any case.
  * A requested table that is NOT listed is rejected BEFORE
    anything is written, and the response names every offender.
    There is no partial-truncate path: either every requested
    table is whitelisted, or nothing is truncated.
  * The whitelist says nothing about Production: the (C) step
    writes only to the Dev engine, and refuses to run at all when
    the Dev URL equals the Prod URL (see pipeline_service).
"""

from __future__ import annotations


def load_whitelist(path: str) -> set[str]:
    """Load the whitelist file.  Raises ValueError if it is missing."""
    try:
        with open(path, encoding="utf-8") as fh:
            lines = fh.read().splitlines()
    except FileNotFoundError as exc:
        raise ValueError(
            f"Whitelist file not found: {path}. Refusing to truncate "
            "anything without it (fail closed). Create it with one Dev "
            "Oracle table name per line -- see "
            "config/White_list_tables_safe_to_truncate.txt."
        ) from exc
    names = set()
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        names.add(line.upper())
    return names


def check_whitelisted(requested: list[str], whitelist: set[str]) -> list[str]:
    """Requested names NOT in the whitelist (empty = all allowed)."""
    return [name for name in requested if name.upper() not in whitelist]

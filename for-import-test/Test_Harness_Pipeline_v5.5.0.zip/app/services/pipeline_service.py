"""Pipeline service: the daily tester flow, steps (A) to (F).

The flow (see PIPELINE_USER_GUIDE.md):
  (A) By 8 AM the Production ETL has completed: ETL_INPUT_TABLES
      (_D_, _H_, supporting) and ETL_OUTPUT_TABLES (C_S_*,
      Status/State, ZZ*) are ready in Oracle Production.  This step
      is a precondition, not an endpoint -- the readiness endpoint
      checks it (tables exist, with row counts) before step (B).
  (B) Prod Oracle -> Prod_SQLite (a SQLite file).
  (C) Prod_SQLite -> Dev Oracle, truncating ONLY tables listed in
      White_list_tables_safe_to_truncate.txt.
  (D) Run the Snowflake ETL for a source in Dev.
  (E) Snowflake Dev -> Dev_SQLite (a SQLite file).
  (F) Compare Prod_SQLite vs Dev_SQLite record by record into
      Compare_Results_SQLite.  Step (G), the Streamlit UI, reads
      that file; it is not part of this service.

This service owns only the rules: which tables, in which order,
what counts as success, and every safety gate.  All row movement
goes through TableStore (repositories/pipeline_repository.py);
all record comparison goes through pipeline_compare.py.  Like the
v5 services, a per-table failure is recorded and the run continues
-- one bad table must not hide the other tables' results -- while
a validation failure (unknown source/table/workflow, whitelist
refusal, prod==dev) raises before anything is written.

Overall status: COMPLETED (every table copied/loaded), PARTIAL
(at least one table skipped/not-found/failed but at least one
succeeded), FAILED (nothing succeeded, or the step itself failed).
"""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

from sqlalchemy import create_engine

from app.core.config import settings
from app.core.pipeline_engines import PipelineEngines
from app.domain.pipeline_catalog import (
    PipelineTable,
    default_workflows,
    get_source,
    tables_for_pipeline,
)
from app.domain.pipeline_models import (
    PipelineTableResult,
    ReadinessResponse,
    ReadinessTable,
    TableCompareSummary,
)
from app.repositories.pipeline_repository import TableStore
from app.services import pipeline_compare, whitelist


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def resolve_sqlite_file(sqlite_dir: str, filename: str, must_exist: bool) -> str:
    """Resolve a bare filename inside the SQLite directory.

    Rejects separators and ".." outright: a request must never
    escape the directory.  must_exist=True (inputs) requires the
    file to be there; False (outputs) just returns the path.
    """
    if not filename or filename != os.path.basename(filename) or filename in (".", ".."):
        raise ValueError(
            f"Invalid SQLite filename: {filename!r}. Give a bare filename "
            "inside the pipeline SQLite directory, not a path."
        )
    path = os.path.join(sqlite_dir, filename)
    if must_exist and not os.path.exists(path):
        raise ValueError(
            f"SQLite file not found in the pipeline directory: {filename!r}. "
            "Run the step that produces it first."
        )
    return path


def _overall(results: list[PipelineTableResult]) -> str:
    ok = {"COPIED", "LOADED"}
    statuses = {r.status for r in results}
    if statuses and statuses <= ok:
        return "COMPLETED"
    if statuses & ok:
        return "PARTIAL"
    return "FAILED"


def _copy_tables(
    source_store: TableStore, source_schema: str | None,
    target_store: TableStore, target_schema: str | None,
    tables: list[PipelineTable], clear_first: bool,
    verb: str, batch_size: int = settings.copy_batch_size,
) -> list[PipelineTableResult]:
    """Copy tables between two stores, verifying row counts."""
    results: list[PipelineTableResult] = []
    for spec in tables:
        src_schema = TableStore.schema_for(spec, source_store.dialect, source_schema)
        tgt_schema = TableStore.schema_for(spec, target_store.dialect, target_schema)
        if spec.missing_from_exports:
            results.append(PipelineTableResult(
                table=spec.name, kind=spec.kind, status="SKIPPED_MISSING",
                message="Not in the supplied Oracle exports; definition must be supplied first.",
            ))
            continue
        if not source_store.table_exists(spec.name, src_schema):
            results.append(PipelineTableResult(
                table=spec.name, kind=spec.kind, status="NOT_FOUND",
                message=f"Table {spec.name} does not exist on the source side.",
            ))
            continue
        try:
            source_rows = source_store.count_rows(spec.name, src_schema)
            target_store.ensure_table(spec.name, tgt_schema)
            if clear_first:
                target_store.clear_table(spec.name, tgt_schema)
            copied = 0
            for batch in source_store.stream_rows(spec, src_schema, batch_size):
                target_store.insert_rows(spec.name, tgt_schema, batch)
                copied += len(batch)
            target_rows = target_store.count_rows(spec.name, tgt_schema)
            # clear_first + fresh file both start empty, so the
            # target count must equal the source count afterwards.
            if target_rows == source_rows and copied == source_rows:
                status = verb
                message = f"{verb} {source_rows} rows."
            else:
                status = "FAILED"
                message = (f"Row-count mismatch: source={source_rows}, "
                           f"streamed={copied}, target={target_rows}.")
            results.append(PipelineTableResult(
                table=spec.name, kind=spec.kind, status=status,
                source_rows=source_rows, target_rows=target_rows, message=message,
            ))
        except Exception as exc:
            results.append(PipelineTableResult(
                table=spec.name, kind=spec.kind, status="FAILED",
                message=f"{type(exc).__name__}: {exc}",
            ))
    return results


# ---------------------------------------------------------------------------
# (A) Readiness: is Production ready for step (B)?
# ---------------------------------------------------------------------------
def readiness(engines: PipelineEngines, source: str) -> ReadinessResponse:
    spec = get_source(source)
    store = TableStore(engines.prod)
    tables: list[ReadinessTable] = []
    missing: list[str] = []
    for table in spec.all_tables:
        schema = TableStore.schema_for(table, store.dialect, None)
        exists = store.table_exists(table.name, schema)
        count = store.count_rows(table.name, schema) if exists else None
        if not exists:
            missing.append(table.name)
        tables.append(ReadinessTable(
            table=table.name, kind=table.kind, exists=exists, row_count=count,
            message="" if exists else "Table does not exist on the Prod side.",
        ))
    ready = not missing
    message = (
        f"Production is ready for source {spec.source}: all {len(tables)} tables exist."
        if ready else
        f"Production is NOT ready for source {spec.source}: {len(missing)} table(s) missing: "
        + ", ".join(missing)
    )
    return ReadinessResponse(source=spec.source, ready=ready, message=message, tables=tables)


# ---------------------------------------------------------------------------
# (B) Prod Oracle -> Prod_SQLite
# ---------------------------------------------------------------------------
def prod_to_sqlite(
    engines: PipelineEngines, source: str, requested: list[str] | None,
) -> tuple[list[PipelineTableResult], str, str]:
    spec = get_source(source)
    tables = tables_for_pipeline(source, None, requested)
    if not tables:
        raise ValueError(
            f"No tables registered for source {spec.source} yet. Add its "
            "Oracle table list to pipeline_catalog.py first (see the guide)."
        )
    os.makedirs(engines.sqlite_dir, exist_ok=True)
    filename = f"prod_{spec.source}_{utc_timestamp()}.db"
    path = os.path.join(engines.sqlite_dir, filename)
    if os.path.exists(path):
        os.remove(path)
    prod_store = TableStore(engines.prod)
    sqlite_store = TableStore(create_engine(f"sqlite:///{path}"))
    try:
        results = _copy_tables(prod_store, None, sqlite_store, None, tables,
                               clear_first=False, verb="COPIED")
    finally:
        sqlite_store.engine.dispose()
    return results, _overall(results), filename


# ---------------------------------------------------------------------------
# (C) Prod_SQLite -> Dev Oracle (whitelist-gated truncate + load)
# ---------------------------------------------------------------------------
def sqlite_to_dev(
    engines: PipelineEngines, source: str, prod_sqlite: str,
    requested: list[str] | None,
) -> tuple[list[PipelineTableResult], str]:
    if engines.prod_label == engines.dev_label:
        raise ValueError(
            "Refusing to run: the Prod and Dev connections are identical. "
            "Step (C) truncates Dev tables; it must never run against "
            "Production. Fix PIPELINE_ORACLE_PROD_URL / PIPELINE_ORACLE_DEV_URL."
        )
    allowed = whitelist.load_whitelist(settings.pipeline_whitelist_path)
    spec = get_source(source)
    tables = tables_for_pipeline(source, None, requested)
    offenders = whitelist.check_whitelisted([t.name for t in tables], allowed)
    if offenders:
        raise ValueError(
            "Refusing to truncate: these tables are NOT in the whitelist file "
            f"({settings.pipeline_whitelist_path}): {', '.join(offenders)}. "
            "Add them to the file first, or remove them from the request. "
            "Nothing was truncated."
        )
    prod_path = resolve_sqlite_file(engines.sqlite_dir, prod_sqlite, must_exist=True)
    sqlite_store = TableStore(create_engine(f"sqlite:///{prod_path}"))
    dev_store = TableStore(engines.dev)
    try:
        results: list[PipelineTableResult] = []
        for table in tables:
            if table.missing_from_exports:
                results.append(PipelineTableResult(
                    table=table.name, kind=table.kind, status="SKIPPED_MISSING",
                    message="Not in the supplied Oracle exports; definition must be supplied first.",
                ))
                continue
            dev_schema = TableStore.schema_for(table, dev_store.dialect, None)
            if not dev_store.table_exists(table.name, dev_schema):
                results.append(PipelineTableResult(
                    table=table.name, kind=table.kind, status="NOT_FOUND",
                    message=f"Table {table.name} does not exist in Dev. Create it "
                            "there first (the Dev schemas mirror Production); this step never creates Dev tables.",
                ))
                continue
            sub = _copy_tables(sqlite_store, None, dev_store, None, [table],
                               clear_first=True, verb="LOADED")
            results.extend(sub)
        return results, _overall(results)
    finally:
        sqlite_store.engine.dispose()


# ---------------------------------------------------------------------------
# (D) Run the Snowflake ETL for a source in Dev
# ---------------------------------------------------------------------------
def run_snowflake_etl(
    engines: PipelineEngines, source: str, workflows: list[str] | None,
    reset_outputs: bool,
) -> tuple[list[dict], str, dict]:
    spec = get_source(source)
    keys = workflows if workflows is not None else default_workflows(source)
    if not keys:
        raise ValueError(f"No workflows registered for source {spec.source}.")
    unknown = [k for k in keys if k not in spec.runners]
    if unknown:
        raise ValueError(
            f"Unknown workflow(s) for source {spec.source}: {unknown}. "
            f"Allowed: {sorted(spec.runners)}"
        )
    if engines.demo_mode:
        from app.services import demo_etl_simulator

        counts = demo_etl_simulator.run_demo_etl(
            TableStore(engines.dev), TableStore(engines.snowflake_dev)
        )
        note = counts.pop("_note", "")
        results = [{
            "workflow": "(demo-simulator)",
            "status": "COMPLETED",
            "message": note + " " + "; ".join(f"{t}: {n} rows" for t, n in counts.items()),
        }]
        return results, "COMPLETED", counts
    snow_store = TableStore(engines.snowflake_dev)
    results: list[dict] = []
    if reset_outputs:
        for table in spec.output_tables:
            try:
                snow_store.clear_table(table.name, engines.snowflake_schema)
            except Exception as exc:
                results.append({
                    "workflow": "(reset-outputs)", "status": "FAILED",
                    "message": f"Could not truncate Dev output table {table.name}: {exc}",
                })
                return results, "FAILED", {}
        results.append({
            "workflow": "(reset-outputs)", "status": "CLEARED",
            "message": f"Truncated {len(spec.output_tables)} Dev output tables in "
                       f"{engines.snowflake_schema} before running.",
        })
    summaries: dict[str, str] = {}
    for key in keys:
        proc = spec.runners[key]
        try:
            text_out = snow_store.call_procedure(engines.snowflake_schema, proc)
            summaries[key] = text_out
            results.append({
                "workflow": key, "procedure": proc, "status": "COMPLETED",
                "message": text_out,
            })
        except Exception as exc:
            results.append({
                "workflow": key, "procedure": proc, "status": "FAILED",
                "message": f"{type(exc).__name__}: {exc}",
            })
            for rest in keys[keys.index(key) + 1:]:
                results.append({
                    "workflow": rest, "procedure": spec.runners[rest],
                    "status": "NOT_RUN",
                    "message": "Not started because an earlier workflow failed.",
                })
            return results, "FAILED", summaries
    return results, "COMPLETED", summaries


# ---------------------------------------------------------------------------
# (E) Snowflake Dev -> Dev_SQLite
# ---------------------------------------------------------------------------
def snowflake_to_sqlite(
    engines: PipelineEngines, source: str, requested: list[str] | None,
    include_inputs: bool,
) -> tuple[list[PipelineTableResult], str, str]:
    kinds = ["output"] + (["input"] if include_inputs else [])
    tables = tables_for_pipeline(source, kinds, requested)
    if not tables:
        raise ValueError(
            f"No tables registered for source {get_source(source).source} yet. "
            "Add its Oracle table list to pipeline_catalog.py first (see the guide)."
        )
    os.makedirs(engines.sqlite_dir, exist_ok=True)
    filename = f"dev_{get_source(source).source}_{utc_timestamp()}.db"
    path = os.path.join(engines.sqlite_dir, filename)
    if os.path.exists(path):
        os.remove(path)
    snow_store = TableStore(engines.snowflake_dev)
    sqlite_store = TableStore(create_engine(f"sqlite:///{path}"))
    try:
        results = _copy_tables(snow_store, engines.snowflake_schema,
                               sqlite_store, None, tables,
                               clear_first=False, verb="COPIED")
    finally:
        sqlite_store.engine.dispose()
    return results, _overall(results), filename


# ---------------------------------------------------------------------------
# (F) Compare Prod_SQLite vs Dev_SQLite -> Compare_Results_SQLite
# ---------------------------------------------------------------------------
def compare_sqlites(
    engines: PipelineEngines, source: str, prod_sqlite: str,
    dev_sqlite: str, requested: list[str] | None,
) -> tuple[list[TableCompareSummary], str, str, str, str]:
    spec = get_source(source)
    tables = tables_for_pipeline(source, ["output"], requested)
    if not tables:
        raise ValueError(
            f"No output tables registered for source {spec.source} yet. "
            "Add its Oracle table list to pipeline_catalog.py first (see the guide)."
        )
    prod_path = resolve_sqlite_file(engines.sqlite_dir, prod_sqlite, must_exist=True)
    dev_path = resolve_sqlite_file(engines.sqlite_dir, dev_sqlite, must_exist=True)
    os.makedirs(engines.sqlite_dir, exist_ok=True)
    # Second-resolution timestamps alone could collide on back-to-back
    # runs, so the run id carries a short random suffix.  The same id
    # is the control-store run id, the results DB's run id, and the
    # results filename -- one id everywhere, so GET /pipeline/compare
    # can find the diff rows it recorded.
    run_id = f"{spec.source}_{utc_timestamp()}_{uuid.uuid4().hex[:6]}"
    filename = f"compare_{run_id}.db"
    results_path = os.path.join(engines.sqlite_dir, filename)
    if os.path.exists(results_path):
        os.remove(results_path)
    pipeline_compare.create_results_db(results_path)
    prod_store = TableStore(create_engine(f"sqlite:///{prod_path}"))
    dev_store = TableStore(create_engine(f"sqlite:///{dev_path}"))
    try:
        summaries, verdict, message = pipeline_compare.compare_tables(
            prod_store, dev_store, tables, results_path, run_id,
            spec.source, prod_sqlite, dev_sqlite,
            started_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
    finally:
        prod_store.engine.dispose()
        dev_store.engine.dispose()
    status = "COMPLETED" if verdict in ("MATCH", "MISMATCH") else "PARTIAL"
    return summaries, verdict, status, filename, run_id

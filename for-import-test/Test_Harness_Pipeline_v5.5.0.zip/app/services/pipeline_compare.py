"""Record-by-record compare engine (step F).

Compares one output table at a time between two SQLite files
(Prod_SQLite and Dev_SQLite), streaming both sides in PK order and
merging them in Python -- a merge join, not a load-everything
approach, so a large table costs memory proportional to the batch
size, not the table size.  Every row lands in exactly one class:

  * MATCHED      -- same PK, every compared column equal.
  * DIFFERENT    -- same PK, at least one column differs.  The
                   differing columns and both values are stored.
  * ONLY_IN_PROD -- PK exists in Prod_SQLite only.
  * ONLY_IN_DEV  -- PK exists in Dev_SQLite only.

Tables with no PK in the registry cannot be compared record by
record: they get a count-only row (status COUNT_ONLY) and push the
verdict to PARTIAL rather than a false MATCH.  Tables missing on
either side are reported, not failed: a missing Dev table is
exactly the kind of thing the tester needs to see.

Value normalisation: the two sides may come from different engines
(Oracle NUMBER arrives as Decimal, SQLite as int), so values are
normalised before comparing -- dates/datetimes to ISO strings,
numbers to their shortest decimal string, bytes to hex, None stays
None.  The stored diff values are the normalised forms.  One honest
caveat: exotic floats (many decimal places) compare on their
shortest string form, so a float that differs beyond display
precision reads as equal.  For money/measure columns this is the
right trade; for bit-exact float work, compare those tables by
another means.

Results file (Compare_Results_SQLite) schema, created explicitly
here -- three tables, no ORM:
  * compare_runs  -- one row per compare run.
  * table_summary -- one row per compared table, with complete
                     counts (counts are never capped).
  * row_diffs     -- one row per DIFFERENT / ONLY_IN_* row, up to
                     pipeline_compare_diff_cap per table.  Counts
                     stay complete when the cap bites; only the
                     stored detail is capped, and diff_rows_stored
                     says how many were kept.
"""

from __future__ import annotations

import json
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Column, Index, Integer, MetaData, String, Table, Text, create_engine, text

from app.core.config import settings
from app.domain.pipeline_catalog import PipelineTable
from app.domain.pipeline_models import TableCompareSummary
from app.repositories.pipeline_repository import TableStore

_METADATA = MetaData()

COMPARE_RUNS = Table(
    "compare_runs", _METADATA,
    Column("run_id", String, primary_key=True),
    Column("source", String, nullable=False),
    Column("prod_sqlite", String, nullable=False),
    Column("dev_sqlite", String, nullable=False),
    Column("started_at", String, nullable=False),
    Column("finished_at", String, nullable=True),
    Column("status", String, nullable=False),
    Column("verdict", String, nullable=False),
    Column("message", Text, nullable=False, default=""),
)

TABLE_SUMMARY = Table(
    "table_summary", _METADATA,
    Column("run_id", String, nullable=False),
    Column("table_name", String, nullable=False),
    Column("status", String, nullable=False),
    Column("prod_count", Integer, nullable=True),
    Column("dev_count", Integer, nullable=True),
    Column("matched", Integer, nullable=False, default=0),
    Column("different", Integer, nullable=False, default=0),
    Column("only_in_prod", Integer, nullable=False, default=0),
    Column("only_in_dev", Integer, nullable=False, default=0),
    Column("diff_rows_stored", Integer, nullable=False, default=0),
    Column("message", Text, nullable=False, default=""),
)

ROW_DIFFS = Table(
    "row_diffs", _METADATA,
    Column("run_id", String, nullable=False),
    Column("table_name", String, nullable=False),
    Column("status", String, nullable=False),  # DIFFERENT | ONLY_IN_PROD | ONLY_IN_DEV
    Column("pk_json", Text, nullable=False, default="{}"),
    Column("differing_columns_json", Text, nullable=False, default="[]"),
    Column("prod_values_json", Text, nullable=False, default="{}"),
    Column("dev_values_json", Text, nullable=False, default="{}"),
    Index("ix_row_diffs_run_table_status", "run_id", "table_name", "status"),
)


def normalize(value):
    """Normalise one value for cross-engine comparison and JSON storage."""
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value.normalize())
    if isinstance(value, float):
        try:
            return str(Decimal(str(value)).normalize())
        except Exception:
            return str(value)  # NaN / Infinity have no decimal form
    if isinstance(value, int):
        return str(value)
    if isinstance(value, bytes):
        return value.hex()
    return str(value)


def _pk_tuple(row: dict, pk: list[str]) -> tuple:
    return tuple(normalize(row.get(c)) for c in pk)


class _Peekable:
    """A batched row stream with one-row lookahead."""

    def __init__(self, batches):
        self._batches = iter(batches)
        self._buffer: list[dict] = []
        self._pos = 0
        self._exhausted = False

    def _fill(self):
        if self._pos >= len(self._buffer) and not self._exhausted:
            try:
                self._buffer = next(self._batches)
                self._pos = 0
            except StopIteration:
                self._exhausted = True

    def peek(self) -> dict | None:
        self._fill()
        if self._pos >= len(self._buffer):
            return None
        return self._buffer[self._pos]

    def take(self) -> dict | None:
        row = self.peek()
        if row is not None:
            self._pos += 1
        return row


def create_results_db(path: str) -> None:
    """Create the three results tables in a fresh SQLite file."""
    engine = create_engine(f"sqlite:///{path}")
    try:
        _METADATA.create_all(engine)
    finally:
        engine.dispose()


def compare_tables(
    prod: TableStore,
    dev: TableStore,
    tables: list[PipelineTable],
    results_db_path: str,
    run_id: str,
    source: str,
    prod_sqlite: str,
    dev_sqlite: str,
    started_at: str,
    diff_cap: int = settings.pipeline_compare_diff_cap,
    batch_size: int = settings.copy_batch_size,
) -> tuple[list[TableCompareSummary], str, str]:
    """Compare every table; write summaries + diffs; return (summaries, verdict, message).

    Verdict: MATCH only if every table is MATCH; MISMATCH if any
    table differs and nothing is incomplete; PARTIAL if any table is
    missing, PK-less (count-only) or failed -- incomplete evidence
    must not be reported as a clean mismatch or a clean match.
    """
    engine = create_engine(f"sqlite:///{results_db_path}")
    summaries: list[TableCompareSummary] = []
    try:
        with engine.begin() as conn:
            for spec in tables:
                summary = _compare_one_table(conn, prod, dev, spec, run_id, diff_cap, batch_size)
                summaries.append(summary)
        statuses = {s.status for s in summaries}
        if statuses <= {"MATCH"} and summaries:
            verdict = "MATCH"
        elif statuses & {"MISSING_IN_PROD", "MISSING_IN_DEV", "COUNT_ONLY", "FAILED"}:
            verdict = "PARTIAL"
        elif "MISMATCH" in statuses:
            verdict = "MISMATCH"
        else:
            verdict = "PARTIAL"
        message = (
            f"Compare {verdict} over {len(summaries)} tables: "
            f"{sum(s.matched for s in summaries)} matched rows, "
            f"{sum(s.different for s in summaries)} different, "
            f"{sum(s.only_in_prod for s in summaries)} only in Prod, "
            f"{sum(s.only_in_dev for s in summaries)} only in Dev."
        )
        with engine.begin() as conn:
            conn.execute(
                COMPARE_RUNS.insert().values(
                    run_id=run_id, source=source, prod_sqlite=prod_sqlite,
                    dev_sqlite=dev_sqlite, started_at=started_at,
                    finished_at=datetime.now().isoformat(timespec="seconds"),
                    status="COMPLETED", verdict=verdict, message=message,
                )
            )
        return summaries, verdict, message
    finally:
        engine.dispose()


def _compare_one_table(conn, prod: TableStore, dev: TableStore, spec: PipelineTable,
                       run_id: str, diff_cap: int, batch_size: int) -> TableCompareSummary:
    def _store(summary: TableCompareSummary) -> TableCompareSummary:
        conn.execute(TABLE_SUMMARY.insert().values(
            run_id=run_id, table_name=summary.table, status=summary.status,
            prod_count=summary.prod_count, dev_count=summary.dev_count,
            matched=summary.matched, different=summary.different,
            only_in_prod=summary.only_in_prod, only_in_dev=summary.only_in_dev,
            diff_rows_stored=summary.diff_rows_stored, message=summary.message,
        ))
        return summary

    try:
        prod_exists = prod.table_exists(spec.name, None)
        dev_exists = dev.table_exists(spec.name, None)
        if not prod_exists or not dev_exists:
            missing = "MISSING_IN_PROD" if not prod_exists else "MISSING_IN_DEV"
            return _store(TableCompareSummary(
                table=spec.name, status=missing,
                prod_count=prod.count_rows(spec.name, None) if prod_exists else None,
                dev_count=dev.count_rows(spec.name, None) if dev_exists else None,
                message=f"Table {spec.name} is missing on the "
                        f"{'Prod' if not prod_exists else 'Dev'} side; it cannot be compared.",
            ))
        prod_count = prod.count_rows(spec.name, None)
        dev_count = dev.count_rows(spec.name, None)
        if not spec.pk:
            return _store(TableCompareSummary(
                table=spec.name, status="COUNT_ONLY",
                prod_count=prod_count, dev_count=dev_count,
                message=f"No PK registered for {spec.name}; counts only "
                        f"(Prod={prod_count}, Dev={dev_count}). Register a PK to compare record by record.",
            ))
        summary = TableCompareSummary(
            table=spec.name, status="MATCH", prod_count=prod_count, dev_count=dev_count,
        )
        stored = 0

        def _record(status: str, pk_row: dict, differing: list[str], prod_row: dict, dev_row: dict):
            nonlocal stored
            if status == "DIFFERENT":
                summary.different += 1
            elif status == "ONLY_IN_PROD":
                summary.only_in_prod += 1
            else:
                summary.only_in_dev += 1
            if stored >= diff_cap:
                return
            prod_vals = {c: normalize(prod_row.get(c)) for c in differing} if status == "DIFFERENT" else (
                {c: normalize(prod_row.get(c)) for c in spec.columns} if status == "ONLY_IN_PROD" else {})
            dev_vals = {c: normalize(dev_row.get(c)) for c in differing} if status == "DIFFERENT" else (
                {c: normalize(dev_row.get(c)) for c in spec.columns} if status == "ONLY_IN_DEV" else {})
            conn.execute(ROW_DIFFS.insert().values(
                run_id=run_id, table_name=spec.name, status=status,
                pk_json=json.dumps({c: normalize(pk_row.get(c)) for c in spec.pk}),
                differing_columns_json=json.dumps(differing),
                prod_values_json=json.dumps(prod_vals),
                dev_values_json=json.dumps(dev_vals),
            ))
            stored += 1

        prod_stream = _Peekable(prod.stream_rows(spec, None, batch_size))
        dev_stream = _Peekable(dev.stream_rows(spec, None, batch_size))
        while True:
            p = prod_stream.peek()
            d = dev_stream.peek()
            if p is None and d is None:
                break
            if d is None or (p is not None and _pk_tuple(p, spec.pk) < _pk_tuple(d, spec.pk)):
                prod_stream.take()
                _record("ONLY_IN_PROD", p, [], p, {})
            elif p is None or _pk_tuple(d, spec.pk) < _pk_tuple(p, spec.pk):
                dev_stream.take()
                _record("ONLY_IN_DEV", d, [], {}, d)
            else:
                prod_stream.take()
                dev_stream.take()
                differing = [c for c in spec.columns if normalize(p.get(c)) != normalize(d.get(c))]
                if differing:
                    _record("DIFFERENT", p, differing, p, d)
                else:
                    summary.matched += 1
        summary.diff_rows_stored = stored
        summary.status = "MATCH" if (summary.different == 0 and summary.only_in_prod == 0 and summary.only_in_dev == 0) else "MISMATCH"
        summary.message = (
            f"Prod={prod_count}, Dev={dev_count}, matched={summary.matched}, "
            f"different={summary.different}, only_in_prod={summary.only_in_prod}, "
            f"only_in_dev={summary.only_in_dev}."
        )
        return _store(summary)
    except Exception as exc:
        return _store(TableCompareSummary(
            table=spec.name, status="FAILED",
            message=f"{type(exc).__name__}: {exc}",
        ))

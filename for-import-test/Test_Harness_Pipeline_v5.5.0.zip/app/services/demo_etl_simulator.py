"""DEMO ONLY -- a simulated Snowflake ETL run for the sample pack.

This module is used ONLY when PIPELINE_DEMO_MODE=true.  It is not a
Snowflake procedure, it never runs in production, and it must never
be pointed at a real database: it reads the Dev-side SQLite inputs
and writes Dev-side SQLite outputs, mimicking what the Snowflake
mappings do at a small scale -- derive party/phone/spine/
exception/deactivation rows from the staged members.

Why it exists: the demo has no Snowflake, so step (D) needs
something that turns Dev inputs into Dev outputs, or steps (E)
and (F) would have nothing to copy or compare.

The derivation lives in derive_outputs() and is shared with the
seed script on purpose: the seed builds the Prod outputs with
plant_diffs=False, the simulator builds the Dev outputs with
plant_diffs=True, so every row matches exactly EXCEPT the planted
differences below.  That is what makes the compare produce every
status (MATCHED, DIFFERENT, ONLY_IN_PROD, ONLY_IN_DEV) for the
tester to see in the Streamlit UI.

PLANTED DIFFERENCES (deliberate, documented, demo-only):
  * Member 1003: last name changed in Dev (DIFFERENT on C_S_TRS_PTY).
  * Member 1005: dropped from Dev party output (ONLY_IN_PROD on C_S_TRS_PTY).
  * Member 1007: an extra Dev-only party row (ONLY_IN_DEV on C_S_TRS_PTY).
  * EXC_STG_BAD_REC_MEMB: one extra Dev-only exception row (ONLY_IN_DEV).
  * Every other sample row matches exactly, including all of
    C_S_TRS_PTY_RLE_PHN, STG_TRS_VALID_MEMBERS and
    ZZ_UTL_UNMERGE_TREE_SRC_KEY.

Re-runs: the simulator truncates its own output tables first, so
the demo can be re-run end to end.  The real (D) endpoint does NOT
do this by default (see RunSnowflakeEtlRequest.reset_outputs).
"""

from __future__ import annotations

from app.domain.pipeline_catalog import PipelineTable, get_source
from app.repositories.pipeline_repository import TableStore

_INPUT_COLS = [
    "INDV_ID", "FIRST_NAME", "LAST_NAME", "GENDER_CD", "DOB_DT",
    "INACTIVE_IND", "DELETE_SW",
]


def derive_outputs(members: list[dict], plant_diffs: bool) -> dict[str, list[dict]]:
    """Derive the five sample outputs from staged members.

    plant_diffs=False reproduces the Production (IDQ) result;
    plant_diffs=True reproduces the Dev (Snowflake) result with the
    planted differences.  Column values not derived from the inputs
    are None/0/1 defaults, identical on both sides by construction.
    """
    # -- C_S_TRS_PTY: one row per member ------------------------------
    pty = []
    for m in members:
        pty.append({
            "PKEY_SRC_OBJECT": f"TRS-{m['INDV_ID']}",
            "ROWID_OBJECT": None, "DELETED_IND": 0, "DELETED_DATE": None,
            "DELETED_BY": None, "PERIOD_START_DATE": None, "PERIOD_END_DATE": None,
            "VERSION_SEQ": 1, "PERIOD_REFERENCE_TIME": None, "TIMELINE_ACTION": 1,
            "LAST_UPDATE_DATE": None, "UPDATED_BY": None, "CREATE_DATE": None,
            "CREATOR": None, "SRC_ROWID": None, "HUB_STATE_IND": 0,
            "PTY_BO_CLASS_CD": None, "PRFX_NM": None, "FRST_NM": m["FIRST_NAME"],
            "MDL_NM": None, "LST_NM": m["LAST_NAME"], "SFX_NM": None,
            "FULL_NM": f"{m['FIRST_NAME']} {m['LAST_NAME']}".strip(),
            "GNDR_CD": m["GENDER_CD"], "BIRTH_DT": m["DOB_DT"], "DEATH_DT": None,
            "FLAG_SRC": None, "SRC_FULL_NM": None, "SRC_LAST_UPD_DT": None,
            "ETHNCTY": None, "SRC_RACE_CD": None, "SRC_ETHNCTY": None, "RACE_CD": None,
        })
    if plant_diffs:
        for row in pty:
            if row["PKEY_SRC_OBJECT"] == "TRS-1003":
                row["LST_NM"] = "Changed"
                row["FULL_NM"] = "Carol Changed"
        pty = [r for r in pty if r["PKEY_SRC_OBJECT"] != "TRS-1005"]
        pty.append({
            "PKEY_SRC_OBJECT": "TRS-1007", "ROWID_OBJECT": None, "DELETED_IND": 0,
            "DELETED_DATE": None, "DELETED_BY": None, "PERIOD_START_DATE": None,
            "PERIOD_END_DATE": None, "VERSION_SEQ": 1, "PERIOD_REFERENCE_TIME": None,
            "TIMELINE_ACTION": 1, "LAST_UPDATE_DATE": None, "UPDATED_BY": None,
            "CREATE_DATE": None, "CREATOR": None, "SRC_ROWID": None, "HUB_STATE_IND": 0,
            "PTY_BO_CLASS_CD": None, "PRFX_NM": None, "FRST_NM": "Dev", "MDL_NM": None,
            "LST_NM": "Only", "SFX_NM": None, "FULL_NM": "Dev Only", "GNDR_CD": "F",
            "BIRTH_DT": "1990-01-01", "DEATH_DT": None, "FLAG_SRC": None,
            "SRC_FULL_NM": None, "SRC_LAST_UPD_DT": None, "ETHNCTY": None,
            "SRC_RACE_CD": None, "SRC_ETHNCTY": None, "RACE_CD": None,
        })

    # -- C_S_TRS_PTY_RLE_PHN: one synthetic phone per member 1001-1005 --
    phn = []
    for indv_id in (1001, 1002, 1003, 1004, 1005):
        phn.append({
            "PKEY_SRC_OBJECT": f"TRS-{indv_id}-PHN", "ROWID_OBJECT": None,
            "DELETED_IND": 0, "DELETED_DATE": None, "DELETED_BY": None,
            "PERIOD_START_DATE": None, "PERIOD_END_DATE": None, "VERSION_SEQ": 1,
            "PERIOD_REFERENCE_TIME": None, "TIMELINE_ACTION": 1,
            "LAST_UPDATE_DATE": None, "UPDATED_BY": None, "CREATE_DATE": None,
            "CREATOR": None, "SRC_ROWID": None, "HUB_STATE_IND": 0,
            "PTY_RLE_FK": None, "PHN_TP": "HOME", "USG_TP": "PRIMARY",
            "PHN_NUM": f"555010{indv_id % 10}", "PREF_LVL": 1, "SRC_LAST_UPD_DT": None,
        })

    # -- STG_TRS_VALID_MEMBERS: the spine, one row per member --------
    spine = [{
        "INDV_ID": m["INDV_ID"], "PTY_PK": f"TRS-{m['INDV_ID']}",
        "SRC_TBL": "STG_TRS_D_DC_INDV", "CREATE_DATE": None,
    } for m in members]

    # -- EXC_STG_BAD_REC_MEMB: blank-last-name exceptions ------------
    exc = []
    for m in members:
        if not (m["LAST_NAME"] or "").strip():
            exc.append({
                "SRC_SYS": "TRS", "SRC_SYS_ID_1": str(m["INDV_ID"]), "SRC_SYS_ID_2": None,
                "SRC_SYS_ID_3": None, "EXCEPTION_TYPE": "BAD_REC",
                "EXCEPTION_CODE": "BLANK_LAST_NAME", "EXCEPTION_DESC": "Last name is blank",
                "RUN_DATE": None, "PREFIX": None, "FIRST_NAME": m["FIRST_NAME"],
                "MIDDLE_NAME": None, "LAST_NAME": m["LAST_NAME"], "SUFFIX": None,
                "ALIAS_PREFIX": None, "ALIAS_FIRST_NAME": None, "ALIAS_MIDDLE_NAME": None,
                "ALIAS_LAST_NAME": None, "ALIAS_SUFFIX": None, "BIRTH_DATE": m["DOB_DT"],
                "GENDER": m["GENDER_CD"], "ADDRESS_TYPE": None, "ADDRESS_LINE_1": None,
                "ADDRESS_LINE_2": None, "ADDRESS_CITY": None, "ADDRESS_COUNTY": None,
                "ADDRESS_STATE": None, "ADDRESS_ZIP": None, "ADDRESS_ZIP_EXT": None,
                "ADDRESS_COUNTRY": None, "ADDRESS_DR_ERROR_CODE": None,
                "ADDRESS_DR_ERROR_DESC": None, "ADDRESS_DR_MAILABILITY_SCORE": None,
                "PRIMARY_PHONE": None, "WORK_PHONE": None, "SECONDARY_PHONE": None,
                "EMAIL": None, "ATTRIBUTE_NAME": "LAST_NAME", "ATTRIBUTE_VALUE": "",
                "MAPPING_NAME": "PTY", "PERIOD_START_DATE": None, "PERIOD_END_DATE": None,
                "DEATH_DT": None,
            })
    if plant_diffs:
        exc.append({
            "SRC_SYS": "TRS", "SRC_SYS_ID_1": "1002", "SRC_SYS_ID_2": None, "SRC_SYS_ID_3": None,
            "EXCEPTION_TYPE": "BAD_REC", "EXCEPTION_CODE": "DEV_ONLY_CHECK",
            "EXCEPTION_DESC": "Planted Dev-only exception for the demo",
            "RUN_DATE": None, "PREFIX": None, "FIRST_NAME": "Bob", "MIDDLE_NAME": None,
            "LAST_NAME": "Jones", "SUFFIX": None, "ALIAS_PREFIX": None,
            "ALIAS_FIRST_NAME": None, "ALIAS_MIDDLE_NAME": None, "ALIAS_LAST_NAME": None,
            "ALIAS_SUFFIX": None, "BIRTH_DATE": None, "GENDER": "M", "ADDRESS_TYPE": None,
            "ADDRESS_LINE_1": None, "ADDRESS_LINE_2": None, "ADDRESS_CITY": None,
            "ADDRESS_COUNTY": None, "ADDRESS_STATE": None, "ADDRESS_ZIP": None,
            "ADDRESS_ZIP_EXT": None, "ADDRESS_COUNTRY": None, "ADDRESS_DR_ERROR_CODE": None,
            "ADDRESS_DR_ERROR_DESC": None, "ADDRESS_DR_MAILABILITY_SCORE": None,
            "PRIMARY_PHONE": None, "WORK_PHONE": None, "SECONDARY_PHONE": None,
            "EMAIL": None, "ATTRIBUTE_NAME": "DEMO", "ATTRIBUTE_VALUE": "X",
            "MAPPING_NAME": "PTY", "PERIOD_START_DATE": None, "PERIOD_END_DATE": None,
            "DEATH_DT": None,
        })

    # -- ZZ_UTL_UNMERGE_TREE_SRC_KEY: inactive members only ----------
    zz = [{
        "INDV_ID": m["INDV_ID"], "SRC_KEY": f"TRS-{m['INDV_ID']}",
        "TREE_LEVEL": 1, "PROCESSED_YN": "N",
    } for m in members if (m["INACTIVE_IND"] or "N") == "Y"]

    return {
        "C_S_TRS_PTY": pty,
        "C_S_TRS_PTY_RLE_PHN": phn,
        "STG_TRS_VALID_MEMBERS": spine,
        "EXC_STG_BAD_REC_MEMB": exc,
        "ZZ_UTL_UNMERGE_TREE_SRC_KEY": zz,
    }


def _members(dev: TableStore) -> list[dict]:
    """Dev input members, from STG_TRS_D_DC_INDV (subset of columns)."""
    spec = PipelineTable(name="STG_TRS_D_DC_INDV", kind="input", columns=_INPUT_COLS)
    rows: list[dict] = []
    for batch in dev.stream_rows(spec, None, 1000):
        rows.extend(batch)
    return rows


def _write(store: TableStore, table_name: str, rows: list[dict]) -> int:
    spec = next(t for t in get_source("TRS").output_tables if t.name == table_name)
    store.ensure_table(table_name, None)
    store.clear_table(table_name, None)
    cleaned = [{c: row.get(c) for c in spec.columns} for row in rows]
    store.insert_rows(table_name, None, cleaned)
    return len(cleaned)


def run_demo_etl(dev: TableStore, snowflake: TableStore) -> dict:
    """Simulate the TRS stage load into the demo Snowflake file.

    Returns per-output-table row counts plus a note naming the
    planted differences.  The `snowflake` store here is the demo
    SQLite file standing in for Snowflake Dev -- in real mode this
    function is never called.
    """
    outputs = derive_outputs(_members(dev), plant_diffs=True)
    counts = {name: _write(snowflake, name, rows) for name, rows in outputs.items()}
    counts["_note"] = (
        "DEMO ONLY. Planted differences vs Prod: member 1003 renamed, "
        "member 1005 dropped from C_S_TRS_PTY, member 1007 added, one "
        "extra EXC row. Everything else matches Prod exactly."
    )
    return counts

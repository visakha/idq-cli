"""Pipeline engine factory: Prod Oracle, Dev Oracle, Snowflake Dev.

Engines are built from the CURRENT settings on every call, not
cached: tests flip settings (demo mode, temp directories) between
requests, and a cached engine would silently keep the old database.
Creating an engine is cheap -- it opens no connection until first
use -- so per-request construction costs nothing here.

Demo mode (PIPELINE_DEMO_MODE=true) is explicit: all three sides
are SQLite files under PIPELINE_DEMO_DIR (demo_prod.db,
demo_dev_oracle.db, demo_snowflake.db, built by
sample_data/seed_demo.py).  A missing demo file is a configuration
error naming the seed script, never a silent empty database.

Real mode needs PIPELINE_ORACLE_PROD_URL and
PIPELINE_ORACLE_DEV_URL (full SQLAlchemy URLs) plus the Snowflake
settings (account, user, authenticator/token/password, warehouse,
role) and the Dev install location (PIPELINE_SNOWFLAKE_DATABASE /
PIPELINE_SNOWFLAKE_SCHEMA, defaulting to MDM_ETL_<SOURCE> /
<SOURCE>_ETL_WRK).

The FastAPI dependency below yields the engines and disposes them
after the request, so no pool outlives the request that used it.
"""

from __future__ import annotations

import os
from collections.abc import Iterator

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from app.core.config import settings


class PipelineEngines:
    """The three pipeline sides, plus the locations the steps need."""

    def __init__(self, prod: Engine, dev: Engine, snowflake_dev: Engine,
                 sqlite_dir: str, snowflake_schema: str, demo_mode: bool,
                 prod_label: str, dev_label: str) -> None:
        self.prod = prod
        self.dev = dev
        self.snowflake_dev = snowflake_dev
        self.sqlite_dir = sqlite_dir
        self.snowflake_schema = snowflake_schema
        self.demo_mode = demo_mode
        # Labels for the prod==dev safety guard (URLs in real mode,
        # file paths in demo mode).  Compared as plain strings.
        self.prod_label = prod_label
        self.dev_label = dev_label

    def dispose_all(self) -> None:
        for engine in (self.prod, self.dev, self.snowflake_dev):
            try:
                engine.dispose()
            except Exception:
                pass


def build_pipeline_engines() -> PipelineEngines:
    """Build the three engines from current settings."""
    sqlite_dir = settings.pipeline_sqlite_dir
    if settings.pipeline_demo_mode:
        demo_dir = settings.pipeline_demo_dir
        paths = {
            "prod": os.path.join(demo_dir, "demo_prod.db"),
            "dev": os.path.join(demo_dir, "demo_dev_oracle.db"),
            "snowflake": os.path.join(demo_dir, "demo_snowflake.db"),
        }
        missing = [p for p in paths.values() if not os.path.exists(p)]
        if missing:
            raise RuntimeError(
                "Demo mode is on but demo database file(s) are missing: "
                + ", ".join(missing)
                + ". Build them first with: python sample_data/seed_demo.py"
            )
        return PipelineEngines(
            prod=create_engine(f"sqlite:///{paths['prod']}"),
            dev=create_engine(f"sqlite:///{paths['dev']}"),
            snowflake_dev=create_engine(f"sqlite:///{paths['snowflake']}"),
            sqlite_dir=sqlite_dir,
            snowflake_schema="",
            demo_mode=True,
            prod_label=paths["prod"],
            dev_label=paths["dev"],
        )
    prod_url = settings.pipeline_oracle_prod_url
    dev_url = settings.pipeline_oracle_dev_url
    if not prod_url or not dev_url:
        raise RuntimeError(
            "Pipeline Oracle URLs are not configured: set "
            "PIPELINE_ORACLE_PROD_URL and PIPELINE_ORACLE_DEV_URL in .env "
            "(or run with PIPELINE_DEMO_MODE=true for the SQLite demo)."
        )
    if not settings.snowflake_account or not settings.snowflake_user:
        raise RuntimeError(
            "Snowflake Dev is not configured for the pipeline: set "
            "SNOWFLAKE_ACCOUNT and SNOWFLAKE_USER (plus authenticator/token "
            "or password) in .env."
        )
    url = (
        f"snowflake://{settings.snowflake_user}"
        f"@{settings.snowflake_account}/{settings.pipeline_snowflake_database}"
        f"/{settings.pipeline_snowflake_schema}"
    )
    connect_args: dict[str, str] = {}
    if settings.snowflake_authenticator:
        connect_args["authenticator"] = settings.snowflake_authenticator
    if settings.snowflake_oauth_token:
        connect_args["token"] = settings.snowflake_oauth_token
    if settings.snowflake_password:
        connect_args["password"] = settings.snowflake_password
    if settings.snowflake_warehouse:
        connect_args["warehouse"] = settings.snowflake_warehouse
    if settings.snowflake_role:
        connect_args["role"] = settings.snowflake_role
    return PipelineEngines(
        prod=create_engine(prod_url),
        dev=create_engine(dev_url),
        snowflake_dev=create_engine(url, connect_args=connect_args),
        sqlite_dir=sqlite_dir,
        snowflake_schema=settings.pipeline_snowflake_schema or "",
        demo_mode=False,
        prod_label=prod_url,
        dev_label=dev_url,
    )


def get_pipeline_engines() -> Iterator[PipelineEngines]:
    """FastAPI dependency: build engines, yield them, dispose after."""
    engines = build_pipeline_engines()
    try:
        yield engines
    finally:
        engines.dispose_all()

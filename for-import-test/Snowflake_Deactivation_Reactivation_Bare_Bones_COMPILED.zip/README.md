# TRS Deactivation + Reactivation — Bare-Bones package

Bare-bones version of `Snowflake_Deactivation_Reactivation_Simplified.zip`
(the TRS deactivation procedures drafted from the IDQ deactivation workflow
exports). Same business SQL, no control plane: no checkpoint table, no run
ids, no job-control procedures. The only record of a run is the summary
string each procedure returns.

## Contents

- `TRS/mappings/` — 5 drafted mapping procedures:
  - `sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList` — party keys
    (max 10,000, `PROCESSED_YN <> 'Y'`) to `ZZ_UTL_UNMERGE_TREE_SRC_KEY`.
  - `sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList` —
    relationship keys to `ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY` (all keys) and
    `ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF` (merged only).
  - `sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit` —
    history/audit capture into `STG_TRS_DEACTIVATED_RELATIONSHIPS`.
  - `sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed` — marks
    party log rows `'Y'` (trusts the copied key table).
  - `sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed` —
    marks relationship log rows `'Y'` only where the hub proves the soft
    delete landed (`MAX(HUB_STATE_IND) = -1`).
- `TRS/runners/` — 4 workflow runner procedures + 4 `run_*.sql` snowsql
  entry points (`Initial`, `Relationship_Deactivation`, `History`,
  `Complete`), all taking no arguments and returning a combined summary.
- `00_common/` — the two common helper files, verbatim (business functions;
  `fn_snow_helper36_common` formats the summary lines).
- `diagrams/` — swimlane + process-flow lifecycle diagrams (SVG + PNG + DOT).
- `ANALYSIS_DEACTIVATION_REACTIVATION.md` — the cross-source
  deactivation/reactivation analysis, carried verbatim from the simplified
  package except for the bare-bones note at its top.
- `STEP_MAP_DEACTIVATION.md` — step map for the 5 mappings, same basis.
- `STRIPPED_NOTES.md` — the exact removal list, the one behaviour change,
  and the run commands.

## What was removed

- All `sp_etl_checkpoint` / `sp_etl_job_begin` / `sp_etl_job_finish` /
  `sp_etl_job_fail` calls; the job-control DDL and procedures are not shipped.
- `P_JOB_RUN_ID` (parameter, run-id generation, and the `JOB_RUN_ID=` return
  prefix) from all 5 mappings and all 4 runners.
- The step-90 gateway *checkpoint rows* in the Initial and Relationship
  runners — replaced by summary lines carrying the same gateway message.
- There was never a config table in this package (it predates the
  step-driver config design), so there is nothing config-related to remove.

## What was kept

- Business SQL verbatim: filters (`PROCESSED_YN <> 'Y'` party,
  `NVL(PROCESSED_YN,'N') <> 'Y'` relationship), the 10,000-row cap, the
  14-character `'TRS'` padding, TRUNCATE + INSERT publishes, the
  `MAX(HUB_STATE_IND) = -1` verification, and every preserved quirk in the
  mapping headers (including the History Audit no-dedup flag).
- Step-5 work-table cleanup (bare `DROP TABLE IF EXISTS`), TRANSIENT
  `WRK_TRS_DACT_*` work tables left standing after a run, single publish
  transactions with rollback + raise on failure.
- The summary string: steps still append their row counts through
  `fn_snow_helper36_common`, mappings `RETURN l_summary`, runners return
  the concatenated mapping summaries. Counts live only in that string.

## Behaviour change — runners now return mapping summaries

The simplified runners discarded each mapping's return value and returned
only a short status line, claiming a CALL's return could not be assigned to
a variable. That claim is out of date: the scalar-call form
`l_x := (CALL proc(...))` was validated at the ECI step-driver live compile
(74/74 files, 0 errors), and it is used here. In this package the runner
return value is the only record of the run, so discarding the mapping
summaries would have left nothing. This changes no business SQL — it only
surfaces what the mappings already returned.

## Install

Install everything into ONE schema: helpers, mappings, and runners all call
each other unqualified, and there is no `COMMON` schema in this package.
Order: `00_common/` files first, then `TRS/mappings/`, then `TRS/runners/`.
The target/log/utility tables (`STG_TRS_DEACTIVED_MEMBERS`,
`STG_TRS_DEACTIVATED_RELATIONSHIPS`, `ZZ_UTL_*`, `C_B_PTY_RLE_REL_XREF`)
must already exist in that schema or be reachable from it.

## How to run

Each `run_*.sql` calls its runner with no arguments; or call a runner
directly. The returned string is the only record — log it. Example
(Windows Command Prompt; adjust `-d` / `-s` / `-w` to the install):

```
snowsql -a DOOPELI-LL99227 -u VIZY --authenticator SNOWFLAKE_JWT --private-key-path C:\keys\vizy_rsa_key.p8 -r ACCOUNTADMIN -w SNOWFLAKE_LEARNING_WH -d MDM_ETL_TRS -s TRS_ETL_WRK -q "CALL sp_etl_run_wf_TRS_Deactivation_Initial();" > C:\logs\trs_deactivation_initial.log 2>&1
```

Run order for a full cycle: `Initial` (copy party keys) -> run
`./unmerge_soft_delete_party.sh` externally when the summary shows copied
rows > 0 -> `Relationship_Deactivation` (copy relationship keys) -> run
`./unmerge_soft_delete_relationship.sh` externally when its summary shows
rows > 0 -> `Complete` (mark processed). `History` is independent and runs
on its own. The external shell scripts are a black box (not in the IDQ
export, not drafted here); the IDQ indicator-file command task stays with
the scheduler.

## Where the rest of the deactivation / reactivation landscape lives

This zip is deliberately NOT a duplicate of code that already exists in
bare-bones form elsewhere:

- **Capture** (TRS party + relationship deactivation capture inside the
  Ongoing load) lives in the stage-load mappings of
  `Snowflake_All_Sources_Bare_Bones_v2.1.zip` — same bare-bones style.
- **ECI reactivation** (`RFA` / `RFP` / `RFM` drivers) lives in the same
  all-sources bare-bones zip.
- **Other sources' deactivation** (the exclusion model: Validation mappings
  writing `*_INACTIVE_STS` tables, downstream `NOT EXISTS` filters) lives
  in the same all-sources bare-bones zip.
- **NOT implemented anywhere** (known gaps, see the analysis): IDQ's
  `Upd_Delete_Inactive` re-admit (DD_DELETE of the status row) — hence the
  Snowflake reactivation verdicts No for ECI / WIC / TTF; the shell scripts
  above; History Audit's missing dedup guard (re-runs re-insert).

## Not validated

Static verification only (see STRIPPED_NOTES.md): no live Snowflake
compile, run, or row-count parity for this package. First run still needs
to confirm the scalar-call capture form and zero-argument calls in this
schema, exactly as with the all-sources bare-bones package.

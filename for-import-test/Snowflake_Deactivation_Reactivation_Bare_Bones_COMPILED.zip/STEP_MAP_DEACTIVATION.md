> BARE-BONES NOTE — This document is carried verbatim from the simplified
> deactivation package (Snowflake_Deactivation_Reactivation_Simplified.zip).
> Where it describes checkpoint rows, JOB_CONTROL_ETL, or run ids, it is
> describing that version's implementation. In this bare-bones package all
> of that is removed; the exact deltas are in STRIPPED_NOTES.md. The IDQ
> analysis itself (filters, state machine, verdicts) is unchanged.

# STEP MAP — TRS Deactivation + Reactivation (Snowflake drafts, simplified v2 style)

> Scope of this package: **deactivation / reactivation procedures ONLY**.
> Stage-load mappings, the compare tool and every previous zip are untouched.
> Every procedure below is **DRAFTED FROM IDQ MAPPING** — no Snowflake
> deactivation originals were ever supplied, so none of these is a
> like-for-like rewrite of a supplied Snowflake procedure. Each file's header
> names its IDQ mapping and export file. All SQL, filters and parameters were
> read directly from the `-2` XML exports (including the port-level wiring:
> target columns were traced through the XML's `TransformationFieldPort`
> `fromPort` chains, not guessed from column names).

## Conventions (same as the stage-load simplified v2 style)

- Procedures: `sp_snow_main_<IDQ mapping name>`; original IDQ mapping
  parameters first (where the mapping has them), `P_JOB_RUN_ID VARCHAR
  DEFAULT NULL` appended last.
- Staged steps in tens (10, 20, 30 …), one checkpoint row per step
  (`WORKING` / `CREATED` with row count and business purpose) in the shared
  `JOB_CONTROL_ETL` table via `sp_etl_job_begin` / `sp_etl_checkpoint` /
  `sp_etl_job_finish` / `sp_etl_job_fail` — `SOURCE` first (`'TRS'` in every
  control call here). A `TERMINATING` row closes every run.
- Step 5 `CLEANUP_PREVIOUS_RUN` at the start of every mapping: bare
  `DROP TABLE IF EXISTS` statements for that mapping's work tables ONLY.
  **No checkpoint call for drops — zero `DROPPED` checkpoint arguments.**
- Mapping-level restart only: no `P_RESUME_STEP`, no resume guards, no
  end-of-run drops, no cleanup procedure. Work tables are left standing
  after the run and cleaned at the start of the next run.
- All work tables are `TRANSIENT`, named `WRK_TRS_DACT_*`, never shared
  across mappings. No cursors, no session `TEMP` tables.
- Publish is the ONLY transaction. Publish modes (documented, justified
  deviations from the stage-load insert-only rule):
  - CopyList publish = `TRUNCATE + INSERT` — IDQ truncate-loads the utility
    tables and the external scripts consume the whole table, so a re-run
    must replace, not accumulate.
  - Mark Processed publish = `UPDATE` — IDQ update strategy `DD_UPDATE`.
  - History Audit publish = plain `INSERT` — IDQ load type Normal, no truncate.
- Shared helpers used (pre-existing from the stage-load framework, NOT
  invented here): `fn_snow_helper36_common` (run-log line) and, for History
  Audit only, `fn_snow_helper41_common` (one `V_LOOKUP_CODE_VALUE` row per
  `CODE_TYPE` / `SRC_SYS` / `SRC_CODE_VALUE` — the IDQ lookup's `returnAny`).

## Run order (whole cycle)

1. Capture — **prerequisite, NOT in this package** (see Prerequisites below):
   Ongoing load captures party + relationship deactivations (`PROCESSED_YN = 'N'`).
2. `wf_TRS_Deactivation_Initial` → copy party keys → **external**
   `./unmerge_soft_delete_party.sh` (black box, not drafted).
3. `wf_TRS_Relationship_Deactivation` → copy relationship keys → **external**
   `./unmerge_soft_delete_relationship.sh` (black box, not drafted).
4. `wf_TRS_Pty_Rle_Rel_DeActivation_History` → history/audit capture (can run
   independently of steps 2–3; it feeds the same relationship log).
5. `wf_TRS_Deactivation_Complete` (after the MDM batch applies the staged
   soft deletes) → mark party + relationship rows `'Y'`.

## 1. `sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList`

- IDQ mapping: `m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList`,
  workflow `wf_TRS_Deactivation_Initial`, export `wf_TRS_Deactivation_Initial-2.xml`.
- File: `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList.sql`
- Parameters: none in IDQ; `P_JOB_RUN_ID` appended.
- Steps:
  - 5 `CLEANUP_PREVIOUS_RUN` — drops `WRK_TRS_DACT_COPYP_S10_SRC`,
    `WRK_TRS_DACT_COPYP_S20_READY` (no checkpoint).
  - 10 `UNPROCESSED_LOG_ROWS` — `WRK_TRS_DACT_COPYP_S10_SRC`: `PTY_PK` from
    `STG_TRS_DEACTIVED_MEMBERS` where `PROCESSED_YN <> 'Y'`,
    `QUALIFY ROW_NUMBER() OVER () <= 10000`.
  - 20 `READY_TO_PUBLISH` — `WRK_TRS_DACT_COPYP_S20_READY`: `PTY_PK` as
    `PKEY_SRC_OBJECT`, `ROWID_SYSTEM` stamped `'TRS           '` (14 chars:
    `'TRS'` + 11 spaces), `EXPLODE_NODE_IND = '1'`.
  - 30 `PUBLISH` — one transaction: `TRUNCATE + INSERT` into
    `ZZ_UTL_UNMERGE_TREE_SRC_KEY` (`PKEY_SRC_OBJECT`, `ROWID_SYSTEM`,
    `EXPLODE_NODE_IND`).
- Preserved quirks:
  - **10,000-row cap** with no `ORDER BY` in IDQ: the empty `OVER ()` keeps
    the pick order unspecified, exactly as Oracle `ROWNUM` without `ORDER BY`.
    Designer note ties the cap to the old 30-minute web-service unmerge
    timeout; the unmerge is now a command task (2025-09-02), so the cap's
    rationale may be stale — but the cap is preserved. Backlog > 10,000
    needs repeated runs.
  - **NULL `PROCESSED_YN` excluded**: bare `<> 'Y'`, no `NVL` — unlike the
    relationship CopyList. Do not "align" them without a business decision.
  - Only `PTY_PK` is carried: it is the only source column wired to the
    target in the XML (confirmed by port trace).

## 2. `sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList`

- IDQ mapping: `m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList`,
  workflow `wf_TRS_Relationship_Deactivation`, export
  `wf_TRS_Relationship_Deactivation-2.xml`.
- File: `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList.sql`
- Parameters: none in IDQ; `P_JOB_RUN_ID` appended.
- Steps:
  - 5 `CLEANUP_PREVIOUS_RUN` — drops `WRK_TRS_DACT_COPYR_S10_SRC`,
    `WRK_TRS_DACT_COPYR_S20_SOFTDEL`, `WRK_TRS_DACT_COPYR_S30_UNMERGE`
    (no checkpoint).
  - 10 `UNPROCESSED_LOG_ROWS` — `WRK_TRS_DACT_COPYR_S10_SRC`:
    `PKEY_SRC_OBJECT`, `ROWID_XREF`, `ROWID_SYSTEM`, `MERGED_YN`,
    `MASTER_RECORD_YN` from `STG_TRS_DEACTIVATED_RELATIONSHIPS` where
    `NVL(PROCESSED_YN,'N') <> 'Y'` and `ROWID_XREF IS NOT NULL`.
  - 20 `READY_SOFTDEL` — `WRK_TRS_DACT_COPYR_S20_SOFTDEL`: all step-10 rows
    as (`PKEY_SRC_OBJECT`, `ROWID_SYSTEM`) — the log row's own
    `ROWID_SYSTEM`, nothing stamped.
  - 30 `READY_UNMERGE` — `WRK_TRS_DACT_COPYR_S30_UNMERGE`: `ROWID_XREF`
    where `MERGED_YN = 'Y'` only.
  - 40 `PUBLISH` — one transaction: `TRUNCATE + INSERT` into
    `ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY` and `TRUNCATE + INSERT` into
    `ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF`; one checkpoint carrying the
    combined count and both per-table counts in its message (multi-target
    stage-load precedent).
- Preserved quirks:
  - **Commented-out `MASTER_RECORD_YN` exclusion**: the IDQ filter reads
    `MERGED_YN ='Y'` with `--and MASTER_RECORD_YN ='N'` commented out
    (ML, 2024-12-06: excluding master records would soft-delete data
    merged into a master). The exclusion is preserved as a comment in
    step 30 and is **NOT** applied — master records stay in the unmerge table.
  - **NULL `PROCESSED_YN` included** via `NVL(...,'N')` (2025-09-02
    correction) — the opposite of the party CopyList.
  - Rows without `ROWID_XREF` are excluded by the source filter even if
    unprocessed.

## 3. `sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit`

- IDQ mapping: `m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit`,
  workflow `wf_TRS_Pty_Rle_Rel_DeActivation_History`, export
  `wf_TRS_Pty_Rle_Rel_DeActivation_History-2.xml`.
- File: `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit.sql`
- Parameters (IDQ order, with IDQ defaults): `P_ABSENT_PAR_SQ_ALT_ID_TP
  VARCHAR DEFAULT '012'`, `P_INDV_ID_ALT_ID_TP VARCHAR DEFAULT '007'`,
  then `P_JOB_RUN_ID` appended. **Both IDQ parameters are unused in the
  mapping body** (no `$$` reference exists in the export); they are carried
  for signature fidelity only.
- Steps:
  - 5 `CLEANUP_PREVIOUS_RUN` — drops `WRK_TRS_DACT_HIST_S10_MINPK`,
    `WRK_TRS_DACT_HIST_S20_SRC`, `WRK_TRS_DACT_HIST_S30_KEYED`,
    `WRK_TRS_DACT_HIST_S40_XREF`, `WRK_TRS_DACT_HIST_S50_READY`
    (no checkpoint).
  - 10 `MIN_PK` — `WRK_TRS_DACT_HIST_S10_MINPK`: `MIN(pty_pk)` per `indv_id`
    from `STG_TRS_VALID_MEMBERS`.
  - 20 `HIST_REL_SRC` — `WRK_TRS_DACT_HIST_S20_SRC`: the IDQ source SQL
    verbatim (minus the Oracle `/*+ parallel (4) */` hint) over
    `STG_TRS_H_DC_RELATIONSHIPS_A`, both ends joined through step 10,
    `SRC_SYS = 'TRS'`. `EFF_BEGIN_DT` / `EFF_END_DT` are carried here and
    dropped at step 30 (no target column takes them).
  - 30 `KEYED_REL` — `WRK_TRS_DACT_HIST_S30_KEYED`: `PTY_REL` translation
    via `fn_snow_helper41_common()` (LEFT JOIN, `returnAny`) +
    `Exp_Gen_PKEY`: each end as `'<party key>|Member'`, composite
    `PKEY_SRC_OBJECT = fk1 | fk2 | master code` (direct concatenation).
  - 40 `XREF_ONE` — `WRK_TRS_DACT_HIST_S40_XREF`: `C_B_PTY_RLE_REL_XREF`
    grouped CTEs (mathematically the IDQ `SELECT DISTINCT` window-function
    SQL — same restructuring as the live capture rewrite) plus
    `MERGE_YN` / `MASTER_RECORD_YN` derivation, one row per
    `PKEY_SRC_OBJECT` (first by `ROWID_OBJECT`, the lookup's `returnAny`).
  - 50 `READY_TO_PUBLISH` — `WRK_TRS_DACT_HIST_S50_READY`: step 30 LEFT JOIN
    step 40, in target column order (minus `PROCESSED_YN`):
    `INDV_ID`, `REF_INDV_ID`, `PTY_RLE_FK_1`, `PTY_RLE_FK_2`,
    `REL_TYPE_CODE` (= source `RELATIONSHIP_TYPE_CD`, not master code),
    `ROWID_XREF` (= `MIN_ROWID_XREF`), `PKEY_SRC_OBJECT`, `ROWID_OBJECT`,
    `ROWID_SYSTEM` (= `SRC_SYS` `'TRS'`, not the xref row's value),
    `LOAD_DATE` (= run start, IDQ `LAST_UPDATE_DATE = sysdate`),
    `SRC_PKEY_CT`, `MASTER_RECORD_YN`, `MERGED_YN` (= `TRIM(MERGE_YN)`).
  - 60 `PUBLISH` — one transaction: plain `INSERT` into
    `STG_TRS_DEACTIVATED_RELATIONSHIPS` (no truncate).
- Preserved quirks — **read before running**:
  - **FLAG 1 — NO dedup / not-exists logic exists in this mapping.** The
    History XML has no lookup against the target log, no already-logged
    guard and no filter of any kind. This is a **plain INSERT**: re-running
    re-inserts every history relationship read, including keys already in
    the log. Preserved as written — do not add a guard without a business
    decision. (The live capture, by contrast, keeps only keys not already
    logged as unprocessed.)
  - **FLAG 2 — NO cross-reference-exists filter.** Unlike the live capture
    (`MIN_ROWID_XREF NOT NULL`), History publishes rows whose xref lookup
    missed, with NULL `ROWID_OBJECT` / `ROWID_XREF` / `SRC_PKEY_CT` /
    `MASTER_RECORD_YN` / `MERGED_YN`. The CopyList source filter
    (`ROWID_XREF IS NOT NULL`) is what later excludes those rows from
    unmerge/soft-delete; meanwhile they sit in the log, unprocessed.
  - **FLAG 3 — Untranslated types yield NULL `PKEY_SRC_OBJECT` here**, not
    the `'fk1|fk2|'` key the live rewrite produces with its `NVL`
    convention (inherited from its original Snowflake procedure). This
    draft follows the IDQ direct concatenation literally, because no
    Snowflake original exists for History.
  - `PROCESSED_YN` is **not written** (no upstream port feeds it) — left to
    the column default of `STG_TRS_DEACTIVATED_RELATIONSHIPS`, exactly as
    the live capture rewrite does. Confirm the column default before
    relying on this step: if it is not `'N'`, processes testing
    `PROCESSED_YN = 'N'` exactly will miss these rows (the CopyList still
    picks up NULL via `NVL`).
  - The xref lookup has **no `ROWID_SYSTEM` filter** (unlike Complete's
    lookup, which restricts to `'TRS'`) and derives **no soft-delete flag**
    (unlike the live capture's `SOFT_DELETE_YN` from `MAX(HUB_STATE_IND)`).
  - `LOAD_DATE` link is **inferred, not wired**: the export's Write
    instance wires only `INDV_ID` explicitly, so remaining target links
    are inferred by port name/position from the `Exp_TRS` outputs, as the
    live rewrite does for the same pattern (`LAST_UPDATE_DATE = sysdate`
    → `LOAD_DATE` = run start). If IDQ in fact feeds `LOAD_DATE` from
    nothing, it would be NULL/default — flagged here, not hidden.
  - `min_pk` comment ("prioritze the mci record") vs code (`MIN(pty_pk)`):
    the code is what executes; the comment is not a guarantee MIN() makes
    on its own.

## 4. `sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed`

- IDQ mapping: `m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed`,
  workflow `wf_TRS_Deactivation_Complete`, export
  `wf_TRS_Deactivation_Complete-2.xml`.
- File: `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed.sql`
- Parameters: none in IDQ; `P_JOB_RUN_ID` appended.
- Steps:
  - 5 `CLEANUP_PREVIOUS_RUN` — drops `WRK_TRS_DACT_MARKP_S10_KEYS`,
    `WRK_TRS_DACT_MARKP_S20_READY` (no checkpoint).
  - 10 `UNMERGED_KEYS` — `WRK_TRS_DACT_MARKP_S10_KEYS`: `PKEY_SRC_OBJECT`
    as `PTY_PK` from `ZZ_UTL_UNMERGE_TREE_SRC_KEY` (driver since
    2025-05-21: keys actually unmerged, not the original list).
  - 20 `READY_TO_PUBLISH` — `WRK_TRS_DACT_MARKP_S20_READY`: `DISTINCT`
    keys joining a log row with `PROCESSED_YN = 'N'` exactly (IDQ lookup
    filter + `NOT ISNULL(PTY_PK1)` filter; lookup is `returnAny`).
  - 30 `PUBLISH` — one transaction: `UPDATE STG_TRS_DEACTIVED_MEMBERS
    SET PROCESSED_YN = 'Y'` where `PTY_PK IN (ready)` and
    `PROCESSED_YN = 'N'` (DD_UPDATE semantics).
- Preserved quirks:
  - **Trust-the-key-table asymmetry**: NO re-verification against MDM
    state. A key that failed to unmerge could be marked processed. The
    relationship side verifies hub state; this side does not. Confirm
    intentional before relying on it.
  - **`PROCESSED_YN = 'N'` exact, no `NVL`**: NULL rows are NOT matched or
    marked — unlike the relationship side.
  - The `'N'` guard is re-applied in the publish `UPDATE` so stale
    evidence cannot mark a row that changed after step 20. Idempotent:
    re-running marks nothing twice.

## 5. `sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed`

- IDQ mapping: `m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed`,
  workflow `wf_TRS_Deactivation_Complete`, export
  `wf_TRS_Deactivation_Complete-2.xml`.
- File: `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed.sql`
- Parameters: none in IDQ; `P_JOB_RUN_ID` appended.
- Steps:
  - 5 `CLEANUP_PREVIOUS_RUN` — drops `WRK_TRS_DACT_MARKR_S10_SRC`,
    `WRK_TRS_DACT_MARKR_S20_SOFTDEL`, `WRK_TRS_DACT_MARKR_S30_READY`
    (no checkpoint).
  - 10 `UNPROCESSED_LOG_ROWS` — `WRK_TRS_DACT_MARKR_S10_SRC`:
    `PKEY_SRC_OBJECT`, `LOAD_DATE` from `STG_TRS_DEACTIVATED_RELATIONSHIPS`
    where `NVL(PROCESSED_YN,'N') <> 'Y'` and `ROWID_XREF IS NOT NULL`.
  - 20 `SOFT_DELETED_KEYS` — `WRK_TRS_DACT_MARKR_S20_SOFTDEL`: the IDQ
    lookup SQL verbatim (minus the Oracle hint) — `PKEY_SRC_OBJECT` from
    `C_B_PTY_RLE_REL_XREF` where `ROWID_SYSTEM = 'TRS'`, grouped,
    `HAVING MAX(HUB_STATE_IND) = -1`.
  - 30 `READY_TO_PUBLISH` — `WRK_TRS_DACT_MARKR_S30_READY`: `DISTINCT`
    inner join of steps 10 and 20 (IDQ lookup + `NOT ISNULL(PKEY_SRC_OBJECT)`
    filter; lookup is `returnAny`).
  - 40 `PUBLISH` — one transaction: `UPDATE
    STG_TRS_DEACTIVATED_RELATIONSHIPS SET PROCESSED_YN = 'Y'` where
    `PKEY_SRC_OBJECT IN (ready)` and the source guards re-applied
    (`NVL(PROCESSED_YN,'N') <> 'Y'`, `ROWID_XREF IS NOT NULL`).
- Preserved quirks:
  - **Hub-state verification**: a row is marked only when its group proves
    the soft delete landed (`MAX(HUB_STATE_IND) = -1` — a maximum test,
    not an every-row test).
  - **NULL `PROCESSED_YN` included** via `NVL` (2025-09-24 correction) —
    the opposite of the party side.
  - `LOAD_DATE` is carried through IDQ unchanged and is NOT assigned in
    the publish `UPDATE` (assigning it to itself would be a no-op); only
    `PROCESSED_YN` changes.
  - Idempotent by design: Complete is the safe re-run point after a
    failed cycle.

## Runners

| Runner file | Workflow | Order | External step |
|---|---|---|---|
| `TRS/runners/sp_etl_run_wf_TRS_Deactivation_Initial.sql` (+ `run_wf_TRS_Deactivation_Initial.sql`) | `wf_TRS_Deactivation_Initial` | CopyList (party) | Step-90 checkpoint `EXTERNAL_SCRIPT_PENDING` (status `STARTED`, not completed): utility-table count = IDQ `TgtRows`; `> 0` → run `./unmerge_soft_delete_party.sh` externally, then Complete; `= 0` → skip the script (IDQ skips the command when `TgtRows = 0`). |
| `TRS/runners/sp_etl_run_wf_TRS_Relationship_Deactivation.sql` (+ `run_wf_TRS_Relationship_Deactivation.sql`) | `wf_TRS_Relationship_Deactivation` | CopyList (relationship) | Step-90 checkpoint `EXTERNAL_SCRIPT_PENDING` with both counts (soft-delete = primary `TgtRows` equivalent); `> 0` → run `./unmerge_soft_delete_relationship.sh` externally, then Complete; `= 0` → skip. |
| `TRS/runners/sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History.sql` (+ `run_wf_TRS_Pty_Rle_Rel_DeActivation_History.sql`) | `wf_TRS_Pty_Rle_Rel_DeActivation_History` | History Audit only (IDQ: Start → mapping → End, no gateway/command/indicator) | None. Passes mapping defaults `'012'`, `'007'` explicitly, then run id. |
| `TRS/runners/sp_etl_run_wf_TRS_Deactivation_Complete.sql` (+ `run_wf_TRS_Deactivation_Complete.sql`) | `wf_TRS_Deactivation_Complete` | Mark Processed party, then relationship (IDQ order) | None in-runner. Run AFTER the external scripts + MDM batch. The `.ind` touch is left to the scheduler, as in the stage-load runners. |

All runners pass a single `P_JOB_RUN_ID` through to every mapping (one
workflow run = one run id in `JOB_CONTROL_ETL`), write a workflow-level
`STARTING` row (`MAPPING_NAME = 'WORKFLOW'`), and finish/fail with the
shared control procedures. They never write to a target table and never
drop a work table. The shell scripts are a **black box**: not drafted, and
their internals are not invented anywhere in this package.

## Prerequisites — NOT rewritten here (do not duplicate)

These already ship in the all-sources stage-load package
(`TRS_Snowflake_Modular_Rewrite_All_Sources_Simplified.zip`) and must run
before / alongside this package:

- Party deactivation capture (Stage 1, Ongoing load):
  `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_1.sql`
  (IDQ `m_Tgt_C_S_TRS_Pty_Deactivation_1` — writes
  `STG_TRS_DEACTIVED_MEMBERS` with `PROCESSED_YN = 'N'`).
- Relationship deactivation capture (Stage 1, Ongoing load):
  `TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_1.sql`
  (IDQ `m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_1` — writes
  `STG_TRS_DEACTIVATED_RELATIONSHIPS`; note its own parity gap:
  `PROCESSED_YN` left to the column default, and the already-soft-deleted
  `'Y'` shortcut is not reproduced as a separate row).
- ECI reactivation procedures (separate source, same package):
  `ECI/mappings/sp_snow_main_m_Tgt_Stg_ECI_Pty_Reactivation_D_Family_Addr.sql`,
  `ECI/mappings/sp_snow_main_m_Tgt_Stg_ECI_Pty_Reactivation_D_Family_Phn.sql`,
  `ECI/mappings/sp_snow_main_m_Tgt_Stg_ECI_Pty_Reactivation_D_Medicaid.sql`.

## Flagged gaps — things that could NOT be grounded in the XML (never invented)

1. **History Audit `LOAD_DATE` link is inferred** (see §3): the export's
   Write instance wires only `INDV_ID` explicitly. `LAST_UPDATE_DATE =
   sysdate` → `LOAD_DATE` = run start is the only reading consistent with
   the live-capture pattern, but the export alone cannot prove IDQ feeds
   `LOAD_DATE` at all. Verify against a live IDQ run or the target's
   column default before production use.
2. **History Audit `PROCESSED_YN` column default is unknown from the
   exports.** The mapping does not write it. Confirm whether
   `STG_TRS_DEACTIVATED_RELATIONSHIPS.PROCESSED_YN` defaults to `'N'`
   (IDQ behaviour for new rows) or to NULL.
3. **History Audit has no dedup and no xref-exists filter** (§3, Flags 1–2).
   This is grounded (absence verified: 6 transformations, no filter, no
   target lookup) — but whether that absence is intentional or an IDQ
   defect is a business question, not something the XML answers.
4. **Party CopyList 10,000 cap rationale is stale** (old web-service
   timeout; unmerge is now a command task). The cap is preserved, but
   whether 10,000 is still the right batch size, and how a backlog is
   drained, needs a business decision.
5. **Party vs relationship asymmetries are preserved, not reconciled**:
   NULL `PROCESSED_YN` handling differs on every pair (CopyList party
   excludes / relationship includes; Mark Processed party excludes /
   relationship includes), and only the relationship close-out verifies
   hub state. Each difference is verbatim from the XML; none was "fixed".
6. **The shell scripts are a black box.** `unmerge_soft_delete_party.sh`
   and `unmerge_soft_delete_relationship.sh` (plus the Oracle soft-delete
   procedure they call) do the real hub work and are not in any export.
   Their behaviour — including the documented duplicate-key failure on
   re-run after partial staging — cannot be verified from this package.
7. **No live Snowflake compile or row-count parity run** has been done for
   any procedure in this package (same caveat as the stage-load rewrites).
   That is a required pre-production step.
8. **`EXPLODE_NODE_IND` type**: the IDQ expression field is string(1) with
   value `1`; this draft writes `'1'`. If the Snowflake target column is
   numeric, it coerces; confirm the target column type at install time.
9. **Utility-table row counts in the runners are read back with
   `COUNT(*)`** after the mapping call, rather than from the mapping's
   return value (Snowflake scripting cannot assign a `CALL` result).
   Because both utility tables are truncate-loaded by their mappings,
   the count equals the copied count — unless another process writes to
   those tables between the mapping and the count, which the IDQ design
   does not anticipate either.

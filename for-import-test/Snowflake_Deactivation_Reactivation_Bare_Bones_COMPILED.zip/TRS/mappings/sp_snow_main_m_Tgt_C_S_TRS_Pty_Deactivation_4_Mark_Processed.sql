-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed  --  DRAFTED FROM IDQ MAPPING
--
-- DRAFT STATUS -- READ FIRST
--   This procedure is DRAFTED FROM IDQ MAPPING m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed
--   in export file wf_TRS_Deactivation_Complete-2.xml (workflow
--   wf_TRS_Deactivation_Complete).  It is NOT a like-for-like rewrite of
--   a supplied Snowflake procedure: no Snowflake deactivation originals
--   were ever supplied.  Every filter, lookup condition and update
--   behaviour below was taken from that IDQ mapping's XML (source,
--   lookup filter and condition, filter transformation, expression and
--   update-strategy transformations, and the port wiring
--   Read -> Lookup -> Filt -> Exp -> Upd -> Write), not from any
--   Snowflake original.
--
-- IDQ MAPPING (from the export)
--   Source : Read_ZZ_UTL_UNMERGE_TREE_SRC_KEY (PKEY_SRC_OBJECT,
--            ROWID_SYSTEM, EXPLODE_NODE_IND -- only PKEY_SRC_OBJECT is
--            wired downstream).  Designer note (RS, 2025-05-21): "Update
--            the Source table to ZZ_UTL_UNMERGE_TREE_SRC_KEY" -- i.e.
--            this mapping is driven by the keys that were ACTUALLY
--            unmerged, not by the original deactivation list.
--   Lookup: Lookup_Unprocessed_Deactivations on STG_TRS_DEACTIVED_MEMBERS,
--            filter "STG_TRS_DEACTIVED_MEMBERS"."PROCESSED_YN" = 'N',
--            condition PTY_PK = PTY_PK1 (PTY_PK1 is the source key port,
--            fed from the key table's PKEY_SRC_OBJECT),
--            multiple matches: returnAny.
--   Filter: Filt_Keep_Unprocessed, condition NOT ISNULL(PTY_PK1) -- keep
--            only keys that matched a still-unprocessed log row.  (The
--            filter's own note: "Keep only records that have not been
--            written to the deactivation table before. (Simplifies
--            re-run of this mapping if necessary)".)
--   Express: Exp_Set_to_Processed, Processed_Y = 'Y' (plus the PTY_PK
--            passthrough).
--   Update : Upd_Processed_Deactivations, updateStrategy = DD_UPDATE.
--   Target : Write_STG_TRS_DEACTIVED_MEMBERS -- DD_UPDATE by the key
--            (PTY_PK), setting PROCESSED_YN = 'Y'.  No other column is
--            written by this mapping.
--            Port wiring confirmed from the XML: target PTY_PK <-
--            Upd.PTY_PK <- Exp.PTY_PK <- Filt.PTY_PK <-
--            key-table PKEY_SRC_OBJECT; target PROCESSED_YN <-
--            Upd.Processed_Y <- Exp.Processed_Y ('Y').
--
-- DATA FLOW (read this top to bottom -- it IS the business flow)
--   Step 10  WRK_TRS_DACT_MARKP_S10_KEYS   keys actually unmerged (key table)
--   Step 20  WRK_TRS_DACT_MARKP_S20_READY  keys matching a still-unprocessed
--                                          log row (lookup + filter)
--   Step 30  PUBLISH                      STG_TRS_DEACTIVED_MEMBERS,
--                                          in one transaction (UPDATE,
--                                          DD_UPDATE semantics)
--   Start  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
--                                previous run (step 5, drops only), then rebuild from step 10
--   End    TERMINATING           work tables are NOT dropped: they
--                                stay in the database until the next
--                                run of this mapping cleans them up
--
-- WORK TABLES (all TRANSIENT, never shared with another mapping)
--   WRK_TRS_DACT_MARKP_S10_KEYS, WRK_TRS_DACT_MARKP_S20_READY.  They live
--   in the same schema as the targets (unqualified names, as in the
--   stage-load templates), are prefixed WRK_TRS_DACT_, and are not registered anywhere (no control table in this bare-bones package).  They survive a session
--   crash (TRANSIENT, not TEMP).  A Snowflake CURSOR was NOT used: every
--   step here is set-based by design.
--
-- PRESERVED QUIRKS AND DEVIATIONS (do not "fix" silently)
--   * TRUST-THE-KEY-TABLE ASYMMETRY (preserved): this party mapping
--     does NOT re-verify anything against MDM state.  A key in
--     ZZ_UTL_UNMERGE_TREE_SRC_KEY whose log row is still 'N' is marked
--     'Y' whether or not the unmerge actually succeeded in the hub.
--     The relationship Mark Processed mapping, by contrast, only marks
--     a row when its cross-reference group proves the soft delete landed
--     (MAX(HUB_STATE_IND) = -1).  A party key that failed to unmerge
--     could therefore be marked processed here.  That asymmetry is in
--     the IDQ design, not a drafting choice -- confirm it is intentional
--     before relying on it.
--   * PROCESSED_YN = 'N' EXACT (preserved): the lookup filter is an exact
--     'N' test, with NO NVL.  A log row with PROCESSED_YN NULL is NOT
--     matched and is NOT marked, even if its key was unmerged -- unlike
--     the relationship side, which treats NULL as unprocessed.  Both
--     behaviours are reproduced as written.
--   * UPDATE publish (documented deviation from the stage-load
--     insert-only rule): IDQ update strategy is DD_UPDATE, so the
--     publish here is an UPDATE, not an INSERT.  Nothing is inserted
--     and nothing is deleted by this procedure.
--   * Ready keys are DISTINCT: the IDQ lookup is returnAny (existence),
--     so the ready table holds each matching key once.  The publish
--     uses an IN-subquery rather than a join, so a log table with
--     duplicate PTY_PK rows updates each matching row exactly once.
--   * The PROCESSED_YN = 'N' guard is re-applied in the publish UPDATE
--     itself, so a row that changed between step 20 and step 30 is not
--     marked on stale evidence.
--
-- SIGNATURE
--   The IDQ mapping has no mapping parameters, so there are no original
--   parameters to preserve.  BARE-BONES: the simplified version appended
--   P_JOB_RUN_ID (NULL = start a new run); it is removed here, so this
--   procedure takes no arguments and returns only the summary string.
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed ()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed';
    l_rows       NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Work tables are NOT dropped at the end of a run, so any table this
    -- mapping created in a previous run is still in the database. Dropping
    -- them here, at the start of this run, is what makes a mapping-level
    -- restart work: the run then rebuilds every step from scratch.
    -- DROP TABLE IF EXISTS is a no-op if a table is already absent.
    -- NOTE: nothing is recorded for these drops, by design.
    DROP TABLE IF EXISTS WRK_TRS_DACT_MARKP_S10_KEYS;
    DROP TABLE IF EXISTS WRK_TRS_DACT_MARKP_S20_READY;

    -- ---- Step 10: KEYS ACTUALLY UNMERGED --------------------------------
    -- Purpose: Read_ZZ_UTL_UNMERGE_TREE_SRC_KEY -- the driver of this
    -- mapping (since 2025-05-21, the keys actually unmerged, not the
    -- original deactivation list).  Only PKEY_SRC_OBJECT is carried: it
    -- is the only key-table column wired downstream in IDQ (as PTY_PK1).
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_MARKP_S10_KEYS AS
    SELECT PKEY_SRC_OBJECT AS PTY_PK
      FROM ZZ_UTL_UNMERGE_TREE_SRC_KEY;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_MARKP_S10_KEYS;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 UNMERGED_KEYS', :l_rows) || CHR(10);

    -- ---- Step 20: KEYS MATCHING A STILL-UNPROCESSED LOG ROW -------------
    -- Purpose: Lookup_Unprocessed_Deactivations + Filt_Keep_Unprocessed,
    -- as a table.  A key survives only if a log row with that PTY_PK is
    -- still flagged PROCESSED_YN = 'N' exactly (no NVL -- NULL rows do
    -- NOT match, see header).  DISTINCT because the IDQ lookup is
    -- returnAny: this is an existence test, not a row multiplier.
    -- This mapping deliberately does NOT check MDM state (see header).
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_MARKP_S20_READY AS
    SELECT DISTINCT k.PTY_PK
      FROM WRK_TRS_DACT_MARKP_S10_KEYS k
      JOIN STG_TRS_DEACTIVED_MEMBERS m ON m.PTY_PK = k.PTY_PK
     WHERE m.PROCESSED_YN = 'N';
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_MARKP_S20_READY;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 READY_TO_PUBLISH', :l_rows) || CHR(10);

    -- ---- Step 30: PUBLISH -- one transaction, one target, UPDATE --------
    -- This is the ONLY step that writes to a final target, and the only
    -- step inside an explicit transaction.  IDQ update strategy is
    -- DD_UPDATE: PROCESSED_YN is set to 'Y' (Exp_Set_to_Processed) for
    -- the matched keys, and nothing else is written.  The PROCESSED_YN
    -- = 'N' guard is re-applied here so stale evidence cannot mark a
    -- row that changed after step 20.  If the UPDATE fails, it rolls
    -- back, the work tables survive, and the mapping must be restarted
    -- from the beginning. No per-step record survives a failure: the
    -- summary string is only returned on success.  Idempotent by design: re-running marks nothing
    -- twice, because marked rows are no longer 'N'.
    BEGIN TRANSACTION;
    UPDATE STG_TRS_DEACTIVED_MEMBERS
       SET PROCESSED_YN = 'Y'
     WHERE PTY_PK IN (SELECT PTY_PK FROM WRK_TRS_DACT_MARKP_S20_READY)
       AND PROCESSED_YN = 'N';
    l_rows := SQLROWCOUNT;
    COMMIT;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 PUBLISH (STG_TRS_DEACTIVED_MEMBERS)', :l_rows) || CHR(10);

    -- ---- TERMINATING ------------------------------------------------------
    
    RETURN l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- Roll back the publish transaction if one is open (harmless if
        -- none is), then raise.  Nothing is written on failure: there
        -- is no FAILED row in this bare-bones package.  Work tables are
        -- NOT dropped here: they stay until the next run cleans them
        -- up at its start.  The caller (workflow runner) will see the
        -- raise and stop the workflow; the operator restarts the mapping
        -- with a new run.
        ROLLBACK;
        
        
        RAISE;
END;
$$;

-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList  --  DRAFTED FROM IDQ MAPPING
--
-- DRAFT STATUS -- READ FIRST
--   This procedure is DRAFTED FROM IDQ MAPPING m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList
--   in export file wf_TRS_Relationship_Deactivation-2.xml (workflow
--   wf_TRS_Relationship_Deactivation).  It is NOT a like-for-like rewrite
--   of a supplied Snowflake procedure: no Snowflake deactivation originals
--   were ever supplied.  Every filter, expression and load behaviour below
--   was taken from that IDQ mapping's XML (source filter, filter
--   transformation, target truncate flags and the port wiring
--   Read -> Exp_Default_System -> {Write soft-delete, Fil -> Write unmerge}),
--   not from any Snowflake original.
--
-- IDQ MAPPING (from the export)
--   Source : STG_TRS_DEACTIVATED_RELATIONSHIPS
--            filter: nvl("STG_TRS_DEACTIVATED_RELATIONSHIPS"."PROCESSED_YN",'N') <> 'Y'
--                    and "STG_TRS_DEACTIVATED_RELATIONSHIPS"."ROWID_XREF" is not null
--            Designer note on the mapping (2025-09-02, ML): "Corrected
--            source fiter criteria to include null processed_YN".
--   Express: Exp_Default_System -- pure passthrough of PKEY_SRC_OBJECT,
--            ROWID_XREF, MASTER_RECORD_YN, MERGED_YN, ROWID_SYSTEM.
--            No column is stamped or derived here; ROWID_SYSTEM is the
--            log row's own value (unlike the party CopyList, which stamps
--            'TRS' space-padded).
--   Filter : Fil_Merged_Relationships, condition (verbatim from the XML):
--              MERGED_YN ='Y'
--              --and MASTER_RECORD_YN ='N'
--              -- [ML 12/6/2024] Excluding master records will lead to
--              -- soft deleting data that was merged with a master record
--              -- which would be an error. Therefore flag was commented out.
--   Targets: ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY (PKEY_SRC_OBJECT, ROWID_SYSTEM),
--            truncateTargetTable = true -- receives ALL unprocessed keys.
--            ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF (ROWID_XREF),
--            truncateTargetTable = true -- receives only MERGED_YN = 'Y' keys.
--            Port wiring confirmed from the XML: soft-delete target <-
--            Exp_Default_System.PKEY_SRC_OBJECT / ROWID_SYSTEM; unmerge
--            target <- Fil_Merged_Relationships.ROWID_XREF.
--
-- DATA FLOW (read this top to bottom -- it IS the business flow)
--   Step 10  WRK_TRS_DACT_COPYR_S10_SRC     unprocessed log rows with a ROWID_XREF
--   Step 20  WRK_TRS_DACT_COPYR_S20_SOFTDEL target-shaped keys for the soft-delete
--                                          table (ALL rows from step 10)
--   Step 30  WRK_TRS_DACT_COPYR_S30_UNMERGE target-shaped keys for the unmerge
--                                          table (MERGED_YN = 'Y' only)
--   Step 40  PUBLISH                       BOTH utility tables, in one
--                                          transaction (TRUNCATE + INSERT each)
--   Start  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
--                                previous run (step 5, drops only), then rebuild from step 10
--   End    TERMINATING           work tables are NOT dropped: they
--                                stay in the database until the next
--                                run of this mapping cleans them up
--
-- WORK TABLES (all TRANSIENT, never shared with another mapping)
--   WRK_TRS_DACT_COPYR_S10_SRC, WRK_TRS_DACT_COPYR_S20_SOFTDEL,
--   WRK_TRS_DACT_COPYR_S30_UNMERGE.  They live in the same schema as the
--   targets (unqualified names, as in the stage-load templates), are
--   prefixed WRK_TRS_DACT_, and are not registered anywhere (no control table in this bare-bones package).  They survive a session crash
--   (TRANSIENT, not TEMP).  A Snowflake CURSOR was NOT used: every step
--   here is set-based by design.
--
-- PRESERVED QUIRKS AND DEVIATIONS (do not "fix" silently)
--   * Commented-out MASTER_RECORD_YN exclusion (preserved as a comment
--     in step 30, and as the reason step 30 filters on MERGED_YN alone):
--     the IDQ filter once read MERGED_YN = 'Y' AND MASTER_RECORD_YN = 'N',
--     but the MASTER_RECORD_YN half is commented out in the XML because
--     excluding master records would soft-delete data that was merged
--     into a master record.  Master records therefore STAY in the unmerge
--     table.  Do NOT re-add the exclusion.
--   * NULL PROCESSED_YN is INCLUDED here (NVL(PROCESSED_YN,'N') <> 'Y'),
--     unlike the party CopyList, which uses a bare <> 'Y' and excludes
--     NULL rows.  Both behaviours are reproduced as written.
--   * Rows WITHOUT a ROWID_XREF are excluded by the source filter, even
--     if unprocessed: a relationship that never matched an MDM
--     cross-reference has no key for either utility table.
--   * TRUNCATE + INSERT publish (documented deviation from the stage-load
--     insert-only rule): IDQ truncate-loads both utility tables and the
--     external unmerge/soft-delete script consumes the WHOLE tables, so
--     a re-run must REPLACE the keys, not accumulate them.  Both
--     truncates and both inserts are in the ONE publish transaction.
--   * The external script is a BLACK BOX: ./unmerge_soft_delete_relationship.sh
--     is not in the IDQ export and is NOT drafted here.  This procedure
--     only copies the keys; the runner records the external-script step
--     as a summary line (see sp_etl_run_wf_TRS_Relationship_Deactivation).
--
-- SIGNATURE
--   The IDQ mapping has no mapping parameters, so there are no original
--   parameters to preserve.  BARE-BONES: the simplified version appended
--   P_JOB_RUN_ID (NULL = start a new run); it is removed here, so this
--   procedure takes no arguments and returns only the summary string.
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList ()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList';
    l_rows       NUMBER DEFAULT 0;
    l_softdel_rows NUMBER DEFAULT 0;
    l_unmerge_rows NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Work tables are NOT dropped at the end of a run, so any table this
    -- mapping created in a previous run is still in the database. Dropping
    -- them here, at the start of this run, is what makes a mapping-level
    -- restart work: the run then rebuilds every step from scratch.
    -- DROP TABLE IF EXISTS is a no-op if a table is already absent.
    -- NOTE: nothing is recorded for these drops, by design.
    DROP TABLE IF EXISTS WRK_TRS_DACT_COPYR_S10_SRC;
    DROP TABLE IF EXISTS WRK_TRS_DACT_COPYR_S20_SOFTDEL;
    DROP TABLE IF EXISTS WRK_TRS_DACT_COPYR_S30_UNMERGE;

    -- ---- Step 10: UNPROCESSED LOG ROWS WITH A CROSS-REFERENCE KEY -------
    -- Purpose: Read_STG_TRS_DEACTIVATED_RELATIONSHIPS -- the IDQ source
    -- filter, verbatim in Snowflake form: NVL(PROCESSED_YN,'N') <> 'Y'
    -- (NULL counts as unprocessed) AND ROWID_XREF IS NOT NULL.  The five
    -- columns carried are exactly the columns Exp_Default_System passes
    -- through in IDQ; MASTER_RECORD_YN is carried even though no later
    -- step filters on it, so that the commented-out exclusion (step 30)
    -- stays visible against the data it would have excluded.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_COPYR_S10_SRC AS
    SELECT PKEY_SRC_OBJECT, ROWID_XREF, ROWID_SYSTEM, MERGED_YN, MASTER_RECORD_YN
      FROM STG_TRS_DEACTIVATED_RELATIONSHIPS
     WHERE NVL(PROCESSED_YN, 'N') <> 'Y'
       AND ROWID_XREF IS NOT NULL;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_COPYR_S10_SRC;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 UNPROCESSED_LOG_ROWS', :l_rows) || CHR(10);

    -- ---- Step 20: SOFT-DELETE KEYS -- ALL unprocessed keys --------------
    -- Purpose: Write_ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY, as a table.  Every
    -- row from step 10, with the log row's own ROWID_SYSTEM (nothing is
    -- stamped here).  This table is in target column order, so step 40
    -- is a plain TRUNCATE + INSERT ... SELECT.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_COPYR_S20_SOFTDEL AS
    SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM
      FROM WRK_TRS_DACT_COPYR_S10_SRC;
    SELECT COUNT(*) INTO :l_softdel_rows FROM WRK_TRS_DACT_COPYR_S20_SOFTDEL;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 READY_SOFTDEL', :l_softdel_rows) || CHR(10);

    -- ---- Step 30: UNMERGE KEYS -- merged relationships only -------------
    -- Purpose: Fil_Merged_Relationships + Write_ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF,
    -- as a table.  Filter, verbatim from the IDQ XML:
    --     MERGED_YN = 'Y'
    --     --and MASTER_RECORD_YN = 'N'
    --     -- [ML 12/6/2024] Excluding master records will lead to soft
    --     -- deleting data that was merged with a master record which
    --     -- would be an error. Therefore flag was commented out.
    -- The MASTER_RECORD_YN half MUST NOT be re-applied: master records
    -- stay in the unmerge table, because data merged into a master would
    -- otherwise be wrongly soft-deleted.  This table is in target column
    -- order, so step 40 is a plain TRUNCATE + INSERT ... SELECT.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_COPYR_S30_UNMERGE AS
    SELECT ROWID_XREF
      FROM WRK_TRS_DACT_COPYR_S10_SRC
     WHERE MERGED_YN = 'Y';
     -- NOTE: the IDQ filter's MASTER_RECORD_YN = 'N' half is commented
     -- out in the XML (see header) and is deliberately NOT applied here.
    SELECT COUNT(*) INTO :l_unmerge_rows FROM WRK_TRS_DACT_COPYR_S30_UNMERGE;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 READY_UNMERGE', :l_unmerge_rows) || CHR(10);

    -- ---- Step 40: PUBLISH -- one transaction, two targets ---------------
    -- This is the ONLY step that writes to a final target, and the only
    -- step inside an explicit transaction.  IDQ truncate-loads both
    -- utility tables and the external script consumes the whole tables,
    -- so the publish is TRUNCATE + INSERT for each table: a re-run
    -- replaces the keys instead of accumulating them (documented
    -- deviation from the stage-load insert-only rule -- see header).
    -- If either INSERT fails, the transaction rolls back, the work tables
    -- survive, and the mapping must be restarted from the beginning.
    -- Following the multi-target stage-load precedent, the summary
    -- carries the combined inserted count and the per-table counts.
    BEGIN TRANSACTION;
    TRUNCATE TABLE ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY;
    INSERT INTO ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY
           (PKEY_SRC_OBJECT, ROWID_SYSTEM)
    SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM
      FROM WRK_TRS_DACT_COPYR_S20_SOFTDEL;
    l_rows := SQLROWCOUNT;
    TRUNCATE TABLE ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF;
    INSERT INTO ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF
           (ROWID_XREF)
    SELECT ROWID_XREF
      FROM WRK_TRS_DACT_COPYR_S30_UNMERGE;
    l_rows := l_rows + SQLROWCOUNT;
    COMMIT;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 40 PUBLISH (softdel ' || :l_softdel_rows || ' + unmerge ' || :l_unmerge_rows || ')', :l_rows) || CHR(10);

    -- ---- TERMINATING ------------------------------------------------------
    
    RETURN l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- Roll back the publish transaction if one is open (harmless if
        -- none is), then raise.  Nothing is written on failure: there
        -- is no FAILED row in this bare-bones package.  Work tables are
        -- NOT dropped here: they stay until the next run cleans them
        -- up at its start.  The caller (workflow runner) will see the
        -- raise and stop the workflow; the operator restarts the mapping
        -- with a new run.
        ROLLBACK;
        
        
        RAISE;
END;
$$;

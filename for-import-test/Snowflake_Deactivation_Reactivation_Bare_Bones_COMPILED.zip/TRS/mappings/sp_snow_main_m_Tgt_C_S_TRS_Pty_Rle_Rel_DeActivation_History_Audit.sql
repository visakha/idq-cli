-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit  --  DRAFTED FROM IDQ MAPPING
--
-- DRAFT STATUS -- READ FIRST
--   This procedure is DRAFTED FROM IDQ MAPPING m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit
--   in export file wf_TRS_Pty_Rle_Rel_DeActivation_History-2.xml (workflow
--   wf_TRS_Pty_Rle_Rel_DeActivation_History).  It is NOT a like-for-like
--   rewrite of a supplied Snowflake procedure: no Snowflake deactivation
--   originals were ever supplied.  Every SQL statement, expression and
--   filter below was taken from that IDQ mapping's XML (source custom SQL,
--   both lookup definitions, both expression transformations and the
--   target field list), not from any Snowflake original.  Where the live
--   relationship-capture rewrite
--   (sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_1, in the
--   all-sources stage-load package) implements the same pattern, this
--   draft follows it -- and every place where this draft DIFFERS from
--   that pattern is flagged below, because the History XML itself differs.
--
-- IDQ MAPPING (from the export)
--   Source : Read_STG_TRS_H_DC_RELATIONSHIPS_A, custom SQL (verbatim):
--              WITH min_pk as  -- find 1 source key per indiv, prioritze the mci record
--              ( SELECT indv_id, MIN(pty_pk) pty_pk
--                  FROM stg_trs_valid_members GROUP BY indv_id )
--              SELECT /*+ parallel (4) */ rel.indv_id, ref_indv_id,
--                     eff_begin_dt, eff_end_dt, relationship_type_cd,
--                     pk1.pty_pk as pty_pkey, pk2.pty_pk as ref_pty_pkey,
--                     'TRS' as src_sys
--                FROM stg_trs_h_dc_relationships_a rel
--                JOIN min_pk pk1 ON rel.indv_id = pk1.indv_id
--                JOIN min_pk pk2 ON rel.ref_indv_id = pk2.indv_id
--            The Oracle /*+ parallel (4) */ hint has no Snowflake
--            equivalent and is dropped (it changes execution, not rows).
--            NOTE on the min_pk comment: the code takes MIN(pty_pk) per
--            individual; the "prioritze the mci record" claim is the
--            designer's comment, not something MIN() guarantees on its
--            own.  Preserved as written.
--   Lookup: Lookup_V_LOOKUP_CODE_VALUE on V_LOOKUP_CODE_VALUE,
--            filter CODE_TYPE = 'PTY_REL',
--            condition SRC_CODE_VALUE = RELATIONSHIP_TYPE_CD
--                    AND SRC_SYS = SRC_SYS_IN, multiple matches: returnAny.
--            Implemented with the pre-existing shared helper
--            fn_snow_helper41_common() (one row per CODE_TYPE / SRC_SYS /
--            SRC_CODE_VALUE), exactly as the live capture rewrite does.
--   Express: Exp_Gen_PKEY
--              v_PTY_RLE_FK_INDV     = IIF(ISNULL(in_PTY_PKEY), NULL,
--                                        LTRIM(RTRIM(in_PTY_PKEY)) || '|Member')
--              v_PTY_RLE_FK_REF_INDV = IIF(ISNULL(in_REF_PTY_PKEY), NULL,
--                                        LTRIM(RTRIM(in_REF_PTY_PKEY)) || '|Member')
--              PTY_RLE_FK_1          = v_PTY_RLE_FK_INDV
--              PTY_RLE_FK_2          = v_PTY_RLE_FK_REF_INDV
--              PKEY_SRC_OBJECT       = v_PTY_RLE_FK_INDV || '|' ||
--                                      v_PTY_RLE_FK_REF_INDV || '|' ||
--                                      in_RELATIONSHIP_TYPE_MSTR_CD
--            (in_RELATIONSHIP_TYPE_MSTR_CD is the lookup's MSTR_CODE_VALUE;
--            in_PTY_PKEY / in_REF_PTY_PKEY are the source's pty_pkey /
--            ref_pty_pkey.)
--   Lookup: Lkp_C_B_PTY_RLE_REL_XREF on C_B_PTY_RLE_REL_XREF,
--            condition PKEY_SRC_OBJECT = in_PKEY_SRC_OBJECT, custom SQL:
--              SELECT DISTINCT T.ROWID_OBJECT, T.PKEY_SRC_OBJECT,
--                     T.ROWID_SYSTEM,
--                     COUNT(DISTINCT PKEY_SRC_OBJECT) OVER
--                       (PARTITION BY ROWID_OBJECT) SRC_PKEY_CT,
--                     CASE WHEN COUNT(DISTINCT PKEY_SRC_OBJECT) OVER
--                       (PARTITION BY ROWID_OBJECT) > 1
--                       THEN 'Y' ELSE 'N' END MERGE_YN,
--                     case when T.ROWID_OBJECT = T.ORIG_ROWID_OBJECT
--                       then 'Y' else 'N' end MASTER_RECORD_YN,
--                     min(rowid_xref) over
--                       (partition by PKEY_SRC_OBJECT) MIN_ROWID_XREF
--                FROM C_B_PTY_RLE_REL_XREF T
--            NOTE: this lookup SQL has NO ROWID_SYSTEM filter (unlike the
--            Complete workflow's lookup, which restricts to 'TRS') and
--            derives NO soft-delete flag (unlike the live capture, which
--            derives SOFT_DELETE_YN from MAX(HUB_STATE_IND)).  Both
--            omissions are preserved.
--   Express: Exp_TRS_PTY_RLE_REL_DeActivate
--              LAST_UPDATE_DATE = sysdate
--              o_MERGE_YN       = RTRIM(LTRIM(MERGE_YN))
--            plus passthroughs (see step 50 for which ports feed the target).
--   Target : Write_STG_TRS_DEACTIVATED_RELATIONSHIPS, load type Normal
--            (plain INSERT; the target is NOT truncated in this mapping).
--
-- DATA FLOW (read this top to bottom -- it IS the business flow)
--   Step 10  WRK_TRS_DACT_HIST_S10_MINPK   one source key per individual (min_pk)
--   Step 20  WRK_TRS_DACT_HIST_S20_SRC     history relationships, both ends
--                                          resolved through step 10
--   Step 30  WRK_TRS_DACT_HIST_S30_KEYED   PTY_REL translation + composite
--                                          PKEY_SRC_OBJECT (Exp_Gen_PKEY)
--   Step 40  WRK_TRS_DACT_HIST_S40_XREF    MDM cross-reference, one row per
--                                          source key (return-any)
--   Step 50  WRK_TRS_DACT_HIST_S50_READY   publish-ready rows -- PLAIN, see FLAG
--   Step 60  PUBLISH                       STG_TRS_DEACTIVATED_RELATIONSHIPS,
--                                          in one transaction (INSERT only)
--   Start  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
--                                previous run (step 5, drops only), then rebuild from step 10
--   End    TERMINATING           work tables are NOT dropped: they
--                                stay in the database until the next
--                                run of this mapping cleans them up
--
-- WORK TABLES (all TRANSIENT, never shared with another mapping)
--   WRK_TRS_DACT_HIST_S10_MINPK, WRK_TRS_DACT_HIST_S20_SRC,
--   WRK_TRS_DACT_HIST_S30_KEYED, WRK_TRS_DACT_HIST_S40_XREF,
--   WRK_TRS_DACT_HIST_S50_READY.  They live in the same schema as the
--   targets (unqualified names, as in the stage-load templates), are
--   prefixed WRK_TRS_DACT_, and are not registered anywhere (no control table in this bare-bones package).  They survive a session crash
--   (TRANSIENT, not TEMP).  A Snowflake CURSOR was NOT used: every step
--   here is set-based by design.
--
-- *** FLAG 1 -- NO DEDUP / NOT-EXISTS LOGIC EXISTS IN THIS MAPPING ***
--   The History XML contains NO lookup against
--   STG_TRS_DEACTIVATED_RELATIONSHIPS, NO "already logged" guard and NO
--   filter of any kind.  The live relationship capture
--   (m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_1) DOES have one: it keeps
--   only rows whose key is NOT already logged as unprocessed
--   (PROCESSED_YN = 'N').  That guard is ABSENT here, so this draft is a
--   PLAIN INSERT: re-running this procedure re-inserts every history
--   relationship it reads, including keys already in the log.  This is
--   preserved as written in the XML -- it is NOT a drafting omission --
--   but it must be understood before this procedure is run twice over
--   the same history extract.  Do NOT add a dedup guard without a
--   business decision, because adding one would change what the IDQ
--   workflow does.
--
-- *** FLAG 2 -- NO CROSS-REFERENCE-EXISTS FILTER ***
--   The live capture drops rows whose key finds no cross-reference
--   (MIN_ROWID_XREF NOT NULL).  The History XML has no such filter, so
--   this draft publishes rows whose xref lookup missed, with NULL
--   ROWID_OBJECT / ROWID_XREF / SRC_PKEY_CT / MASTER_RECORD_YN /
--   MERGED_YN.  That includes untranslated relationship types (see
--   Flag 3).  Preserved as written; the CopyList source filter
--   (ROWID_XREF IS NOT NULL) is what later excludes those rows from
--   the unmerge/soft-delete step -- they sit in the log, unprocessed,
--   until a cross-reference appears or they are dealt with otherwise.
--
-- *** FLAG 3 -- UNTRANSLATED TYPES: NULL KEY HERE, NOT A '...|' KEY ***
--   The IDQ key expression concatenates the master code directly, so an
--   untranslated type (lookup miss, master code NULL) yields a NULL
--   PKEY_SRC_OBJECT in this draft -- Snowflake || with a NULL operand
--   is NULL, exactly as in IDQ.  The live capture rewrite instead wraps
--   each part in NVL(...,'') (a convention inherited from its original
--   Snowflake procedure), so an untranslated type there yields a key
--   ending in '|'.  This draft does NOT follow that convention, because
--   no Snowflake original exists for History and the IDQ expression is
--   the only authority.  Either way the row finds no cross-reference;
--   the difference is only what key (NULL vs 'fk1|fk2|') is stored.
--
-- OTHER PRESERVED NOTES (do not "fix" silently)
--   * PROCESSED_YN is NOT written by this mapping: no upstream port
--     feeds it (the target field list includes it, but Exp_TRS produces
--     no PROCESSED_YN value).  It is left to the column default of
--     STG_TRS_DEACTIVATED_RELATIONSHIPS -- exactly as the live capture
--     rewrite does.  If the column default is 'N', new rows behave as
--     IDQ new rows; if it is NULL, the CopyList still picks them up
--     (it treats NULL as unprocessed) but any process testing
--     PROCESSED_YN = 'N' exactly would miss them.  Confirm the column
--     default before relying on this step.
--   * LOAD_DATE: the IDQ expression produces LAST_UPDATE_DATE = sysdate
--     and the target column is LOAD_DATE.  The export's Write instance
--     wires only INDV_ID explicitly, so the remaining target links are
--     inferred by port name/position from the Exp_TRS outputs, exactly
--     as the live capture rewrite does for the same pattern: LOAD_DATE
--     is written here as the run start (:l_run_ts, the Snowflake
--     equivalent of sysdate at run time).  If the target's LOAD_DATE is
--     instead fed by nothing in IDQ, it would be NULL/default -- that
--     cannot be distinguished from this export alone, and is flagged
--     here rather than hidden.
--   * ROWID_SYSTEM is written as SRC_SYS ('TRS') from the source, NOT
--     as the xref row's ROWID_SYSTEM: the Exp_TRS ROWID_SYSTEM port is
--     fed from Exp_Gen_PKEY.SRC_SYS in the XML.  The xref lookup's own
--     ROWID_SYSTEM value is therefore dropped, as in the live rewrite.
--   * REL_TYPE_CODE is the SOURCE relationship type code
--     (RELATIONSHIP_TYPE_CD), not the translated master code: the
--     Exp_TRS S_REL_TYPE_CODE port is fed from
--     Exp_Gen_PKEY.RELATIONSHIP_TYPE_CD in the XML.
--   * EFF_BEGIN_DT / EFF_END_DT are selected by the source SQL and
--     passed through Exp_Gen_PKEY, but no target column takes them, so
--     they are dropped at step 30.  They are carried in step 20 only so
--     the source step stays verbatim.
--   * The xref lookup's window-function SQL is restructured into grouped
--     CTEs in step 40 (per-object distinct-key count, per-key minimum
--     ROWID_XREF), which is mathematically the same result as the IDQ
--     SELECT DISTINCT with window functions, and is the same
--     restructuring the live capture rewrite uses.  The "return any
--     row" behaviour is reproduced as: first row per PKEY_SRC_OBJECT
--     ordered by ROWID_OBJECT.
--   * fn_snow_helper36_common / fn_snow_helper41_common are pre-existing
--     shared helpers from the stage-load framework, not invented here.
--
-- SIGNATURE
--   The IDQ mapping HAS two mapping parameters, both with defaults in
--   the XML and NEITHER referenced by any expression in the mapping
--   (no $$ reference exists in the export).  They are carried here for
--   signature fidelity, in IDQ order, with their IDQ defaults, and are
--   otherwise unused -- exactly as in IDQ.  BARE-BONES: the simplified
--   version also appended P_JOB_RUN_ID; it is removed here.
--     P_ABSENT_PAR_SQ_ALT_ID_TP  VARCHAR  DEFAULT '012'  -- IDQ default; unused
--     P_INDV_ID_ALT_ID_TP        VARCHAR  DEFAULT '007'  -- IDQ default; unused
--                                                          (a run id is generated
--                                                          and returned in the summary).
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit (
    P_ABSENT_PAR_SQ_ALT_ID_TP  VARCHAR DEFAULT '012',
    P_INDV_ID_ALT_ID_TP        VARCHAR DEFAULT '007'
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit';
    l_run_ts     TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
    l_rows       NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Work tables are NOT dropped at the end of a run, so any table this
    -- mapping created in a previous run is still in the database. Dropping
    -- them here, at the start of this run, is what makes a mapping-level
    -- restart work: the run then rebuilds every step from scratch.
    -- DROP TABLE IF EXISTS is a no-op if a table is already absent.
    -- NOTE: nothing is recorded for these drops, by design.
    DROP TABLE IF EXISTS WRK_TRS_DACT_HIST_S10_MINPK;
    DROP TABLE IF EXISTS WRK_TRS_DACT_HIST_S20_SRC;
    DROP TABLE IF EXISTS WRK_TRS_DACT_HIST_S30_KEYED;
    DROP TABLE IF EXISTS WRK_TRS_DACT_HIST_S40_XREF;
    DROP TABLE IF EXISTS WRK_TRS_DACT_HIST_S50_READY;

    -- ---- Step 10: ONE SOURCE KEY PER INDIVIDUAL (min_pk) ----------------
    -- Purpose: the min_pk CTE of the IDQ source SQL, materialised once
    -- because step 20 joins it twice (once per relationship end).
    -- MIN(pty_pk) per indv_id from STG_TRS_VALID_MEMBERS, exactly as
    -- written (see header note on the "prioritze the mci record" comment).
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_HIST_S10_MINPK AS
    SELECT indv_id, MIN(pty_pk) pty_pk FROM STG_TRS_VALID_MEMBERS GROUP BY indv_id;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_HIST_S10_MINPK;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 MIN_PK', :l_rows) || CHR(10);

    -- ---- Step 20: HISTORY RELATIONSHIPS, BOTH ENDS RESOLVED -------------
    -- Purpose: Read_STG_TRS_H_DC_RELATIONSHIPS_A -- the IDQ source SQL
    -- verbatim, except for the dropped Oracle parallel hint.  A
    -- relationship whose member or reference member is not a valid
    -- member is dropped here by the inner joins, before any key is
    -- built.  SRC_SYS is 'TRS' for every row.  EFF_BEGIN_DT / EFF_END_DT
    -- are carried here (they are in the source SQL) but are dropped at
    -- step 30: no target column takes them.  Reads ONLY step 10 (twice).
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_HIST_S20_SRC AS
    SELECT rel.indv_id AS INDV_ID, rel.ref_indv_id AS REF_INDV_ID,
           rel.eff_begin_dt AS EFF_BEGIN_DT, rel.eff_end_dt AS EFF_END_DT,
           rel.relationship_type_cd AS RELATIONSHIP_TYPE_CD,
           pk1.pty_pk AS PTY_PKEY, pk2.pty_pk AS REF_PTY_PKEY, 'TRS' AS SRC_SYS
      FROM STG_TRS_H_DC_RELATIONSHIPS_A rel
      JOIN WRK_TRS_DACT_HIST_S10_MINPK pk1 ON rel.indv_id = pk1.indv_id
      JOIN WRK_TRS_DACT_HIST_S10_MINPK pk2 ON rel.ref_indv_id = pk2.indv_id;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_HIST_S20_SRC;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 HIST_REL_SRC', :l_rows) || CHR(10);

    -- ---- Step 30: PTY_REL TRANSLATION + COMPOSITE KEY (Exp_Gen_PKEY) ----
    -- Purpose: Lookup_V_LOOKUP_CODE_VALUE (code type PTY_REL) +
    -- Exp_Gen_PKEY, exactly as written in IDQ.  Each end becomes
    -- '<party key>|Member' (NULL if the key is NULL -- not possible
    -- after step 20's inner joins, but kept as written), and the
    -- composite key is member | ref member | master type.  The lookup
    -- is a LEFT JOIN, as in IDQ a lookup miss leaves the master code
    -- NULL; the key expression is a direct concatenation, so an
    -- untranslated type yields a NULL PKEY_SRC_OBJECT here (see header
    -- Flag 3 -- this differs from the live rewrite's NVL convention).
    -- Reads ONLY step 20.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_HIST_S30_KEYED AS
    WITH
    lkp_cv AS (SELECT * FROM TABLE(fn_snow_helper41_common()))
    SELECT s.*,
           IFF(s.PTY_PKEY IS NULL, NULL, TRIM(s.PTY_PKEY) || '|Member')               AS pty_rle_fk_1,
           IFF(s.REF_PTY_PKEY IS NULL, NULL, TRIM(s.REF_PTY_PKEY) || '|Member')       AS pty_rle_fk_2,
           IFF(s.PTY_PKEY IS NULL, NULL, TRIM(s.PTY_PKEY) || '|Member') || '|'
           || IFF(s.REF_PTY_PKEY IS NULL, NULL, TRIM(s.REF_PTY_PKEY) || '|Member') || '|'
           || pt.MSTR_CODE_VALUE                                                      AS pkey_src_object
      FROM WRK_TRS_DACT_HIST_S20_SRC s
      LEFT JOIN lkp_cv pt ON pt.CODE_TYPE = 'PTY_REL' AND pt.SRC_SYS = s.SRC_SYS
                         AND pt.SRC_CODE_VALUE = s.RELATIONSHIP_TYPE_CD;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_HIST_S30_KEYED;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 KEYED_REL', :l_rows) || CHR(10);

    -- ---- Step 40: MDM CROSS-REFERENCE, ONE ROW PER SOURCE KEY ----------
    -- Purpose: Lkp_C_B_PTY_RLE_REL_XREF (custom lookup SQL, restructured
    -- into grouped CTEs -- mathematically the same as the IDQ
    -- SELECT DISTINCT with window functions; see header).  Per hub
    -- object: the count of distinct source keys (SRC_PKEY_CT); per
    -- source key: the lowest ROWID_XREF.  From those: MERGE_YN = 'Y'
    -- when more than one distinct source key shares a hub object,
    -- MASTER_RECORD_YN = 'Y' when ROWID_OBJECT = ORIG_ROWID_OBJECT.
    -- No ROWID_SYSTEM filter and no soft-delete flag exist in this
    -- lookup (see header).  Then xref_one keeps one row per
    -- PKEY_SRC_OBJECT (first by ROWID_OBJECT) -- the lookup's
    -- "return any row".  This table is independent of steps 10-30 (it
    -- reads only C_B_PTY_RLE_REL_XREF), but it is a step in its own
    -- right so its row count and contents can be inspected before the
    -- ready step joins it.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_HIST_S40_XREF AS
    WITH
    xref_obj AS (
        SELECT ROWID_OBJECT, COUNT(DISTINCT PKEY_SRC_OBJECT) AS SRC_PKEY_CT
          FROM C_B_PTY_RLE_REL_XREF
         GROUP BY ROWID_OBJECT
    ),
    xref_key AS (
        SELECT PKEY_SRC_OBJECT, MIN(ROWID_XREF) AS MIN_ROWID_XREF
          FROM C_B_PTY_RLE_REL_XREF
         GROUP BY PKEY_SRC_OBJECT
    ),
    xref AS (
        SELECT DISTINCT t.ROWID_OBJECT, t.PKEY_SRC_OBJECT, t.ROWID_SYSTEM, o.SRC_PKEY_CT,
               IFF(o.SRC_PKEY_CT > 1, 'Y', 'N')                          AS MERGE_YN,
               IFF(t.ROWID_OBJECT = t.ORIG_ROWID_OBJECT, 'Y', 'N')        AS MASTER_RECORD_YN,
               k.MIN_ROWID_XREF
          FROM C_B_PTY_RLE_REL_XREF t
          JOIN xref_obj o ON o.ROWID_OBJECT = t.ROWID_OBJECT
          JOIN xref_key k ON k.PKEY_SRC_OBJECT = t.PKEY_SRC_OBJECT
    )
    SELECT * FROM xref
    QUALIFY ROW_NUMBER() OVER (PARTITION BY PKEY_SRC_OBJECT ORDER BY ROWID_OBJECT) = 1;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_HIST_S40_XREF;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 40 XREF_ONE', :l_rows) || CHR(10);

    -- ---- Step 50: READY -- PLAIN, NO DEDUP, NO XREF-EXISTS FILTER -------
    -- Purpose: Exp_TRS_PTY_RLE_REL_DeActivate, as a table, joined to
    -- step 40.  *** FLAG: there is deliberately NO not-already-logged
    -- guard and NO MIN_ROWID_XREF IS NOT NULL filter here, because the
    -- History XML has neither (see header Flags 1 and 2).  Every row
    -- from step 30 is published, including re-runs of already-logged
    -- keys and rows whose xref lookup missed (NULL xref columns).
    -- Column values, from the XML port wiring:
    --   PTY_RLE_FK_1/2 = keyed '<party key>|Member' ends;
    --   REL_TYPE_CODE  = SOURCE relationship type code (not master code);
    --   ROWID_XREF     = MIN_ROWID_XREF (NULL on lookup miss);
    --   ROWID_SYSTEM   = SRC_SYS ('TRS'), not the xref row's value;
    --   LOAD_DATE      = run start (IDQ LAST_UPDATE_DATE = sysdate);
    --   MERGED_YN      = TRIM(MERGE_YN) (IDQ RTRIM(LTRIM(MERGE_YN)));
    --   PROCESSED_YN   = NOT selected (left to the column default).
    -- This table is in target column order (minus PROCESSED_YN), so
    -- step 60 is a plain INSERT ... SELECT.  Reads ONLY steps 30 and 40.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_HIST_S50_READY AS
    SELECT k.INDV_ID AS INDV_ID, k.REF_INDV_ID AS REF_INDV_ID,
           k.pty_rle_fk_1 AS PTY_RLE_FK_1, k.pty_rle_fk_2 AS PTY_RLE_FK_2,
           k.RELATIONSHIP_TYPE_CD AS REL_TYPE_CODE, x.MIN_ROWID_XREF AS ROWID_XREF,
           k.pkey_src_object AS PKEY_SRC_OBJECT,
           x.ROWID_OBJECT AS ROWID_OBJECT, k.SRC_SYS AS ROWID_SYSTEM,
           :l_run_ts AS LOAD_DATE, x.SRC_PKEY_CT AS SRC_PKEY_CT,
           x.MASTER_RECORD_YN AS MASTER_RECORD_YN,
           TRIM(x.MERGE_YN) AS MERGED_YN
      FROM WRK_TRS_DACT_HIST_S30_KEYED k
      LEFT JOIN WRK_TRS_DACT_HIST_S40_XREF x ON x.PKEY_SRC_OBJECT = k.pkey_src_object;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_HIST_S50_READY;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 50 READY_TO_PUBLISH', :l_rows) || CHR(10);

    -- ---- Step 60: PUBLISH -- one transaction, one target ----------------
    -- This is the ONLY step that writes to a final target, and the only
    -- step inside an explicit transaction.  IDQ load type is Normal
    -- (plain INSERT, no truncate), so this is a plain INSERT from step
    -- 50 -- including, by design, any rows already in the log (see
    -- header Flag 1).  If the INSERT fails, it rolls back, the
    -- work tables survive, and the mapping must be restarted from the
    -- beginning. No per-step record survives a failure: the summary
    -- string is only returned on success.
    BEGIN TRANSACTION;
    INSERT INTO STG_TRS_DEACTIVATED_RELATIONSHIPS
           (INDV_ID, REF_INDV_ID, PTY_RLE_FK_1, PTY_RLE_FK_2, REL_TYPE_CODE, ROWID_XREF, PKEY_SRC_OBJECT,
            ROWID_OBJECT, ROWID_SYSTEM, LOAD_DATE, SRC_PKEY_CT, MASTER_RECORD_YN, MERGED_YN)
    SELECT INDV_ID, REF_INDV_ID, PTY_RLE_FK_1, PTY_RLE_FK_2, REL_TYPE_CODE, ROWID_XREF, PKEY_SRC_OBJECT,
           ROWID_OBJECT, ROWID_SYSTEM, LOAD_DATE, SRC_PKEY_CT, MASTER_RECORD_YN, MERGED_YN
      FROM WRK_TRS_DACT_HIST_S50_READY;
    l_rows := SQLROWCOUNT;
    COMMIT;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 60 PUBLISH (STG_TRS_DEACTIVATED_RELATIONSHIPS)', :l_rows) || CHR(10);

    -- ---- TERMINATING ------------------------------------------------------
    
    RETURN l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- Roll back the publish transaction if one is open (harmless if
        -- none is), then raise.  Nothing is written on failure: there
        -- is no FAILED row in this bare-bones package.  Work tables are
        -- NOT dropped here: they stay until the next run cleans them
        -- up at its start.  The caller (workflow runner) will see the
        -- raise and stop the workflow; the operator restarts the mapping
        -- with a new run.
        ROLLBACK;
        
        
        RAISE;
END;
$$;

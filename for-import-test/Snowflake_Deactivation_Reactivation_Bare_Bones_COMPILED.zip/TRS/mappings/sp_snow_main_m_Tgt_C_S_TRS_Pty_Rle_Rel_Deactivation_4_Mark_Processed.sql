-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed  --  DRAFTED FROM IDQ MAPPING
--
-- DRAFT STATUS -- READ FIRST
--   This procedure is DRAFTED FROM IDQ MAPPING m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed
--   in export file wf_TRS_Deactivation_Complete-2.xml (workflow
--   wf_TRS_Deactivation_Complete).  It is NOT a like-for-like rewrite of
--   a supplied Snowflake procedure: no Snowflake deactivation originals
--   were ever supplied.  Every filter, lookup SQL and update behaviour
--   below was taken from that IDQ mapping's XML (source filter, lookup
--   custom SQL and condition, filter transformation, expression and
--   update-strategy transformations, and the port wiring
--   Read -> Lookup -> Filt -> Exp -> Upd -> Write), not from any
--   Snowflake original.
--
-- IDQ MAPPING (from the export)
--   Source : Read_STG_TRS_DEACTIVATED_RELATIONSHIPS (projects
--            PKEY_SRC_OBJECT, LOAD_DATE, PROCESSED_YN),
--            filter: nvl("STG_TRS_DEACTIVATED_RELATIONSHIPS"."PROCESSED_YN",'N') <> 'Y'
--                    and "STG_TRS_DEACTIVATED_RELATIONSHIPS"."ROWID_XREF" is not null
--            Designer note (2025-09-24, ML): "Corrected source fiter
--            criteria to include null processed_YN".
--   Lookup: Lookup_C_B_PTY_RLE_REL_XREF on C_B_PTY_RLE_REL_XREF,
--            condition PKEY_SRC_OBJECT = PKEY_SRC_OBJECT1,
--            multiple matches: returnAny, custom SQL (verbatim):
--              SELECT /*+ parallel (4) */ T.PKEY_SRC_OBJECT
--                FROM C_B_PTY_RLE_REL_XREF T
--               WHERE T.ROWID_SYSTEM = 'TRS'
--               GROUP BY T.PKEY_SRC_OBJECT
--              HAVING MAX(T.HUB_STATE_IND) = -1
--            The Oracle /*+ parallel (4) */ hint has no Snowflake
--            equivalent and is dropped (it changes execution, not rows).
--   Filter: Filt_Keep_Soft_Deletes, condition NOT ISNULL(PKEY_SRC_OBJECT)
--            -- keep only rows whose key was found in the soft-deleted
--            set (the lookup's output key is non-null exactly when a
--            match exists).
--   Express: Exp_Set_to_Processed, Processed_Y = 'Y' (plus the
--            PTY_REL_PK passthrough -- the source PKEY_SRC_OBJECT --
--            and the LOAD_DATE passthrough).
--   Update : Upd_Processed_Deactivations, updateStrategy = DD_UPDATE.
--   Target : Write_STG_TRS_DEACTIVATED_RELATIONSHIPS -- DD_UPDATE by the
--            key (PKEY_SRC_OBJECT), setting PROCESSED_YN = 'Y'.
--            Port wiring confirmed from the XML: target PKEY_SRC_OBJECT
--            <- Upd.PTY_REL_PK <- Exp.PTY_REL_PK <-
--            Filt.PKEY_SRC_OBJECT (source key); target LOAD_DATE <-
--            Upd.LOAD_DATE <- Exp.LOAD_DATE <- Filt.LOAD_DATE (the
--            source row's own LOAD_DATE, carried through unchanged);
--            target PROCESSED_YN <- Upd.Processed_Y <- Exp.Processed_Y ('Y').
--
-- DATA FLOW (read this top to bottom -- it IS the business flow)
--   Step 10  WRK_TRS_DACT_MARKR_S10_SRC     unprocessed log rows with a ROWID_XREF
--   Step 20  WRK_TRS_DACT_MARKR_S20_SOFTDEL keys proven soft-deleted in the hub
--                                          (MAX(HUB_STATE_IND) = -1, system TRS)
--   Step 30  WRK_TRS_DACT_MARKR_S30_READY  keys present in both (lookup + filter)
--   Step 40  PUBLISH                      STG_TRS_DEACTIVATED_RELATIONSHIPS,
--                                          in one transaction (UPDATE,
--                                          DD_UPDATE semantics)
--   Start  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
--                                previous run (step 5, drops only), then rebuild from step 10
--   End    TERMINATING           work tables are NOT dropped: they
--                                stay in the database until the next
--                                run of this mapping cleans them up
--
-- WORK TABLES (all TRANSIENT, never shared with another mapping)
--   WRK_TRS_DACT_MARKR_S10_SRC, WRK_TRS_DACT_MARKR_S20_SOFTDEL,
--   WRK_TRS_DACT_MARKR_S30_READY.  They live in the same schema as the
--   targets (unqualified names, as in the stage-load templates), are
--   prefixed WRK_TRS_DACT_, and are not registered anywhere (no control table in this bare-bones package).  They survive a session crash
--   (TRANSIENT, not TEMP).  A Snowflake CURSOR was NOT used: every step
--   here is set-based by design.
--
-- PRESERVED QUIRKS AND DEVIATIONS (do not "fix" silently)
--   * HUB-STATE VERIFICATION (the stricter side of the Complete
--     asymmetry): unlike the party Mark Processed mapping, which trusts
--     the key table, this mapping marks a row ONLY when its
--     cross-reference group proves the soft delete landed:
--     MAX(HUB_STATE_IND) = -1 for that PKEY_SRC_OBJECT in
--     C_B_PTY_RLE_REL_XREF with ROWID_SYSTEM = 'TRS'.  A key whose hub
--     rows are not all... -- precisely, whose group maximum is not -1
--     -- stays unprocessed and will be retried next cycle.  Note the
--     test is on the MAX, not on every row: a group with any row still
--     at another state fails only if its maximum differs from -1.
--   * NULL PROCESSED_YN is INCLUDED (NVL(PROCESSED_YN,'N') <> 'Y'),
--     unlike the party Mark Processed lookup, which tests 'N' exactly
--     and excludes NULL rows.  Both behaviours are reproduced as written.
--   * Rows WITHOUT a ROWID_XREF are excluded by the source filter, even
--     if unprocessed: a relationship that never matched a cross-reference
--     cannot be proven soft-deleted and is never marked here.
--   * LOAD_DATE is carried through the IDQ flow unchanged (source value
--     in, same value out) and is therefore NOT assigned in the publish
--     UPDATE: assigning it to itself would be a no-op.  Only
--     PROCESSED_YN changes.
--   * UPDATE publish (documented deviation from the stage-load
--     insert-only rule): IDQ update strategy is DD_UPDATE, so the
--     publish here is an UPDATE, not an INSERT.  Nothing is inserted
--     and nothing is deleted by this procedure.
--   * Ready keys are DISTINCT: the IDQ lookup is returnAny (existence),
--     so the ready table holds each proven key once.  The publish uses
--     an IN-subquery rather than a join, so a log table with duplicate
--     PKEY_SRC_OBJECT rows updates each matching row exactly once.
--   * The source guards (NVL(PROCESSED_YN,'N') <> 'Y' and
--     ROWID_XREF IS NOT NULL) are re-applied in the publish UPDATE
--     itself, so a row that changed between step 30 and step 40 is not
--     marked on stale evidence.
--
-- SIGNATURE
--   The IDQ mapping has no mapping parameters, so there are no original
--   parameters to preserve.  BARE-BONES: the simplified version appended
--   P_JOB_RUN_ID (NULL = start a new run); it is removed here, so this
--   procedure takes no arguments and returns only the summary string.
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed ()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed';
    l_rows       NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Work tables are NOT dropped at the end of a run, so any table this
    -- mapping created in a previous run is still in the database. Dropping
    -- them here, at the start of this run, is what makes a mapping-level
    -- restart work: the run then rebuilds every step from scratch.
    -- DROP TABLE IF EXISTS is a no-op if a table is already absent.
    -- NOTE: nothing is recorded for these drops, by design.
    DROP TABLE IF EXISTS WRK_TRS_DACT_MARKR_S10_SRC;
    DROP TABLE IF EXISTS WRK_TRS_DACT_MARKR_S20_SOFTDEL;
    DROP TABLE IF EXISTS WRK_TRS_DACT_MARKR_S30_READY;

    -- ---- Step 10: UNPROCESSED LOG ROWS WITH A CROSS-REFERENCE KEY -------
    -- Purpose: Read_STG_TRS_DEACTIVATED_RELATIONSHIPS -- the IDQ source
    -- filter, verbatim in Snowflake form: NVL(PROCESSED_YN,'N') <> 'Y'
    -- (NULL counts as unprocessed, per the 2025-09-24 correction) AND
    -- ROWID_XREF IS NOT NULL.  PKEY_SRC_OBJECT and LOAD_DATE are
    -- carried (the IDQ source projects them); LOAD_DATE is carried
    -- through unchanged to the target and is never reassigned.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_MARKR_S10_SRC AS
    SELECT PKEY_SRC_OBJECT, LOAD_DATE
      FROM STG_TRS_DEACTIVATED_RELATIONSHIPS
     WHERE NVL(PROCESSED_YN, 'N') <> 'Y'
       AND ROWID_XREF IS NOT NULL;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_MARKR_S10_SRC;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 UNPROCESSED_LOG_ROWS', :l_rows) || CHR(10);

    -- ---- Step 20: KEYS PROVEN SOFT-DELETED IN THE HUB -------------------
    -- Purpose: Lookup_C_B_PTY_RLE_REL_XREF -- the IDQ custom lookup SQL,
    -- verbatim except for the dropped Oracle parallel hint.  A key
    -- qualifies only when its cross-reference group for system 'TRS'
    -- has MAX(HUB_STATE_IND) = -1, i.e. the soft delete actually landed
    -- in the hub.  This table is independent of step 10 (it reads only
    -- C_B_PTY_RLE_REL_XREF), but it is a step in its own right so its
    -- row count and contents can be inspected before matching.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_MARKR_S20_SOFTDEL AS
    SELECT T.PKEY_SRC_OBJECT
      FROM C_B_PTY_RLE_REL_XREF T
     WHERE T.ROWID_SYSTEM = 'TRS'
     GROUP BY T.PKEY_SRC_OBJECT
    HAVING MAX(T.HUB_STATE_IND) = -1;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_MARKR_S20_SOFTDEL;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 SOFT_DELETED_KEYS', :l_rows) || CHR(10);

    -- ---- Step 30: MATCHED KEYS -- lookup + filter ------------------------
    -- Purpose: Filt_Keep_Soft_Deletes (NOT ISNULL(PKEY_SRC_OBJECT) on
    -- the lookup output), as a table: an inner join, because the filter
    -- keeps exactly the rows whose key was found in step 20.  DISTINCT
    -- because the IDQ lookup is returnAny: this is an existence test,
    -- not a row multiplier.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_MARKR_S30_READY AS
    SELECT DISTINCT s.PKEY_SRC_OBJECT
      FROM WRK_TRS_DACT_MARKR_S10_SRC s
      JOIN WRK_TRS_DACT_MARKR_S20_SOFTDEL d ON d.PKEY_SRC_OBJECT = s.PKEY_SRC_OBJECT;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_MARKR_S30_READY;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 READY_TO_PUBLISH', :l_rows) || CHR(10);

    -- ---- Step 40: PUBLISH -- one transaction, one target, UPDATE --------
    -- This is the ONLY step that writes to a final target, and the only
    -- step inside an explicit transaction.  IDQ update strategy is
    -- DD_UPDATE: PROCESSED_YN is set to 'Y' (Exp_Set_to_Processed) for
    -- the matched keys, and nothing else is written -- LOAD_DATE is
    -- carried through unchanged in IDQ and is not reassigned here.
    -- The source guards are re-applied here so stale evidence cannot
    -- mark a row that changed after step 30.  If the UPDATE fails, it
    -- rolls back, the work tables survive, and the mapping must be
    -- restarted from the beginning. No per-step record survives a
    -- failure: the summary string is only returned on success.  Idempotent by design: re-running
    -- marks nothing twice, because marked rows are no longer
    -- unprocessed.
    BEGIN TRANSACTION;
    UPDATE STG_TRS_DEACTIVATED_RELATIONSHIPS
       SET PROCESSED_YN = 'Y'
     WHERE PKEY_SRC_OBJECT IN (SELECT PKEY_SRC_OBJECT FROM WRK_TRS_DACT_MARKR_S30_READY)
       AND NVL(PROCESSED_YN, 'N') <> 'Y'
       AND ROWID_XREF IS NOT NULL;
    l_rows := SQLROWCOUNT;
    COMMIT;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 40 PUBLISH (STG_TRS_DEACTIVATED_RELATIONSHIPS)', :l_rows) || CHR(10);

    -- ---- TERMINATING ------------------------------------------------------
    
    RETURN l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- Roll back the publish transaction if one is open (harmless if
        -- none is), then raise.  Nothing is written on failure: there
        -- is no FAILED row in this bare-bones package.  Work tables are
        -- NOT dropped here: they stay until the next run cleans them
        -- up at its start.  The caller (workflow runner) will see the
        -- raise and stop the workflow; the operator restarts the mapping
        -- with a new run.
        ROLLBACK;
        
        
        RAISE;
END;
$$;

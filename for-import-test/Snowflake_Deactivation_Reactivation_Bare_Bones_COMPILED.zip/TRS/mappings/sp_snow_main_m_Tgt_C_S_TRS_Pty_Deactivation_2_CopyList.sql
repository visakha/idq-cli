-- ============================================================================
-- sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList  --  DRAFTED FROM IDQ MAPPING
--
-- DRAFT STATUS -- READ FIRST
--   This procedure is DRAFTED FROM IDQ MAPPING m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList
--   in export file wf_TRS_Deactivation_Initial-2.xml (workflow wf_TRS_Deactivation_Initial).
--   It is NOT a like-for-like rewrite of a supplied Snowflake procedure:
--   no Snowflake deactivation originals were ever supplied.  Every filter,
--   expression and load behaviour below was taken from that IDQ mapping's
--   XML (source filter, expression fields, target truncate flag and the
--   port wiring Read -> Exp_Default_System -> Write), not from any
--   Snowflake original.
--
-- IDQ MAPPING (from the export)
--   Source : STG_TRS_DEACTIVED_MEMBERS (note the database spelling DEACTIVED)
--            filter: "STG_TRS_DEACTIVED_MEMBERS"."PROCESSED_YN" <> 'Y'
--                    and rownum <= 10000
--   Express: Exp_Default_System
--              PTY_PK            passthrough (wired to target PKEY_SRC_OBJECT)
--              Soruce_System     = 'TRS           '  -- 14 characters: 'TRS' + 11 spaces.
--                                  (IDQ spelling "Soruce_System" kept in this note only;
--                                  the expression comment in the XML reads "NOTE the MDM
--                                  pads with sapces!!".  ROWID_SYSTEM is 14 chars wide.)
--              EXPLODE_NODE_IND  = 1  (IDQ expression field is string(1); written
--                                  here as '1')
--   Target : ZZ_UTL_UNMERGE_TREE_SRC_KEY (PKEY_SRC_OBJECT, ROWID_SYSTEM,
--            EXPLODE_NODE_IND), truncateTargetTable = true, load type Normal.
--            Port wiring confirmed from the XML: target PKEY_SRC_OBJECT <-
--            Exp_Default_System.PTY_PK; ROWID_SYSTEM <- Soruce_System;
--            EXPLODE_NODE_IND <- EXPLODE_NODE_IND.  No other source column
--            is wired to the target, so no other source column is carried.
--
-- DATA FLOW (read this top to bottom -- it IS the business flow)
--   Step 10  WRK_TRS_DACT_COPYP_S10_SRC    unprocessed log rows, capped at 10,000
--   Step 20  WRK_TRS_DACT_COPYP_S20_READY  target-shaped keys (PKEY_SRC_OBJECT,
--                                          ROWID_SYSTEM, EXPLODE_NODE_IND)
--   Step 30  PUBLISH                      ZZ_UTL_UNMERGE_TREE_SRC_KEY, in one
--                                          transaction (TRUNCATE + INSERT)
--   Start  CLEANUP_PREVIOUS_RUN  drop any work tables left by the
--                                previous run (step 5, drops only), then rebuild from step 10
--   End    TERMINATING           work tables are NOT dropped: they
--                                stay in the database until the next
--                                run of this mapping cleans them up
--
-- WORK TABLES (all TRANSIENT, never shared with another mapping)
--   WRK_TRS_DACT_COPYP_S10_SRC, WRK_TRS_DACT_COPYP_S20_READY.  They live
--   in the same schema as the targets (unqualified names, as in the
--   stage-load templates), are prefixed WRK_TRS_DACT_, and are not registered anywhere (no control table in this bare-bones package).  They survive a session
--   crash (TRANSIENT, not TEMP).  A Snowflake CURSOR was NOT used: every
--   step here is set-based by design.
--
-- PRESERVED QUIRKS AND DEVIATIONS (do not "fix" silently)
--   * 10,000-row cap: IDQ applies rownum <= 10000 with NO ORDER BY, so
--     which 10,000 rows are picked is unspecified in IDQ.  The designer
--     note on the source ties the cap to the OLD web-service unmerge
--     timeout ("Capped at 10k rows to coincide with the WS time out
--     (30min). 10k Rows typically unmerge in 15 min."), and the unmerge
--     is now a command task (./unmerge_soft_delete_party.sh, 2025-09-02),
--     so the cap's rationale may be stale -- but the cap is preserved
--     exactly as specified.  Snowflake has no ROWNUM, so the cap is
--     written as QUALIFY ROW_NUMBER() OVER () <= 10000: the empty OVER ()
--     keeps the pick order unspecified, exactly as in IDQ.  A backlog
--     over 10,000 needs repeated runs; this procedure never drains more
--     than 10,000 keys per run.
--   * NULL PROCESSED_YN asymmetry (preserved): this party CopyList uses
--     PROCESSED_YN <> 'Y' with NO NVL, so a log row with PROCESSED_YN
--     NULL is NOT picked up (NULL <> 'Y' is not true).  The relationship
--     CopyList, by contrast, uses NVL(PROCESSED_YN,'N') <> 'Y' and DOES
--     pick up NULL rows.  Both behaviours are reproduced as written;
--     do not "align" them without a business decision.
--   * TRUNCATE + INSERT publish (documented deviation from the stage-load
--     insert-only rule): IDQ truncate-loads ZZ_UTL_UNMERGE_TREE_SRC_KEY
--     and the external unmerge/soft-delete script consumes the WHOLE
--     table, so a re-run must REPLACE the keys, not accumulate them.
--     Appending here would re-present keys from earlier cycles to the
--     script.  The truncate and the insert are in the ONE publish
--     transaction, so a failed publish leaves the previous keys intact.
--   * The external script is a BLACK BOX: ./unmerge_soft_delete_party.sh
--     is not in the IDQ export and is NOT drafted here.  This procedure
--     only copies the keys; the runner records the external-script step
--     as a summary line (see sp_etl_run_wf_TRS_Deactivation_Initial).
--
-- SIGNATURE
--   The IDQ mapping has no mapping parameters, so there are no original
--   parameters to preserve.  BARE-BONES: the simplified version appended
--   P_JOB_RUN_ID (NULL = start a new run); it is removed here, so this
--   procedure takes no arguments and returns only the summary string.
--   A restart is simply a new run: the mapping cleans up the
--   previous run's work tables at its start (step 5) and runs
--   every step from scratch. There is no step-level restart.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList ()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    c_mapping    VARCHAR DEFAULT 'm_Tgt_C_S_TRS_Pty_Deactivation_2_CopyList';
    l_rows       NUMBER DEFAULT 0;
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- ---- Step 5: CLEANUP_PREVIOUS_RUN -- drop work tables left by a previous run
    -- Work tables are NOT dropped at the end of a run, so any table this
    -- mapping created in a previous run is still in the database. Dropping
    -- them here, at the start of this run, is what makes a mapping-level
    -- restart work: the run then rebuilds every step from scratch.
    -- DROP TABLE IF EXISTS is a no-op if a table is already absent.
    -- NOTE: nothing is recorded for these drops, by design.
    DROP TABLE IF EXISTS WRK_TRS_DACT_COPYP_S10_SRC;
    DROP TABLE IF EXISTS WRK_TRS_DACT_COPYP_S20_READY;

    -- ---- Step 10: UNPROCESSED LOG ROWS, CAPPED AT 10,000 -----------------
    -- Purpose: Read_STG_TRS_DEACTIVED_MEMBERS -- the IDQ source filter,
    -- verbatim in Snowflake form: PROCESSED_YN <> 'Y' (no NVL -- NULL
    -- rows are NOT picked up, see header) and at most 10,000 rows.
    -- QUALIFY ROW_NUMBER() OVER () keeps the pick order unspecified,
    -- exactly as Oracle ROWNUM without ORDER BY does.  Only PTY_PK is
    -- carried: it is the only source column wired to the target in IDQ.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_COPYP_S10_SRC AS
    SELECT PTY_PK
      FROM STG_TRS_DEACTIVED_MEMBERS
     WHERE PROCESSED_YN <> 'Y'
    QUALIFY ROW_NUMBER() OVER () <= 10000;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_COPYP_S10_SRC;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 10 UNPROCESSED_LOG_ROWS', :l_rows) || CHR(10);

    -- ---- Step 20: TARGET-SHAPED KEYS (Exp_Default_System) ---------------
    -- Purpose: the IDQ expression, as a table.  PTY_PK becomes the
    -- target key PKEY_SRC_OBJECT; ROWID_SYSTEM is stamped 'TRS' padded
    -- to 14 characters with spaces, exactly as the MDM expects; and
    -- EXPLODE_NODE_IND is 1.  This table is in target column order,
    -- so step 30 is a plain TRUNCATE + INSERT ... SELECT.
    CREATE OR REPLACE TRANSIENT TABLE WRK_TRS_DACT_COPYP_S20_READY AS
    SELECT PTY_PK AS PKEY_SRC_OBJECT,
           'TRS           ' AS ROWID_SYSTEM,
           '1' AS EXPLODE_NODE_IND
      FROM WRK_TRS_DACT_COPYP_S10_SRC;
    SELECT COUNT(*) INTO :l_rows FROM WRK_TRS_DACT_COPYP_S20_READY;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 20 READY_TO_PUBLISH', :l_rows) || CHR(10);

    -- ---- Step 30: PUBLISH -- one transaction, one target ----------------
    -- This is the ONLY step that writes to a final target, and the only
    -- step inside an explicit transaction.  IDQ truncate-loads this
    -- utility table and the external script consumes the whole table,
    -- so the publish is TRUNCATE + INSERT: a re-run replaces the keys
    -- instead of accumulating them (documented deviation from the
    -- stage-load insert-only rule -- see header).  If the INSERT fails,
    -- the transaction rolls back, the work tables survive, and the
    -- mapping must be restarted from the beginning. No per-step record
    -- survives a failure: the summary string is only returned on success.
    BEGIN TRANSACTION;
    TRUNCATE TABLE ZZ_UTL_UNMERGE_TREE_SRC_KEY;
    INSERT INTO ZZ_UTL_UNMERGE_TREE_SRC_KEY
           (PKEY_SRC_OBJECT, ROWID_SYSTEM, EXPLODE_NODE_IND)
    SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM, EXPLODE_NODE_IND
      FROM WRK_TRS_DACT_COPYP_S20_READY;
    l_rows := SQLROWCOUNT;
    COMMIT;
    
    l_summary := l_summary || fn_snow_helper36_common(:c_mapping, 'step 30 PUBLISH (ZZ_UTL_UNMERGE_TREE_SRC_KEY)', :l_rows) || CHR(10);

    -- ---- TERMINATING ------------------------------------------------------
    
    RETURN l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- Roll back the publish transaction if one is open (harmless if
        -- none is), then raise.  Nothing is written on failure: there
        -- is no FAILED row in this bare-bones package.  Work tables are
        -- NOT dropped here: they stay until the next run cleans them
        -- up at its start.  The caller (workflow runner) will see the
        -- raise and stop the workflow; the operator restarts the mapping
        -- with a new run.
        ROLLBACK;
        
        
        RAISE;
END;
$$;

-- ----------------------------------------------------------------------------
-- run_wf_TRS_Pty_Rle_Rel_DeActivation_History.sql
--
-- SnowSQL entry point for the drafted Snowflake replacement of
-- wf_TRS_Pty_Rle_Rel_DeActivation_History (IDQ export
-- wf_TRS_Pty_Rle_Rel_DeActivation_History-2.xml).  This REPLACES the IDQ
-- workflow's single mapping task with one runner CALL.
--
-- SnowSQL:  snowsql -c <connection> -f run_wf_TRS_Pty_Rle_Rel_DeActivation_History.sql
--
-- Restarting: just run this script again. There is no step-level
-- restart and no resume call -- the mapping cleans up the previous
-- run's WRK tables at its start (step 5) and runs every step from
-- scratch. A restart is simply a new run. NOTE: the History Audit
-- mapping has NO dedup guard (see its header, Flag 1) -- re-running
-- re-inserts every history relationship it reads, so do not re-run
-- blindly over the same history extract.
-- ----------------------------------------------------------------------------
!set exit_on_error=true

CALL sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History();

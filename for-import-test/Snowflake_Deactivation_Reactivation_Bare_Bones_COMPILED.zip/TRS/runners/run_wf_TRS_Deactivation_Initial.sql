-- ----------------------------------------------------------------------------
-- run_wf_TRS_Deactivation_Initial.sql
--
-- SnowSQL entry point for the drafted Snowflake replacement of
-- wf_TRS_Deactivation_Initial (IDQ export wf_TRS_Deactivation_Initial-2.xml).
-- This REPLACES the IDQ workflow's mapping task with one runner CALL.
-- The runner copies the keys and records the external-script gateway
-- as a summary line; the external script ./unmerge_soft_delete_party.sh itself
-- is NOT run by this script -- run it externally when the summary
-- shows copied rows > 0, then run wf_TRS_Deactivation_Complete.
-- The IDQ command task (touch <workflow>.ind) is still left to the
-- scheduler, exactly as in the stage-load runners.
--
-- SnowSQL:  snowsql -c <connection> -f run_wf_TRS_Deactivation_Initial.sql
--
-- Restarting: just run this script again. There is no step-level
-- restart and no resume call -- the mapping cleans up the previous
-- run's WRK tables at its start (step 5) and runs every step from
-- scratch. A restart is simply a new run. See the runner header
-- for the IDQ duplicate-key re-run caveat.
-- ----------------------------------------------------------------------------
!set exit_on_error=true

CALL sp_etl_run_wf_TRS_Deactivation_Initial();

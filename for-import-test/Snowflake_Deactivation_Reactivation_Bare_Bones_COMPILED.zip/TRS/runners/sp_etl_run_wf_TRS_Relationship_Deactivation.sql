-- ============================================================================
-- sp_etl_run_wf_TRS_Relationship_Deactivation  --  WORKFLOW RUNNER (app level)
-- DRAFTED FROM IDQ MAPPING / WORKFLOW: wf_TRS_Relationship_Deactivation in
-- export file wf_TRS_Relationship_Deactivation-2.xml.  This runner is NOT
-- a like-for-like rewrite of a supplied Snowflake procedure: no Snowflake
-- deactivation originals were ever supplied.
--
-- Runs the Snowflake replacement for IDQ workflow wf_TRS_Relationship_Deactivation:
--   1. m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList -- copies
--      unprocessed relationship keys to ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY
--      (all keys) and ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF (merged only).
--   2. EXTERNAL SCRIPT STEP (recorded, not executed): the IDQ workflow
--      gates on $var:TgtRows > 0 -- with no copied rows the command step
--      is skipped.  The command itself
--      (./unmerge_soft_delete_relationship.sh from
--      /u01/apps/informatica/mdm_exec_batch/scripts) runs OUTSIDE this
--      runner and outside the IDQ export, and is NOT drafted here.
--      This runner therefore ends with summary lines that record both
--      copied row counts and the gateway decision, so the operator knows
--      whether to run the script.  After the script, the
--      separate wf_TRS_Deactivation_Complete runner closes the cycle.
--
-- The IDQ indicator-file command task (touch ${var:sys.WorkflowName}.ind
-- in /opt/apps/informatica/SrcFiles/Indicators) is left to the scheduler,
-- exactly as in the stage-load runners.
--
-- HOW TO RUN IT
--   CALL sp_etl_run_wf_TRS_Relationship_Deactivation();
--   (It takes no arguments and returns the combined summary string:
--   the mapping summary plus the gateway decision.)
--
-- RESTARTING (mapping level only -- there is no step-level restart)
--   A restart is simply a new run: call the runner again. The mapping, at its start (step 5), drops any
--   work tables the previous run left in the database, then runs every
--   step from scratch. Work tables are never dropped at the end of a run.
--   NOTE the IDQ re-run caveat, preserved here: re-running after a
--   partial failure re-populates the utility tables, and the external
--   script can fail with a duplicate-key error if soft-delete records
--   were already staged. Sequence recovery as Complete/clean-up first,
--   not a blind restart.
--
-- RUNNER RETURNS THE MAPPING SUMMARY
--   BARE-BONES CHANGE: the simplified version claimed a CALL's return
--   value could not be assigned to a variable, so the runner returned
--   only a short status line. That claim is out of date: the scalar-call
--   form l_x := (CALL proc(...)) was validated at the ECI step-driver
--   live compile, and it is used here. The runner captures the mapping
--   summary and returns it together with the gateway decision. There is
--   no JOB_CONTROL_ETL in this package, so the returned string is the
--   only record of the run.  The copied row counts are read back from
--   the utility tables themselves (both truncate-loaded, so their row
--   counts ARE the copied counts -- the TgtRows equivalent; the
--   soft-delete count is the primary count, since it holds all keys).
--
-- This runner is APP level: it owns the workflow order, but it never
-- writes to a target table itself and never drops a work table.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_etl_run_wf_TRS_Relationship_Deactivation (
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    l_softdel_rows NUMBER DEFAULT 0;
    l_unmerge_rows NUMBER DEFAULT 0;
    l_map        VARCHAR DEFAULT '';
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- 1. Copy unprocessed relationship keys to both utility tables.
    l_map := (CALL sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList());
    l_summary := l_summary || '--- m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_2_CopyList ---' || CHR(10) || :l_map || CHR(10);

    -- 2. External-script gateway (summary lines, not a checkpoint row).
    -- Both utility tables are truncate-loaded, so their COUNT(*) values
    -- are exactly the copied counts (the IDQ TgtRows equivalent is the
    -- soft-delete count, which holds all keys).  The script itself is
    -- NOT run here -- these summary lines record the gateway outcome
    -- for the operator.  The script is still pending at this point;
    -- the status below means only that the COPY stage completed.
    SELECT COUNT(*) INTO :l_softdel_rows FROM ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY;
    SELECT COUNT(*) INTO :l_unmerge_rows FROM ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF;
    l_summary := l_summary || 'STATUS=COPY_COMPLETED_SCRIPT_PENDING SOFTDEL_ROWS=' || :l_softdel_rows || ' UNMERGE_ROWS=' || :l_unmerge_rows || '.' || CHR(10)
        || 'IDQ gateway (TgtRows > 0) for Cmd_Unmerge_Soft_Delete: soft-delete keys = ' || :l_softdel_rows
        || '; unmerge keys = ' || :l_unmerge_rows || '. '
        || CASE WHEN :l_softdel_rows > 0
                THEN 'Run ./unmerge_soft_delete_relationship.sh from /u01/apps/informatica/mdm_exec_batch/scripts externally, then run wf_TRS_Deactivation_Complete.'
                ELSE 'No rows copied: SKIP the external script (IDQ skips the command step when TgtRows = 0).' END || CHR(10);

    RETURN l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- The failing mapping has already raised and left its work tables
        -- in place. The workflow stops here; the next run starts cleanly
        -- from step 5 of the mapping (there is no step-level restart).
        RAISE;
END;
$$;

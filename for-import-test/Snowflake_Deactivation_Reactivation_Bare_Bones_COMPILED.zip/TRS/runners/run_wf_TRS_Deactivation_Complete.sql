-- ----------------------------------------------------------------------------
-- run_wf_TRS_Deactivation_Complete.sql
--
-- SnowSQL entry point for the drafted Snowflake replacement of
-- wf_TRS_Deactivation_Complete (IDQ export wf_TRS_Deactivation_Complete-2.xml).
-- This REPLACES the IDQ workflow's two mapping tasks with one runner
-- CALL (party mark-processed, then relationship mark-processed).  Run
-- this script AFTER the external unmerge/soft-delete scripts have run
-- and the MDM batch has applied the staged soft deletes.  The IDQ
-- command task (touch <workflow>.ind) is still left to the scheduler,
-- exactly as in the stage-load runners.
--
-- SnowSQL:  snowsql -c <connection> -f run_wf_TRS_Deactivation_Complete.sql
--
-- Restarting: just run this script again. There is no step-level
-- restart and no resume call -- each mapping cleans up the previous
-- run's WRK tables at its start (step 5) and runs every step from
-- scratch. A restart is simply a new run. Both mappings are
-- idempotent by design, so Complete is the safe re-run point.
-- ----------------------------------------------------------------------------
!set exit_on_error=true

CALL sp_etl_run_wf_TRS_Deactivation_Complete();

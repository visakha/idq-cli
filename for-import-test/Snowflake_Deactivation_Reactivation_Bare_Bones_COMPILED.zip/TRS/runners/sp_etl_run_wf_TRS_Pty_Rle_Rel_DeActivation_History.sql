-- ============================================================================
-- sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History  --  WORKFLOW RUNNER (app level)
-- DRAFTED FROM IDQ MAPPING / WORKFLOW: wf_TRS_Pty_Rle_Rel_DeActivation_History in
-- export file wf_TRS_Pty_Rle_Rel_DeActivation_History-2.xml.  This runner
-- is NOT a like-for-like rewrite of a supplied Snowflake procedure: no
-- Snowflake deactivation originals were ever supplied.
--
-- Runs the Snowflake replacement for IDQ workflow
-- wf_TRS_Pty_Rle_Rel_DeActivation_History.  The IDQ workflow is the
-- simplest deactivation workflow: Start -> one mapping task -> End, with
-- no gateway, no command task, no indicator file and no workflow
-- variables in the export.  This runner mirrors it exactly:
--   1. m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit -- captures
--      history/audit relationship deactivations into
--      STG_TRS_DEACTIVATED_RELATIONSHIPS.
--
-- The mapping's original parameters are passed explicitly with their
-- IDQ defaults ('012', '007'). Both parameters are unused in the mapping
-- body (see the mapping header); they are passed for signature fidelity.
--
-- HOW TO RUN IT
--   CALL sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History();
--   (It takes no arguments and returns the mapping summary string.)
--
-- RESTARTING (mapping level only -- there is no step-level restart)
--   A restart is simply a new run: call the runner again. The mapping, at its start (step 5), drops any
--   work tables the previous run left in the database, then runs every
--   step from scratch. Work tables are never dropped at the end of a run.
--   NOTE: the History Audit mapping has NO dedup guard (see its header,
--   Flag 1) -- re-running re-inserts every history relationship it reads.
--   Do not re-run blindly over the same history extract.
--
-- RUNNER RETURNS THE MAPPING SUMMARY
--   BARE-BONES CHANGE: the simplified version claimed a CALL's return
--   value could not be assigned to a variable, so the runner returned
--   only a short status line. That claim is out of date: the scalar-call
--   form l_x := (CALL proc(...)) was validated at the ECI step-driver
--   live compile, and it is used here. The runner captures the mapping
--   summary and returns it. There is no JOB_CONTROL_ETL in this package,
--   so the returned string is the only record of the run.
--
-- This runner is APP level: it owns the workflow order, but it never
-- writes to a target table itself and never drops a work table.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_etl_run_wf_TRS_Pty_Rle_Rel_DeActivation_History (
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    l_map        VARCHAR DEFAULT '';
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- 1. History/audit capture (the workflow's only mapping task).
    l_map := (CALL sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit('012', '007'));
    l_summary := l_summary || '--- m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit ---' || CHR(10) || :l_map || CHR(10);

    RETURN 'STATUS=COMPLETED MAPPINGS=1.' || CHR(10) || l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- The failing mapping has already raised and left its work tables
        -- in place. The workflow stops here; the next run starts cleanly
        -- from step 5 of the mapping (there is no step-level restart).
        RAISE;
END;
$$;

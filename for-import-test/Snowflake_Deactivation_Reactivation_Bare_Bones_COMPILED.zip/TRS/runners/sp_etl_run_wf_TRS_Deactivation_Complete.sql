-- ============================================================================
-- sp_etl_run_wf_TRS_Deactivation_Complete  --  WORKFLOW RUNNER (app level)
-- DRAFTED FROM IDQ MAPPING / WORKFLOW: wf_TRS_Deactivation_Complete in
-- export file wf_TRS_Deactivation_Complete-2.xml.  This runner is NOT a
-- like-for-like rewrite of a supplied Snowflake procedure: no Snowflake
-- deactivation originals were ever supplied.
--
-- Runs the Snowflake replacement for IDQ workflow wf_TRS_Deactivation_Complete,
-- in the same order as the IDQ workflow (no gateways or conditions -- the
-- two mapping tasks run in sequence, then the indicator-file command):
--   1. m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed -- marks party
--      log rows 'Y' for keys actually unmerged (trusts the key table;
--      no MDM-state verification -- see that mapping's header).
--   2. m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed -- marks
--      relationship log rows 'Y' only where the hub proves the soft
--      delete landed (MAX(HUB_STATE_IND) = -1).
--
-- Run this workflow AFTER the external unmerge/soft-delete scripts have
-- run (see the Initial and Relationship runners) and the MDM batch has
-- applied the staged soft deletes.  Both mappings are idempotent by
-- design (their filters keep only keys matching a still-unprocessed log
-- row), so Complete is the safe re-run point after a failed cycle.
--
-- The IDQ indicator-file command task (touch ${var:sys.WorkflowName}.ind
-- in /opt/apps/informatica/SrcFiles/Indicators) is left to the scheduler,
-- exactly as in the stage-load runners.
--
-- HOW TO RUN IT
--   CALL sp_etl_run_wf_TRS_Deactivation_Complete();
--   (It takes no arguments and returns the combined summary string of
--   both mappings.)
--
-- RESTARTING (mapping level only -- there is no step-level restart)
--   A restart is simply a new run: call the runner again. Each mapping, at its start (step 5), drops any
--   work tables the previous run left in the database, then runs every
--   step from scratch. Work tables are never dropped at the end of a run,
--   and no mapping is ever skipped because it completed in an earlier run.
--
-- RUNNER RETURNS EACH MAPPING'S SUMMARY
--   BARE-BONES CHANGE: the simplified version claimed a CALL's return
--   value could not be assigned to a variable, so the runner returned
--   only a short status line. That claim is out of date: the scalar-call
--   form l_x := (CALL proc(...)) was validated at the ECI step-driver
--   live compile, and it is used here. The runner captures both mapping
--   summaries and returns them together. There is no JOB_CONTROL_ETL in
--   this package, so the returned string is the only record of the run.
--
-- This runner is APP level: it owns the workflow order, but it never
-- writes to a target table itself and never drops a work table.
-- ============================================================================
CREATE OR REPLACE PROCEDURE sp_etl_run_wf_TRS_Deactivation_Complete (
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    l_map        VARCHAR DEFAULT '';
    l_summary    VARCHAR DEFAULT '';
BEGIN
    -- 1. Party mark-processed (driven by the unmerge key table).
    l_map := (CALL sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed());
    l_summary := l_summary || '--- m_Tgt_C_S_TRS_Pty_Deactivation_4_Mark_Processed ---' || CHR(10) || :l_map || CHR(10);

    -- 2. Relationship mark-processed (hub-state verified).
    l_map := (CALL sp_snow_main_m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed());
    l_summary := l_summary || '--- m_Tgt_C_S_TRS_Pty_Rle_Rel_Deactivation_4_Mark_Processed ---' || CHR(10) || :l_map || CHR(10);

    RETURN 'STATUS=COMPLETED MAPPINGS=2.' || CHR(10) || l_summary;
EXCEPTION
    WHEN OTHER THEN
        -- The failing mapping has already raised and left its work tables
        -- in place. The workflow stops here; the next run starts cleanly
        -- from step 5 of each mapping (there is no step-level restart).
        RAISE;
END;
$$;

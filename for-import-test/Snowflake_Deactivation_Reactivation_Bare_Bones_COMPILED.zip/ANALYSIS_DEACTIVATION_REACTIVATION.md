> BARE-BONES NOTE — This document is carried verbatim from the simplified
> deactivation package (Snowflake_Deactivation_Reactivation_Simplified.zip).
> Where it describes checkpoint rows, JOB_CONTROL_ETL, or run ids, it is
> describing that version's implementation. In this bare-bones package all
> of that is removed; the exact deltas are in STRIPPED_NOTES.md. The IDQ
> analysis itself (filters, state machine, verdicts) is unchanged.

# Deactivation and Reactivation — what the source provides vs what the ETL infers

**Scope: strictly deactivation and reactivation.** Stage-load mappings are covered only
where they *are* the deactivation mechanism (the Validation mappings, the TRS capture
mappings, the CRE timeline mapping). No compare tool, no other topic.

**Sources checked, not assumed.** Every condition below was read from one of:

- the four TRS deactivation IDQ exports (`wf_TRS_Deactivation_Initial-2.xml`,
  `wf_TRS_Relationship_Deactivation-2.xml`,
  `wf_TRS_Pty_Rle_Rel_DeActivation_History-2.xml`,
  `wf_TRS_Deactivation_Complete-2.xml`) and the TRS Ongoing export's deactivation
  mappings, as previously documented in `TRS_IDQ_Deactivation_Logic.md`;
- the per-workflow mapping docs in `/tmp/alldocs` (the CDI translations of the IDQ
  mappings for ECI, FSS, WIC, TTF, CRE);
- the Snowflake drop-in originals in `/tmp/allsrc` and the modular rewrites in
  `~/workspace/snowflake_multisource/` (same behaviour on every deactivation point
  below, except where a difference is explicitly called out).

**How to read the verdicts.** "Loads again" means: on a later run, after the
deactivation/reactivation trigger, does the party's row reach a `C_S_*` staging table
again (IDQ) / the corresponding Snowflake target again (rewrites)? The answer is given
separately for IDQ and for Snowflake, because they differ — that difference is the
single most important finding in this document.

---

## 0. The core question, answered in one table

| Source | Deactivation signal: source-supplied or ETL-inferred? | What happens to the record? | Reactivation: does the party load again? |
|---|---|---|---|
| **TRS** | **Source-supplied flags** (`INACTIVE_IND` / `DELETE_SW`) | MDM **unmerge + soft-delete** (`hub_state_ind = -1`); party leaves the valid-member spine | **No — IDQ and Snowflake.** No reactivation path exists in the uploads at all. |
| **ECI** | **Mixed**: ETL-inferred blank name and duplicate case; **source view** for family status (`V_ECI_ETL_LU_FAMILY_VALIDATION`) | **Exclusion** from every later mapping via `STG_ECI_PTY_INACTIVE_STS`. Nothing is deleted from the hub by this mechanism. | **Yes — IDQ. No — Snowflake** (the status-row delete is not performed). |
| **FSS** | **Source-supplied**: `CLIENT_DTL__CAPXACTION = 'D'` and `LAST_INACTV_CLIENT_YN = 'Y'` from `V_FSS_ETL_SRC`, plus ETL-inferred blank name | **Exclusion** via `STG_FSS_PTY_INACTIVE_STS`. Nothing is deleted from the hub by this mechanism. | **No — IDQ and Snowflake.** Reactivation writes a non-null value back into the status table, so the party stays excluded. |
| **WIC** | **Pure ETL interpretation**: blank standardized name only | **Exclusion** via `STG_WIC_PTY_INACTIVE_STS`. Nothing is deleted from the hub by this mechanism. | **Yes — IDQ. No — Snowflake** (the status-row delete is not performed). |
| **TTF** | **Mixed**: ETL-inferred blank/`DECLINED` name, plus **source-supplied** `CLIENT_EXISTS_FLAG = 'N'` from `V_TTF_ETL_SRC` | **Exclusion** via `STG_TTF_PTY_INACTIVE_STS`. Nothing is deleted from the hub by this mechanism. | **Yes — IDQ. No — Snowflake** (the status-row delete is not performed). |
| **CRE** | **Source-supplied maintenance records** (`STG_CRE_D_CARE_CASE_MAINT`, `MAINT_FLAG = 'D'`, `REC` in `CASEMOV`/`CASEDEL`) | **End-dated timeline rows** (`TIMELINE_ACTION = 2`). Never excluded, never deleted. | **Not applicable as a concept** — there is no deactivation/reactivation machinery. A later regular row loads as a new `C_S_*` row in both engines (see §6). |

Two structural facts explain most of the table:

1. **Only TRS ever touches the hub.** TRS is the only source with an unmerge /
   soft-delete path (shell scripts + MDM batch). The four Validation-model sources
   (ECI, FSS, WIC, TTF) never delete or unmerge anything: they write a key into a
   `*_PTY_INACTIVE_STS` table, and every later mapping refuses to load that key.
   A party that was already in the hub and then gets a status row keeps its hub row
   (nothing in the uploads removes it) — it simply stops receiving new `C_S_*` rows.
   Whether anything ever soft-deletes such a party is an open question (§8, Q1).
2. **Re-admission in the Validation model is a delete, not a flag flip.** The only
   thing standing between an excluded party and its next load is the presence of a
   row in the status table. IDQ re-admits a party by *deleting* that row
   (`Upd_Delete_Inactive`, `DD_DELETE`). The Snowflake code — originals and rewrites
   alike — never deletes, so the row, and therefore the exclusion, is permanent in
   Snowflake unless someone deletes the row by hand. FSS is the exception that proves
   the rule: even IDQ does not re-admit, because its reactivation branch writes a
   new non-null row into the status table instead of only deleting the old one.

---

## 1. The shared Validation-model mechanics (ECI, FSS, WIC, TTF)

All four sources run the same pattern. A first mapping, `m_Tgt_C_S_<SRC>_Pty_Validation`,
is the workflow's first step. Its own description (identical in all four docs) is:

> "Check party data to see if it passes criteria to be included in the MDM. If not,
> record keys in a deactivation list that is used as a filter in subsequent jobs.
> Handle reactivations (removal from deactivation list)."

### 1.1 The status table and the H / P / D values

A deactivated party gets one row in `STG_<SRC>_PTY_INACTIVE_STS`
(`SRC_KEY`, `ROWID_SYSTEM`, `DEACTIVATION_STS`, `DEACTIVATION_DT`) and one row in
`STG_<SRC>_PTY_INACTIVE_LOG` (`SRC_KEY`, `ROWID_SYSTEM`, `ACTION`, `ACTION_DT`,
`ACTION = 'Deactivation'`). New status rows are written only when the party has no
status yet (`Filt_new_deactivations`: `IsNull(DEACTIVATION_STS)`).

The status value is derived from the MDM cross-reference `C_B_PTY_XREF` hub state,
identically in all four mappings:

```
IIF(IsNull(HUB_STATE_IND), 'H'
  , IIF(HUB_STATE_IND = -1, 'D'
    , 'P'))
```

Per the mapping headers: `H` = "Records were deactivated at the time of the
historical load so record was never loaded into the MDM"; `P` = "Deactivation is
pending (to be processed)"; `D` = "Deactivated (Hub state ind = -1 in MDM)".
(Correction: the ECI header renders the `D` line as "Hub state ind = 1 in MDM";
the expression in all four mappings tests `HUB_STATE_IND = -1`, and the expression
governs. Treat the ECI header line as a typo.)

Note what `P` does *not* mean in the evidence: no mapping, workflow, or procedure in
the uploads ever reads a `P` row and acts on it. There is no unmerge, no soft-delete,
no "pending queue" consumer for the Validation sources. `P` is a label on an excluded
key, nothing more (§8, Q1).

### 1.2 The downstream filter — identical semantics in all four sources

Every later mapping in the workflow (Party, Address, Alt Id, Phone/EAddr, and
Relationship for both ends) looks the key up in the status table and keeps only rows
with no status. In IDQ form the filter is a lookup followed by a null test, e.g.
ECI Party `Flt_Remove_Inactive`: `IsNull(DEACTIVATION_STS)`; ECI Relationship
`Filter_Fam_Child_Valid`: `isnull(CHILD_DEACTIVATION_STS) and
isnull(FAM_DEACTIVATION_STS1)` — *both* ends of a relationship must be unblocked,
or the relationship row is discarded.

In the Snowflake code the same filter is rendered as `NOT EXISTS` with an explicit
non-null test. ECI Party:

```sql
WHERE NOT EXISTS (SELECT 1 FROM STG_ECI_PTY_INACTIVE_STS i
                  WHERE i.SRC_KEY = e.pkey_src_object AND i.ROWID_SYSTEM = e.src_system
                    AND i.DEACTIVATION_STS IS NOT NULL)
```

FSS Party, WIC Party, TTF Party are the same shape, with their own table, key, and
system literal (`'FSS'`, `'WIC'`, `'TTF'`). The modular rewrites preserve this filter
verbatim (e.g. ECI rewrite `WRK_ECI_PTY_S20_ACTIVE`, FSS rewrite step 10, WIC rewrite
`WRK_WIC_PTY_S10_ACTIVE`, TTF rewrite `WRK_TTF_PTY_S1_ACTIVE`).

**The blocking condition is a non-null *value*, not mere row presence.** A status row
whose `DEACTIVATION_STS` were NULL would not block. No code path writes a NULL status
(all writes are `H`/`P`/`D`, or FSS `'Reactivation'`), so in practice any status row
blocks. This is exactly why the FSS reactivation defect (§4) bites, and why the
missing Snowflake delete (§1.3) is permanent rather than temporary.

### 1.3 The delete that Snowflake does not perform — and its consequence

In IDQ, the Reactivation router group feeds two targets: `Upd_Delete_Inactive`
(update strategy `DD_DELETE`) deleting the status row, and `Exp_Log_Reactv` writing
`ACTION = 'Reactivation'` to the *log* table. The log is audit only; nothing reads it
as a filter. Removing the status row is what re-admits the party.

In the Snowflake originals, every Validation procedure carries the same comment, e.g.
ECI:

> "Not performed: the IDQ DD_DELETE of STG_ECI_PTY_INACTIVE_STS
> (Upd_Delete_Inactive). Insert only."

and, in the procedure body:

> "Rtr_Valid_Party.Reactivation -> Upd_Delete_Inactive (DD_DELETE) ->
> Write_STG_ECI_PTY_INACTIVE_STS. Not performed: the IDQ DD_DELETE of
> STG_ECI_PTY_INACTIVE_STS. This code base never deletes, truncates or drops
> (rows are only inserted)."

The modular rewrites preserve this exactly (each rewrite Validation header states the
reactivation delete "is NOT performed, exactly as in the original"). The reactivation
*log* insert is preserved in ECI, WIC, and TTF rewrites, so a reactivated party gets a
fresh `'Reactivation'` log row every run — while its status row, and therefore its
exclusion, never goes away.

**Consequence, stated plainly per source** (full verdicts in §7):

- ECI, WIC, TTF in Snowflake: a party that is deactivated once is excluded forever
  (short of manual deletion of its status row), even when the source data later
  satisfies the reactivation condition and IDQ would re-admit it. The reactivation
  log rows accumulate as misleading evidence that reactivation "happened".
- FSS in Snowflake: same outcome, but for an additional reason — see §4.
- TRS in Snowflake: a different, larger gap — the whole act/close half of
  deactivation is absent (§2.5).

One more Snowflake subtlety, same in originals and rewrites: the Validation status
lookup picks the *latest* row per key (`QUALIFY ROW_NUMBER() OVER (PARTITION BY
SRC_KEY ... ORDER BY DEACTIVATION_DT DESC NULLS LAST) = 1`), which is what decides
whether the Reactivation group fires. The downstream filter, by contrast, blocks on
*any* non-null row. So in Snowflake a party can simultaneously be "reactivating"
(Validation sees a status, conditions met, logs `'Reactivation'`) and "excluded"
(every downstream mapping still sees the old status row) — every run, indefinitely.

---

## 2. TRS — source flags, hub soft-delete, no reactivation

### (a) What signal triggers deactivation

**Source-supplied flags in TIERS**, read by `m_Tgt_C_S_TRS_Pty_Deactivation_1`
(capture runs inside `wf_TRS_Stage_Load_1_Ongoing`). Its source SQL unions two
individual extracts:

```sql
Select indv_id, inactive_ind, delete_sw, create_dt
from STG_TRS_D_DC_INDV
where inactive_ind = 'Y' or delete_sw = 'Y'

UNION all

Select indv_id, inactive_ind, null , create_dt
from STG_TRS_D_CV_DC_MCI_INDV
where inactive_ind = 'Y'
```

The result is joined to `STG_TRS_VALID_MEMBERS` (only previously-valid members are
captured) and filtered to rows not already logged (`Filt_New_Only`:
`ISNULL(PTY_PK1)` against a lookup on `STG_TRS_DEACTIVED_MEMBERS` — note the table
name is spelled `DEACTIVED` in the database).

Relationships are captured by `m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_1` from
`STG_TRS_D_DC_RELATIONSHIPS_A`, resolving both individuals to party keys through the
valid-member spine (`min_pk` CTE: one key per individual, MCI record preferred),
translating the type through the `PTY_REL` code crosswalk, and checking the MDM
cross-reference `C_B_PTY_RLE_REL_XREF`. Only rows that actually exist in the MDM are
logged (`Fil_New_Deactivations`:
`ISNULL(Lkp_PKEY_SRC_OBJECT) and not ISNULL(ROWID_XREF)`).

### (b) Source-supplied or ETL-inferred

**Source-supplied, end to end.** The party trigger is a flag the source system set
(`INACTIVE_IND`, `DELETE_SW`); the relationship trigger is the presence of the
relationship in the deactivated-relationships delta. The only ETL-derived judgements
are the hub-state derivations on relationships (below), not the trigger itself.

### (c) What happens to the record

**MDM unmerge + soft-delete — the only hub action in the whole package.** In four
stages (full detail in `TRS_IDQ_Deactivation_Logic.md`, §6.3–§6.6):

1. **Capture** (Ongoing load + History workflow). New party rows go to
   `STG_TRS_DEACTIVED_MEMBERS` with `PROCESSED_YN = 'N'`; the same members are
   deleted from the valid-member spine `STG_TRS_VALID_MEMBERS` by an update-strategy
   delete (`Delete_Valid_Stage`, `DD_DELETE`). New relationship rows go to
   `STG_TRS_DEACTIVATED_RELATIONSHIPS` with `PROCESSED_YN = 'N'` — except a
   relationship already soft-deleted in the hub, which is logged directly as `'Y'`
   and never actioned (`PROCESSED_YN = IIF(SOFT_DELETE_YN = 'Y' , 'Y','N')`, where
   `SOFT_DELETE_YN` comes from
   `case when max(HUB_STATE_IND) OVER (PARTITION BY ROWID_OBJECT) = -1 then 'Y'
   else 'N' end` on `C_B_PTY_RLE_REL_XREF`). The capture also derives `MERGE_YN`
   (more than one source key merged into the hub object) and `MASTER_RECORD_YN`.
2. **Copy keys** (`wf_TRS_Deactivation_Initial`, `wf_TRS_Relationship_Deactivation`).
   Party CopyList reads `PROCESSED_YN <> 'Y'`, **capped at `rownum <= 10000`** (see
   §2.4), stamps `SRC_SYS = 'TRS'` (space-padded, as the MDM expects) and
   `EXPLODE_NODE_IND = 1`, and truncate-loads `ZZ_UTL_UNMERGE_TREE_SRC_KEY`.
   Relationship CopyList reads
   `nvl("STG_TRS_DEACTIVATED_RELATIONSHIPS"."PROCESSED_YN",'N') <>'Y' and
   "STG_TRS_DEACTIVATED_RELATIONSHIPS"."ROWID_XREF" is not null`, truncate-loads
   **all** keys to `ZZ_UTL_SOFTDEL_PTY_REL_SRC_KEY` and only merged ones
   (`MERGED_YN = 'Y'`) to `ZZ_UTL_UNMERGE_PTY_REL_ROWID_XREF`. Both workflows gate
   on `$var:TgtRows > 0` — with no copied rows the command step is skipped.
3. **Act** (command tasks — the one black box). `./unmerge_soft_delete_party.sh` /
   `./unmerge_soft_delete_relationship.sh` (working directory
   `/u01/apps/informatica/mdm_exec_batch/scripts`) run the MDM batch-group unmerge
   for the copied keys, then a custom Oracle soft-delete procedure that stages
   `hub_state_ind = -1` records in the MDM staging tables; the MDM batch applies
   them. Hub rows are flagged `-1`, **never physically deleted**. Success (or no
   data) writes the `.ind` indicator file in `/opt/apps/informatica/SrcFiles/Indicators`.
   The scripts are not in the IDQ exports: their internals are not described here
   beyond what the workflow annotations state (§8, Q2).
4. **Close** (`wf_TRS_Deactivation_Complete`, after the MDM batch). Party Mark
   Processed reads keys in `ZZ_UTL_UNMERGE_TREE_SRC_KEY`, matches log rows still at
   `PROCESSED_YN = 'N'` (lookup filter `"STG_TRS_DEACTIVED_MEMBERS"."PROCESSED_YN"
   = 'N'`), and sets `'Y'` via `DD_UPDATE` — **it trusts the key table and does not
   re-verify hub state**. Relationship Mark Processed is stricter: a row is flagged
   only when its cross-reference group proves the soft delete landed, via a lookup
   whose SQL is:

   ```sql
   SELECT /*+ parallel (4) */ T.PKEY_SRC_OBJECT
   FROM C_B_PTY_RLE_REL_XREF T
   WHERE T.ROWID_SYSTEM = 'TRS'
   GROUP BY T.PKEY_SRC_OBJECT
   HAVING MAX(T.HUB_STATE_IND) = -1
   ```

   (its source filter was corrected 2025-09-24 to include rows where
   `PROCESSED_YN` is null). Anything left at `'N'` is retried next cycle by design.

### (d) Reactivation trigger + mechanism + verdict

**There is none.** A search of all four TRS deactivation exports and the Ongoing
deactivation mappings finds zero mentions of reactivation. No mapping deletes a row
from `STG_TRS_DEACTIVED_MEMBERS` or `STG_TRS_DEACTIVATED_RELATIONSHIPS`; Mark
Processed only ever sets `PROCESSED_YN` to `'Y'`. And the Ongoing party mapping's
valid-member snapshot excludes anyone in the log unconditionally:

```sql
SELECT DISTINCT indv_id FROM STG_TRS_VALID_MEMBERS
MINUS
SELECT DISTINCT indv_id FROM STG_TRS_D_DC_INDV WHERE Inactive_ind = 'Y' OR delete_sw = 'Y'
MINUS
SELECT DISTINCT indv_id FROM STG_TRS_D_CV_DC_MCI_INDV WHERE Inactive_ind = 'Y'
MINUS                              -- re-runs and re-activations
SELECT indv_id FROM STG_TRS_DEACTIVED_MEMBERS
```

The comment names re-activations explicitly: a once-logged member stays out of the
valid list even if the TIERS flags later clear.

- **Verdict, IDQ: the party does NOT load again.** Even if `INACTIVE_IND` /
  `DELETE_SW` flip back, the log row and the `MINUS` keep the party out of
  `C_S_TRS_PTY`. Re-admission would require intervention outside the documented
  flows (e.g. removing the log row) — no such step exists in the uploads (§8, Q3).
- **Verdict, Snowflake: the party does NOT load again either — and deactivation
  itself does not complete.** The rewrites contain only the two capture mappings
  (`m_Tgt_C_S_TRS_Pty_Deactivation_1`, `m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_1`).
  The Initial / Relationship / Complete workflows, the CopyLists, the scripts, and
  Mark Processed are **not in the Snowflake package at all** (the only
  `CopyList`/`unmerge` hits in the rewrite tree are comments). Log rows therefore
  accumulate at `PROCESSED_YN = 'N'` forever, no unmerge or soft-delete ever runs,
  and the hub keeps the party. The party is still excluded from the Snowflake party
  load by the same `MINUS STG_TRS_DEACTIVED_MEMBERS` snapshot rule — so the
  *staging* behaviour matches IDQ, but the *hub* behaviour does not happen at all.

### 2.1 The History workflow's role

`wf_TRS_Pty_Rle_Rel_DeActivation_History` is capture-only: a single mapping task,
`m_Tgt_C_S_TRS_Pty_Rle_Rel_DeActivation_History_Audit`, running the same capture
pattern over the history extract `STG_TRS_H_DC_RELATIONSHIPS_A` into the same
relationship log `STG_TRS_DEACTIVATED_RELATIONSHIPS`. No gateway, no command, no
indicator file. Its rows then flow through the normal Relationship / Complete path.
It adds no new mechanism; it extends capture to history/audit relationships so they
are deactivated in step with current ones.

### 2.2 The 10,000-row CopyList cap (carried item)

Only the **party** CopyList is capped: `"STG_TRS_DEACTIVED_MEMBERS"."PROCESSED_YN"
<> 'Y' and rownum <= 10000`. The designer note ties the cap to the old 30-minute
web-service unmerge timeout ("10k Rows typically unmerge in 15 min"). The
relationship CopyList has no `rownum` cap. Since 2025-09-02 the unmerge runs as a
command task, not a web-service call, so the cap's rationale may be stale — but the
cap itself is still in the export, so a backlog over 10,000 party deactivations still
drains at most 10k per cycle. Confirm whether the cap is still wanted (§8, Q4).

### 2.3 D1 — the party-spine delete (carried item, refined)

IDQ's `Delete_Valid_Stage` (`DD_DELETE`) removes deactivated members from the
`STG_TRS_VALID_MEMBERS` *table*. The Snowflake originals and the rewrite do **not**
perform it; the rewrite makes it an explicit, checkpointed no-op step (step 50,
`DELETE_VALID_STAGE_NOT_PERFORMED`):

> "IDQ DD_DELETE of STG_TRS_VALID_MEMBERS deliberately NOT performed: insert-only
> Snowflake rule. Deactivated members remain in the valid-member list."

The consequence is narrower than "everything downstream breaks", and it matters to
state it precisely:

- **Party `C_S` load: protected anyway.** The Ongoing snapshot `MINUS`es both
  today's inactivations and anyone in the deactivation log, so a deactivated member
  is excluded from `C_S_TRS_PTY` / `C_S_TRS_PTY_RLE` in Snowflake just as in IDQ —
  provided the log row exists (i.e. provided the capture mapping ran).
- **Spine-table joins: NOT protected.** Any downstream mapping that joins
  `STG_TRS_VALID_MEMBERS` directly — the relationship capture's `min_pk` resolution
  is the documented example — still sees the deactivated member in Snowflake,
  because the stale row was never removed. That is the real parity gap: it is about
  key resolution for *other* records, not about the deactivated party's own load.

### 2.4 D3 — PROCESSED_YN left to the column default (carried item)

In the relationship capture rewrite, `PROCESSED_YN` is **not in the INSERT column
list** — it is left to the target column's default, whereas IDQ sets it explicitly
(`'Y'` for already-soft-deleted rows, `'N'` otherwise). The party capture rewrite
does set `'N'` explicitly. The consequence depends on the actual default of
`STG_TRS_DEACTIVATED_RELATIONSHIPS.PROCESSED_YN`, which is **not in the uploads**:

- If the default is `'N'`, behaviour matches IDQ except that already-soft-deleted
  rows lose their `'Y'` shortcut (they would be picked up by the relationship
  CopyList's `nvl(PROCESSED_YN,'N') <> 'Y'` filter and re-actioned, though the hub
  check in Mark Processed would still close them).
- If the default is NULL, the relationship CopyList still picks the rows up (its
  filter uses `nvl`), but any consumer testing `PROCESSED_YN = 'N'` exactly would
  miss them.

Confirm the column default before relying on the relationship log (§8, Q5).

---

## 3. ECI — mixed signals, exclusion, and the only full reactivation path

### (a) What signal triggers deactivation

`m_Tgt_C_S_ECI_Pty_Validation` reads `STG_ECI_D_CHILD` UNION ALL `STG_ECI_D_FAMILY`
(`SOURCE_TABLE` = `'ECI_CHILD'` / `'ECI_FAMILY'`; party key
`LPAD(ID,10,'0') || IIF(SOURCE_TABLE = 'ECI_FAMILY', 'F','')`). Names are
standardized first (`mplt_Name_Standardization_Indv_Member`, which per the 2024-10-17
note "changes malformed names to null, before the check for null names"), then the
router `Rtr_Valid_Party` fires:

- `Invalid_Party_Name`:
  `(Length(Rtrim(FIRST_NAME))=0 OR Length(Rtrim(LAST_NAME))=0 OR IsNULL(FIRST_NAME)
  OR IsNULL(LAST_NAME) ) AND FAM_INACTIVE_YN = 'N'` → `EXC_STG_BAD_REC_MEMB`
  (a row goes to every group whose condition is true, so these rows are *also*
  Deactivation rows).
- `Deactivation`:
  `Length(Rtrim(FIRST_NAME))=0 OR Length(Rtrim(LAST_NAME))=0 OR IsNULL(FIRST_NAME)
  OR IsNULL(LAST_NAME) OR NOT IsNull(OMIT_ID) OR FAM_INACTIVE_YN = 'Y'`
  → `STG_ECI_PTY_INACTIVE_STS` (new rows only) + `STG_ECI_PTY_INACTIVE_LOG`
  (`'Deactivation'`).

### (b) Source-supplied or ETL-inferred — mixed, and one correction to the starting evidence

- **ETL-inferred:** blank standardized first or last name.
- **ETL-inferred via a source view:** duplicate case — `OMIT_ID` is the `ID` returned
  by `Lookup_V_ECI_ETL_LU_DUP_CASES` on view `V_ECI_ETL_LU_DUP_CASES`
  (`SOURCE_TABLE = SOURCE_TABLE1 AND ID = ID1`). The view's own definition is not in
  the uploads; what it counts as a "duplicate case" is therefore not verifiable here
  (§8, Q6). (Per the 2025-01-10 note, the lookup was changed to "a view that
  includes family IDs".)
- **Source view, but broader than the starting evidence said:** family status comes
  from `Lookup_V_ECI_ETL_LU_FAMILY_VALIDATION` on view
  `V_ECI_ETL_LU_FAMILY_VALIDATION`
  (`SOURCE_TABLE = SOURCE_TABLE1 AND ID_FAMILY = ID`), returning `FAM_NAME_STATUS`,
  `FAM_PHONE_AND_ADDRESS_STS`, and `FAM_INACTIVE_STS`. The router does **not** test
  the inactive column alone; it tests the derived flag:

  ```
  FAM_INACTIVE_YN = IIF(ISNULL(FAM_NAME_STATUS) and ISNULL(FAM_PHONE_AND_ADDRESS_STS)
                        and ISNULL(FAM_INACTIVE_STATUS), 'N','Y')
  ```

  So a family counts as "inactive" for routing if **any** of the three view columns
  is non-null — a family name problem or a phone/address problem alone is enough to
  deactivate the party, not just a family inactive status. The view definition itself
  is not in the uploads, so what each column means beyond its name is unverified
  (§8, Q6). This corrects the starting shorthand "family inactive via
  FAM_INACTIVE_STS".

### (c) What happens to the record

**Exclusion from later mappings** via `STG_ECI_PTY_INACTIVE_STS` (§1.2). Every later
ECI mapping applies it: Party (`Flt_Remove_Inactive`), Address (`Fil_Inactive_recs`),
Alt Id (`Filter`), Phone/EAddr (`fil_deactivated_status`), Relationship
(`Filter_Fam_Child_Valid`, both ends). No hub delete, no unmerge, no end-dating.
A deactivated ECI party that was already in the hub keeps its hub row as far as the
uploads show; it just stops receiving new `C_S_ECI_*` rows.

### (d) Reactivation trigger + mechanism + verdict

**Trigger** (`Reactivation` group):
`NOT IsNull(DEACTIVATION_STS) and Length(Rtrim(FIRST_NAME))>0 and
Length(Rtrim(LAST_NAME))>0 and IsNull(OMIT_ID) and FAM_INACTIVE_YN='N'` — i.e. the
party has a status, both standardized names are present, it is no longer a duplicate
case, and the family is active on all three view columns.

**Mechanism, IDQ (two parts):**

1. Party-level: `Upd_Delete_Inactive` (`DD_DELETE`) deletes the status row, and
   `Exp_Log_Reactv` writes `'Reactivation'` to `STG_ECI_PTY_INACTIVE_LOG`. The
   next run's downstream `NOT EXISTS` filters then pass, and the party loads again.
2. Dependant-history moves (three mappings, running in parallel with the Party
   mapping after Validation in the IDQ taskflow): they move the latest history row
   of each dependant record of a reactivated party back into the delta tables, "to
   enable the creation of hub state 1 records for reactivation of these dependant
   tables":
   - `m_Tgt_Stg_ECI_Pty_Reactivation_D_Family_Addr`: `STG_ECI_H_FAMILY_ADDRESS` →
     `STG_ECI_D_FAMILY_ADDRESS`, latest `LOAD_DATE` per `ID_FAMILY_ADDRESS` where
     `ID_FAMILY in (select ID from V_ECI_ETL_LU_REACTIVATED_ID where ID_TYPE =
     'ID_FAMILY')`, keeping only rows not already in the delta
     (`IsNull(LKP_ID_FAMILY_ADDRESS)`).
   - `m_Tgt_Stg_ECI_Pty_Reactivation_D_Family_Phn`: same pattern,
     `STG_ECI_H_FAMILY_PHONE` → `STG_ECI_D_FAMILY_PHONE`, `ID_TYPE = 'ID_FAMILY'`.
   - `m_Tgt_Stg_ECI_Pty_Reactivation_D_Medicaid`: `STG_ECI_H_MEDICAID` →
     `STG_ECI_D_MEDICAID`, latest `LOAD_DATE` per `ID_MEDICAID` via
     `STG_ECI_SN_CASE`, where `ID_CHILD in (select ID from
     V_ECI_ETL_LU_REACTIVATED_ID where ID_TYPE = 'ID_CHILD')` — **but as coded it
     writes no rows**: its filter tests the *source* port (`IsNull(ID_MEDICAID)`,
     a history key that is never NULL) instead of the lookup result
     (`lkp_ID_MEDICAID`), unlike its two sister mappings. The Snowflake rewrite
     preserves this with a `P_TEST_LOOKUP_RESULT` parameter (default `'N'` = as
     coded, writes nothing; `'Y'` = test the lookup result, as the sisters do).

**`V_ECI_ETL_LU_REACTIVATED_ID` — what is known and what is not.** The view's
definition is **not in the uploads**. What the three mapping docs and three
procedures show is only its interface: columns `ID` and `ID_TYPE`, with
`ID_TYPE = 'ID_FAMILY'` selecting reactivated families and `ID_TYPE = 'ID_CHILD'`
selecting reactivated children, and its use as the driver of the three history
moves. Whether it is derived from the reactivation log, from the status-table
delete, from a source flag, or from something else is **unknown and must not be
guessed** (§8, Q7). Note the consequence: the history moves cannot be reasoned about
end-to-end until that view is supplied, because the set of "reactivated" IDs is
exactly what it returns.

- **Verdict, IDQ: YES — the party loads again**, and (for family address/phone)
  its dependant history rows are re-seeded into the delta tables for re-load.
  Medicaid dependants do **not** re-seed as coded (see the defect above).
- **Verdict, Snowflake: NO — the party does not load again.** The Validation
  delete is not performed (§1.3), so the status row survives, every downstream
  `NOT EXISTS ... DEACTIVATION_STS IS NOT NULL` filter keeps blocking, and the
  `'Reactivation'` log rows accumulate without effect. The three history-move
  procedures are present in the rewrite (Medicaid with the same default-`'N'`
  defect), and the rewrite runner calls them — but *after* the Party mapping,
  whereas IDQ runs them in parallel with it — and their delta rows still face the
  same status filter in every downstream mapping, so they do not produce `C_S_*`
  re-loads either. The only fix within this design is deleting the status row
  (manually, or by restoring the delete step as a business decision).

---

## 4. FSS — source-supplied delete/inactive flags, exclusion, and a reactivation that never re-admits

### (a) What signal triggers deactivation

`m_Tgt_C_S_FSS_Pty_Validation` reads the view **`V_FSS_ETL_SRC`** (the view's own
definition is outside the export and is not in the uploads) with the source filter:

```sql
("V_FSS_ETL_SRC"."LAST_ACTIVE_CLIENT_REGISTRATION_YN" = 'Y'
OR "V_FSS_ETL_SRC"."LAST_INACTV_CLIENT_YN" = 'Y')
```

i.e. the Validation mapping sees both last-active registrations and rows marking
all registrations inactive. (The downstream Party mapping reads the same view with
the narrower filter `"V_FSS_ETL_SRC"."LAST_ACTIVE_CLIENT_REGISTRATION_YN"='Y'`.)
The router:

- `Invalid_Party_Name`: blank standardized first or last name →
  `EXC_STG_BAD_REC_MEMB`.
- `Deactivation`:
  `Length(Rtrim(FIRST_NAME))=0 OR Length(Rtrim(LAST_NAME))=0 OR
  IsNULL(FIRST_NAME) OR IsNULL(LAST_NAME) OR CLIENT_DTL__CAPXACTION = 'D' OR
  LAST_INACTV_CLIENT_YN = 'Y'` → `STG_FSS_PTY_INACTIVE_LOG` (`'Deactivation'`) +
  `STG_FSS_PTY_INACTIVE_STS` (new rows only, `H`/`P`/`D` per §1.1).

### (b) Source-supplied or ETL-inferred

**Mostly source-supplied.** `CLIENT_DTL__CAPXACTION = 'D'` is a source capture-action
(delete) carried on the view row, and `LAST_INACTV_CLIENT_YN = 'Y'` is a source
all-registrations-inactive flag carried on the view row. The blank-name arm is
ETL-inferred (standardized name, same mapplet as the other sources). This confirms
the starting evidence, with the source view pinned down as `V_FSS_ETL_SRC`.

### (c) What happens to the record

**Exclusion** via `STG_FSS_PTY_INACTIVE_STS` (§1.2), applied by Party
(`Flt_Remove_Inactive`), Address (`Fil_Inactive_recs`), Alt Id (`Filter`),
Phone/EAddr (`fil_deactivated_status`), and Relationship (`Filter_Fam_Child_Valid`,
both ends). No hub delete, no unmerge, no end-dating.

### (d) Reactivation trigger + mechanism + verdict

**Trigger** (`Reactivation` group):
`NOT IsNull(DEACTIVATION_STS) and Length(Rtrim(FIRST_NAME))>0 and
Length(Rtrim(LAST_NAME))>0 and CLIENT_DTL__CAPXACTION <> 'D' and
LAST_INACTV_CLIENT_YN <> 'Y'` — has a status, names present, not deleted, not
all-inactive. (NULL action/flag does not satisfy `<> 'D'` / `<> 'Y'`, so a NULL is
not a reactivation in either engine.)

**Mechanism — the defect, stated exactly.** In IDQ the Reactivation group feeds
*two* status-table targets: `Upd_Delete_Inactive` (`DD_DELETE`) deleting the old
status row, **and** `Exp_Log_Reactv` — which, unlike every other source, is linked
to the **status** table, not the log table. `Write_STG_FSS_PTY_INACTIVE_STS` (the
first of the three STS targets) is an Insert whose links are
`DEACTIVATION_STS ← Exp_Log_Reactv.ACTION` (`'Reactivation'`) and
`DEACTIVATION_DT ← Exp_Log_Reactv.ACTION_DT`. So IDQ deletes the old row and
immediately inserts a new row with `DEACTIVATION_STS = 'Reactivation'`. There is
no reactivation write to `STG_FSS_PTY_INACTIVE_LOG` at all (that log receives only
`'Deactivation'` rows, from `Exp_Log_Deactv`).

Because the downstream filter blocks on any non-null status value (§1.2), the new
`'Reactivation'` row blocks exactly as thoroughly as the old `H`/`P`/`D` row did.
The Oracle drop-in summary says it plainly: "Because later mappings skip any key
with a non-null status, a reactivated FSS client stays excluded - confirm with the
business."

- **Verdict, IDQ: NO — the party does not load again.** This is not a Snowflake
  divergence; IDQ itself never re-admits an FSS client. The delete-then-reinsert
  means the exclusion survives reactivation in the source engine too.
- **Verdict, Snowflake: NO — the party does not load again**, for two stacked
  reasons: the delete is not performed (§1.3) *and* the `'Reactivation'` insert
  into `STG_FSS_PTY_INACTIVE_STS` is preserved verbatim in the original and in the
  rewrite (rewrite step 50d, "Reactivation -> STG_FSS_PTY_INACTIVE_STS").
  Each reactivation run therefore adds another non-null status row. Fixing only the
  missing delete would not fix FSS; the reactivation target itself must change
  (status row deleted and nothing re-inserted, with the `'Reactivation'` event
  written to the log table like the other sources) — a business decision, flagged
  in §8, Q8.

---

## 5. WIC — pure ETL interpretation, exclusion, clean reactivation in IDQ only

### (a) What signal triggers deactivation

`m_Tgt_C_S_WIC_Pty_Validation` reads the view `V_WIC_ETL_SRC` (definition outside
the export, not in the uploads). The router has exactly one deactivation condition:

- `Deactivation`:
  `Length(Rtrim(FIRST_NAME))=0 OR Length(Rtrim(LAST_NAME))=0 OR
  IsNULL(FIRST_NAME) OR IsNULL(LAST_NAME)` → `STG_WIC_PTY_INACTIVE_LOG`
  (`'Deactivation'`) + `STG_WIC_PTY_INACTIVE_STS` (new rows only).
- `Invalid_Party_Name` is the same blank-name condition → `EXC_STG_BAD_REC_MEMB`.

### (b) Source-supplied or ETL-inferred

**Pure ETL interpretation.** No source flag, status column, or exists-flag
participates. A WIC party is "deactivated" if and only if its standardized first or
last name is blank (or null) after `mplt_Name_Standardization_Indv_Member`. That
means data-quality failures (unparseable / junk / missing names) are indistinguishable
from genuine deactivations in the WIC stream: there is no source-supplied signal to
tell them apart, and no source-supplied signal ever *un*-deactivates a party except
by the name becoming present again.

### (c) What happens to the record

**Exclusion** via `STG_WIC_PTY_INACTIVE_STS` (§1.2), applied by Party
(`Flt_Remove_Inactive`), Address (`Fil_Inactive_recs`), Alt Id (`Filter`), and
Phone/EAddr (`fil_deactivated_status`). (WIC has no Relationship mapping in the
uploads.) No hub delete, no unmerge, no end-dating.

### (d) Reactivation trigger + mechanism + verdict

**Trigger** (`Reactivation` group):
`NOT IsNull(DEACTIVATION_STS) and Length(Rtrim(FIRST_NAME))>0 and
Length(Rtrim(LAST_NAME))>0` — has a status and both standardized names are now
present. Nothing else is required.

**Mechanism, IDQ:** `Upd_Delete_Inactive` (`DD_DELETE`) deletes the status row and
`Exp_Log_Reactv` writes `'Reactivation'` to `STG_WIC_PTY_INACTIVE_LOG` (the log
table, correctly, unlike FSS). Next run, the downstream filters pass.

- **Verdict, IDQ: YES — the party loads again** as soon as a present name appears
  in the source view.
- **Verdict, Snowflake: NO — the party does not load again.** The delete is not
  performed (§1.3); the rewrite preserves the log-only reactivation insert
  (step 40d, "Reactivation -> STG_WIC_PTY_INACTIVE_LOG") and the
  `NOT EXISTS ... DEACTIVATION_STS IS NOT NULL` downstream filters, so the original
  status row blocks every later mapping indefinitely. The starting shorthand
  "reactivation = log only" is the *Snowflake* behaviour; in IDQ it is log **plus
  delete**, and the delete is the part that matters.

---

## 6. TTF — blank/declined names plus a source exists-flag, exclusion, clean reactivation in IDQ only

### (a) What signal triggers deactivation

`m_Tgt_C_S_TTF_Pty_Validation` reads the view `V_TTF_ETL_SRC` (definition outside
the export, not in the uploads; the stored FYCLIENTS_ID list in the mapping text is
a WHERE fragment in non-custom-query mode and is documented as looking unused).
Party key is `LPAD(CLIENTS_ID, 10, '0')` (from `CLIENTS_ID` via `ID`). Names are
standardized with `CopyOf_mplt_Name_Standardization_Indv_Member`. The router:

- `Invalid_Party_Name`:
  `(Length(Rtrim(FIRST_NAME))=0 OR Length(Rtrim(LAST_NAME))=0 OR
  IsNULL(FIRST_NAME) OR IsNULL(LAST_NAME) OR IN(UPPER(LAST_NAME),'DECLINED') OR
  IN(UPPER(FIRST_NAME),'DECLINED') OR IN(UPPER(LAST_NAME),'DO_NOT_DISCLOSE') OR
  IN(UPPER(FIRST_NAME),'DO_NOT_DISCLOSE') )` → `EXC_STG_BAD_REC_MEMB`.
- `Deactivation`:
  `Length(Rtrim(FIRST_NAME))=0 OR Length(Rtrim(LAST_NAME))=0 OR
  IsNULL(FIRST_NAME) OR IsNULL(LAST_NAME) OR IN(UPPER(LAST_NAME),'DECLINED') OR
  IN(UPPER(FIRST_NAME),'DECLINED') OR CLIENT_EXISTS_FLAG='N'`
  → `STG_TTF_PTY_INACTIVE_LOG` (`'Deactivation'`) + `STG_TTF_PTY_INACTIVE_STS`
  (new rows only).

Note the deliberate asymmetry: `DO_NOT_DISCLOSE` is an invalid name (exception row)
but **not** a deactivation — a `DO_NOT_DISCLOSE` party with no other trigger is
logged as bad data and is not excluded by the status table.

### (b) Source-supplied or ETL-inferred — mixed

- **ETL-inferred:** blank standardized name, and the literal placeholder
  `'DECLINED'` (any case) in first or last name.
- **Source-supplied:** `CLIENT_EXISTS_FLAG = 'N'`, a column read from
  `V_TTF_ETL_SRC` by `Read_V_TTF_ETL_SRC`. This confirms the starting evidence,
  with the source pinned down: the flag comes from the source view, not from any
  ETL derivation. What sets the flag in the source system is not in the uploads
  (§8, Q9).

### (c) What happens to the record

**Exclusion** via `STG_TTF_PTY_INACTIVE_STS` (§1.2), applied by Party
(`Flt_Remove_Inactive`), Alt Id (`Filter`), and Phone (`fil_deactivated_status`).
(TTF has no Address or Relationship mapping in the uploads.) No hub delete, no
unmerge, no end-dating.

### (d) Reactivation trigger + mechanism + verdict

**Trigger** (`Reactivation` group):
`NOT IsNull(DEACTIVATION_STS) and Length(Rtrim(FIRST_NAME))>0 and
Length(Rtrim(LAST_NAME))>0 and NOT IN(UPPER(LAST_NAME),'DECLINED') and NOT
IN(UPPER(FIRST_NAME),'DECLINED') and CLIENT_EXISTS_FLAG = 'Y'` — has a status,
names present and not `'DECLINED'`, and the source flag back to `'Y'`.

**Mechanism, IDQ:** `Upd_Delete_Inactive` (`DD_DELETE`) deletes the status row and
`Exp_Log_Reactv` writes `'Reactivation'` to `STG_TTF_PTY_INACTIVE_LOG`. Next run,
the downstream filters pass.

- **Verdict, IDQ: YES — the party loads again** when names are present/not
  declined and `CLIENT_EXISTS_FLAG` returns to `'Y'`.
- **Verdict, Snowflake: NO — the party does not load again.** The delete is not
  performed (§1.3); the rewrite preserves the log-only reactivation insert and the
  downstream `NOT EXISTS` filters, so the status row blocks indefinitely — same
  shape as WIC (§5).

---

## 7. CRE — source maintenance records, end-dated rows, no deactivation concept

### (a) What signal triggers deactivation

There is no deactivation trigger, because CRE has no deactivation step. What it has
is **source-supplied case maintenance**: the single mapping
`m_Tgt_C_S_CRE_CARE_Clients` reads a three-branch union over the snapshot
`STG_CRE_SN_CARE_CLIENTS`, the delta `STG_CRE_D_CARE_CLIENTS`, and the maintenance
table `STG_CRE_D_CARE_CASE_MAINT`:

```sql
-- Branch 1: regular rows
SELECT ... , 'I' AS REC_TYPE
FROM STG_CRE_D_CARE_CLIENTS CLIENTS
WHERE CLIENTS.MAINT_FLAG IS NULL

UNION ALL

-- Branch 2: deleted / moved sources
SELECT ... , DECODE(MAINT.REC, 'CASEMOV', 'B', 'D')
FROM STG_CRE_D_CARE_CLIENTS DELTAS
LEFT JOIN STG_CRE_SN_CARE_CLIENTS CLIENTS
  ON DELTAS.CARE_ID = CLIENTS.CARE_ID
JOIN STG_CRE_D_CARE_CASE_MAINT MAINT
  ON CLIENTS.CARE_ID = MAINT.SOURCE_ID
 AND DELTAS.MAINT_FLAG = 'D'
 AND MAINT.REC IN ('CASEMOV', 'CASEDEL')

UNION ALL

-- Branch 3: move targets
SELECT ... , 'A' AS REC_TYPE
FROM STG_CRE_SN_CARE_CLIENTS CLIENTS
JOIN STG_CRE_D_CARE_CASE_MAINT MAINT
  ON CLIENTS.CARE_ID = MAINT.TARGET_ID
 AND MAINT.REC = 'CASEMOV'
```

This confirms the starting evidence and refines it: the maintenance join requires
`MAINT_FLAG = 'D'` **and** `REC IN ('CASEMOV', 'CASEDEL')`, and the resulting
`REC_TYPE` distinguishes a move source (`'B'`, from `CASEMOV`) from a delete source
(`'D'`, from `CASEDEL`). The move *target* (`'A'`, third branch) is a separate row,
not an end-dating.

### (b) Source-supplied or ETL-inferred

**Source-supplied.** The maintenance records (`CASEDEL` / `CASEMOV`) are source
data; the ETL only decodes them (`DECODE(MAINT.REC, 'CASEMOV', 'B', 'D')`) and
applies the timeline arithmetic. (Do not confuse this with the router group named
`DELETES` — `ISNULL(MAINT_FLAG) OR (MAINT_FLAG = 'D' AND REC = 'CASEDEL')` — which
is broader than end-dating: it also routes ordinary `MAINT_FLAG IS NULL` rows.
End-dating itself is driven by `REC_TYPE`, below.)

### (c) What happens to the record

**End-dated timeline rows — written, not excluded, not deleted.** Rows with
`REC_TYPE IN ('B', 'D')` are flagged `end_dated` and written to the `C_S_CRE_*`
targets with:

```
PERIOD_START_DATE = CARE_LASTUP_DT - 1 day
PERIOD_END_DATE   = CARE_LASTUP_DT
TIMELINE_ACTION   = 2
PERIOD_REFERENCE_TIME = PERIOD_START_DATE
LAST_UPDATE_DATE  = run start - 1 hour
```

(The party row's period-end / reference-time handling differs slightly from the
role's — the header notes the role keeps the run start — and the role and alternate
ids carry `TIMELINE_ACTION` / `PERIOD_REFERENCE_TIME` as NULL. Those are
presentation details, not a different outcome: the row is loaded with a closed
period.) A CRE client is therefore never filtered out of a load and never removed
from a staging table by this mechanism; its history is closed by a new row with a
bounded period. The Snowflake original and rewrite preserve this exactly, except
that IDQ's "truncate target table" of `CRE_SRC_MRG` and the `C_S_CRE_*` targets is
not performed in Snowflake (insert-only), so repeated runs append rather than
replace — a general insert-only note, not a deactivation difference.

### (d) Reactivation trigger + mechanism + verdict

**There is no reactivation trigger, mechanism, or status table in the CRE uploads**
(no `*_PTY_INACTIVE_STS`, no reactivation mapping, no reactivation mention
anywhere in the CRE docs). The closest thing to "coming back" is an ordinary
branch-1 row: a `CARE_ID` whose `MAINT_FLAG` is NULL loads as `REC_TYPE 'I'`
(a fresh `C_S_CRE_*` row, one row per `CARE_ID` after the `REC_TYPE` descending
ranking).

- **Verdict, IDQ: the party loads again in the narrow, literal sense** — a later
  regular row writes new `C_S_CRE_*` rows. But the uploads do **not** show the MDM
  treating that row as a reactivation of the end-dated row (no un-end-dating, no
  hub-state flip is described anywhere in the CRE material). Whether the MDM batch
  re-opens the timeline or simply adds a new version is not evidenced here
  (§8, Q10).
- **Verdict, Snowflake: same as IDQ** on this point — the end-dating arithmetic and
  the regular-row load are both preserved, and there is no status table whose
  missing delete could block re-load. CRE is the only source whose re-load story
  does not change between engines.

---

## 8. Re-admission verdicts, side by side

"Loads again" = the party's row reaches `C_S_*` again on a later run after the
reactivation condition is met. (For TRS, "loads again" is additionally about the hub:
see the TRS row note.)

| Source | IDQ: loads again? | Snowflake (originals + rewrites): loads again? | Why the engines differ (or do not) |
|---|---|---|---|
| TRS (party) | **No** | **No** — and hub deactivation never runs | No reactivation path in either engine; log row + `MINUS` block re-load in both. Snowflake additionally lacks CopyList / scripts / Mark Processed, so the hub soft-delete never happens. |
| TRS (relationship) | **No** (no reactivation path; log never cleared) | **No** (capture only; `PROCESSED_YN` left to column default — §2.4) | Same as party, plus the D3 default question. |
| ECI | **Yes** (party + family Addr/Phn history re-seed; Medicaid re-seed broken as coded) | **No** | Status-row `DD_DELETE` not performed; downstream `NOT EXISTS` keeps blocking. |
| FSS | **No** | **No** | Reactivation re-inserts non-null `'Reactivation'` into the status table in both engines; Snowflake additionally skips the delete. |
| WIC | **Yes** | **No** | Status-row `DD_DELETE` not performed; log-only reactivation has no effect on the filter. |
| TTF | **Yes** | **No** | Same as WIC. |
| CRE | **Yes, narrowly** (a new regular row loads; not a "reactivation" in the hub sense) | **Yes, narrowly** (same) | No status table, no delete to miss. Only the truncate-vs-append difference, which does not change this verdict. |

The pattern to carry forward: **every Validation-model re-admission in IDQ is a
delete; every Snowflake divergence in this document is that delete (or, for FSS,
the reactivation target) not being reproduced.** Any Snowflake reactivation fix must
restore the delete — it cannot be fixed by writing more log rows.

---

## 9. Open questions — flagged, not answered

1. **Does anything ever soft-delete a previously-loaded Validation-model party?**
   No workflow, mapping, or procedure in the uploads reads a `P` (pending) status
   row and acts on it. If a party is already in the hub and later gets a status row,
   the uploads show only that new `C_S_*` rows stop. Confirm whether a hub
   soft-delete for these sources exists elsewhere, or whether "pending" parties
   simply linger in the hub.
2. **What do the TRS scripts actually do?** `unmerge_soft_delete_party.sh` and
   `unmerge_soft_delete_relationship.sh` plus the custom Oracle soft-delete
   procedure are outside the exports. Only the workflow annotations are known:
   MDM batch-group unmerge of the copied keys, then staging `hub_state_ind = -1`
   records, applied by normal MDM batch processing, with a `.ind` indicator file
   on success or no-data. Version and review the scripts themselves; do not infer
   their internals (e.g. ordering, error handling, which child tables are staged).
3. **Is there a TRS re-admission path at all?** No reactivation step exists in the
   TRS uploads, and the Ongoing `MINUS` explicitly covers "re-runs and
   re-activations". If a TIERS member's flags clear, is the intended behaviour
   permanent exclusion, manual log removal, or something else? Unanswered in the
   evidence.
4. **Is the 10,000-row party CopyList cap still wanted?** Its documented rationale
   (30-minute web-service unmerge timeout) predates the 2025-09-02 change to a
   command task. The cap is still in the export; a backlog over 10k still drains at
   most 10k per cycle. Confirm, and confirm backlog behaviour.
5. **What is the column default of `STG_TRS_DEACTIVATED_RELATIONSHIPS.PROCESSED_YN`?**
   The relationship capture rewrite leaves it to the default (§2.4). The default
   value is not in the uploads, and the two candidate values (`'N'` vs NULL) have
   different consequences for CopyList pickup and for exact-`'N'` consumers.
6. **What do the ECI source views actually compute?** `V_ECI_ETL_LU_DUP_CASES`
   (what counts as a duplicate case), `V_ECI_ETL_LU_FAMILY_VALIDATION` (what each
   of `FAM_NAME_STATUS`, `FAM_PHONE_AND_ADDRESS_STS`, `FAM_INACTIVE_STS` means),
   and the FSS/WIC/TTF source views `V_FSS_ETL_SRC`, `V_WIC_ETL_SRC`,
   `V_TTF_ETL_SRC` (including how `CLIENT_EXISTS_FLAG`, `CLIENT_DTL__CAPXACTION`,
   and `LAST_INACTV_CLIENT_YN` are derived) are all outside the exports. Their
   definitions are needed before any of these triggers can be validated against
   source-system behaviour.
7. **`V_ECI_ETL_LU_REACTIVATED_ID` is undefined in the uploads.** Only its
   interface is known (`ID`, `ID_TYPE` ∈ `'ID_FAMILY'` / `'ID_CHILD'`). What
   populates it — the reactivation log, the status delete, a source flag, or
   something else — and when it is refreshed relative to Validation, is unknown.
   The ECI history-move story cannot be closed without it.
8. **FSS reactivation target: defect or intent?** The IDQ wiring sends the
   reactivation event to the status table (`DEACTIVATION_STS = 'Reactivation'`)
   instead of the log table, which permanently excludes the reactivated client in
   both engines. Confirm with the business whether this is a known defect to fix
   (delete + log, like the other sources) or intended behaviour.
9. **What sets TTF `CLIENT_EXISTS_FLAG`?** The flag is read from `V_TTF_ETL_SRC`
   but its source-system derivation is not in the uploads. In particular, whether
   `'N'` means "client left the program", "client record deleted", or something
   narrower affects how the TTF deactivation signal should be interpreted.
10. **Does the MDM treat a later CRE regular row as a reactivation?** The CRE
    mapping writes an end-dated row (`TIMELINE_ACTION = 2`) and, later, a regular
    row (`'I'`) for the same `CARE_ID`, but nothing in the uploads describes the
    hub-side effect (timeline re-opened vs new version appended). Confirm with the
    MDM batch behaviour, not the staging mapping alone.
11. **Party vs relationship close-out asymmetry (TRS).** Only the relationship
    Mark Processed verifies hub state (`MAX(HUB_STATE_IND) = -1`); the party
    mapping trusts the copied key table. A party key that failed to unmerge could
    therefore be marked processed. Confirm this is intentional (carried from the
    prior TRS analysis; unchanged by this package).
12. **Re-run hazard (TRS).** Per the workflows' own annotations, re-running
    Initial/Relationship after a partial failure re-populates the MDM staging
    tables and can fail on duplicate keys if soft-delete rows were already staged.
    Recovery sequencing (Complete/clean-up first, not blind restart) is a runbook
    matter, not visible in the exports.

---

## Appendix: evidence map (where each claim was read)

| Claim | Read from |
|---|---|
| TRS capture SQL, spine delete, CopyList filters/cap, script names, indicator file, Mark Processed asymmetry | `wf_TRS_Deactivation_Initial-2.xml`, `wf_TRS_Relationship_Deactivation-2.xml`, `wf_TRS_Pty_Rle_Rel_DeActivation_History-2.xml`, `wf_TRS_Deactivation_Complete-2.xml`, `wf_TRS_Stage_Load_1_Ongoing.xml` (deactivation mappings), via `TRS_IDQ_Deactivation_Logic.md` §6.3–§6.6; `MAX(HUB_STATE_IND)` lookup re-verified directly in the Complete export |
| ECI/FSS/WIC/TTF Validation router conditions, H/P/D derivation, `Upd_Delete_Inactive`, downstream `IsNull(DEACTIVATION_STS)` filters | `/tmp/alldocs/wf_<SRC>_Stage_Load/mappings/m_Tgt_C_S_<SRC>_Pty_Validation.md` and the downstream `m_Tgt_C_S_<SRC>_Pty*.md` docs |
| Downstream `NOT EXISTS ... DEACTIVATION_STS IS NOT NULL` rendering; "Not performed: DD_DELETE" comments | `/tmp/allsrc/wf_<SRC>_Stage_Load/sp_snow_main_m_Tgt_C_S_<SRC>_Pty*.sql` and the same files in `~/workspace/snowflake_multisource/<SRC>/mappings/` |
| ECI reactivation history moves; Medicaid source-port filter defect; `V_ECI_ETL_LU_REACTIVATED_ID` references | `/tmp/alldocs/wf_ECI_Stage_Load/mappings/m_Tgt_Stg_ECI_Pty_Reactivation_D_*.md` and `/tmp/allsrc/wf_ECI_Stage_Load/sp_snow_main_m_Tgt_Stg_ECI_Pty_Reactivation_D_*.sql`; rewrite runner order in `~/workspace/snowflake_multisource/ECI/runners/` |
| FSS reactivation-to-status-table wiring | FSS Validation doc, `Write_STG_FSS_PTY_INACTIVE_STS` links (`DEACTIVATION_STS ← Exp_Log_Reactv.ACTION`) + Oracle drop-in summary in the same doc + FSS Snowflake original header |
| CRE maintenance union, `REC_TYPE` decode, end-dating arithmetic | `/tmp/alldocs/wf_CRE_Stage_Load_Ongoing/mappings/m_Tgt_C_S_CRE_CARE_Clients.md` + `/tmp/allsrc/wf_CRE_Stage_Load_Ongoing/sp_snow_main_m_Tgt_C_S_CRE_CARE_Clients.sql` |
| TRS rewrite: capture-only package, step-50 checkpoint, `MINUS` snapshot, `PROCESSED_YN` default note | `~/workspace/snowflake_multisource/TRS/mappings/sp_snow_main_m_Tgt_C_S_TRS_Pty_Deactivation_1.sql`, `..._Rel_DeActivation_1.sql`, `..._Pty_OnGoing.sql`, `TRS/runners/sp_etl_run_wf_TRS_Stage_Load_1_Ongoing.sql` |
| Absence claims (no TRS reactivation, no Validation-model hub action, no CRE status table) | Full-text searches over `/tmp/alldocs`, `/tmp/allsrc`, and the four TRS deactivation exports for `reactivat*`, `PTY_INACTIVE_STS` readers, and `inactive_sts` respectively — zero hits outside the places cited above |
